/*     */ import greenfoot.Actor;
/*     */ import greenfoot.Greenfoot;
/*     */ import greenfoot.GreenfootSound;
/*     */ import greenfoot.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Zombie
/*     */   extends Actor
/*     */ {
/*     */   protected int zombieSpeed;
/*     */   protected int zombieHealth;
/*  16 */   protected GreenfootSound comingZombie = new GreenfootSound("zombies_coming.wav");
/*  17 */   protected static boolean gameOver = false;
/*  18 */   protected static int zombieCount = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Zombie()
/*     */   {
/*  25 */     if (zombieCount == 0)
/*     */     {
/*  27 */       this.comingZombie.play();
/*     */     }
/*  29 */     zombieCount += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setSpeed(int speed)
/*     */   {
/*  39 */     if (isTouching(Plants.class))
/*     */     {
/*  41 */       this.zombieSpeed = 0;
/*     */     }
/*     */     else
/*     */     {
/*  45 */       this.zombieSpeed = speed;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setHealth(int health)
/*     */   {
/*  54 */     this.zombieHealth = health;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void zombieHit(int damage, String filename, int timeLoop, int points)
/*     */   {
/*  67 */     if (isTouching(Bullet.class))
/*     */     {
/*  69 */       this.zombieHealth -= damage;
/*  70 */       removeTouching(Bullet.class);
/*     */     }
/*     */     
/*  73 */     if (this.zombieHealth <= 0)
/*     */     {
/*  75 */       removeTouching(Bullet.class);
/*  76 */       dyingZombieAnimation(filename, timeLoop);
/*     */       
/*  78 */       Backyard world = (Backyard)getWorld();
/*  79 */       Counter score = world.getScoreCounter();
/*  80 */       score.add(points);
/*  81 */       world.removeObject(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void dyingZombieAnimation(String filename, int timeLoop)
/*     */   {
/*  90 */     DeadActor dead = new DeadActor(filename, timeLoop);
/*  91 */     World world = getWorld();
/*  92 */     world.addObject(dead, getX(), getY());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkGameOver()
/*     */   {
/* 100 */     Backyard world = (Backyard)getWorld();
/* 101 */     int column = world.returnGridColumnPosition(getX());
/* 102 */     if (getX() < 260)
/*     */     {
/* 104 */       setHealth(-1);
/* 105 */       Counter score = world.getScoreCounter();
/* 106 */       world.stopBackgroundMusic();
/* 107 */       gameOver = true;
/* 108 */       Greenfoot.setWorld(new GameOver(score.getValue()));
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\Zombie.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */