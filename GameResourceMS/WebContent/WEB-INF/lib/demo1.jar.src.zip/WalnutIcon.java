/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WalnutIcon
/*    */   extends Sidebar
/*    */ {
/*    */   public WalnutIcon(int positionX, int positionY)
/*    */   {
/* 19 */     setCostOfPlant(25);
/* 20 */     setIconCoordinates(positionX, positionY);
/* 21 */     setActiveImage("active_walnut.png");
/* 22 */     setInactiveImage("inactive_walnut.png");
/*    */   }
/*    */   
/*    */   public void act()
/*    */   {
/* 27 */     createPlant(new Walnut());
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\WalnutIcon.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */