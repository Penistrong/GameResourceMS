/*    */ import greenfoot.Actor;
/*    */ import greenfoot.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeadActor
/*    */   extends Actor
/*    */ {
/*    */   private GifImage gif;
/*    */   private int loopTime;
/*    */   
/*    */   public DeadActor(String filename, int timeforloop)
/*    */   {
/* 20 */     this.gif = new GifImage(filename);
/* 21 */     setImage(this.gif.getCurrentImage());
/* 22 */     this.loopTime = timeforloop;
/*    */   }
/*    */   
/* 25 */   private long lastAdded = System.currentTimeMillis();
/*    */   
/*    */ 
/*    */ 
/*    */   public void act()
/*    */   {
/* 31 */     long curTime = System.currentTimeMillis();
/* 32 */     setImage(this.gif.getCurrentImage());
/* 33 */     if (curTime >= this.lastAdded + this.loopTime)
/*    */     {
/* 35 */       this.lastAdded = curTime;
/* 36 */       getWorld().removeObject(this);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\DeadActor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */