/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Walnut
/*    */   extends Plants
/*    */ {
/* 14 */   private GifImage gifFullLife = new GifImage("walnut_full_life.gif");
/* 15 */   private GifImage gifHalfLife = new GifImage("walnut_half_life.gif");
/* 16 */   private GifImage gif = this.gifFullLife;
/* 17 */   private int halfLife = 5000;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Walnut()
/*    */   {
/* 24 */     setImage(this.gifFullLife.getCurrentImage());
/* 25 */     setTimeToLive(this.halfLife * 2);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void act()
/*    */   {
/* 33 */     plantHit("walnut_dead.gif", 1000);
/* 34 */     halfDead();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private void halfDead()
/*    */   {
/* 42 */     if (this.timeToLive < this.halfLife)
/*    */     {
/* 44 */       setImage(this.gifHalfLife.getCurrentImage());
/*    */     }
/*    */     else
/*    */     {
/* 48 */       setImage(this.gifFullLife.getCurrentImage());
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\Walnut.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */