/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Pea
/*    */   extends Bullet
/*    */ {
/*    */   public void act()
/*    */   {
/* 19 */     move(this.speed);
/* 20 */     checkBoundaries();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\Pea.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */