/*     */ import greenfoot.Actor;
/*     */ import greenfoot.GreenfootImage;
/*     */ import java.awt.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Counter
/*     */   extends Actor
/*     */ {
/*  36 */   private static final Color transparent = new Color(0, 0, 0, 0);
/*     */   private GreenfootImage background;
/*     */   private int value;
/*     */   private int target;
/*     */   private String prefix;
/*     */   
/*     */   public Counter()
/*     */   {
/*  44 */     this(new String());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Counter(String prefix)
/*     */   {
/*  53 */     this.background = getImage();
/*  54 */     this.value = 0;
/*  55 */     this.target = 0;
/*  56 */     this.prefix = prefix;
/*  57 */     updateImage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void act()
/*     */   {
/*  66 */     if (this.value < this.target) {
/*  67 */       this.value += 1;
/*  68 */       updateImage();
/*     */     }
/*  70 */     else if (this.value > this.target) {
/*  71 */       this.value -= 1;
/*  72 */       updateImage();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(int score)
/*     */   {
/*  83 */     this.target += score;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getValue()
/*     */   {
/*  91 */     return this.target;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(int newValue)
/*     */   {
/*  99 */     this.target = newValue;
/* 100 */     this.value = newValue;
/* 101 */     updateImage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrefix(String prefix)
/*     */   {
/* 110 */     this.prefix = prefix;
/* 111 */     updateImage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void updateImage()
/*     */   {
/* 119 */     GreenfootImage image = new GreenfootImage(this.background);
/* 120 */     GreenfootImage text = new GreenfootImage(this.prefix + this.value, 22, Color.BLACK, transparent);
/*     */     
/* 122 */     if (text.getWidth() > image.getWidth() - 20)
/*     */     {
/* 124 */       image.scale(text.getWidth() + 20, image.getHeight());
/*     */     }
/*     */     
/* 127 */     image.drawImage(text, (image.getWidth() - text.getWidth()) / 2, 
/* 128 */       (image.getHeight() - text.getHeight()) / 2);
/* 129 */     setImage(image);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\Counter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */