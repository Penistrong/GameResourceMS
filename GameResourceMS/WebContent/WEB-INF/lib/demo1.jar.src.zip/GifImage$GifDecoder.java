/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.DataBufferInt;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GifImage$GifDecoder
/*     */ {
/*     */   public static final int STATUS_OK = 0;
/*     */   public static final int STATUS_FORMAT_ERROR = 1;
/*     */   public static final int STATUS_OPEN_ERROR = 2;
/*     */   private BufferedInputStream in;
/*     */   private int status;
/*     */   private int width;
/*     */   private int height;
/*     */   private boolean gctFlag;
/*     */   private int gctSize;
/*     */   private int loopCount;
/*     */   private int[] gct;
/*     */   private int[] lct;
/*     */   private int[] act;
/*     */   private int bgIndex;
/*     */   private int bgColor;
/*     */   private int lastBgColor;
/*     */   private int pixelAspect;
/*     */   private boolean lctFlag;
/*     */   private boolean interlace;
/*     */   private int lctSize;
/*     */   private int ix;
/*     */   private int iy;
/*     */   private int iw;
/*     */   private int ih;
/*     */   private Rectangle lastRect;
/*     */   private BufferedImage image;
/*     */   private BufferedImage lastImage;
/*     */   private byte[] block;
/*     */   private int blockSize;
/*     */   private int dispose;
/*     */   private int lastDispose;
/*     */   private boolean transparency;
/*     */   private int delay;
/*     */   private int transIndex;
/*     */   private static final int MaxStackSize = 4096;
/*     */   private short[] prefix;
/*     */   private byte[] suffix;
/*     */   private byte[] pixelStack;
/*     */   private byte[] pixels;
/*     */   private ArrayList<GifImage.GifDecoder.GifFrame> frames;
/*     */   private int frameCount;
/*     */   
/*     */   private GifImage$GifDecoder(GifImage paramGifImage)
/*     */   {
/* 217 */     this.loopCount = 1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 247 */     this.block = new byte['Ā'];
/*     */     
/* 249 */     this.blockSize = 0;
/*     */     
/*     */ 
/* 252 */     this.dispose = 0;
/*     */     
/*     */ 
/* 255 */     this.lastDispose = 0;
/*     */     
/* 257 */     this.transparency = false;
/*     */     
/* 259 */     this.delay = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class GifFrame
/*     */   {
/*     */     private BufferedImage image;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private int delay;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public GifFrame(BufferedImage im, int del)
/*     */     {
/* 285 */       this.image = im;
/* 286 */       this.delay = del;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDelay(int n)
/*     */   {
/* 303 */     this.delay = -1;
/* 304 */     if ((n >= 0) && (n < this.frameCount)) {
/* 305 */       this.delay = ((GifImage.GifDecoder.GifFrame)this.frames.get(n)).delay;
/*     */     }
/* 307 */     return this.delay;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFrameCount()
/*     */   {
/* 316 */     return this.frameCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BufferedImage getImage()
/*     */   {
/* 325 */     return getFrame(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLoopCount()
/*     */   {
/* 335 */     return this.loopCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setPixels()
/*     */   {
/* 344 */     int[] dest = ((DataBufferInt)this.image.getRaster().getDataBuffer()).getData();
/*     */     
/*     */ 
/* 347 */     if (this.lastDispose > 0) {
/* 348 */       if (this.lastDispose == 3)
/*     */       {
/* 350 */         int n = this.frameCount - 2;
/* 351 */         if (n > 0) {
/* 352 */           this.lastImage = getFrame(n - 1);
/*     */         } else {
/* 354 */           this.lastImage = null;
/*     */         }
/*     */       }
/*     */       
/* 358 */       if (this.lastImage != null) {
/* 359 */         int[] prev = ((DataBufferInt)this.lastImage.getRaster().getDataBuffer()).getData();
/* 360 */         System.arraycopy(prev, 0, dest, 0, this.width * this.height);
/*     */         
/*     */ 
/* 363 */         if (this.lastDispose == 2)
/*     */         {
/* 365 */           Graphics2D g = this.image.createGraphics();
/* 366 */           Color c = null;
/* 367 */           if (this.transparency) {
/* 368 */             c = new Color(0, 0, 0, 0);
/*     */           } else {
/* 370 */             c = new Color(this.lastBgColor);
/*     */           }
/* 372 */           g.setColor(c);
/* 373 */           g.setComposite(AlphaComposite.Src);
/* 374 */           g.fill(this.lastRect);
/* 375 */           g.dispose();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 381 */     int pass = 1;
/* 382 */     int inc = 8;
/* 383 */     int iline = 0;
/* 384 */     for (int i = 0; i < this.ih; i++) {
/* 385 */       int line = i;
/* 386 */       if (this.interlace) {
/* 387 */         if (iline >= this.ih) {
/* 388 */           pass++;
/* 389 */           switch (pass) {
/*     */           case 2: 
/* 391 */             iline = 4;
/* 392 */             break;
/*     */           case 3: 
/* 394 */             iline = 2;
/* 395 */             inc = 4;
/* 396 */             break;
/*     */           case 4: 
/* 398 */             iline = 1;
/* 399 */             inc = 2;
/*     */           }
/*     */         }
/* 402 */         line = iline;
/* 403 */         iline += inc;
/*     */       }
/* 405 */       line += this.iy;
/* 406 */       if (line < this.height) {
/* 407 */         int k = line * this.width;
/* 408 */         int dx = k + this.ix;
/* 409 */         int dlim = dx + this.iw;
/* 410 */         if (k + this.width < dlim) {
/* 411 */           dlim = k + this.width;
/*     */         }
/* 413 */         int sx = i * this.iw;
/* 414 */         while (dx < dlim)
/*     */         {
/* 416 */           int index = this.pixels[(sx++)] & 0xFF;
/* 417 */           int c = this.act[index];
/* 418 */           if (c != 0) {
/* 419 */             dest[dx] = c;
/*     */           }
/* 421 */           dx++;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BufferedImage getFrame(int n)
/*     */   {
/* 433 */     BufferedImage im = null;
/* 434 */     if ((n >= 0) && (n < this.frameCount)) {
/* 435 */       im = ((GifImage.GifDecoder.GifFrame)this.frames.get(n)).image;
/*     */     }
/* 437 */     return im;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Dimension getFrameSize()
/*     */   {
/* 446 */     return new Dimension(this.width, this.height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(BufferedInputStream is)
/*     */   {
/* 457 */     init();
/* 458 */     if (is != null) {
/* 459 */       this.in = is;
/* 460 */       readHeader();
/* 461 */       if (!err()) {
/* 462 */         readContents();
/* 463 */         if (this.frameCount < 0) {
/* 464 */           this.status = 1;
/*     */         }
/*     */       }
/*     */     } else {
/* 468 */       this.status = 2;
/*     */     }
/*     */     try {
/* 471 */       is.close();
/*     */     }
/*     */     catch (IOException localIOException) {}
/* 474 */     return this.status;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(InputStream is)
/*     */   {
/* 485 */     init();
/* 486 */     if (is != null) {
/* 487 */       if (!(is instanceof BufferedInputStream))
/* 488 */         is = new BufferedInputStream(is);
/* 489 */       this.in = ((BufferedInputStream)is);
/* 490 */       readHeader();
/* 491 */       if (!err()) {
/* 492 */         readContents();
/* 493 */         if (this.frameCount < 0) {
/* 494 */           this.status = 1;
/*     */         }
/*     */       }
/*     */     } else {
/* 498 */       this.status = 2;
/*     */     }
/*     */     try {
/* 501 */       is.close();
/*     */     }
/*     */     catch (IOException localIOException) {}
/* 504 */     return this.status;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(String name)
/*     */   {
/* 516 */     this.status = 0;
/*     */     try {
/* 518 */       URL url = getClass().getClassLoader().getResource(name);
/* 519 */       if (url == null) {
/* 520 */         name = "images/" + name;
/* 521 */         url = getClass().getClassLoader().getResource(name);
/* 522 */         if (url == null) {
/* 523 */           throw new RuntimeException("The gif file \"" + name + "\" doesn't exist.");
/*     */         }
/*     */       }
/* 526 */       this.in = new BufferedInputStream(url.openStream());
/* 527 */       this.status = read(this.in);
/*     */     } catch (IOException e) {
/* 529 */       this.status = 2;
/*     */     }
/*     */     
/* 532 */     return this.status;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void decodeImageData()
/*     */   {
/* 540 */     int NullCode = -1;
/* 541 */     int npix = this.iw * this.ih;
/*     */     
/*     */ 
/* 544 */     if ((this.pixels == null) || (this.pixels.length < npix)) {
/* 545 */       this.pixels = new byte[npix];
/*     */     }
/* 547 */     if (this.prefix == null)
/* 548 */       this.prefix = new short['က'];
/* 549 */     if (this.suffix == null)
/* 550 */       this.suffix = new byte['က'];
/* 551 */     if (this.pixelStack == null) {
/* 552 */       this.pixelStack = new byte['ခ'];
/*     */     }
/*     */     
/*     */ 
/* 556 */     int data_size = read();
/* 557 */     int clear = 1 << data_size;
/* 558 */     int end_of_information = clear + 1;
/* 559 */     int available = clear + 2;
/* 560 */     int old_code = NullCode;
/* 561 */     int code_size = data_size + 1;
/* 562 */     int code_mask = (1 << code_size) - 1;
/* 563 */     for (int code = 0; code < clear; code++) {
/* 564 */       this.prefix[code] = 0;
/* 565 */       this.suffix[code] = ((byte)code); }
/*     */     int bi;
/*     */     int pi;
/*     */     int top;
/*     */     int first;
/* 570 */     int count; int bits; int datum = bits = count = first = top = pi = bi = 0;
/*     */     
/* 572 */     for (int i = 0; i < npix;) {
/* 573 */       if (top == 0) {
/* 574 */         if (bits < code_size)
/*     */         {
/* 576 */           if (count == 0)
/*     */           {
/* 578 */             count = readBlock();
/* 579 */             if (count <= 0)
/*     */               break;
/* 581 */             bi = 0;
/*     */           }
/* 583 */           datum += ((this.block[bi] & 0xFF) << bits);
/* 584 */           bits += 8;
/* 585 */           bi++;
/* 586 */           count--;
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/* 592 */           code = datum & code_mask;
/* 593 */           datum >>= code_size;
/* 594 */           bits -= code_size;
/*     */           
/*     */ 
/*     */ 
/* 598 */           if ((code > available) || (code == end_of_information))
/*     */             break;
/* 600 */           if (code == clear)
/*     */           {
/* 602 */             code_size = data_size + 1;
/* 603 */             code_mask = (1 << code_size) - 1;
/* 604 */             available = clear + 2;
/* 605 */             old_code = NullCode;
/*     */ 
/*     */           }
/* 608 */           else if (old_code == NullCode) {
/* 609 */             this.pixelStack[(top++)] = this.suffix[code];
/* 610 */             old_code = code;
/* 611 */             first = code;
/*     */           }
/*     */           else {
/* 614 */             int in_code = code;
/* 615 */             if (code == available) {
/* 616 */               this.pixelStack[(top++)] = ((byte)first);
/* 617 */               code = old_code;
/*     */             }
/* 619 */             while (code > clear) {
/* 620 */               this.pixelStack[(top++)] = this.suffix[code];
/* 621 */               code = this.prefix[code];
/*     */             }
/* 623 */             first = this.suffix[code] & 0xFF;
/*     */             
/*     */ 
/*     */ 
/* 627 */             if (available >= 4096)
/*     */               break;
/* 629 */             this.pixelStack[(top++)] = ((byte)first);
/* 630 */             this.prefix[available] = ((short)old_code);
/* 631 */             this.suffix[available] = ((byte)first);
/* 632 */             available++;
/* 633 */             if (((available & code_mask) == 0) && (available < 4096)) {
/* 634 */               code_size++;
/* 635 */               code_mask += available;
/*     */             }
/* 637 */             old_code = in_code;
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 642 */         top--;
/* 643 */         this.pixels[(pi++)] = this.pixelStack[top];
/* 644 */         i++;
/*     */       }
/*     */     }
/* 647 */     for (i = pi; i < npix; i++) {
/* 648 */       this.pixels[i] = 0;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean err()
/*     */   {
/* 657 */     return this.status != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void init()
/*     */   {
/* 664 */     this.status = 0;
/* 665 */     this.frameCount = 0;
/* 666 */     this.frames = new ArrayList();
/* 667 */     this.gct = null;
/* 668 */     this.lct = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int read()
/*     */   {
/* 675 */     int curByte = 0;
/*     */     try {
/* 677 */       curByte = this.in.read();
/*     */     } catch (IOException e) {
/* 679 */       this.status = 1;
/*     */     }
/* 681 */     return curByte;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int readBlock()
/*     */   {
/* 690 */     this.blockSize = read();
/* 691 */     int n = 0;
/* 692 */     if (this.blockSize > 0) {
/*     */       try {
/* 694 */         int count = 0;
/* 695 */         while (n < this.blockSize) {
/* 696 */           count = this.in.read(this.block, n, this.blockSize - n);
/* 697 */           if (count == -1)
/*     */             break;
/* 699 */           n += count;
/*     */         }
/*     */       }
/*     */       catch (IOException localIOException) {}
/*     */       
/* 704 */       if (n < this.blockSize) {
/* 705 */         this.status = 1;
/*     */       }
/*     */     }
/* 708 */     return n;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int[] readColorTable(int ncolors)
/*     */   {
/* 719 */     int nbytes = 3 * ncolors;
/* 720 */     int[] tab = null;
/* 721 */     byte[] c = new byte[nbytes];
/* 722 */     int n = 0;
/*     */     try {
/* 724 */       n = this.in.read(c);
/*     */     }
/*     */     catch (IOException localIOException) {}
/* 727 */     if (n < nbytes) {
/* 728 */       this.status = 1;
/*     */     } else {
/* 730 */       tab = new int['Ā'];
/* 731 */       int i = 0;
/* 732 */       int j = 0;
/* 733 */       while (i < ncolors) {
/* 734 */         int r = c[(j++)] & 0xFF;
/* 735 */         int g = c[(j++)] & 0xFF;
/* 736 */         int b = c[(j++)] & 0xFF;
/* 737 */         tab[(i++)] = (0xFF000000 | r << 16 | g << 8 | b);
/*     */       }
/*     */     }
/* 740 */     return tab;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void readContents()
/*     */   {
/* 748 */     boolean done = false;
/* 749 */     while ((!done) && (!err())) {
/* 750 */       int code = read();
/* 751 */       switch (code)
/*     */       {
/*     */       case 44: 
/* 754 */         readImage();
/* 755 */         break;
/*     */       
/*     */       case 33: 
/* 758 */         code = read();
/* 759 */         switch (code) {
/*     */         case 249: 
/* 761 */           readGraphicControlExt();
/* 762 */           break;
/*     */         
/*     */         case 255: 
/* 765 */           readBlock();
/* 766 */           String app = "";
/* 767 */           for (int i = 0; i < 11; i++) {
/* 768 */             app = app + (char)this.block[i];
/*     */           }
/* 770 */           if (app.equals("NETSCAPE2.0")) {
/* 771 */             readNetscapeExt();
/*     */           } else
/* 773 */             skip();
/* 774 */           break;
/*     */         
/*     */         default: 
/* 777 */           skip();
/*     */         }
/* 779 */         break;
/*     */       
/*     */       case 59: 
/* 782 */         done = true;
/* 783 */         break;
/*     */       
/*     */       case 0: 
/*     */         break;
/*     */       
/*     */       default: 
/* 789 */         this.status = 1;
/*     */       }
/*     */       
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void readGraphicControlExt()
/*     */   {
/* 798 */     read();
/* 799 */     int packed = read();
/* 800 */     this.dispose = ((packed & 0x1C) >> 2);
/* 801 */     if (this.dispose == 0) {
/* 802 */       this.dispose = 1;
/*     */     }
/* 804 */     this.transparency = ((packed & 0x1) != 0);
/* 805 */     this.delay = (readShort() * 10);
/* 806 */     this.transIndex = read();
/* 807 */     read();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void readHeader()
/*     */   {
/* 814 */     String id = "";
/* 815 */     for (int i = 0; i < 6; i++) {
/* 816 */       id = id + (char)read();
/*     */     }
/* 818 */     if (!id.startsWith("GIF")) {
/* 819 */       this.status = 1;
/* 820 */       return;
/*     */     }
/*     */     
/* 823 */     readLSD();
/* 824 */     if ((this.gctFlag) && (!err())) {
/* 825 */       this.gct = readColorTable(this.gctSize);
/* 826 */       this.bgColor = this.gct[this.bgIndex];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void readImage()
/*     */   {
/* 834 */     this.ix = readShort();
/* 835 */     this.iy = readShort();
/* 836 */     this.iw = readShort();
/* 837 */     this.ih = readShort();
/*     */     
/* 839 */     int packed = read();
/* 840 */     this.lctFlag = ((packed & 0x80) != 0);
/* 841 */     this.interlace = ((packed & 0x40) != 0);
/*     */     
/*     */ 
/* 844 */     this.lctSize = (2 << (packed & 0x7));
/*     */     
/* 846 */     if (this.lctFlag) {
/* 847 */       this.lct = readColorTable(this.lctSize);
/* 848 */       this.act = this.lct;
/*     */     } else {
/* 850 */       this.act = this.gct;
/* 851 */       if (this.bgIndex == this.transIndex)
/* 852 */         this.bgColor = 0;
/*     */     }
/* 854 */     int save = 0;
/* 855 */     if (this.transparency) {
/* 856 */       save = this.act[this.transIndex];
/* 857 */       this.act[this.transIndex] = 0;
/*     */     }
/*     */     
/* 860 */     if (this.act == null) {
/* 861 */       this.status = 1;
/*     */     }
/*     */     
/* 864 */     if (err()) {
/* 865 */       return;
/*     */     }
/* 867 */     decodeImageData();
/* 868 */     skip();
/*     */     
/* 870 */     if (err()) {
/* 871 */       return;
/*     */     }
/* 873 */     this.frameCount += 1;
/*     */     
/*     */ 
/* 876 */     this.image = new BufferedImage(this.width, this.height, 3);
/*     */     
/* 878 */     setPixels();
/*     */     
/* 880 */     this.frames.add(new GifImage.GifDecoder.GifFrame(this.image, this.delay));
/*     */     
/* 882 */     if (this.transparency) {
/* 883 */       this.act[this.transIndex] = save;
/*     */     }
/* 885 */     resetFrame();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void readLSD()
/*     */   {
/* 895 */     this.width = readShort();
/* 896 */     this.height = readShort();
/*     */     
/*     */ 
/* 899 */     int packed = read();
/* 900 */     this.gctFlag = ((packed & 0x80) != 0);
/*     */     
/*     */ 
/* 903 */     this.gctSize = (2 << (packed & 0x7));
/*     */     
/* 905 */     this.bgIndex = read();
/* 906 */     this.pixelAspect = read();
/*     */   }
/*     */   
/*     */ 
/*     */   protected void readNetscapeExt()
/*     */   {
/*     */     do
/*     */     {
/* 914 */       readBlock();
/* 915 */       if (this.block[0] == 1)
/*     */       {
/* 917 */         int b1 = this.block[1] & 0xFF;
/* 918 */         int b2 = this.block[2] & 0xFF;
/* 919 */         this.loopCount = (b2 << 8 | b1);
/*     */       }
/* 921 */     } while ((this.blockSize > 0) && (!err()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int readShort()
/*     */   {
/* 929 */     return read() | read() << 8;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void resetFrame()
/*     */   {
/* 936 */     this.lastDispose = this.dispose;
/* 937 */     this.lastRect = new Rectangle(this.ix, this.iy, this.iw, this.ih);
/* 938 */     this.lastImage = this.image;
/* 939 */     this.lastBgColor = this.bgColor;
/* 940 */     int dispose = 0;
/* 941 */     boolean transparency = false;
/* 942 */     int delay = 0;
/* 943 */     this.lct = null;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void skip()
/*     */   {
/*     */     do
/*     */     {
/* 951 */       readBlock();
/* 952 */     } while ((this.blockSize > 0) && (!err()));
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\GifImage$GifDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */