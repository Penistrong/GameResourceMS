/*    */ import greenfoot.Actor;
/*    */ import greenfoot.Greenfoot;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClickToStart
/*    */   extends Actor
/*    */ {
/* 13 */   private GifImage gif = new GifImage("click_to_start.gif");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void act()
/*    */   {
/* 20 */     setImage(this.gif.getCurrentImage());
/*    */     
/* 22 */     if (Greenfoot.mouseClicked(this))
/*    */     {
/* 24 */       Greenfoot.setWorld(new Backyard());
/* 25 */       StartScreen world = (StartScreen)getWorld();
/* 26 */       world.stopBackgroundMusic();
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\ClickToStart.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */