/*     */ import greenfoot.Actor;
/*     */ import greenfoot.Greenfoot;
/*     */ import greenfoot.GreenfootImage;
/*     */ import greenfoot.MouseInfo;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Sidebar
/*     */   extends Actor
/*     */ {
/*     */   protected int costOfPlant;
/*     */   protected boolean isGrabbed;
/*  15 */   protected boolean isActive = false;
/*     */   
/*     */   protected int iconX;
/*     */   protected int iconY;
/*     */   protected GreenfootImage activeImage;
/*     */   protected GreenfootImage inactiveImage;
/*     */   
/*     */   protected void setCostOfPlant(int cost)
/*     */   {
/*  24 */     this.costOfPlant = cost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setIconCoordinates(int x, int y)
/*     */   {
/*  32 */     this.iconX = x;
/*  33 */     this.iconY = y;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void createPlant(Plants plant)
/*     */   {
/*  41 */     Backyard world = (Backyard)getWorld();
/*  42 */     Counter sunCounter = world.getSunCounter();
/*  43 */     if (this.costOfPlant <= sunCounter.getValue())
/*     */     {
/*  45 */       setImage(this.activeImage);
/*  46 */       createPlantDragAndDrop(plant, world, sunCounter);
/*     */     }
/*     */     else
/*     */     {
/*  50 */       setImage(this.inactiveImage);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void createPlantDragAndDrop(Plants plant, Backyard world, Counter sunCounter)
/*     */   {
/*  61 */     if ((Greenfoot.mousePressed(this)) && (!this.isGrabbed))
/*     */     {
/*     */ 
/*  64 */       this.isGrabbed = true;
/*     */       
/*     */ 
/*  67 */       MouseInfo mi = Greenfoot.getMouseInfo();
/*  68 */       world.removeObject(this);
/*  69 */       world.addObject(this, mi.getX(), mi.getY());
/*  70 */       return;
/*     */     }
/*     */     
/*  73 */     if ((Greenfoot.mouseDragged(this)) && (this.isGrabbed))
/*     */     {
/*     */ 
/*  76 */       MouseInfo mi = Greenfoot.getMouseInfo();
/*  77 */       setLocation(mi.getX(), mi.getY());
/*  78 */       return;
/*     */     }
/*     */     
/*  81 */     if ((Greenfoot.mouseDragEnded(this)) && (this.isGrabbed))
/*     */     {
/*     */ 
/*     */ 
/*  85 */       MouseInfo mi = Greenfoot.getMouseInfo();
/*  86 */       setLocation(this.iconX, this.iconY);
/*  87 */       int plantRow = world.returnGridRowPosition(mi.getY());
/*  88 */       int plantColumn = world.returnGridColumnPosition(mi.getX());
/*  89 */       if ((plantRow != -1) && (plantColumn != -1))
/*     */       {
/*  91 */         if (world.getObjectsAt(plantColumn, plantRow, Actor.class).isEmpty())
/*     */         {
/*  93 */           world.addObject(plant, plantColumn, plantRow);
/*  94 */           sunCounter.add(-this.costOfPlant);
/*     */         }
/*     */       }
/*     */       
/*  98 */       this.isGrabbed = false;
/*  99 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setActiveImage(String activeImageLink)
/*     */   {
/* 108 */     this.activeImage = new GreenfootImage(activeImageLink);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setInactiveImage(String inactiveImageLink)
/*     */   {
/* 116 */     this.inactiveImage = new GreenfootImage(inactiveImageLink);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\Sidebar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */