/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SunFlowerIcon
/*    */   extends Sidebar
/*    */ {
/*    */   public SunFlowerIcon(int positionX, int positionY)
/*    */   {
/* 18 */     setCostOfPlant(50);
/* 19 */     setIconCoordinates(positionX, positionY);
/* 20 */     setActiveImage("active_sunflower.png");
/* 21 */     setInactiveImage("inactive_sunflower.png");
/*    */   }
/*    */   
/*    */   public void act()
/*    */   {
/* 26 */     createPlant(new Sunflower());
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\SunFlowerIcon.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */