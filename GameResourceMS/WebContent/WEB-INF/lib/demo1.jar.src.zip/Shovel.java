/*    */ import greenfoot.Actor;
/*    */ import greenfoot.Greenfoot;
/*    */ import greenfoot.MouseInfo;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Shovel
/*    */   extends Actor
/*    */ {
/*    */   protected boolean isGrabbed;
/*    */   protected int iconX;
/*    */   protected int iconY;
/*    */   
/*    */   public Shovel(int posX, int posY)
/*    */   {
/* 21 */     this.iconX = posX;
/* 22 */     this.iconY = posY;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void act()
/*    */   {
/* 30 */     removePlant();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private void removePlant()
/*    */   {
/* 39 */     Backyard world = (Backyard)getWorld();
/*    */     
/*    */ 
/* 42 */     if ((Greenfoot.mousePressed(this)) && (!this.isGrabbed))
/*    */     {
/*    */ 
/* 45 */       this.isGrabbed = true;
/*    */       
/*    */ 
/* 48 */       MouseInfo mi = Greenfoot.getMouseInfo();
/* 49 */       world.removeObject(this);
/* 50 */       world.addObject(this, mi.getX(), mi.getY());
/* 51 */       return;
/*    */     }
/*    */     
/* 54 */     if ((Greenfoot.mouseDragged(this)) && (this.isGrabbed))
/*    */     {
/*    */ 
/* 57 */       MouseInfo mi = Greenfoot.getMouseInfo();
/* 58 */       setLocation(mi.getX(), mi.getY());
/* 59 */       return;
/*    */     }
/*    */     
/* 62 */     if ((Greenfoot.mouseDragEnded(this)) && (this.isGrabbed))
/*    */     {
/*    */ 
/*    */ 
/* 66 */       MouseInfo mi = Greenfoot.getMouseInfo();
/*    */       
/* 68 */       int plantRow = mi.getY();
/* 69 */       int plantColumn = mi.getX();
/* 70 */       if (!world.getObjectsAt(plantColumn, plantRow, Actor.class).isEmpty())
/*    */       {
/* 72 */         removeTouching(Plants.class);
/*    */       }
/*    */       
/* 75 */       setLocation(this.iconX, this.iconY);
/* 76 */       this.isGrabbed = false;
/* 77 */       return;
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\Shovel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */