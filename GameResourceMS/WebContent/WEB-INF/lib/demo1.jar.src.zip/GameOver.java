/*    */ import greenfoot.GreenfootSound;
/*    */ import greenfoot.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GameOver
/*    */   extends World
/*    */ {
/* 13 */   private GreenfootSound backgroundMusic = new GreenfootSound("atebrains.wav");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public GameOver(int score)
/*    */   {
/* 21 */     super(1111, 602, 1);
/* 22 */     this.backgroundMusic.play();
/* 23 */     Counter counter = new Counter();
/* 24 */     addObject(counter, 613, 553);
/* 25 */     counter.setValue(score);
/* 26 */     Replay replay = new Replay();
/* 27 */     addObject(replay, 1042, 577);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void stopBackgroundMusic()
/*    */   {
/* 35 */     this.backgroundMusic.stop();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\GameOver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */