/*    */ import greenfoot.Actor;
/*    */ import greenfoot.GreenfootSound;
/*    */ import greenfoot.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZombiesAreComing
/*    */   extends Actor
/*    */ {
/* 12 */   private GreenfootSound comingZombie = new GreenfootSound("zombies_coming.wav");
/*    */   private long lastAdded;
/*    */   
/*    */   public ZombiesAreComing()
/*    */   {
/* 17 */     this.comingZombie.play();
/* 18 */     this.lastAdded = System.currentTimeMillis();
/*    */   }
/*    */   
/*    */   public void act()
/*    */   {
/* 23 */     long curTime = System.currentTimeMillis();
/* 24 */     if (curTime >= this.lastAdded + 1500L) {
/* 25 */       getWorld().removeObject(this);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\ZombiesAreComing.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */