/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PeaShootIcon
/*    */   extends Sidebar
/*    */ {
/*    */   public PeaShootIcon(int positionX, int positionY)
/*    */   {
/* 18 */     setCostOfPlant(100);
/* 19 */     setIconCoordinates(positionX, positionY);
/* 20 */     setActiveImage("active_peashooter.png");
/* 21 */     setInactiveImage("inactive_peashooter.png");
/*    */   }
/*    */   
/*    */   public void act()
/*    */   {
/* 26 */     createPlant(new PeaShooter());
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\PeaShootIcon.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */