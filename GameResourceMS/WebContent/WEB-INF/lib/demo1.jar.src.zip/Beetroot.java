/*    */ import greenfoot.World;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Beetroot
/*    */   extends Plants
/*    */ {
/* 13 */   private GifImage gif = new GifImage("beetroot.gif");
/*    */   
/*    */ 
/*    */ 
/*    */   public Beetroot()
/*    */   {
/* 19 */     setImage(this.gif.getCurrentImage());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void act()
/*    */   {
/* 27 */     setImage(this.gif.getCurrentImage());
/* 28 */     shootBeet(2000);
/* 29 */     plantHit("beetroot_dying.gif", 1000);
/*    */   }
/*    */   
/* 32 */   private long lastAdded = System.currentTimeMillis();
/*    */   
/*    */ 
/*    */ 
/*    */   private void shootBeet(int timeInterval)
/*    */   {
/* 38 */     if (!getWorld().getObjects(Zombie.class).isEmpty())
/*    */     {
/* 40 */       long curTime = System.currentTimeMillis();
/* 41 */       if (curTime >= this.lastAdded + timeInterval)
/*    */       {
/* 43 */         this.lastAdded = curTime;
/* 44 */         Beet beet = new Beet();
/* 45 */         World world = getWorld();
/* 46 */         world.addObject(beet, getX() + 29, getY() + 20);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\Beetroot.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */