/*    */ import greenfoot.World;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PeaShooter
/*    */   extends Plants
/*    */ {
/* 13 */   private GifImage gif = new GifImage("pea_shooter.gif");
/*    */   
/*    */ 
/*    */ 
/*    */   public PeaShooter()
/*    */   {
/* 19 */     setImage(this.gif.getCurrentImage());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void act()
/*    */   {
/* 27 */     setImage(this.gif.getCurrentImage());
/* 28 */     shootPeas(2000);
/* 29 */     plantHit("pea_shooter_dying.gif", 900);
/*    */   }
/*    */   
/* 32 */   private long lastAdded = System.currentTimeMillis();
/*    */   
/*    */ 
/*    */ 
/*    */   private void shootPeas(int timeInterval)
/*    */   {
/* 38 */     if (!getWorld().getObjects(Zombie.class).isEmpty())
/*    */     {
/* 40 */       long curTime = System.currentTimeMillis();
/* 41 */       if (curTime >= this.lastAdded + timeInterval)
/*    */       {
/* 43 */         this.lastAdded = curTime;
/* 44 */         Pea pea = new Pea();
/* 45 */         World world = getWorld();
/* 46 */         world.addObject(pea, getX() + 28, getY() - 11);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\PeaShooter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */