/*    */ import greenfoot.Actor;
/*    */ import greenfoot.Greenfoot;
/*    */ import greenfoot.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Sun
/*    */   extends Actor
/*    */ {
/* 14 */   private GifImage gif = new GifImage("sun.gif");
/* 15 */   private boolean sunFall = false;
/* 16 */   private int sunSpeed = 2;
/*    */   
/*    */ 
/*    */ 
/*    */   public Sun()
/*    */   {
/* 22 */     setImage(this.gif.getCurrentImage());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void act()
/*    */   {
/* 30 */     setImage(this.gif.getCurrentImage());
/*    */     
/* 32 */     if (this.sunFall == true)
/*    */     {
/* 34 */       sunDrop();
/*    */     }
/*    */     
/* 37 */     if (Greenfoot.mouseClicked(this))
/*    */     {
/* 39 */       Backyard world = (Backyard)getWorld();
/* 40 */       Counter sunCounter = world.getSunCounter();
/* 41 */       sunCounter.add(25);
/* 42 */       world.removeObject(this);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private void sunDrop()
/*    */   {
/* 51 */     move(this.sunSpeed);
/* 52 */     if (getY() >= getWorld().getHeight() - 30) {
/* 53 */       this.sunSpeed = 0;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void letTheSunFall()
/*    */   {
/* 61 */     this.sunFall = true;
/* 62 */     turn(90);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\Sun.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */