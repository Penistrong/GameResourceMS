/*      */ package bluej;
/*      */ 
/*      */ import bluej.utility.Debug;
/*      */ import bluej.utility.Utility;
/*      */ import java.awt.Color;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Image;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Toolkit;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.PrintStream;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URI;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.MissingResourceException;
/*      */ import java.util.Properties;
/*      */ import java.util.Scanner;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.KeyStroke;
/*      */ import javax.swing.UIManager;
/*      */ import javax.swing.UIManager.LookAndFeelInfo;
/*      */ import javax.swing.UnsupportedLookAndFeelException;
/*      */ import javax.swing.border.BevelBorder;
/*      */ import javax.swing.border.Border;
/*      */ import javax.swing.border.CompoundBorder;
/*      */ import javax.swing.border.EmptyBorder;
/*      */ import javax.swing.border.LineBorder;
/*      */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Config
/*      */ {
/*   89 */   public static final String nl = System.getProperty("line.separator");
/*      */   
/*      */   public static Properties moeSystemProps;
/*      */   
/*      */   public static Properties moeUserProps;
/*   94 */   public static String compilertype = "javac";
/*      */   
/*      */   public static String language;
/*      */   
/*      */   public static Rectangle screenBounds;
/*   99 */   public static final String osname = System.getProperty("os.name", "");
/*      */   public static final String DEFAULT_LANGUAGE = "english";
/*      */   public static final String BLUEJ_OPENPACKAGE = "bluej.openPackage";
/*      */   public static final String bluejDebugLogName = "bluej-debuglog.txt";
/*      */   public static final String greenfootDebugLogName = "greenfoot-debuglog.txt";
/*  104 */   public static String debugLogName = "bluej-debuglog.txt";
/*      */   
/*  106 */   private static Boolean isRaspberryPi = null;
/*      */   
/*  108 */   public static final Color ENV_COLOUR = new Color(152, 32, 32);
/*      */   
/*      */ 
/*      */ 
/*  112 */   public static final Border focusBorder = new CompoundBorder(new LineBorder(Color.BLACK), new BevelBorder(1, new Color(195, 195, 195), new Color(240, 240, 240), new Color(195, 195, 195), new Color(124, 124, 124)));
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  120 */   public static final Border normalBorder = new CompoundBorder(new EmptyBorder(1, 1, 1, 1), new BevelBorder(1, new Color(195, 195, 195), new Color(240, 240, 240), new Color(124, 124, 124), new Color(195, 195, 195)));
/*      */   
/*      */ 
/*      */   private static Properties systemProps;
/*      */   
/*      */ 
/*      */   private static Properties userProps;
/*      */   
/*      */ 
/*      */   private static Properties greenfootProps;
/*      */   
/*      */ 
/*      */   private static Properties commandProps;
/*      */   
/*      */ 
/*      */   private static Properties initialCommandLineProps;
/*      */   
/*      */   private static Properties langProps;
/*      */   
/*      */   private static Properties langVarProps;
/*      */   
/*      */   private static BlueJPropStringSource propSource;
/*      */   
/*      */   private static File bluejLibDir;
/*      */   
/*      */   private static File userPrefDir;
/*      */   
/*      */   private static File greenfootLibDir;
/*      */   
/*      */   private static boolean usingMacOSScreenMenubar;
/*      */   
/*  151 */   private static boolean initialised = false;
/*  152 */   private static boolean isGreenfoot = false;
/*      */   
/*      */   private static final String BLUEJ_DEBUG_DOCK_ICON = "vm.icns";
/*      */   
/*      */   private static final String GREENFOOT_DEBUG_DOCK_ICON = "greenfootvm.icns";
/*      */   
/*      */   private static final String BLUEJ_DEBUG_DOCK_NAME = "BlueJ Virtual Machine";
/*      */   
/*      */   private static final String GREENFOOT_DEBUG_DOCK_NAME = "Greenfoot";
/*      */   
/*  162 */   protected static final int SHORTCUT_MASK = Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  167 */   public static final KeyStroke GREENFOOT_SET_PLAYER_NAME_SHORTCUT = KeyStroke.getKeyStroke(80, SHORTCUT_MASK | 0x40);
/*      */   
/*      */   private static Color selectionColour;
/*      */   
/*      */   private static Color selectionColour2;
/*      */   private static Color highlightColour;
/*      */   private static Color highlightColour2;
/*  174 */   private static List<String> debugVMArgs = new ArrayList();
/*      */   
/*      */ 
/*  177 */   private static boolean isDebugVm = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void initialise(File bluejLibDir, Properties tempCommandLineProps, boolean bootingGreenfoot)
/*      */   {
/*  188 */     initialise(bluejLibDir, tempCommandLineProps, bootingGreenfoot, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void initialise(File bluejLibDir, Properties tempCommandLineProps, boolean bootingGreenfoot, boolean createUserhome)
/*      */   {
/*  200 */     if (initialised) {
/*  201 */       return;
/*      */     }
/*  203 */     initialised = true;
/*      */     
/*  205 */     initialCommandLineProps = tempCommandLineProps;
/*      */     
/*  207 */     isGreenfoot = bootingGreenfoot;
/*      */     
/*  209 */     screenBounds = calculateScreenBounds();
/*      */     
/*      */ 
/*  212 */     bluejLibDir = bluejLibDir;
/*  213 */     greenfootLibDir = new File(bluejLibDir, "greenfoot");
/*      */     
/*      */ 
/*  216 */     if (systemProps == null)
/*      */     {
/*  218 */       isDebugVm = false;
/*      */       
/*      */ 
/*  221 */       systemProps = loadDefs("bluej.defs", System.getProperties());
/*      */       
/*      */ 
/*      */ 
/*  225 */       if (isGreenfoot()) {
/*  226 */         greenfootProps = loadDefs("greenfoot.defs", systemProps);
/*  227 */         userProps = new Properties(greenfootProps);
/*      */       }
/*      */       else {
/*  230 */         userProps = new Properties(systemProps);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  235 */     commandProps = new Properties(userProps);
/*      */     
/*      */ 
/*      */ 
/*  239 */     commandProps.putAll(tempCommandLineProps);
/*  240 */     commandProps.setProperty("bluej.libdir", bluejLibDir.getAbsolutePath());
/*      */     
/*  242 */     if (createUserhome)
/*      */     {
/*      */ 
/*  245 */       initUserHome();
/*      */       
/*      */ 
/*  248 */       loadProperties(getApplicationName().toLowerCase(), userProps);
/*      */       
/*      */ 
/*  251 */       if (isGreenfoot) {
/*  252 */         debugLogName = "greenfoot-debuglog.txt";
/*      */       }
/*      */       
/*  255 */       checkDebug(userPrefDir);
/*      */     }
/*      */     
/*  258 */     initLanguage();
/*      */     
/*  260 */     moeSystemProps = loadDefs("moe.defs", System.getProperties());
/*  261 */     moeUserProps = new Properties(moeSystemProps);
/*  262 */     loadProperties("moe", moeUserProps);
/*      */     
/*      */ 
/*  265 */     String macOSscreenMenuBar = getPropString("bluej.macos.screenmenubar", "true");
/*      */     
/*  267 */     System.setProperty("apple.laf.useScreenMenuBar", macOSscreenMenuBar);
/*      */     
/*  269 */     usingMacOSScreenMenubar = (isMacOS()) && (macOSscreenMenuBar.equals("true"));
/*      */     
/*  271 */     boolean themed = getPropBoolean("bluej.useTheme");
/*  272 */     if (themed) {
/*  273 */       MetalLookAndFeel.setCurrentTheme(new BlueJTheme());
/*      */     }
/*      */     
/*  276 */     String laf = getPropString("bluej.lookAndFeel", "bluejdefault");
/*  277 */     setLookAndFeel(laf);
/*      */     
/*      */ 
/*  280 */     initDebugVMArgs();
/*  281 */     setVMLocale();
/*      */     
/*      */ 
/*      */ 
/*  285 */     commandProps.setProperty("bluej.version", "3.1.1");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void initLanguage()
/*      */   {
/*  295 */     language = commandProps.getProperty("bluej.language", null);
/*      */     
/*      */ 
/*  298 */     if (language == null) {
/*  299 */       language = "english";
/*      */       try {
/*  301 */         String iso3lang = Locale.getDefault().getISO3Language();
/*      */         
/*  303 */         for (int i = 1;; i++) {
/*  304 */           String langString = getPropString("bluej.language" + i, null);
/*  305 */           if (langString == null) {
/*      */             break;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  313 */           int colonIndex = langString.indexOf(':');
/*  314 */           if (colonIndex != -1)
/*      */           {
/*      */ 
/*      */ 
/*  318 */             int secondColon = langString.indexOf(':', colonIndex + 1);
/*  319 */             if (secondColon != -1)
/*      */             {
/*      */ 
/*      */ 
/*  323 */               if (langString.substring(secondColon + 1).equals(iso3lang)) {
/*  324 */                 language = langString.substring(0, colonIndex);
/*  325 */                 break;
/*      */               } }
/*      */           }
/*      */         }
/*  329 */         Debug.log("Detected language \"" + language + "\" based on iso639-2 code \"" + iso3lang + "\"");
/*      */       }
/*      */       catch (MissingResourceException mre) {
/*  332 */         Debug.log("Using default language \"" + language + "\"");
/*      */       }
/*      */     }
/*      */     
/*  336 */     langProps = loadLanguageLabels(language);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void initUserHome()
/*      */   {
/*  349 */     String homeDir = getPropString("bluej.userHome", "$user.home");
/*  350 */     File userHome = new File(homeDir);
/*      */     
/*  352 */     String prefDirName = getBlueJPrefDirName();
/*      */     
/*      */ 
/*  355 */     userPrefDir = new File(userHome, prefDirName);
/*      */     
/*  357 */     int nameCounter = 1;
/*      */     
/*  359 */     while (!userPrefDir.isDirectory() ? 
/*  360 */       !userPrefDir.mkdirs() : 
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  365 */       !userPrefDir.canWrite())
/*      */     {
/*      */ 
/*      */ 
/*  369 */       nameCounter++;
/*  370 */       String propertyName = "bluej.userHome" + nameCounter;
/*  371 */       homeDir = getPropString(propertyName, null);
/*  372 */       if (homeDir == null) {
/*      */         break;
/*      */       }
/*  375 */       userHome = new File(homeDir);
/*  376 */       userPrefDir = new File(userHome, prefDirName);
/*      */     }
/*      */     
/*      */ 
/*  380 */     if (homeDir == null)
/*      */     {
/*  382 */       homeDir = System.getProperty("user.home");
/*  383 */       userHome = new File(homeDir);
/*  384 */       userPrefDir = new File(userHome, prefDirName);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void initializeVMside(File bluejLibDir, File userConfigDir, Properties tempCommandLineProps, boolean bootingGreenfoot, BlueJPropStringSource propSource)
/*      */   {
/*  397 */     isDebugVm = true;
/*  398 */     propSource = propSource;
/*  399 */     userPrefDir = userConfigDir;
/*      */     
/*      */ 
/*      */ 
/*  403 */     systemProps = new Properties()
/*      */     {
/*      */       public String getProperty(String key)
/*      */       {
/*  407 */         return Config.propSource.getBlueJPropertyString(key, null);
/*      */       }
/*      */       
/*      */ 
/*      */       public String getProperty(String key, String def)
/*      */       {
/*  413 */         return Config.propSource.getBlueJPropertyString(key, def);
/*      */       }
/*  415 */     };
/*  416 */     userProps = new Properties(systemProps)
/*      */     {
/*      */       public Object setProperty(String key, String val)
/*      */       {
/*  420 */         String rval = getProperty(key);
/*  421 */         Config.propSource.setUserProperty(key, val);
/*  422 */         return rval;
/*      */       }
/*      */       
/*      */ 
/*      */       public String getProperty(String key)
/*      */       {
/*  428 */         return Config.propSource.getBlueJPropertyString(key, null);
/*      */       }
/*      */       
/*      */ 
/*      */       public String getProperty(String key, String def)
/*      */       {
/*  434 */         return Config.propSource.getBlueJPropertyString(key, def);
/*      */       }
/*  436 */     };
/*  437 */     initialise(bluejLibDir, tempCommandLineProps, bootingGreenfoot, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Properties getInitialCommandLineProperties()
/*      */   {
/*  446 */     return initialCommandLineProps;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void initializeStandalone(BlueJPropStringSource propSource)
/*      */   {
/*  455 */     if (initialised) {
/*  456 */       return;
/*      */     }
/*  458 */     initialised = true;
/*  459 */     isGreenfoot = true;
/*  460 */     propSource = propSource;
/*      */     
/*  462 */     langProps = new Properties()
/*      */     {
/*      */       public String getProperty(String key)
/*      */       {
/*  466 */         return Config.propSource.getLabel(key);
/*      */       }
/*      */       
/*      */ 
/*      */       public String getProperty(String key, String def)
/*      */       {
/*  472 */         return Config.propSource.getLabel(key);
/*      */       }
/*  474 */     };
/*  475 */     commandProps = langProps;
/*      */   }
/*      */   
/*      */   public static boolean isInitialised()
/*      */   {
/*  480 */     return initialised;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getVMIconsName()
/*      */   {
/*  488 */     if (isGreenfoot()) {
/*  489 */       return "greenfootvm.icns";
/*      */     }
/*  491 */     return "vm.icns";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getVMDockName()
/*      */   {
/*  499 */     if (isGreenfoot()) {
/*  500 */       return "Greenfoot";
/*      */     }
/*  502 */     return "BlueJ Virtual Machine";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isDebugVM()
/*      */   {
/*  510 */     return isDebugVm;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isMacOS()
/*      */   {
/*  518 */     return osname.startsWith("Mac");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isRaspberryPi()
/*      */   {
/*  529 */     if (isRaspberryPi == null) {
/*  530 */       boolean result = false;
/*  531 */       if (isLinux()) {
/*      */         try {
/*  533 */           Scanner scanner = new Scanner(new File("/proc/cpuinfo"));
/*      */           
/*  535 */           while (scanner.hasNextLine()) {
/*  536 */             String lineFromFile = scanner.nextLine();
/*  537 */             if (lineFromFile.contains("BCM2708")) {
/*  538 */               result = true;
/*  539 */               break;
/*      */             }
/*      */           }
/*  542 */           scanner.close();
/*      */         }
/*      */         catch (FileNotFoundException fne) {}
/*      */       }
/*      */       
/*  547 */       isRaspberryPi = Boolean.valueOf(result);
/*      */     }
/*  549 */     return isRaspberryPi.booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isMacOSLeopard()
/*      */   {
/*  557 */     return (osname.startsWith("Mac")) && (System.getProperty("os.version").compareTo("10.5") >= 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isMacOSSnowLeopard()
/*      */   {
/*  566 */     return (osname.startsWith("Mac")) && (System.getProperty("os.version").compareTo("10.6") >= 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isWinOS()
/*      */   {
/*  575 */     return osname.startsWith("Windows");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isModernWinOS()
/*      */   {
/*  583 */     return (isWinOS()) && (System.getProperty("os.version").compareTo("6.0") >= 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isLinux()
/*      */   {
/*  592 */     return osname.startsWith("Linux");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isSolaris()
/*      */   {
/*  600 */     return osname.startsWith("Solaris");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isJava15()
/*      */   {
/*  608 */     return System.getProperty("java.specification.version").compareTo("1.5") >= 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isJava16()
/*      */   {
/*  616 */     return System.getProperty("java.specification.version").compareTo("1.6") >= 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isJava17()
/*      */   {
/*  624 */     return System.getProperty("java.specification.version").compareTo("1.7") >= 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isOpenJDK()
/*      */   {
/*  632 */     return System.getProperty("java.runtime.name").startsWith("OpenJDK");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean usingJava15()
/*      */   {
/*  644 */     return isJava15();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String getBlueJPrefDirName()
/*      */   {
/*  655 */     String programName = "bluej";
/*  656 */     if (isGreenfoot) {
/*  657 */       programName = "greenfoot";
/*      */     }
/*  659 */     if (isMacOS()) {
/*  660 */       return "Library/Preferences/org." + programName;
/*      */     }
/*  662 */     if (isWinOS()) {
/*  663 */       return programName;
/*      */     }
/*      */     
/*  666 */     return "." + programName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getApplicationName()
/*      */   {
/*  675 */     if (isGreenfoot) {
/*  676 */       return "Greenfoot";
/*      */     }
/*  678 */     return "BlueJ";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean usingMacScreenMenubar()
/*      */   {
/*  686 */     return usingMacOSScreenMenubar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Rectangle calculateScreenBounds()
/*      */   {
/*  694 */     Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
/*  695 */     return new Rectangle(d);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void checkDebug(File userdir)
/*      */   {
/*  704 */     if ((!isDebugVM()) && 
/*  705 */       (!"true".equals(commandProps.getProperty("bluej.debug")))) {
/*  706 */       File debugLogFile = new File(userdir, debugLogName);
/*      */       try
/*      */       {
/*  709 */         PrintStream outStream = new PrintStream(new FileOutputStream(debugLogFile));
/*  710 */         System.setOut(outStream);
/*  711 */         System.setErr(outStream);
/*  712 */         Debug.setDebugStream(new OutputStreamWriter(outStream));
/*      */         
/*  714 */         Debug.message(getApplicationName() + " run started: " + new Date());
/*  715 */         if (isGreenfoot()) {
/*  716 */           Debug.message("Greenfoot version: " + Boot.GREENFOOT_VERSION);
/*      */         }
/*      */         else {
/*  719 */           Debug.message("BlueJ version 3.1.1");
/*      */         }
/*  721 */         Debug.message("Java version " + System.getProperty("java.version"));
/*  722 */         Debug.message("Virtual machine: " + System.getProperty("java.vm.name") + " " + System.getProperty("java.vm.version") + " (" + System.getProperty("java.vm.vendor") + ")");
/*      */         
/*      */ 
/*      */ 
/*  726 */         Debug.message("Running on: " + System.getProperty("os.name") + " " + System.getProperty("os.version") + " (" + System.getProperty("os.arch") + ")");
/*      */         
/*      */ 
/*  729 */         Debug.message("Java Home: " + System.getProperty("java.home"));
/*  730 */         Debug.message("----");
/*  731 */         return;
/*      */       }
/*      */       catch (IOException e) {
/*  734 */         Debug.reportError("Warning: Unable to create debug log file.");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  743 */     Debug.setDebugStream(new OutputStreamWriter(System.out));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void handleExit()
/*      */   {
/*  751 */     String name = getApplicationName().toLowerCase();
/*  752 */     saveProperties(name, "properties.heading." + name, userProps);
/*  753 */     saveProperties("moe", "properties.heading.moe", moeUserProps);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Properties loadDefs(String filename, Properties parentProperties)
/*      */   {
/*  766 */     File propsFile = new File(bluejLibDir, filename);
/*  767 */     Properties defs = new Properties(parentProperties);
/*      */     try
/*      */     {
/*  770 */       defs.load(new FileInputStream(propsFile));
/*      */     }
/*      */     catch (Exception e) {
/*  773 */       Debug.reportError("Unable to load definitions file: " + propsFile);
/*      */     }
/*      */     
/*  776 */     return defs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Properties loadLanguageLabels(String language)
/*      */   {
/*  787 */     Properties labels = loadDefs("english" + File.separator + "labels", System.getProperties());
/*      */     
/*  789 */     if (isGreenfoot())
/*      */     {
/*      */ 
/*  792 */       String greenfootLabels = "english" + File.separator + "greenfoot/greenfoot-labels";
/*  793 */       File greenfootLabelFile = new File(bluejLibDir, greenfootLabels);
/*      */       try {
/*  795 */         labels.load(new FileInputStream(greenfootLabelFile));
/*      */       }
/*      */       catch (Exception e) {
/*  798 */         Debug.reportError("Unable to load greenfoot labels file: " + greenfootLabelFile);
/*      */       }
/*      */     }
/*      */     
/*  802 */     if (!"english".equals(language)) {
/*  803 */       String languageFileName = language + File.separator + "labels";
/*  804 */       File languageFile = new File(bluejLibDir, languageFileName);
/*      */       try {
/*  806 */         labels.load(new FileInputStream(languageFile));
/*      */       }
/*      */       catch (Exception e) {
/*  809 */         Debug.reportError("Unable to load definitions file: " + languageFile);
/*      */       }
/*  811 */       if (isGreenfoot()) {
/*  812 */         File greenfootLabels = new File(bluejLibDir, language + File.separator + "greenfoot/greenfoot-labels");
/*      */         try {
/*  814 */           labels.load(new FileInputStream(greenfootLabels));
/*      */         }
/*      */         catch (Exception e) {
/*  817 */           Debug.reportError("Unable to load greenfoot labels file: " + greenfootLabels);
/*      */         }
/*      */       }
/*      */     }
/*  821 */     return labels;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void loadProperties(String filename, Properties props)
/*      */   {
/*  830 */     File propsFile = new File(userPrefDir, filename + ".properties");
/*      */     try
/*      */     {
/*  833 */       props.load(new FileInputStream(propsFile));
/*      */     }
/*      */     catch (IOException e) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void saveProperties(String filename, String comment, Properties props)
/*      */   {
/*  845 */     File propsFile = new File(userPrefDir, filename + ".properties");
/*      */     try
/*      */     {
/*  848 */       props.store(new FileOutputStream(propsFile), getString(comment));
/*      */     }
/*      */     catch (IOException e) {
/*  851 */       Debug.reportError("could not save properties file " + propsFile);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Properties getMoeHelp()
/*      */   {
/*  860 */     return loadDefs(language + File.separator + "moe.help", System.getProperties());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getString(String strname)
/*      */   {
/*  869 */     return getString(strname, strname);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getString(String strname, String def)
/*      */   {
/*  878 */     if (langVarProps == null) {
/*  879 */       langVarProps = new Properties();
/*  880 */       langVarProps.put("APPNAME", getApplicationName());
/*      */     }
/*      */     
/*      */ 
/*  884 */     String str = langProps.getProperty(strname, def);
/*      */     int index;
/*  886 */     while ((index = str.indexOf('_')) != -1) {
/*  887 */       str = str.substring(0, index) + str.substring(index + 1);
/*      */     }
/*  889 */     if ((index = str.indexOf('@')) != -1)
/*      */     {
/*  891 */       str = str.substring(0, index);
/*      */     }
/*      */     
/*  894 */     str = PropParser.parsePropString(str, langVarProps);
/*      */     
/*  896 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int getMnemonicKey(String strname)
/*      */   {
/*  910 */     String str = langProps.getProperty(strname, strname);
/*  911 */     int index = str.indexOf('_');
/*  912 */     int mnemonic; int mnemonic; if ((index == -1) || (index + 1 >= str.length())) {
/*  913 */       mnemonic = 0;
/*      */     }
/*      */     else {
/*  916 */       mnemonic = str.codePointAt(index + 1);
/*      */     }
/*  918 */     return mnemonic;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean hasAcceleratorKey(String strname)
/*      */   {
/*  929 */     return langProps.getProperty(strname, strname).indexOf('@') != -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static KeyStroke getAcceleratorKey(String strname)
/*      */   {
/*  941 */     int modifiers = Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();
/*  942 */     String str = langProps.getProperty(strname, strname);
/*      */     
/*  944 */     int index = str.indexOf('@');
/*  945 */     index++;
/*  946 */     if (str.charAt(index) == '^') {
/*  947 */       index++;
/*  948 */       modifiers |= 0x1;
/*      */     }
/*  950 */     String keyString = str.substring(index).toUpperCase();
/*  951 */     if (keyString.length() == 1) {
/*  952 */       return KeyStroke.getKeyStroke(keyString.codePointAt(0), modifiers);
/*      */     }
/*  954 */     KeyStroke k1 = KeyStroke.getKeyStroke(keyString);
/*  955 */     return KeyStroke.getKeyStroke(k1.getKeyCode(), modifiers);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getSystemPropString(String propName)
/*      */   {
/*      */     String sysID;
/*      */     
/*      */ 
/*      */ 
/*      */     String sysID;
/*      */     
/*      */ 
/*  970 */     if ((osname != null) && (osname.startsWith("Windows 9"))) {
/*  971 */       sysID = "win9x";
/*      */     } else { String sysID;
/*  973 */       if ((osname != null) && (osname.equals("Windows Me"))) {
/*  974 */         sysID = "win9x";
/*      */       } else { String sysID;
/*  976 */         if ((osname != null) && (osname.startsWith("Windows"))) {
/*  977 */           sysID = "win";
/*      */         } else { String sysID;
/*  979 */           if ((osname != null) && (osname.startsWith("Linux"))) {
/*  980 */             sysID = "linux";
/*      */           } else { String sysID;
/*  982 */             if ((osname != null) && (osname.startsWith("SunOS"))) {
/*  983 */               sysID = "solaris";
/*      */             } else { String sysID;
/*  985 */               if ((osname != null) && (osname.startsWith("Mac"))) {
/*  986 */                 sysID = "macos";
/*      */               }
/*      */               else
/*  989 */                 sysID = "";
/*      */             }
/*      */           }
/*      */         } } }
/*  993 */     String value = commandProps.getProperty(sysID + propName);
/*      */     
/*      */ 
/*  996 */     if (value == null) {
/*  997 */       value = commandProps.getProperty(propName);
/*      */     }
/*      */     
/* 1000 */     return value;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getPropString(String strname)
/*      */   {
/* 1012 */     String rval = getPropString(strname, null);
/* 1013 */     if (rval == null) {
/* 1014 */       rval = strname;
/*      */     }
/* 1016 */     return rval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getPropString(String strname, String def)
/*      */   {
/* 1027 */     return getPropString(strname, def, commandProps);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getPropString(String strname, String def, Properties props)
/*      */   {
/* 1042 */     String propVal = props.getProperty(strname, def);
/* 1043 */     if (propVal == null) {
/* 1044 */       propVal = def;
/*      */     }
/* 1046 */     if (propVal != null) {
/* 1047 */       return PropParser.parsePropString(propVal, props);
/*      */     }
/* 1049 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getDefaultPropString(String strname, String def)
/*      */   {
/* 1059 */     return systemProps.getProperty(strname, def);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static int getPropInteger(String intname, int def)
/*      */   {
/*      */     int value;
/*      */     
/*      */     try
/*      */     {
/* 1070 */       value = Integer.parseInt(getPropString(intname, String.valueOf(def)));
/*      */     }
/*      */     catch (NumberFormatException nfe) {
/* 1073 */       return def;
/*      */     }
/* 1075 */     return value;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean getPropBoolean(String propname)
/*      */   {
/* 1083 */     return parseBoolean(getPropString(propname, null));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean getPropBoolean(String propname, boolean def)
/*      */   {
/* 1091 */     String propval = getPropString(propname);
/* 1092 */     if (propval == null) {
/* 1093 */       return def;
/*      */     }
/* 1095 */     return parseBoolean(propval);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean parseBoolean(String s)
/*      */   {
/* 1109 */     return (s != null) && (s.equalsIgnoreCase("true"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String removeProperty(String propertyName)
/*      */   {
/* 1117 */     return (String)userProps.remove(propertyName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static File getImageFile(String propname)
/*      */   {
/* 1125 */     String filename = getPropString(propname, null);
/*      */     
/* 1127 */     if (filename != null) {
/* 1128 */       return new File(bluejLibDir, "images" + File.separator + filename);
/*      */     }
/*      */     
/* 1131 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ImageIcon getImageAsIcon(String propname)
/*      */   {
/*      */     try
/*      */     {
/* 1141 */       URL u = getImageFile(propname).toURI().toURL();
/* 1142 */       return new ImageIcon(u);
/*      */     }
/*      */     catch (MalformedURLException mue) {}catch (NullPointerException npe) {}
/*      */     
/* 1146 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ImageIcon getFixedImageAsIcon(String filename)
/*      */   {
/* 1155 */     File image = new File(bluejLibDir, "images" + File.separator + filename);
/*      */     try {
/* 1157 */       return new ImageIcon(image.toURI().toURL());
/*      */     }
/*      */     catch (MalformedURLException mue) {}catch (NullPointerException npe) {}
/*      */     
/* 1161 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ImageIcon getHardImageAsIcon(String filename)
/*      */   {
/*      */     try
/*      */     {
/* 1171 */       File imgFile = new File(bluejLibDir, "images" + File.separator + filename);
/* 1172 */       URL u = imgFile.toURI().toURL();
/*      */       
/* 1174 */       return new ImageIcon(u);
/*      */     }
/*      */     catch (MalformedURLException mue) {}catch (NullPointerException npe) {}
/*      */     
/* 1178 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static Image getImage(String propname)
/*      */   {
/*      */     try
/*      */     {
/* 1187 */       URL u = getImageFile(propname).toURI().toURL();
/* 1188 */       return Toolkit.getDefaultToolkit().createImage(u);
/*      */     }
/*      */     catch (MalformedURLException mue) {}catch (NullPointerException npe) {}
/*      */     
/* 1192 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getJDKExecutablePath(String propName, String executableName)
/*      */   {
/* 1218 */     if (executableName == null) {
/* 1219 */       throw new IllegalArgumentException("must provide an executable name");
/*      */     }
/* 1221 */     String p = propName == null ? null : getSystemPropString(propName);
/*      */     
/* 1223 */     if (p == null)
/*      */     {
/* 1225 */       String jdkPathName = System.getProperty("java.home");
/*      */       
/* 1227 */       if (jdkPathName != null)
/*      */       {
/* 1229 */         File jdkPath = new File(jdkPathName);
/* 1230 */         File binPath = new File(jdkPath, "bin");
/*      */         
/*      */ 
/* 1233 */         File potentialExe = new File(binPath, executableName);
/* 1234 */         if (potentialExe.exists()) {
/* 1235 */           return potentialExe.getAbsolutePath();
/*      */         }
/*      */         
/* 1238 */         potentialExe = new File(binPath, executableName + ".exe");
/* 1239 */         if (potentialExe.exists()) {
/* 1240 */           return potentialExe.getAbsolutePath();
/*      */         }
/*      */         
/*      */ 
/* 1244 */         jdkPath = jdkPath.getParentFile();
/* 1245 */         if (jdkPath != null) {
/* 1246 */           binPath = new File(jdkPath, "bin");
/*      */           
/*      */ 
/* 1249 */           potentialExe = new File(binPath, executableName);
/* 1250 */           if (potentialExe.exists()) {
/* 1251 */             return potentialExe.getAbsolutePath();
/*      */           }
/* 1253 */           potentialExe = new File(binPath, executableName + ".exe");
/* 1254 */           if (potentialExe.exists()) {
/* 1255 */             return potentialExe.getAbsolutePath();
/*      */           }
/*      */         }
/*      */       }
/* 1259 */       return executableName;
/*      */     }
/*      */     
/* 1262 */     return p;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static File getTemplateDir()
/*      */   {
/* 1270 */     return getLanguageFile("templates");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static File getTemplateFile(String base)
/*      */   {
/* 1279 */     return new File(getTemplateDir(), base + ".tmpl");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static File getClassTemplateDir()
/*      */   {
/* 1287 */     String path = commandProps.getProperty("bluej.templatePath", "");
/* 1288 */     if (path.length() == 0) {
/* 1289 */       return getLanguageFile("templates/newclass");
/*      */     }
/* 1291 */     return new File(path);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static File getClassTemplateFile(String base)
/*      */   {
/* 1300 */     return new File(getClassTemplateDir(), base + ".tmpl");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static File getLanguageFile(String base)
/*      */   {
/* 1311 */     return new File(bluejLibDir, language + File.separator + base);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static File getDefaultLanguageFile(String base)
/*      */   {
/* 1319 */     return new File(bluejLibDir, "english" + File.separator + base);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static File getUserConfigFile(String base)
/*      */   {
/* 1328 */     return new File(userPrefDir, base);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static File getUserConfigDir()
/*      */   {
/* 1337 */     return userPrefDir;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static Color getItemColour(String itemname)
/*      */   {
/*      */     try
/*      */     {
/* 1346 */       String rgbStr = getPropString(itemname, "255,0,255");
/* 1347 */       String[] rgbVal = Utility.split(rgbStr, ",");
/*      */       
/* 1349 */       if (rgbVal.length < 3) {
/* 1350 */         Debug.reportError("Error reading colour [" + itemname + "]");
/*      */       } else {
/* 1352 */         int r = Integer.parseInt(rgbVal[0].trim());
/* 1353 */         int g = Integer.parseInt(rgbVal[1].trim());
/* 1354 */         int b = Integer.parseInt(rgbVal[2].trim());
/*      */         
/* 1356 */         return new Color(r, g, b);
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 1360 */       Debug.reportError("Could not get colour for " + itemname);
/*      */     }
/*      */     
/* 1363 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Color getOptionalItemColour(String itemname)
/*      */   {
/*      */     try
/*      */     {
/* 1374 */       String rgbStr = getPropString(itemname, null);
/* 1375 */       if (rgbStr == null) {
/* 1376 */         return null;
/*      */       }
/*      */       
/* 1379 */       String[] rgbVal = Utility.split(rgbStr, ",");
/* 1380 */       if (rgbVal.length < 3) {
/* 1381 */         Debug.reportError("Error reading colour [" + itemname + "]");
/*      */       }
/*      */       else {
/* 1384 */         int r = Integer.parseInt(rgbVal[0].trim());
/* 1385 */         int g = Integer.parseInt(rgbVal[1].trim());
/* 1386 */         int b = Integer.parseInt(rgbVal[2].trim());
/*      */         
/* 1388 */         return new Color(r, g, b);
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 1392 */       Debug.reportError("Could not get colour for " + itemname);
/*      */     }
/*      */     
/* 1395 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Color getSelectionColour()
/*      */   {
/* 1403 */     if (selectionColour == null) {
/* 1404 */       selectionColour = getItemColour("colour.selection");
/*      */     }
/* 1406 */     return selectionColour;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Color getSelectionColour2()
/*      */   {
/* 1414 */     if (selectionColour2 == null) {
/* 1415 */       selectionColour2 = getItemColour("colour.selection2");
/*      */     }
/* 1417 */     return selectionColour2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Color getHighlightColour()
/*      */   {
/* 1425 */     if (highlightColour == null) {
/* 1426 */       highlightColour = getItemColour("colour.highlight");
/*      */     }
/* 1428 */     return highlightColour;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Color getHighlightColour2()
/*      */   {
/* 1436 */     if (highlightColour2 == null) {
/* 1437 */       highlightColour2 = getItemColour("colour.highlight2");
/*      */     }
/* 1439 */     return highlightColour2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Font getFont(String propertyName, String defaultFontName, int size)
/*      */   {
/* 1448 */     String fontName = getPropString(propertyName, defaultFontName);
/*      */     
/*      */     int style;
/* 1451 */     if (fontName.endsWith("-bold")) {
/* 1452 */       int style = 1;
/* 1453 */       fontName = fontName.substring(0, fontName.length() - 5);
/*      */     }
/*      */     else {
/* 1456 */       style = 0;
/*      */     }
/*      */     
/* 1459 */     return new Font(fontName, style, size);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void putLocation(String itemPrefix, Point p)
/*      */   {
/* 1468 */     putPropInteger(itemPrefix + ".x", p.x);
/* 1469 */     putPropInteger(itemPrefix + ".y", p.y);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Point getLocation(String itemPrefix)
/*      */   {
/*      */     try
/*      */     {
/* 1479 */       int x = getPropInteger(itemPrefix + ".x", 16);
/* 1480 */       int y = getPropInteger(itemPrefix + ".y", 16);
/*      */       
/* 1482 */       if (x > screenBounds.width - 16) {
/* 1483 */         x = screenBounds.width - 16;
/*      */       }
/* 1485 */       if (y > screenBounds.height - 16) {
/* 1486 */         y = screenBounds.height - 16;
/*      */       }
/* 1488 */       return new Point(x, y);
/*      */     }
/*      */     catch (Exception e) {
/* 1491 */       Debug.reportError("Could not get screen location for " + itemPrefix);
/*      */     }
/*      */     
/* 1494 */     return new Point(16, 16);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void putPropInteger(String intname, int value)
/*      */   {
/* 1502 */     String defVal = systemProps.getProperty(intname);
/* 1503 */     if (defVal != null) {
/*      */       try {
/* 1505 */         if (value == Integer.valueOf(defVal).intValue()) {
/* 1506 */           userProps.remove(intname);
/*      */         }
/*      */       }
/*      */       catch (NumberFormatException nfe) {}
/*      */     }
/* 1511 */     userProps.setProperty(intname, Integer.toString(value));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void putPropString(String strname, String value)
/*      */   {
/* 1520 */     String defVal = systemProps.getProperty(strname);
/* 1521 */     if ((value != null) && ((defVal == null) || (!defVal.equals(value)))) {
/* 1522 */       userProps.setProperty(strname, value);
/*      */     }
/*      */     else {
/* 1525 */       userProps.remove(strname);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void putPropBoolean(String propname, boolean value)
/*      */   {
/* 1534 */     String sysval = systemProps.getProperty(propname);
/* 1535 */     if (Boolean.valueOf(sysval).booleanValue() == value) {
/* 1536 */       userProps.remove(propname);
/*      */     }
/*      */     else {
/* 1539 */       userProps.setProperty(propname, String.valueOf(value));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static File getBlueJLibDir()
/*      */   {
/* 1548 */     return bluejLibDir;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static File getGreenfootLibDir()
/*      */   {
/* 1556 */     return greenfootLibDir;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getBlueJIconPath()
/*      */   {
/* 1564 */     return bluejLibDir.getPath() + "/images";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void setVMLocale()
/*      */   {
/* 1574 */     String lang = getPropString("vm.language", null);
/* 1575 */     String region = getPropString("vm.country", null);
/*      */     
/*      */ 
/* 1578 */     if (((lang == null) || ("".equals(lang))) && ((region == null) || ("".equals(region)))) {
/* 1579 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1586 */     if ((lang == null) || (lang.equals("")))
/* 1587 */       lang = System.getProperty("user.language");
/* 1588 */     if ((region == null) || (region.equals("")))
/* 1589 */       region = System.getProperty("user.country");
/* 1590 */     debugVMArgs.add("-Duser.language=" + lang);
/* 1591 */     debugVMArgs.add("-Duser.country=" + region);
/* 1592 */     Locale loc = new Locale(lang, region);
/* 1593 */     Locale.setDefault(loc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void setLookAndFeel(String laf)
/*      */   {
/*      */     try
/*      */     {
/* 1604 */       if (laf.equals("default")) {
/* 1605 */         return;
/*      */       }
/*      */       
/*      */ 
/* 1609 */       if (laf.equals("system")) {
/* 1610 */         UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/* 1611 */         return;
/*      */       }
/* 1613 */       if (laf.equals("crossplatform")) {
/* 1614 */         UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
/* 1615 */         usingMacOSScreenMenubar = false;
/* 1616 */         return;
/*      */       }
/*      */       
/* 1619 */       if (!laf.equals("bluejdefault")) {
/* 1620 */         UIManager.LookAndFeelInfo[] lafi = UIManager.getInstalledLookAndFeels();
/* 1621 */         for (int i = 0; i < lafi.length; i++) {
/* 1622 */           if (lafi[i].getName().equals(laf)) {
/* 1623 */             UIManager.setLookAndFeel(lafi[i].getClassName());
/* 1624 */             return;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 1629 */         UIManager.setLookAndFeel(laf);
/* 1630 */         return;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1635 */       if (isWinOS()) {
/* 1636 */         UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/*      */ 
/*      */       }
/* 1639 */       else if ((isLinux()) || (isSolaris())) {
/* 1640 */         UIManager.LookAndFeelInfo[] lafi = UIManager.getInstalledLookAndFeels();
/* 1641 */         UIManager.LookAndFeelInfo nimbus = null;
/* 1642 */         for (UIManager.LookAndFeelInfo lafInstance : lafi) {
/* 1643 */           if (lafInstance.getName().equals("Nimbus")) {
/* 1644 */             nimbus = lafInstance;
/* 1645 */             break;
/*      */           }
/*      */         }
/*      */         
/* 1649 */         if (nimbus != null) {
/* 1650 */           UIManager.setLookAndFeel(nimbus.getClassName());
/*      */         }
/*      */         else {
/* 1653 */           UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
/*      */         }
/*      */       }
/*      */     } catch (ClassNotFoundException e) {
/* 1657 */       Debug.log("Could not find look-and-feel class: " + e.getMessage());
/*      */     } catch (InstantiationException e) {
/* 1659 */       e.printStackTrace();
/*      */     } catch (IllegalAccessException e) {
/* 1661 */       e.printStackTrace();
/*      */     } catch (UnsupportedLookAndFeelException e) {
/* 1663 */       Debug.log("Unsupported look-and-feel: " + e.getMessage());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void initDebugVMArgs()
/*      */   {
/* 1673 */     String args = getPropString("bluej.vm.args");
/* 1674 */     if ((args != null) && (!args.equals("bluej.vm.args")))
/*      */     {
/* 1676 */       List<String> splitArgs = Utility.dequoteCommandLine(args);
/* 1677 */       debugVMArgs.addAll(splitArgs);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static List<String> getDebugVMArgs()
/*      */   {
/* 1686 */     return debugVMArgs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean isGreenfoot()
/*      */   {
/* 1699 */     return isGreenfoot;
/*      */   }
/*      */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\bluej\Config.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */