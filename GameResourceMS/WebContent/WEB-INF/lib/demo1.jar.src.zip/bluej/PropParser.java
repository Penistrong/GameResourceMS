/*     */ package bluej;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropParser
/*     */ {
/*     */   private static final int MAX_DEPTH = 10;
/*     */   
/*     */   public static String parsePropString(String value, Properties subvars)
/*     */   {
/*  64 */     StringBuffer outBuffer = new StringBuffer();
/*  65 */     parsePropString(value, outBuffer, subvars, 0);
/*  66 */     return outBuffer.toString();
/*     */   }
/*     */   
/*     */   private static void parsePropString(String value, StringBuffer outBuffer, Properties subvars, int depth)
/*     */   {
/*  71 */     if (depth > 10) {
/*  72 */       outBuffer.append(value);
/*  73 */       return;
/*     */     }
/*     */     
/*  76 */     StringIter iter = new StringIter(value);
/*     */     
/*  78 */     while (iter.hasNext()) {
/*  79 */       char cc = iter.next();
/*  80 */       if (cc == '$') {
/*  81 */         if (iter.hasNext()) {
/*  82 */           cc = iter.next();
/*  83 */           if (cc == '$')
/*     */           {
/*  85 */             outBuffer.append('$');
/*     */           }
/*  87 */           else if (cc == '{')
/*     */           {
/*  89 */             processVar(iter, outBuffer, subvars, depth);
/*  90 */             do { if (!iter.hasNext()) break;
/*  91 */               cc = iter.next();
/*  92 */             } while (cc != '}');
/*     */ 
/*     */ 
/*     */ 
/*     */           }
/*  97 */           else if (isNameChar(cc))
/*     */           {
/*  99 */             iter.backup();
/* 100 */             processVar(iter, outBuffer, subvars, depth);
/*     */           }
/*     */           else {
/* 103 */             outBuffer.append('$');
/* 104 */             outBuffer.append(cc);
/*     */           }
/*     */         }
/*     */         else {
/* 108 */           outBuffer.append('$');
/*     */         }
/*     */       }
/*     */       else {
/* 112 */         outBuffer.append(cc);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isNameChar(char cc)
/*     */   {
/* 123 */     if (Character.isWhitespace(cc)) {
/* 124 */       return false;
/*     */     }
/* 126 */     if ((cc == '/') || (cc == '\\') || (cc == '{') || (cc == '}') || (cc == '"') || (cc == '$') || (cc == '(') || (cc == ')') || (cc == ' ') || (cc == ':'))
/*     */     {
/* 128 */       return false;
/*     */     }
/* 130 */     if (cc == ',') {
/* 131 */       return false;
/*     */     }
/* 133 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   private static void processVar(StringIter iter, StringBuffer outBuffer, Properties subvars, int depth)
/*     */   {
/* 139 */     StringBuffer varNameBuf = new StringBuffer();
/* 140 */     while (iter.hasNext()) {
/* 141 */       char cc = iter.next();
/* 142 */       if (isNameChar(cc)) {
/* 143 */         varNameBuf.append(cc);
/*     */       }
/* 145 */       else if ((cc == '$') && (iter.hasNext()))
/*     */       {
/*     */ 
/* 148 */         cc = iter.next();
/* 149 */         varNameBuf.append(cc);
/*     */       }
/*     */       else {
/* 152 */         iter.backup();
/* 153 */         break;
/*     */       }
/*     */     }
/*     */     
/* 157 */     String varName = varNameBuf.toString();
/* 158 */     if (varName.equals("filePath"))
/*     */     {
/* 160 */       String arg = processStringArg(iter, subvars, depth);
/* 161 */       if (arg != null) {
/* 162 */         File f = new File(arg);
/*     */         do {
/* 164 */           arg = processStringArg(iter, subvars, depth);
/* 165 */           if (arg != null) {
/* 166 */             f = new File(f, arg);
/*     */           }
/* 168 */         } while (arg != null);
/* 169 */         outBuffer.append(f.getAbsolutePath());
/*     */       }
/*     */     }
/* 172 */     else if (varName.equals("fileUrl"))
/*     */     {
/*     */ 
/* 175 */       String arg = processStringArg(iter, subvars, depth);
/* 176 */       if (arg != null) {
/* 177 */         File f = new File(arg);
/*     */         try {
/* 179 */           String fileUrl = f.toURI().toURL().toString();
/* 180 */           outBuffer.append(fileUrl);
/*     */         }
/*     */         catch (MalformedURLException mfue) {}
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 187 */       String nval = subvars.getProperty(varName);
/* 188 */       if (nval != null) {
/* 189 */         parsePropString(nval, outBuffer, subvars, depth + 1);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String processStringArg(StringIter iter, Properties subvars, int depth)
/*     */   {
/*     */     char cc;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     do
/*     */     {
/* 212 */       if (!iter.hasNext()) {
/* 213 */         return null;
/*     */       }
/* 215 */       cc = iter.next();
/* 216 */     } while (Character.isWhitespace(cc));
/* 217 */     if (cc == '}') {
/* 218 */       return null;
/*     */     }
/*     */     
/* 221 */     if (cc == '"')
/*     */     {
/* 223 */       StringBuffer result = new StringBuffer();
/* 224 */       while (iter.hasNext()) {
/* 225 */         cc = iter.next();
/* 226 */         if (cc == '"') {
/*     */           break;
/*     */         }
/* 229 */         result.append(cc);
/*     */       }
/* 231 */       return result.toString();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 236 */     StringBuffer outBuffer = new StringBuffer();
/* 237 */     iter.backup();
/*     */     do
/*     */     {
/* 240 */       cc = iter.next();
/* 241 */       if ((cc == '$') && (iter.hasNext())) {
/* 242 */         cc = iter.next();
/* 243 */         if ((Character.isWhitespace(cc)) || (cc == '}') || (cc == '"')) {
/* 244 */           outBuffer.append(cc);
/*     */         }
/* 246 */         else if (cc == '{')
/*     */         {
/* 248 */           processVar(iter, outBuffer, subvars, depth);
/* 249 */           do { if (!iter.hasNext()) break;
/* 250 */             cc = iter.next();
/* 251 */           } while (cc != '}');
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/* 258 */           iter.backup();
/* 259 */           processVar(iter, outBuffer, subvars, depth);
/*     */         }
/*     */       }
/*     */       else {
/* 263 */         if ((Character.isWhitespace(cc)) || (cc == '}')) {
/* 264 */           iter.backup();
/* 265 */           break;
/*     */         }
/* 267 */         if (cc == '"')
/*     */         {
/* 269 */           while (iter.hasNext()) {
/* 270 */             cc = iter.next();
/* 271 */             if (cc == '"') {
/*     */               break;
/*     */             }
/* 274 */             outBuffer.append(cc);
/*     */           }
/*     */         }
/*     */         
/* 278 */         outBuffer.append(cc);
/*     */       }
/*     */       
/*     */     }
/* 282 */     while (iter.hasNext());
/*     */     
/* 284 */     return outBuffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class StringIter
/*     */   {
/*     */     private String string;
/*     */     
/*     */ 
/*     */     private int curpos;
/*     */     
/*     */     private int limit;
/*     */     
/*     */ 
/*     */     StringIter(String string)
/*     */     {
/* 301 */       this.string = string;
/* 302 */       this.limit = string.length();
/*     */     }
/*     */     
/*     */     public boolean hasNext()
/*     */     {
/* 307 */       return this.curpos < this.limit;
/*     */     }
/*     */     
/*     */     public char next()
/*     */     {
/* 312 */       return this.string.charAt(this.curpos++);
/*     */     }
/*     */     
/*     */     public void backup()
/*     */     {
/* 317 */       this.curpos -= 1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\bluej\PropParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */