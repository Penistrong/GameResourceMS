/*     */ package bluej;
/*     */ 
/*     */ import bluej.prefmgr.PrefMgr;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Image;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.FontUIResource;
/*     */ import javax.swing.plaf.metal.DefaultMetalTheme;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlueJTheme
/*     */   extends DefaultMetalTheme
/*     */ {
/*  44 */   private final FontUIResource controlFont = new FontUIResource(PrefMgr.getStandardFont());
/*     */   
/*  46 */   private final FontUIResource systemFont = new FontUIResource(this.controlFont);
/*     */   
/*  48 */   private final FontUIResource userFont = new FontUIResource(this.controlFont);
/*     */   
/*  50 */   private final FontUIResource menuFont = new FontUIResource(PrefMgr.getStandardMenuFont());
/*     */   
/*     */   private static final String SMALL_ICON_SUFFIX = "-icon-32.png";
/*     */   
/*     */   private static final String MEDIUM_ICON_SUFFIX = "-icon-48.png";
/*     */   
/*     */   private static final String LARGE_ICON_SUFFIX = "-icon-256.png";
/*     */   
/*  58 */   private static Image iconImage = null;
/*     */   
/*     */ 
/*     */   private static String okayLabel;
/*     */   
/*     */ 
/*     */   private static String cancelLabel;
/*     */   
/*     */   private static String closeLabel;
/*     */   
/*     */   private static String continueLabel;
/*     */   
/*     */   private static Dimension okCancelDimension;
/*     */   
/*     */   public static final int splitPaneDividerWidth = 3;
/*     */   
/*     */   public static final int generalSpacingWidth = 5;
/*     */   
/*  76 */   public static final Border generalBorder = BorderFactory.createEmptyBorder(10, 10, 10, 10);
/*     */   
/*     */ 
/*  79 */   public static final Border generalBorderWithStatusBar = BorderFactory.createEmptyBorder(10, 10, 0, 10);
/*     */   
/*     */ 
/*  82 */   public static final Border dialogBorder = BorderFactory.createEmptyBorder(12, 12, 12, 12);
/*     */   
/*     */ 
/*     */   public static final int commandButtonSpacing = 5;
/*     */   
/*     */   public static final int commandButtonPadding = 12;
/*     */   
/*     */   public static final int componentSpacingSmall = 5;
/*     */   
/*     */   public static final int componentSpacingLarge = 11;
/*     */   
/*     */   public static final int dialogCommandButtonsVertical = 17;
/*     */   
/*     */ 
/*     */   public String getName()
/*     */   {
/*  98 */     return "BlueJTheme";
/*     */   }
/*     */   
/*     */   public FontUIResource getControlTextFont()
/*     */   {
/* 103 */     return this.controlFont;
/*     */   }
/*     */   
/*     */   public FontUIResource getSystemTextFont()
/*     */   {
/* 108 */     return this.systemFont;
/*     */   }
/*     */   
/*     */   public FontUIResource getUserTextFont()
/*     */   {
/* 113 */     return this.userFont;
/*     */   }
/*     */   
/*     */   public FontUIResource getMenuTextFont()
/*     */   {
/* 118 */     return this.menuFont;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Image getIconImage()
/*     */   {
/* 128 */     String appName = Config.getApplicationName().toLowerCase();
/* 129 */     return getApplicationIcon(appName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Image getApplicationIcon(String baseName)
/*     */   {
/* 139 */     if (Config.isMacOS()) {
/* 140 */       return null;
/*     */     }
/* 142 */     if (iconImage == null) {
/* 143 */       if (Config.isModernWinOS())
/*     */       {
/* 145 */         iconImage = Config.getFixedImageAsIcon(baseName + "-icon-256.png").getImage();
/*     */       }
/* 147 */       else if (Config.isWinOS())
/*     */       {
/* 149 */         iconImage = Config.getFixedImageAsIcon(baseName + "-icon-32.png").getImage();
/*     */       }
/*     */       else
/*     */       {
/* 153 */         iconImage = Config.getFixedImageAsIcon(baseName + "-icon-48.png").getImage();
/*     */       }
/*     */     }
/*     */     
/* 157 */     return iconImage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setIconImage(Image newIconImage)
/*     */   {
/* 165 */     iconImage = newIconImage;
/*     */   }
/*     */   
/*     */   public static String getOkLabel()
/*     */   {
/* 170 */     if (okayLabel == null) {
/* 171 */       okayLabel = Config.getString("okay");
/*     */     }
/* 173 */     return okayLabel;
/*     */   }
/*     */   
/*     */   public static String getCancelLabel()
/*     */   {
/* 178 */     if (cancelLabel == null) {
/* 179 */       cancelLabel = Config.getString("cancel");
/*     */     }
/* 181 */     return cancelLabel;
/*     */   }
/*     */   
/*     */   public static String getCloseLabel()
/*     */   {
/* 186 */     if (closeLabel == null) {
/* 187 */       closeLabel = Config.getString("close");
/*     */     }
/* 189 */     return closeLabel;
/*     */   }
/*     */   
/*     */ 
/*     */   public static String getContinueLabel()
/*     */   {
/* 195 */     if (continueLabel == null) {
/* 196 */       continueLabel = Config.getString("continue");
/*     */     }
/* 198 */     return continueLabel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JButton getOkButton()
/*     */   {
/* 208 */     computeButtonWidths();
/*     */     
/* 210 */     JButton okButton = new JButton(getOkLabel());
/*     */     
/* 212 */     okButton.setPreferredSize(okCancelDimension);
/* 213 */     return okButton;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JButton getCancelButton()
/*     */   {
/* 223 */     computeButtonWidths();
/*     */     
/* 225 */     JButton cancelButton = new JButton(getCancelLabel());
/*     */     
/* 227 */     cancelButton.setPreferredSize(okCancelDimension);
/* 228 */     return cancelButton;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JButton getCloseButton()
/*     */   {
/* 238 */     computeButtonWidths();
/*     */     
/* 240 */     JButton closeButton = new JButton(getCloseLabel());
/*     */     
/* 242 */     closeButton.setPreferredSize(okCancelDimension);
/* 243 */     return closeButton;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JButton getContinueButton()
/*     */   {
/* 254 */     computeButtonWidths();
/*     */     
/* 256 */     JButton continueButton = new JButton(getContinueLabel());
/*     */     
/* 258 */     continueButton.setPreferredSize(okCancelDimension);
/* 259 */     return continueButton;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void computeButtonWidths()
/*     */   {
/* 268 */     if (okCancelDimension != null) {
/* 269 */       return;
/*     */     }
/* 271 */     JButton okButton = new JButton(getOkLabel());
/* 272 */     JButton cancelButton = new JButton(getCancelLabel());
/* 273 */     JButton continueButton = new JButton(getContinueLabel());
/*     */     
/* 275 */     int maxWidth = Math.max(cancelButton.getPreferredSize().width, okButton.getPreferredSize().width);
/*     */     
/* 277 */     maxWidth = Math.max(maxWidth, continueButton.getPreferredSize().width);
/*     */     
/*     */ 
/* 280 */     okCancelDimension = new Dimension(maxWidth, okButton.getPreferredSize().height);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\bluej\BlueJTheme.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */