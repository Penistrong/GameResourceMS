/*     */ package bluej.utility;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CenterLayout
/*     */   implements LayoutManager
/*     */ {
/*     */   public void layoutContainer(Container target)
/*     */   {
/*  46 */     synchronized (target.getTreeLock()) {
/*  47 */       Insets insets = target.getInsets();
/*  48 */       int maxwidth = target.getWidth() - (insets.left + insets.right);
/*  49 */       int maxheight = target.getHeight() - (insets.top + insets.bottom);
/*     */       
/*  51 */       Component m = target.getComponent(0);
/*  52 */       if (m.isVisible()) {
/*  53 */         Dimension d = m.getPreferredSize();
/*  54 */         d.width = Math.min(d.width, maxwidth);
/*  55 */         d.height = Math.min(d.height, maxheight);
/*  56 */         m.setSize(d);
/*     */         
/*  58 */         int hspace = maxwidth - d.width;
/*  59 */         int xpos = insets.left + hspace / 2;
/*     */         
/*  61 */         int vspace = maxheight - d.height;
/*  62 */         int ypos = insets.top + vspace / 2;
/*     */         
/*  64 */         m.setLocation(xpos, ypos);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addLayoutComponent(String name, Component comp) {}
/*     */   
/*     */ 
/*     */   public void removeLayoutComponent(Component comp) {}
/*     */   
/*     */ 
/*     */   public Dimension preferredLayoutSize(Container parent)
/*     */   {
/*     */     Dimension d;
/*     */     
/*     */     Dimension d;
/*     */     
/*  83 */     if (parent.getComponentCount() > 0) {
/*  84 */       Component m = parent.getComponent(0);
/*  85 */       d = m.getPreferredSize();
/*     */     }
/*     */     else {
/*  88 */       d = new Dimension(0, 0);
/*     */     }
/*  90 */     Insets insets = parent.getInsets();
/*  91 */     d.height += insets.top + insets.bottom;
/*  92 */     d.width += insets.left + insets.right;
/*  93 */     return d;
/*     */   }
/*     */   
/*     */   public Dimension minimumLayoutSize(Container parent)
/*     */   {
/*     */     Dimension d;
/*     */     Dimension d;
/* 100 */     if (parent.getComponentCount() > 0) {
/* 101 */       Component m = parent.getComponent(0);
/* 102 */       d = m.getMinimumSize();
/*     */     }
/*     */     else {
/* 105 */       d = new Dimension(0, 0);
/*     */     }
/* 107 */     Insets insets = parent.getInsets();
/* 108 */     d.height += insets.top + insets.bottom;
/* 109 */     d.width += insets.left + insets.right;
/* 110 */     return d;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\bluej\utility\CenterLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */