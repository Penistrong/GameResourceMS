package bluej;

public abstract interface BlueJPropStringSource
{
  public abstract String getBlueJPropertyString(String paramString1, String paramString2);
  
  public abstract String getLabel(String paramString);
  
  public abstract void setUserProperty(String paramString1, String paramString2);
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\bluej\BlueJPropStringSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */