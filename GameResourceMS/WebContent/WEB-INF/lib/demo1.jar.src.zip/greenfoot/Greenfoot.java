/*     */ package greenfoot;
/*     */ 
/*     */ import greenfoot.core.Simulation;
/*     */ import greenfoot.core.WorldHandler;
/*     */ import greenfoot.gui.input.KeyboardManager;
/*     */ import greenfoot.gui.input.mouse.MousePollingManager;
/*     */ import greenfoot.sound.MicLevelGrabber;
/*     */ import greenfoot.sound.Sound;
/*     */ import greenfoot.sound.SoundFactory;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Greenfoot
/*     */ {
/*  58 */   private static Random randomGenerator = new Random();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setWorld(World world)
/*     */   {
/*  69 */     if (world == null) {
/*  70 */       throw new NullPointerException("The given world cannot be null.");
/*     */     }
/*     */     
/*  73 */     WorldHandler.getInstance().setWorld(world);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getKey()
/*     */   {
/*  86 */     return WorldHandler.getInstance().getKeyboardManager().getKey();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isKeyDown(String keyName)
/*     */   {
/*  97 */     return WorldHandler.getInstance().getKeyboardManager().isKeyDown(keyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void delay(int time)
/*     */   {
/* 108 */     Simulation.getInstance().sleep(time);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setSpeed(int speed)
/*     */   {
/* 118 */     Simulation.getInstance().setSpeed(speed);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void stop()
/*     */   {
/* 126 */     Simulation.getInstance().setPaused(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void start()
/*     */   {
/* 134 */     Simulation.getInstance().setPaused(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getRandomNumber(int limit)
/*     */   {
/* 142 */     return randomGenerator.nextInt(limit);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void playSound(String soundFile)
/*     */   {
/* 159 */     Sound sound = SoundFactory.getInstance().createSound(soundFile, false);
/*     */     
/* 161 */     if (sound != null) {
/* 162 */       sound.play();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean mousePressed(Object obj)
/*     */   {
/* 183 */     return WorldHandler.getInstance().getMouseManager().isMousePressed(obj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean mouseClicked(Object obj)
/*     */   {
/* 201 */     return WorldHandler.getInstance().getMouseManager().isMouseClicked(obj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean mouseDragged(Object obj)
/*     */   {
/* 222 */     return WorldHandler.getInstance().getMouseManager().isMouseDragged(obj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean mouseDragEnded(Object obj)
/*     */   {
/* 243 */     return WorldHandler.getInstance().getMouseManager().isMouseDragEnded(obj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean mouseMoved(Object obj)
/*     */   {
/* 264 */     return WorldHandler.getInstance().getMouseManager().isMouseMoved(obj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MouseInfo getMouseInfo()
/*     */   {
/* 276 */     return WorldHandler.getInstance().getMouseManager().getMouseInfo();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getMicLevel()
/*     */   {
/* 287 */     return MicLevelGrabber.getInstance().getLevel();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String ask(String prompt)
/*     */   {
/* 298 */     return WorldHandler.getInstance().ask(prompt);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\Greenfoot.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */