/*     */ package greenfoot.util;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.GraphicsConfiguration;
/*     */ import java.awt.GraphicsDevice;
/*     */ import java.awt.GraphicsEnvironment;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Shape;
/*     */ import java.awt.font.FontRenderContext;
/*     */ import java.awt.font.GlyphVector;
/*     */ import java.awt.font.LineMetrics;
/*     */ import java.awt.font.TextLayout;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import javax.imageio.ImageIO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraphicsUtilities
/*     */ {
/*     */   private static GraphicsConfiguration getGraphicsConfiguration()
/*     */   {
/*  90 */     return GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BufferedImage createColorModelCompatibleImage(BufferedImage image)
/*     */   {
/* 106 */     ColorModel cm = image.getColorModel();
/* 107 */     return new BufferedImage(cm, cm.createCompatibleWritableRaster(image.getWidth(), image.getHeight()), cm.isAlphaPremultiplied(), null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BufferedImage createCompatibleImage(BufferedImage image)
/*     */   {
/* 129 */     return createCompatibleImage(image, image.getWidth(), image.getHeight());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BufferedImage createCompatibleImage(BufferedImage image, int width, int height)
/*     */   {
/* 151 */     return getGraphicsConfiguration().createCompatibleImage(width, height, image.getTransparency());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BufferedImage createCompatibleImage(int width, int height)
/*     */   {
/* 170 */     return getGraphicsConfiguration().createCompatibleImage(width, height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BufferedImage createCompatibleTranslucentImage(int width, int height)
/*     */   {
/* 189 */     return getGraphicsConfiguration().createCompatibleImage(width, height, 3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BufferedImage loadCompatibleImage(URL resource)
/*     */     throws IOException
/*     */   {
/* 210 */     BufferedImage image = ImageIO.read(resource);
/* 211 */     if (image == null) {
/* 212 */       throw new IOException("Image format of resource not supported. Resource: " + resource);
/*     */     }
/* 214 */     return toCompatibleImage(image);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BufferedImage loadCompatibleTranslucentImage(URL resource)
/*     */     throws IOException
/*     */   {
/* 234 */     BufferedImage image = ImageIO.read(resource);
/* 235 */     if (image == null) {
/* 236 */       throw new IOException("Image format of resource not supported. Resource: " + resource);
/*     */     }
/* 238 */     return toCompatibleTranslucentImage(image);
/*     */   }
/*     */   
/*     */ 
/*     */   public static BufferedImage loadCompatibleTranslucentImage(byte[] imageData)
/*     */     throws IOException
/*     */   {
/* 245 */     BufferedImage image = ImageIO.read(new ByteArrayInputStream(imageData));
/* 246 */     if (image == null) {
/* 247 */       throw new IOException("Image format of byte data not supported");
/*     */     }
/* 249 */     return toCompatibleTranslucentImage(image);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BufferedImage toCompatibleImage(BufferedImage image)
/*     */   {
/* 267 */     if (image.getColorModel().equals(getGraphicsConfiguration().getColorModel()))
/*     */     {
/* 269 */       return image;
/*     */     }
/*     */     
/* 272 */     BufferedImage compatibleImage = getGraphicsConfiguration().createCompatibleImage(image.getWidth(), image.getHeight(), image.getTransparency());
/*     */     
/*     */ 
/*     */ 
/* 276 */     Graphics g = compatibleImage.getGraphics();
/* 277 */     g.drawImage(image, 0, 0, null);
/* 278 */     g.dispose();
/*     */     
/* 280 */     return compatibleImage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BufferedImage toCompatibleTranslucentImage(BufferedImage image)
/*     */   {
/* 302 */     if ((image.getColorModel().equals(getGraphicsConfiguration().getColorModel())) && (image.getColorModel().hasAlpha()))
/*     */     {
/* 304 */       return image;
/*     */     }
/*     */     
/* 307 */     BufferedImage compatibleImage = getGraphicsConfiguration().createCompatibleImage(image.getWidth(), image.getHeight(), 3);
/*     */     
/*     */ 
/* 310 */     Graphics g = compatibleImage.getGraphics();
/* 311 */     g.drawImage(image, 0, 0, null);
/* 312 */     g.dispose();
/*     */     
/* 314 */     return compatibleImage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BufferedImage createThumbnailFast(BufferedImage image, int newSize)
/*     */   {
/* 342 */     int width = image.getWidth();
/* 343 */     int height = image.getHeight();
/*     */     
/* 345 */     if (width > height) {
/* 346 */       if (newSize >= width) {
/* 347 */         throw new IllegalArgumentException("newSize must be lower than the image width");
/*     */       }
/* 349 */       if (newSize <= 0) {
/* 350 */         throw new IllegalArgumentException("newSize must be greater than 0");
/*     */       }
/*     */       
/*     */ 
/* 354 */       float ratio = width / height;
/* 355 */       width = newSize;
/* 356 */       height = (int)(newSize / ratio);
/*     */     } else {
/* 358 */       if (newSize >= height) {
/* 359 */         throw new IllegalArgumentException("newSize must be lower than the image height");
/*     */       }
/* 361 */       if (newSize <= 0) {
/* 362 */         throw new IllegalArgumentException("newSize must be greater than 0");
/*     */       }
/*     */       
/*     */ 
/* 366 */       float ratio = height / width;
/* 367 */       height = newSize;
/* 368 */       width = (int)(newSize / ratio);
/*     */     }
/*     */     
/* 371 */     BufferedImage temp = createCompatibleImage(image, width, height);
/* 372 */     Graphics2D g2 = temp.createGraphics();
/* 373 */     g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/*     */     
/* 375 */     g2.drawImage(image, 0, 0, temp.getWidth(), temp.getHeight(), null);
/* 376 */     g2.dispose();
/*     */     
/* 378 */     return temp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BufferedImage createThumbnailFast(BufferedImage image, int newWidth, int newHeight)
/*     */   {
/* 405 */     if ((newWidth >= image.getWidth()) || (newHeight >= image.getHeight()))
/*     */     {
/* 407 */       throw new IllegalArgumentException("newWidth and newHeight cannot be greater than the image dimensions");
/*     */     }
/*     */     
/* 410 */     if ((newWidth <= 0) || (newHeight <= 0)) {
/* 411 */       throw new IllegalArgumentException("newWidth and newHeight must be greater than 0");
/*     */     }
/*     */     
/*     */ 
/* 415 */     BufferedImage temp = createCompatibleImage(image, newWidth, newHeight);
/* 416 */     Graphics2D g2 = temp.createGraphics();
/* 417 */     g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/*     */     
/* 419 */     g2.drawImage(image, 0, 0, temp.getWidth(), temp.getHeight(), null);
/* 420 */     g2.dispose();
/*     */     
/* 422 */     return temp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BufferedImage createThumbnail(BufferedImage image, int newSize)
/*     */   {
/* 448 */     int width = image.getWidth();
/* 449 */     int height = image.getHeight();
/*     */     
/* 451 */     boolean isWidthGreater = width > height;
/*     */     
/* 453 */     if (isWidthGreater) {
/* 454 */       if (newSize >= width) {
/* 455 */         throw new IllegalArgumentException("newSize must be lower than the image width");
/*     */       }
/*     */     }
/* 458 */     else if (newSize >= height) {
/* 459 */       throw new IllegalArgumentException("newSize must be lower than the image height");
/*     */     }
/*     */     
/*     */ 
/* 463 */     if (newSize <= 0) {
/* 464 */       throw new IllegalArgumentException("newSize must be greater than 0");
/*     */     }
/*     */     
/*     */ 
/* 468 */     float ratioWH = width / height;
/* 469 */     float ratioHW = height / width;
/*     */     
/* 471 */     BufferedImage thumb = image;
/*     */     do
/*     */     {
/* 474 */       if (isWidthGreater) {
/* 475 */         width /= 2;
/* 476 */         if (width < newSize) {
/* 477 */           width = newSize;
/*     */         }
/* 479 */         height = (int)(width / ratioWH);
/*     */       } else {
/* 481 */         height /= 2;
/* 482 */         if (height < newSize) {
/* 483 */           height = newSize;
/*     */         }
/* 485 */         width = (int)(height / ratioHW);
/*     */       }
/*     */       
/*     */ 
/* 489 */       BufferedImage temp = createCompatibleImage(image, width, height);
/* 490 */       Graphics2D g2 = temp.createGraphics();
/* 491 */       g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/*     */       
/* 493 */       g2.drawImage(thumb, 0, 0, temp.getWidth(), temp.getHeight(), null);
/* 494 */       g2.dispose();
/*     */       
/* 496 */       thumb = temp;
/* 497 */     } while (newSize != (isWidthGreater ? width : height));
/*     */     
/* 499 */     return thumb;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BufferedImage createThumbnail(BufferedImage image, int newWidth, int newHeight)
/*     */   {
/* 524 */     int width = image.getWidth();
/* 525 */     int height = image.getHeight();
/*     */     
/* 527 */     if ((newWidth >= width) || (newHeight >= height)) {
/* 528 */       throw new IllegalArgumentException("newWidth and newHeight cannot be greater than the image dimensions");
/*     */     }
/*     */     
/* 531 */     if ((newWidth <= 0) || (newHeight <= 0)) {
/* 532 */       throw new IllegalArgumentException("newWidth and newHeight must be greater than 0");
/*     */     }
/*     */     
/*     */ 
/* 536 */     BufferedImage thumb = image;
/*     */     do
/*     */     {
/* 539 */       if (width > newWidth) {
/* 540 */         width /= 2;
/* 541 */         if (width < newWidth) {
/* 542 */           width = newWidth;
/*     */         }
/*     */       }
/*     */       
/* 546 */       if (height > newHeight) {
/* 547 */         height /= 2;
/* 548 */         if (height < newHeight) {
/* 549 */           height = newHeight;
/*     */         }
/*     */       }
/*     */       
/* 553 */       BufferedImage temp = createCompatibleImage(image, width, height);
/* 554 */       Graphics2D g2 = temp.createGraphics();
/* 555 */       g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/*     */       
/* 557 */       g2.drawImage(thumb, 0, 0, temp.getWidth(), temp.getHeight(), null);
/* 558 */       g2.dispose();
/*     */       
/* 560 */       thumb = temp;
/* 561 */     } while ((width != newWidth) || (height != newHeight));
/*     */     
/* 563 */     return thumb;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int[] getPixels(BufferedImage img, int x, int y, int w, int h, int[] pixels)
/*     */   {
/* 586 */     if ((w == 0) || (h == 0)) {
/* 587 */       return new int[0];
/*     */     }
/*     */     
/* 590 */     if (pixels == null) {
/* 591 */       pixels = new int[w * h];
/* 592 */     } else if (pixels.length < w * h) {
/* 593 */       throw new IllegalArgumentException("pixels array must have a length >= w*h");
/*     */     }
/*     */     
/*     */ 
/* 597 */     int imageType = img.getType();
/* 598 */     if ((imageType == 2) || (imageType == 1))
/*     */     {
/* 600 */       Raster raster = img.getRaster();
/* 601 */       return (int[])raster.getDataElements(x, y, w, h, pixels);
/*     */     }
/*     */     
/*     */ 
/* 605 */     return img.getRGB(x, y, w, h, pixels, 0, w);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setPixels(BufferedImage img, int x, int y, int w, int h, int[] pixels)
/*     */   {
/* 625 */     if ((pixels == null) || (w == 0) || (h == 0))
/* 626 */       return;
/* 627 */     if (pixels.length < w * h) {
/* 628 */       throw new IllegalArgumentException("pixels array must have a length >= w*h");
/*     */     }
/*     */     
/*     */ 
/* 632 */     int imageType = img.getType();
/* 633 */     if ((imageType == 2) || (imageType == 1))
/*     */     {
/* 635 */       WritableRaster raster = img.getRaster();
/* 636 */       raster.setDataElements(x, y, w, h, pixels);
/*     */     }
/*     */     else {
/* 639 */       img.setRGB(x, y, w, h, pixels, 0, w);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void drawOutlinedText(Graphics2D g, MultiLineStringDimensions d, Color foreground, Color outline)
/*     */   {
/* 652 */     if (foreground == null) {
/* 653 */       foreground = Color.BLACK;
/*     */     }
/* 655 */     g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */     
/* 657 */     for (int i = 0; i < d.lineShapes.length; i++) {
/* 658 */       g.setColor(foreground);
/*     */       
/* 660 */       g.fill(d.lineShapes[i]);
/* 661 */       if (outline != null)
/*     */       {
/* 663 */         g.setColor(outline);
/* 664 */         g.draw(d.lineShapes[i]);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static double getStringHeight(Graphics2D g, String str)
/*     */   {
/* 674 */     FontRenderContext frc = g.getFontRenderContext();
/* 675 */     GlyphVector gv = g.getFont().createGlyphVector(frc, str);
/* 676 */     return gv.getPixelBounds(null, 0.0F, 0.0F).getHeight();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void setFontOfPixelHeight(Graphics2D g, int style, double targetSize)
/*     */   {
/* 691 */     Font font = new Font("SansSerif", style, 1);
/*     */     
/* 693 */     for (int i = 1; i < targetSize; i++)
/*     */     {
/* 695 */       Font bigger = font.deriveFont(i);
/* 696 */       g.setFont(bigger);
/*     */       
/* 698 */       if (bigger.getLineMetrics("WBLMNqpyg", g.getFontRenderContext()).getHeight() >= targetSize)
/*     */         break;
/* 700 */       font = bigger;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 707 */     g.setFont(font);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String[] splitLines(String string)
/*     */   {
/* 714 */     return string.replaceAll("\r", "").split("\n");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MultiLineStringDimensions getMultiLineStringDimensions(String[] lines, int style, double size)
/*     */   {
/* 729 */     BufferedImage image = createCompatibleTranslucentImage(1, 1);
/* 730 */     MultiLineStringDimensions r = new MultiLineStringDimensions(lines.length);
/* 731 */     Graphics2D g = (Graphics2D)image.getGraphics();
/* 732 */     g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 733 */     setFontOfPixelHeight(g, style, size);
/*     */     
/* 735 */     FontRenderContext frc = g.getFontRenderContext();
/* 736 */     Rectangle2D[] lineBounds = new Rectangle2D[lines.length];
/* 737 */     int maxX = 1;
/* 738 */     int y = 0;
/* 739 */     for (int i = 0; i < lines.length; i++)
/*     */     {
/* 741 */       lineBounds[i] = g.getFontMetrics().getStringBounds(lines[i], g);
/* 742 */       maxX = Math.max(maxX, (int)Math.ceil(lineBounds[i].getWidth()));
/* 743 */       y = (int)(y + Math.ceil(lineBounds[i].getHeight()));
/*     */     }
/* 745 */     y = Math.max(y + 1, 1);
/* 746 */     r.overallBounds = new Dimension(maxX, y);
/*     */     
/* 748 */     y = 0;
/* 749 */     for (int i = 0; i < lines.length; i++)
/*     */     {
/*     */ 
/* 752 */       AffineTransform translate = AffineTransform.getTranslateInstance((r.overallBounds.getWidth() - lineBounds[i].getWidth()) / 2.0D, y - lineBounds[i].getMinY());
/* 753 */       r.lineShapes[i] = new TextLayout(!lines[i].isEmpty() ? lines[i] : " ", g.getFont(), frc).getOutline(translate);
/* 754 */       y = (int)(y + Math.ceil(lineBounds[i].getHeight()));
/*     */     }
/*     */     
/*     */ 
/* 758 */     g.dispose();
/*     */     
/* 760 */     return r;
/*     */   }
/*     */   
/*     */   public static class MultiLineStringDimensions
/*     */   {
/*     */     private Shape[] lineShapes;
/*     */     private Dimension overallBounds;
/*     */     
/*     */     public MultiLineStringDimensions(int length)
/*     */     {
/* 770 */       this.lineShapes = new Shape[length];
/*     */     }
/*     */     
/*     */     public int getWidth()
/*     */     {
/* 775 */       return this.overallBounds.width;
/*     */     }
/*     */     
/*     */     public int getHeight()
/*     */     {
/* 780 */       return this.overallBounds.height;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\util\GraphicsUtilities.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */