/*     */ package greenfoot.util;
/*     */ 
/*     */ import bluej.Boot;
/*     */ import bluej.Config;
/*     */ import bluej.utility.Utility;
/*     */ import greenfoot.GreenfootImage;
/*     */ import greenfoot.UserInfo;
/*     */ import greenfoot.core.ImageCache;
/*     */ import greenfoot.platforms.GreenfootUtilDelegate;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.color.ColorSpace;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.font.TextAttribute;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorConvertOp;
/*     */ import java.awt.image.ImageObserver;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GreenfootUtil
/*     */ {
/*     */   public static final int X_AXIS = 0;
/*     */   public static final int Y_AXIS = 1;
/*     */   private static GreenfootUtilDelegate delegate;
/*     */   private static ImageCache imageCache;
/*  87 */   private static final Color urlColor = new Color(0, 90, 200);
/*     */   
/*  89 */   private static boolean haveCheckedForMp3 = false;
/*  90 */   private static boolean mp3available = false;
/*     */   
/*     */   public static void initialise(GreenfootUtilDelegate newDelegate)
/*     */   {
/*  94 */     delegate = newDelegate;
/*  95 */     imageCache = ImageCache.getInstance();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String extractClassName(String qualifiedName)
/*     */   {
/* 103 */     int index = qualifiedName.lastIndexOf('.');
/* 104 */     String name = qualifiedName;
/* 105 */     if (index >= 0) {
/* 106 */       name = qualifiedName.substring(index + 1);
/*     */     }
/* 108 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String extractPackageName(String qualifiedName)
/*     */   {
/* 116 */     int index = qualifiedName.lastIndexOf('.');
/* 117 */     String name = "";
/* 118 */     if (index >= 0) {
/* 119 */       name = qualifiedName.substring(0, index);
/*     */     }
/* 121 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JComponent createSpacer(int axis, int width)
/*     */   {
/* 133 */     JPanel spacer = new JPanel();
/*     */     
/* 135 */     spacer.setMinimumSize(new Dimension(0, 0));
/*     */     
/* 137 */     Dimension size = new Dimension();
/*     */     
/*     */ 
/* 140 */     size.width = 0;
/* 141 */     size.height = 0;
/* 142 */     if (axis == 0) {
/* 143 */       size.width = width;
/*     */     }
/*     */     else {
/* 146 */       size.height = width;
/*     */     }
/* 148 */     spacer.setPreferredSize(size);
/*     */     
/*     */ 
/* 151 */     spacer.setMaximumSize(size);
/*     */     
/* 153 */     spacer.setBorder(null);
/*     */     
/* 155 */     return spacer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JLabel createHelpLabel()
/*     */   {
/* 163 */     JLabel helpLabel = new JLabel();
/* 164 */     Font smallFont = helpLabel.getFont().deriveFont(2, 11.0F);
/* 165 */     helpLabel.setFont(smallFont);
/* 166 */     return helpLabel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isImage(File file)
/*     */   {
/*     */     try
/*     */     {
/* 178 */       BufferedImage img = ImageIO.read(file);
/* 179 */       if (img == null) return false;
/* 180 */       return true;
/*     */     }
/*     */     catch (Exception ex) {}
/* 183 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Image getScaledImage(Image inputImage, int w, int h)
/*     */   {
/* 199 */     ImageWaiter waiter = new ImageWaiter(inputImage);
/*     */     
/* 201 */     waiter.waitDimensions();
/* 202 */     int inputw = waiter.width;
/* 203 */     int inputh = waiter.height;
/*     */     
/*     */ 
/* 206 */     if ((w == inputw) && (h == inputh)) {
/* 207 */       return inputImage;
/*     */     }
/*     */     
/*     */ 
/* 211 */     BufferedImage rImage = GraphicsUtilities.createCompatibleTranslucentImage(w, h);
/* 212 */     Graphics2D graphics = rImage.createGraphics();
/*     */     
/* 214 */     graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/*     */     
/*     */ 
/*     */ 
/* 218 */     if ((inputw <= w) && (inputh <= h)) {
/* 219 */       int xoffs = (w - inputw) / 2;
/* 220 */       int yoffs = (h - inputh) / 2;
/*     */       
/* 222 */       waiter.drawWait(graphics, xoffs, yoffs);
/*     */     }
/*     */     else
/*     */     {
/* 226 */       float xscale = w / inputw;
/* 227 */       float yscale = h / inputh;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 232 */       float scale = xscale < yscale ? xscale : yscale;
/*     */       
/*     */ 
/* 235 */       int neww = (int)(inputw * scale);
/* 236 */       int newh = (int)(inputh * scale);
/* 237 */       if (neww > inputw) {
/* 238 */         neww = inputw;
/*     */       }
/* 240 */       if (newh > inputh) {
/* 241 */         newh = inputh;
/*     */       }
/* 243 */       if (neww < 1) {
/* 244 */         neww = 1;
/*     */       }
/* 246 */       if (newh < 1) {
/* 247 */         newh = 1;
/*     */       }
/* 249 */       if ((neww < w) && (newh < h)) {
/* 250 */         neww++;newh++;
/*     */       }
/*     */       
/*     */ 
/* 254 */       int xoffs = (w - neww) / 2;
/* 255 */       int yoffs = (h - newh) / 2;
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 260 */         waiter.drawWait(graphics, xoffs, yoffs, neww, newh);
/*     */       }
/*     */       catch (OutOfMemoryError oome)
/*     */       {
/* 264 */         graphics.setColor(Color.white);
/* 265 */         graphics.fillRect(1, 1, w - 2, h - 2);
/* 266 */         graphics.setColor(Color.red);
/* 267 */         graphics.drawRect(0, 0, w - 1, h - 1);
/* 268 */         graphics.drawLine(0, 0, w, h);
/* 269 */         graphics.drawLine(0, h, w, 0);
/*     */       }
/*     */     }
/* 272 */     graphics.dispose();
/* 273 */     return rImage;
/*     */   }
/*     */   
/*     */ 
/*     */   public static class ImageWaiter
/*     */     implements ImageObserver
/*     */   {
/*     */     public int width;
/*     */     
/*     */     public int height;
/*     */     
/*     */     public boolean done;
/*     */     
/*     */     public boolean gotDimensions;
/*     */     
/*     */     public Image src;
/*     */     
/*     */ 
/*     */     public ImageWaiter(Image src)
/*     */     {
/* 293 */       this.src = src;
/* 294 */       this.done = false;
/* 295 */       this.gotDimensions = false;
/* 296 */       synchronized (this) {
/* 297 */         this.width = src.getWidth(this);
/* 298 */         this.height = src.getHeight(this);
/* 299 */         if ((this.width != -1) && (this.height != -1)) {
/* 300 */           this.gotDimensions = true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public synchronized void waitDimensions()
/*     */     {
/*     */       try
/*     */       {
/* 311 */         while (!this.gotDimensions) {
/* 312 */           wait();
/*     */         }
/*     */       }
/*     */       catch (InterruptedException ie) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public synchronized void drawWait(Graphics canvas, int x, int y)
/*     */     {
/* 328 */       this.done = canvas.drawImage(this.src, x, y, this);
/*     */       try {
/* 330 */         while (!this.done) {
/* 331 */           wait();
/*     */         }
/*     */       }
/*     */       catch (InterruptedException ie) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public synchronized void drawWait(Graphics canvas, int x, int y, int w, int h)
/*     */     {
/* 349 */       this.done = canvas.drawImage(this.src, x, y, w, h, this);
/*     */       try {
/* 351 */         while (!this.done) {
/* 352 */           wait();
/*     */         }
/*     */       }
/*     */       catch (InterruptedException ie) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public synchronized boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height)
/*     */     {
/* 369 */       if (!this.gotDimensions) {
/* 370 */         if ((infoflags & 0x1) != 0) {
/* 371 */           this.width = width;
/*     */         }
/*     */         
/* 374 */         if ((infoflags & 0x2) != 0) {
/* 375 */           this.height = height;
/*     */         }
/*     */         
/* 378 */         if ((this.width != -1) && (this.height != -1)) {
/* 379 */           this.gotDimensions = true;
/* 380 */           notify();
/* 381 */           return false;
/*     */         }
/*     */         
/* 384 */         return true;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 389 */       if ((infoflags & 0xF0) != 0) {
/* 390 */         this.done = true;
/* 391 */         notify();
/* 392 */         return false;
/*     */       }
/*     */       
/* 395 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void copyDir(File src, File dst)
/*     */   {
/* 405 */     if (!src.isDirectory()) {
/* 406 */       return;
/*     */     }
/* 408 */     if (!dst.exists()) {
/* 409 */       dst.mkdirs();
/*     */     }
/* 411 */     File[] files = src.listFiles();
/* 412 */     for (int i = 0; i < files.length; i++) {
/* 413 */       File file = files[i];
/* 414 */       File newDst = new File(dst, file.getName());
/* 415 */       if (file.isDirectory()) {
/* 416 */         copyDir(file, newDst);
/*     */       }
/*     */       else {
/* 419 */         copyFile(file, newDst);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void copyFile(File src, File dst)
/*     */   {
/* 435 */     if ((!src.isFile()) || (dst.isDirectory())) {
/* 436 */       return;
/*     */     }
/* 438 */     dst.getParentFile().mkdirs();
/* 439 */     if (dst.exists()) {
/* 440 */       dst.delete();
/*     */     }
/*     */     try {
/* 443 */       BufferedInputStream is = new BufferedInputStream(new FileInputStream(src));
/* 444 */       BufferedOutputStream os = new BufferedOutputStream(new FileOutputStream(dst));
/*     */       
/* 446 */       byte[] buffer = new byte[' '];
/* 447 */       int read = 0;
/* 448 */       while (read != -1) {
/* 449 */         os.write(buffer, 0, read);
/* 450 */         read = is.read(buffer);
/*     */       }
/* 452 */       os.flush();
/* 453 */       is.close();
/* 454 */       os.close();
/*     */     } catch (FileNotFoundException ex) {
/* 456 */       ex = 
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 464 */         ex;ex.printStackTrace();
/*     */     } catch (IOException e) {
/* 459 */       e = 
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 464 */         e;e.printStackTrace();
/*     */     }
/*     */     finally {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Iterable<String> getSoundFiles()
/*     */   {
/* 473 */     return delegate.getSoundFiles();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static URL getURL(String filename, String dir)
/*     */     throws FileNotFoundException
/*     */   {
/* 487 */     if (filename == null) {
/* 488 */       throw new NullPointerException("Filename must not be null.");
/*     */     }
/*     */     
/* 491 */     URL url = delegate.getResource(dir + "/" + filename);
/*     */     
/* 493 */     if (url == null) {
/* 494 */       url = delegate.getResource(filename);
/*     */     }
/* 496 */     if (url == null)
/*     */     {
/* 498 */       File f = new File(filename);
/*     */       try
/*     */       {
/* 501 */         if (f.canRead()) {
/* 502 */           url = f.toURI().toURL();
/*     */         }
/*     */       }
/*     */       catch (MalformedURLException e) {}catch (SecurityException se) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 512 */     if (url == null)
/*     */     {
/* 514 */       InputStream s = null;
/*     */       try {
/* 516 */         url = new URL(filename);
/* 517 */         s = url.openStream();
/* 518 */         s.close();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 526 */         if (s != null) {
/*     */           try {
/* 528 */             s.close();
/*     */           }
/*     */           catch (IOException e) {}
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 536 */         checkCase(url);
/*     */       }
/*     */       catch (MalformedURLException e)
/*     */       {
/* 521 */         url = null;
/*     */       }
/*     */       catch (IOException e) {
/* 524 */         url = null;
/*     */       } finally {
/* 526 */         if (s != null) {
/*     */           try {
/* 528 */             s.close();
/*     */           }
/*     */           catch (IOException e) {}
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 538 */     if (url == null) {
/* 539 */       throw new FileNotFoundException("Could not find file: " + filename);
/*     */     }
/* 541 */     return url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void checkCase(URL url)
/*     */   {
/* 553 */     if (url != null) {
/* 554 */       String errMsg = null;
/*     */       try {
/* 556 */         File f = new File(url.toURI());
/* 557 */         String givenName = f.getName();
/* 558 */         String realName = f.getCanonicalFile().getName();
/* 559 */         if ((!realName.equals(givenName)) && (realName.equalsIgnoreCase(givenName))) {
/* 560 */           errMsg = "Filename '" + givenName + "' has the wrong case. It should be: '" + realName + "'";
/*     */         }
/*     */       }
/*     */       catch (Throwable e) {}
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 568 */       if (errMsg != null) {
/* 569 */         throw new IllegalArgumentException(errMsg);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getGreenfootLogoPath()
/*     */   {
/* 579 */     return delegate.getGreenfootLogoPath();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean canBeInstantiated(Class<?> cls)
/*     */   {
/* 591 */     if (cls == null) {
/* 592 */       return false;
/*     */     }
/* 594 */     if ((cls.isEnum()) || (cls.isInterface())) {
/* 595 */       return false;
/*     */     }
/* 597 */     return !Modifier.isAbstract(cls.getModifiers());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BufferedImage createDragShadow(BufferedImage image)
/*     */   {
/* 605 */     BufferedImage dragImage = ShadowRenderer.createDropShadow(image, 3, 0.3F, Color.BLACK);
/* 606 */     Graphics2D g2 = dragImage.createGraphics();
/* 607 */     g2.drawImage(image, 0, 0, null);
/* 608 */     g2.dispose();
/* 609 */     return dragImage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JButton createButton(Action action)
/*     */   {
/* 617 */     JButton button = new JButton(action);
/* 618 */     button.setFocusable(false);
/* 619 */     return button;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Font deriveUnderlinedFont(Font f)
/*     */   {
/* 628 */     Map attr = f.getAttributes();
/* 629 */     attr.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
/* 630 */     Font underLineFont = f.deriveFont(attr);
/* 631 */     return underLineFont;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void makeLink(JLabel label, String url)
/*     */   {
/* 644 */     label.setCursor(new Cursor(12));
/* 645 */     label.setForeground(urlColor);
/* 646 */     Font f = label.getFont();
/* 647 */     Font underLineFont = deriveUnderlinedFont(f);
/* 648 */     label.setFont(underLineFont);
/* 649 */     label.addMouseListener(new MouseAdapter()
/*     */     {
/*     */       public void mouseClicked(MouseEvent e) {
/* 652 */         Utility.openWebBrowser(this.val$url);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void makeGreenfootTitle(Frame frame)
/*     */   {
/* 664 */     String title = frame.getTitle();
/* 665 */     String newTitle = title.replaceAll("BlueJ", "Greenfoot");
/* 666 */     frame.setTitle(newTitle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static File getGreenfootDir()
/*     */     throws IOException
/*     */   {
/* 680 */     File libDir = Config.getBlueJLibDir();
/*     */     
/* 682 */     File greenfootDir = libDir.getParentFile();
/*     */     
/* 684 */     if ((Config.isMacOS()) && (greenfootDir != null) && (greenfootDir.toString().endsWith(".app/Contents/Resources"))) {
/* 685 */       greenfootDir = greenfootDir.getParentFile().getParentFile().getParentFile();
/*     */     }
/* 687 */     if ((greenfootDir == null) || (!greenfootDir.isDirectory()) || (!greenfootDir.canRead())) {
/* 688 */       throw new IOException("Could not read from greenfoot directory: " + greenfootDir);
/*     */     }
/* 690 */     return greenfootDir;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void showApiDoc(String page)
/*     */     throws IOException
/*     */   {
/* 701 */     String customUrl = Config.getPropString("greenfoot.url.javadoc", null);
/* 702 */     if (customUrl != null) {
/* 703 */       Utility.openWebBrowser(customUrl);
/*     */     }
/*     */     else {
/* 706 */       File greenfootDir = getGreenfootDir();
/* 707 */       File location = new File(greenfootDir, "/doc/API/" + page);
/* 708 */       if (location.canRead()) {
/* 709 */         Utility.openWebBrowser(location);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Set<File> get3rdPartyLibs()
/*     */   {
/* 720 */     File bluejLibDir = Config.getBlueJLibDir();
/* 721 */     String[] thirdPartyLibs = Boot.GREENFOOT_EXPORT_JARS;
/* 722 */     Set<File> jars = new TreeSet();
/* 723 */     for (String lib : thirdPartyLibs) {
/* 724 */       jars.add(new File(bluejLibDir, lib));
/*     */     }
/* 726 */     return jars;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isMp3LibAvailable()
/*     */   {
/* 734 */     if (!haveCheckedForMp3) {
/* 735 */       URL url = delegate.getResource("javazoom/jl/decoder/BitstreamException.class");
/* 736 */       mp3available = url != null;
/* 737 */       haveCheckedForMp3 = true;
/*     */     }
/* 739 */     return mp3available;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static File createNumberedFile(File dir, String name, String type)
/*     */     throws IOException
/*     */   {
/* 756 */     File f = new File(dir, name + "." + type);
/* 757 */     int number = 1;
/* 758 */     while (!f.createNewFile()) {
/* 759 */       String numberString = null;
/* 760 */       if (number < 10) {
/* 761 */         numberString = "0" + number;
/*     */       }
/*     */       else {
/* 764 */         numberString = "" + number;
/*     */       }
/* 766 */       f = new File(dir, name + numberString + "." + type);
/* 767 */       number++;
/*     */     }
/* 769 */     return f;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static GreenfootImage getGreenfootImage(String className, String imageName)
/*     */   {
/* 781 */     GreenfootImage image = null;
/* 782 */     if (imageName == null) {
/* 783 */       return image;
/*     */     }
/* 785 */     if (isInvalidImageFilename(imageName)) {
/* 786 */       return image;
/*     */     }
/*     */     
/* 789 */     if (className.equals("Actor")) {
/* 790 */       return new GreenfootImage(getGreenfootLogoPath());
/*     */     }
/*     */     try {
/* 793 */       image = new GreenfootImage(imageName);
/*     */     }
/*     */     catch (IllegalArgumentException iae) {}
/*     */     
/*     */ 
/* 798 */     return image;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void removeCachedImage(String className)
/*     */   {
/* 807 */     imageCache.removeCachedImage(className);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean addCachedImage(String name, GreenfootImage image)
/*     */   {
/* 817 */     return imageCache.addCachedImage(name, image);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static GreenfootImage getCachedImage(String name)
/*     */   {
/* 829 */     return imageCache.getCachedImage(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isInvalidImageFilename(String fileName)
/*     */   {
/* 837 */     return imageCache.isNullCachedImage(fileName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void displayMessage(Component parent, String messageText)
/*     */   {
/* 850 */     delegate.displayMessage(parent, messageText);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String removeExtension(String full)
/*     */   {
/* 861 */     int n = full.lastIndexOf('.');
/* 862 */     if (n == -1) {
/* 863 */       return full;
/*     */     }
/*     */     
/* 866 */     return full.substring(0, n);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isStorageSupported()
/*     */   {
/* 875 */     return delegate.isStorageSupported();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UserInfo getCurrentUserInfo()
/*     */   {
/* 883 */     return delegate.getCurrentUserInfo();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean storeCurrentUserInfo(UserInfo data)
/*     */   {
/* 891 */     if (data.getUserName().equals(getUserName())) {
/* 892 */       return delegate.storeCurrentUserInfo(data);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 897 */     System.err.println("Attempted to store the data for another user, \"" + data.getUserName() + "\" (i.e. a user other than the current user, \"" + getUserName() + "\")");
/* 898 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<UserInfo> getTopUserInfo(int limit)
/*     */   {
/* 909 */     return delegate.getTopUserInfo(limit);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static GreenfootImage getUserImage(String userName)
/*     */   {
/* 917 */     if ((userName == null) || (userName.equals(""))) {
/* 918 */       userName = getUserName();
/*     */     }
/*     */     
/* 921 */     GreenfootImage r = null;
/*     */     
/* 923 */     if (userName != null) {
/* 924 */       r = delegate.getUserImage(userName);
/*     */     }
/*     */     
/* 927 */     if (r == null)
/*     */     {
/*     */ 
/*     */ 
/* 931 */       r = new GreenfootImage(50, 50);
/* 932 */       r.setColor(Color.DARK_GRAY);
/* 933 */       r.fill();
/*     */       
/* 935 */       int CHARS_PER_LINE = 6;
/*     */       
/* 937 */       StringBuilder wrappedName = new StringBuilder();
/* 938 */       if (userName == null)
/* 939 */         userName = "";
/* 940 */       for (int i = 0; i < userName.length(); i += 6) {
/* 941 */         wrappedName.append(userName.substring(i, Math.min(userName.length(), i + 6))).append("\n");
/*     */       }
/* 943 */       GreenfootImage textImage = new GreenfootImage(wrappedName.toString(), 15, Color.WHITE, Color.DARK_GRAY);
/* 944 */       r.drawImage(textImage, Math.max(0, (50 - textImage.getWidth()) / 2), Math.max(0, (50 - textImage.getHeight()) / 2));
/*     */     }
/*     */     
/* 947 */     return r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getUserName()
/*     */   {
/* 955 */     return delegate.getUserName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<UserInfo> getNearbyUserData(int maxAmount)
/*     */   {
/* 965 */     return delegate.getNearbyUserInfo(maxAmount);
/*     */   }
/*     */   
/*     */ 
/*     */   public static BufferedImage convertToGreyImage(BufferedImage image)
/*     */   {
/* 971 */     return new ColorConvertOp(ColorSpace.getInstance(1003), null).filter(image, image);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\util\GreenfootUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */