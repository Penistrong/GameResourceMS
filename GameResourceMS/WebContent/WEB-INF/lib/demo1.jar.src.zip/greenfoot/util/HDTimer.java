/*     */ package greenfoot.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HDTimer
/*     */ {
/*     */   private static Long sleepPrecision;
/*     */   private static long worstYieldTime;
/*     */   private static boolean inited;
/*     */   private static Long waitPrecision;
/*     */   
/*     */   public static synchronized void init()
/*     */   {
/*  48 */     if (!inited) {
/*  49 */       measureSleepPrecision();
/*  50 */       measureWaitPrecision();
/*  51 */       inited = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private static void measureSleepPrecision()
/*     */   {
/*  57 */     int testSize = 11;
/*  58 */     List<Long> tests = new ArrayList();
/*     */     try
/*     */     {
/*  61 */       for (int i = 0; i < testSize; i++) {
/*  62 */         long t1 = System.nanoTime();
/*  63 */         Thread.sleep(0L, 1);
/*  64 */         long t2 = System.nanoTime();
/*  65 */         tests.add(Long.valueOf(t2 - t1));
/*     */       }
/*     */     }
/*     */     catch (InterruptedException e) {
/*  69 */       e.printStackTrace();
/*     */     }
/*  71 */     Collections.sort(tests);
/*  72 */     sleepPrecision = (Long)tests.get(testSize / 2);
/*     */   }
/*     */   
/*     */   private static void measureWaitPrecision()
/*     */   {
/*  77 */     int testSize = 11;
/*  78 */     List<Long> tests = new ArrayList();
/*  79 */     Object lock = new Object();
/*     */     try {
/*  81 */       synchronized (lock) {
/*  82 */         for (int i = 0; i < testSize; i++) {
/*  83 */           long t1 = System.nanoTime();
/*  84 */           lock.wait(0L, 1);
/*  85 */           long t2 = System.nanoTime();
/*  86 */           tests.add(Long.valueOf(t2 - t1));
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (InterruptedException e) {
/*  91 */       e.printStackTrace();
/*     */     }
/*  93 */     Collections.sort(tests);
/*  94 */     waitPrecision = (Long)tests.get(testSize / 2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void sleep(long nanos)
/*     */     throws InterruptedException
/*     */   {
/* 108 */     long tStart = System.nanoTime();
/* 109 */     sleepFromTime(nanos, tStart);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void sleepFromTime(long nanos, long tStart)
/*     */     throws InterruptedException
/*     */   {
/* 125 */     long sleepNanos = nanos - sleepPrecision.longValue();
/*     */     
/*     */ 
/* 128 */     if (nanos / sleepPrecision.longValue() >= 2L) {
/* 129 */       long actualDelayMillis = sleepNanos / 1000000L;
/* 130 */       int nanoRest = (int)(sleepNanos % 1000000L);
/* 131 */       if (Thread.interrupted()) {
/* 132 */         throw new InterruptedException("HDTimer.sleepFromTime interrupted in sleep.");
/*     */       }
/* 134 */       Thread.sleep(actualDelayMillis, nanoRest);
/*     */     }
/*     */     
/*     */ 
/* 138 */     while (System.nanoTime() - tStart + worstYieldTime < nanos) {
/* 139 */       long t1 = System.nanoTime();
/* 140 */       if (Thread.interrupted()) {
/* 141 */         throw new InterruptedException("HDTimer.sleepFromTime interrupted in yield.");
/*     */       }
/* 143 */       Thread.yield();
/* 144 */       long yieldTime = System.nanoTime() - t1;
/* 145 */       if (yieldTime > worstYieldTime) {
/* 146 */         worstYieldTime = yieldTime;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 151 */     while (System.nanoTime() - tStart < nanos) {
/* 152 */       if (Thread.interrupted()) {
/* 153 */         throw new InterruptedException("HDTimer.sleepFromTime interrupted in busy loop.");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static void wait(long nanos, Object lock)
/*     */     throws InterruptedException
/*     */   {
/* 177 */     long tStart = System.nanoTime();
/*     */     
/*     */ 
/* 180 */     long waits = 0L;
/* 181 */     while ((System.nanoTime() - tStart < nanos - waitPrecision.longValue()) || (waits == 0L)) {
/* 182 */       long waitNanos = tStart - System.nanoTime() - waitPrecision.longValue();
/*     */       
/* 184 */       long actualDelayMillis = waitNanos / 1000000L;
/* 185 */       int nanoRest = (int)(waitNanos % 1000000L);
/* 186 */       if ((actualDelayMillis <= 0L) && (nanoRest <= 0))
/*     */       {
/*     */ 
/* 189 */         actualDelayMillis = 0L;
/* 190 */         nanoRest = 1;
/*     */       }
/* 192 */       synchronized (lock) {
/* 193 */         lock.wait(actualDelayMillis, nanoRest);
/* 194 */         waits += 1L;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 200 */     while (System.nanoTime() - tStart + worstYieldTime < nanos) {
/* 201 */       long t1 = System.nanoTime();
/* 202 */       Thread.yield();
/* 203 */       long yieldTime = System.nanoTime() - t1;
/* 204 */       if (yieldTime > worstYieldTime) {
/* 205 */         worstYieldTime = yieldTime;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 210 */     while (System.nanoTime() - tStart < nanos) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void wait(long nanos, ReentrantReadWriteLock lock)
/*     */     throws InterruptedException
/*     */   {
/* 228 */     long tStart = System.nanoTime();
/* 229 */     if (!lock.isWriteLockedByCurrentThread())
/*     */     {
/* 231 */       sleepFromTime(nanos, tStart);
/* 232 */       return;
/*     */     }
/*     */     
/*     */ 
/* 236 */     lock.writeLock().unlock();
/*     */     try {
/* 238 */       sleepFromTime(nanos, tStart);
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 243 */       lock.writeLock().lock();
/*     */     }
/*     */   }
/*     */   
/*     */   static {}
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\util\HDTimer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */