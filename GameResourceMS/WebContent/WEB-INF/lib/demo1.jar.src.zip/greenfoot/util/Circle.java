/*     */ package greenfoot.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Circle
/*     */ {
/*     */   private int x;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int y;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int radius;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Circle(int x, int y, int r)
/*     */   {
/*  39 */     if (r < 0) {
/*  40 */       throw new IllegalArgumentException("Radius must be larger than -1. It was: " + r);
/*     */     }
/*  42 */     setX(x);
/*  43 */     setY(y);
/*  44 */     setRadius(r);
/*     */   }
/*     */   
/*     */ 
/*     */   public Circle() {}
/*     */   
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/*  53 */     if ((other instanceof Circle)) {
/*  54 */       Circle oCircle = (Circle)other;
/*  55 */       return (oCircle.x == this.x) && (oCircle.y == this.y) && (oCircle.radius == this.radius);
/*     */     }
/*  57 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  62 */     int result = 17;
/*  63 */     result = 37 * result + this.x;
/*  64 */     result = 37 * result + this.y;
/*  65 */     result = 37 * result + this.radius;
/*  66 */     return result;
/*     */   }
/*     */   
/*     */   public double getVolume()
/*     */   {
/*  71 */     return 3.141592653589793D * this.radius * this.radius;
/*     */   }
/*     */   
/*     */   public void setX(int x)
/*     */   {
/*  76 */     this.x = x;
/*     */   }
/*     */   
/*     */   public int getX()
/*     */   {
/*  81 */     return this.x;
/*     */   }
/*     */   
/*     */   public void setY(int y)
/*     */   {
/*  86 */     this.y = y;
/*     */   }
/*     */   
/*     */   public int getY()
/*     */   {
/*  91 */     return this.y;
/*     */   }
/*     */   
/*     */   public void setRadius(int radius)
/*     */   {
/*  96 */     this.radius = radius;
/*     */   }
/*     */   
/*     */   public int getRadius()
/*     */   {
/* 101 */     return this.radius;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean intersects(Circle other)
/*     */   {
/* 109 */     int r1 = getRadius();
/* 110 */     int r2 = other.getRadius();
/*     */     
/* 112 */     int dx = getX() - other.getX();
/* 113 */     int dy = getY() - other.getY();
/* 114 */     int dxSq = dx * dx;
/* 115 */     int dySq = dy * dy;
/*     */     
/* 117 */     int circleDistSq = dxSq + dySq;
/*     */     
/* 119 */     if ((r1 + r2) * (r1 + r2) >= circleDistSq) {
/* 120 */       return true;
/*     */     }
/* 122 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void merge(Circle one, Circle two)
/*     */   {
/* 179 */     int dx = one.getX() - two.getX();
/* 180 */     int dy = one.getY() - two.getY();
/* 181 */     int dxSq = dx * dx;
/* 182 */     int dySq = dy * dy;
/* 183 */     int circleDistSq = dxSq + dySq;
/* 184 */     int r2 = one.getRadius() - two.getRadius();
/*     */     
/*     */ 
/* 187 */     if (r2 * r2 >= circleDistSq) {
/* 188 */       if (one.getRadius() < two.getRadius()) {
/* 189 */         setRadius(two.getRadius());
/* 190 */         setX(two.getX());
/* 191 */         setY(two.getY());
/*     */       }
/*     */       else {
/* 194 */         setRadius(one.getRadius());
/* 195 */         setX(one.getX());
/* 196 */         setY(one.getY());
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 201 */       double circleDist = Math.sqrt(circleDistSq);
/* 202 */       double r = (circleDist + one.getRadius() + two.getRadius()) / 2.0D;
/*     */       
/*     */ 
/* 205 */       setRadius((int)Math.ceil(r));
/* 206 */       if (circleDist > 0.0D) {
/* 207 */         double f = (r - one.getRadius()) / circleDist;
/* 208 */         setX(one.getX() - (int)Math.ceil(f * dx));
/* 209 */         setY(one.getY() - (int)Math.ceil(f * dy));
/*     */       } else {
/* 211 */         setX(one.getX());
/* 212 */         setY(one.getY());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/* 218 */     return "(" + this.x + "," + this.y + ") [" + this.radius + "]" + super.toString();
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\util\Circle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */