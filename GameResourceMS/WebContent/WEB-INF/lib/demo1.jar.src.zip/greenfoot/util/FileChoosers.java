/*    */ package greenfoot.util;
/*    */ 
/*    */ import bluej.Config;
/*    */ import bluej.prefmgr.PrefMgr;
/*    */ import bluej.utility.PackageChooserStrict;
/*    */ import java.awt.Component;
/*    */ import java.io.File;
/*    */ import javax.swing.JFileChooser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileChoosers
/*    */ {
/*    */   private static JFileChooser scenarioFileChooser;
/*    */   private static JFileChooser newFileChooser;
/*    */   
/*    */   public static File getFileName(Component parent, File defaultFile, String title)
/*    */   {
/* 51 */     if (newFileChooser == null) {
/* 52 */       newFileChooser = new JFileChooser();
/* 53 */       newFileChooser.setDialogType(1);
/*    */     }
/* 55 */     newFileChooser.setDialogTitle(title);
/* 56 */     newFileChooser.setSelectedFile(defaultFile);
/* 57 */     int result = newFileChooser.showDialog(parent, Config.getString("chooser.newFile.button"));
/*    */     
/* 59 */     if (result != 0) {
/* 60 */       return null;
/*    */     }
/* 62 */     return newFileChooser.getSelectedFile();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static File getScenario(Component parent)
/*    */   {
/* 73 */     if (scenarioFileChooser == null) {
/* 74 */       scenarioFileChooser = new PackageChooserStrict(new File(PrefMgr.getProjectDirectory()));
/* 75 */       scenarioFileChooser.setDialogTitle(Config.getString("chooser.scenario.title"));
/*    */     }
/* 77 */     int result = scenarioFileChooser.showDialog(parent, Config.getString("chooser.scenario.button"));
/*    */     
/* 79 */     if (result != 0) {
/* 80 */       return null;
/*    */     }
/* 82 */     PrefMgr.setProjectDirectory(scenarioFileChooser.getSelectedFile().getParentFile().getPath());
/*    */     
/* 84 */     return scenarioFileChooser.getSelectedFile();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\util\FileChoosers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */