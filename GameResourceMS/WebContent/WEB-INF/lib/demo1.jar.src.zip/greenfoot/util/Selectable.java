package greenfoot.util;

public abstract interface Selectable<T>
{
  public abstract void select(T paramT);
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\util\Selectable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */