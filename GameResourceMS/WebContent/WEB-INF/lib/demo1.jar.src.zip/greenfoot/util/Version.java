/*     */ package greenfoot.util;
/*     */ 
/*     */ import bluej.Config;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Version
/*     */ {
/*     */   private int breakingNumber;
/*     */   private int nonBreakingNumber;
/*     */   private int internalNumber;
/*  55 */   private boolean badVersion = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Version(String versionString)
/*     */   {
/*  66 */     if (versionString == null) {
/*  67 */       this.badVersion = true;
/*  68 */       return;
/*     */     }
/*     */     
/*  71 */     String[] split = versionString.split("\\.");
/*  72 */     List<Integer> numbers = new ArrayList();
/*     */     
/*  74 */     String lastString = null;
/*  75 */     for (String s : split) {
/*     */       try {
/*  77 */         numbers.add(Integer.valueOf(Integer.parseInt(s)));
/*     */       }
/*     */       catch (NumberFormatException nfe) {
/*  80 */         lastString = s;
/*  81 */         break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  87 */     if ((numbers.size() < 3) && (lastString != null))
/*     */     {
/*  89 */       String[] endSplit = lastString.split("[^0-9]+");
/*     */       
/*  91 */       if (endSplit.length > 0) {
/*  92 */         String candidate = endSplit[0];
/*     */         
/*     */ 
/*  95 */         if (lastString.startsWith(candidate)) {
/*  96 */           numbers.add(Integer.valueOf(Integer.parseInt(candidate)));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 101 */     if (numbers.size() == 3) {
/* 102 */       this.breakingNumber = ((Integer)numbers.get(0)).intValue();
/* 103 */       this.nonBreakingNumber = ((Integer)numbers.get(1)).intValue();
/* 104 */       this.internalNumber = ((Integer)numbers.get(2)).intValue();
/*     */     }
/*     */     else {
/* 107 */       this.badVersion = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isOlderAndBreaking(Version other)
/*     */   {
/* 119 */     return (this.breakingNumber < other.breakingNumber) || (this.badVersion) || (other.badVersion);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNonBreaking(Version other)
/*     */   {
/* 129 */     return (this.nonBreakingNumber != other.nonBreakingNumber) || (this.badVersion) || (other.badVersion);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isInternal(Version other)
/*     */   {
/* 140 */     return (this.internalNumber != other.internalNumber) || (this.badVersion) || (other.badVersion);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBad()
/*     */   {
/* 149 */     return this.badVersion;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 157 */     return this.breakingNumber + "." + this.nonBreakingNumber + "." + this.internalNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getChangesMessage(Version apiVersion)
/*     */   {
/* 168 */     StringBuffer message = new StringBuffer(Config.getString("project.version.older.part1") + this + Config.getString("project.version.older.part2") + apiVersion + Config.getString("project.version.older.part3") + "\n");
/*     */     
/*     */ 
/*     */ 
/* 172 */     int changeNumber = 1;
/* 173 */     String changesString = Config.getString("project.version.changes." + changeNumber, "EMPTY").trim();
/*     */     
/* 175 */     while (!changesString.equals("EMPTY")) {
/* 176 */       int spaceIndex = changesString.indexOf(' ');
/* 177 */       if (spaceIndex < 5)
/*     */       {
/* 179 */         return "";
/*     */       }
/* 181 */       String versionString = changesString.substring(0, spaceIndex);
/* 182 */       Version changeVersion = new Version(versionString);
/* 183 */       if (isOlderAndBreaking(changeVersion)) {
/* 184 */         String text = changesString.substring(spaceIndex + 1);
/* 185 */         message.append("\n \n  " + text);
/*     */       }
/* 187 */       changeNumber++;
/* 188 */       changesString = Config.getString("project.version.changes." + changeNumber, "EMPTY");
/*     */     }
/*     */     
/*     */ 
/* 192 */     return message.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBadMessage()
/*     */   {
/* 202 */     return Config.getString("project.version.none");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNewerMessage()
/*     */   {
/* 210 */     return Config.getString("project.version.newer.part1") + this + Config.getString("project.version.newer.part2");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNotGreenfootMessage(File projectDir)
/*     */   {
/* 219 */     return Config.getString("project.version.notGreenfoot") + projectDir;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\util\Version.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */