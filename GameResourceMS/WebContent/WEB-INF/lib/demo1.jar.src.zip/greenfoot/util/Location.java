/*     */ package greenfoot.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Location
/*     */   implements Cloneable
/*     */ {
/*     */   private int x;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int y;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Location()
/*     */   {
/*  38 */     this.x = 0;
/*  39 */     this.y = 0;
/*     */   }
/*     */   
/*     */   public Location(int x, int y)
/*     */   {
/*  44 */     this.x = x;
/*  45 */     this.y = y;
/*     */   }
/*     */   
/*     */   public int getX()
/*     */   {
/*  50 */     return this.x;
/*     */   }
/*     */   
/*     */   public int getY()
/*     */   {
/*  55 */     return this.y;
/*     */   }
/*     */   
/*     */   public void setX(int x)
/*     */   {
/*  60 */     this.x = x;
/*     */   }
/*     */   
/*     */   public void setY(int y)
/*     */   {
/*  65 */     this.y = y;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void scale(int xMappingScale, int yMappingScale)
/*     */   {
/*  76 */     this.x *= xMappingScale;
/*  77 */     this.y *= yMappingScale;
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*  82 */     Object o = null;
/*     */     try {
/*  84 */       o = super.clone();
/*     */     }
/*     */     catch (CloneNotSupportedException e) {}
/*  87 */     return o;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(int dx, int dy)
/*     */   {
/*  98 */     this.x += dx;
/*  99 */     this.y += dy;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 104 */     String s = super.toString();
/* 105 */     s = s + " (" + getX() + ", " + getY() + ")";
/* 106 */     return s;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\util\Location.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */