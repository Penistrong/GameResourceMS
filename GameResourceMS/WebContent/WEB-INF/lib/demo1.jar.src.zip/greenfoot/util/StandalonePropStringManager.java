/*    */ package greenfoot.util;
/*    */ 
/*    */ import bluej.BlueJPropStringSource;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandalonePropStringManager
/*    */   implements BlueJPropStringSource
/*    */ {
/*    */   private Properties values;
/*    */   
/*    */   public StandalonePropStringManager(Properties props)
/*    */   {
/* 40 */     this.values = props;
/*    */   }
/*    */   
/*    */   public String getBlueJPropertyString(String property, String def)
/*    */   {
/* 45 */     return this.values.getProperty(property, def);
/*    */   }
/*    */   
/*    */   public String getLabel(String key)
/*    */   {
/* 50 */     return this.values.getProperty(key, key);
/*    */   }
/*    */   
/*    */   public void setUserProperty(String property, String value)
/*    */   {
/* 55 */     this.values.setProperty(property, value);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\util\StandalonePropStringManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */