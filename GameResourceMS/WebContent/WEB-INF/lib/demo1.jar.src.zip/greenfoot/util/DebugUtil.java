/*    */ package greenfoot.util;
/*    */ 
/*    */ import greenfoot.Actor;
/*    */ import greenfoot.World;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DebugUtil
/*    */ {
/*    */   public static Map<Class<?>, List<String>> restrictedClasses()
/*    */   {
/* 47 */     return restricted;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Map<String, Set<String>> restrictedClassesAsNames()
/*    */   {
/* 56 */     return restrictedAsNames;
/*    */   }
/*    */   
/* 59 */   private static final String[] actorIncludeFields = { "x", "y", "rotation", "image", "world" };
/* 60 */   private static final String[] worldIncludeFields = { "width", "height", "cellSize", "backgroundImage" };
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 67 */   private static final HashMap<Class<?>, List<String>> restricted = new HashMap();
/* 68 */   static { restricted.put(Actor.class, Arrays.asList(actorIncludeFields));
/* 69 */     restricted.put(World.class, Arrays.asList(worldIncludeFields));
/*    */     
/* 71 */     restrictedAsNames = new HashMap();
/* 72 */     for (Map.Entry<Class<?>, List<String>> e : restricted.entrySet()) {
/* 73 */       HashSet<String> values = new HashSet();
/* 74 */       values.addAll((Collection)e.getValue());
/* 75 */       restrictedAsNames.put(((Class)e.getKey()).getName(), values);
/*    */     }
/*    */   }
/*    */   
/*    */   private static final HashMap<String, Set<String>> restrictedAsNames;
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\util\DebugUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */