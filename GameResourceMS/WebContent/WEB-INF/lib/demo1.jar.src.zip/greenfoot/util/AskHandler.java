/*     */ package greenfoot.util;
/*     */ 
/*     */ import bluej.utility.Debug;
/*     */ import greenfoot.core.WorldHandler;
/*     */ import greenfoot.gui.AskPanel;
/*     */ import greenfoot.gui.AskPanel.AnswerListener;
/*     */ import greenfoot.gui.WorldCanvas;
/*     */ import java.awt.Image;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.concurrent.ArrayBlockingQueue;
/*     */ import java.util.concurrent.Callable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AskHandler
/*     */ {
/*     */   private final AskPanel askPanel;
/*     */   private final WorldCanvas worldCanvas;
/*  45 */   private final ArrayBlockingQueue<String> answer = new ArrayBlockingQueue(1);
/*     */   
/*     */   public AskHandler(AskPanel askPanel, WorldCanvas worldCanvas)
/*     */   {
/*  49 */     this.askPanel = askPanel;
/*  50 */     this.worldCanvas = worldCanvas;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Callable<String> ask(String prompt, int worldWidth)
/*     */   {
/*  60 */     Image snapshot = getWorldGreyedSnapShot();
/*     */     
/*  62 */     if (snapshot != null) {
/*  63 */       this.worldCanvas.setOverrideImage(snapshot);
/*     */     }
/*  65 */     this.askPanel.showPanel(Math.max(400, worldWidth), prompt, new AskPanel.AnswerListener()
/*     */     {
/*     */ 
/*     */       public void answered(String answer)
/*     */       {
/*  70 */         AskHandler.this.worldCanvas.setOverrideImage(null);
/*     */         try
/*     */         {
/*  73 */           AskHandler.this.answer.put(answer);
/*     */         }
/*     */         catch (InterruptedException e)
/*     */         {
/*  77 */           Debug.reportError(e);
/*     */         }
/*     */         
/*     */       }
/*  81 */     });
/*  82 */     new Callable()
/*     */     {
/*     */       public String call()
/*     */         throws Exception
/*     */       {
/*  87 */         return (String)AskHandler.this.answer.take();
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Image getWorldGreyedSnapShot()
/*     */   {
/* 100 */     BufferedImage screenShot = WorldHandler.getInstance().getSnapShot();
/* 101 */     if (screenShot != null) {
/* 102 */       GreenfootUtil.convertToGreyImage(screenShot);
/*     */     }
/* 104 */     return screenShot;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stopWaitingForAnswer()
/*     */   {
/* 113 */     if (this.askPanel.isPanelShowing())
/*     */     {
/* 115 */       this.askPanel.hidePanel();
/*     */       try
/*     */       {
/* 118 */         this.answer.put("");
/*     */       }
/*     */       catch (InterruptedException e)
/*     */       {
/* 122 */         Debug.reportError(e);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\util\AskHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */