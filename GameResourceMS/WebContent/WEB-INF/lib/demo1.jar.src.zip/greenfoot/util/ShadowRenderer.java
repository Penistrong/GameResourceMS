/*     */ package greenfoot.util;
/*     */ 
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ConvolveOp;
/*     */ import java.awt.image.Kernel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShadowRenderer
/*     */ {
/*     */   public static BufferedImage createDropShadow(BufferedImage image, int size, float opacity, Color color)
/*     */   {
/*  69 */     BufferedImage shadow = new BufferedImage(image.getWidth() + 4 * size, image.getHeight() + 4 * size, 2);
/*     */     
/*     */ 
/*  72 */     Graphics2D g2 = shadow.createGraphics();
/*  73 */     g2.drawImage(image, size * 2, size * 2, null);
/*     */     
/*  75 */     g2.setComposite(AlphaComposite.SrcIn);
/*  76 */     g2.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(255.0F * opacity)));
/*  77 */     g2.fillRect(0, 0, shadow.getWidth(), shadow.getHeight());
/*     */     
/*  79 */     g2.dispose();
/*     */     
/*  81 */     shadow = getGaussianBlurFilter(size, true).filter(shadow, null);
/*  82 */     shadow = getGaussianBlurFilter(size, false).filter(shadow, null);
/*     */     
/*  84 */     return shadow;
/*     */   }
/*     */   
/*     */   public static ConvolveOp getGaussianBlurFilter(int radius, boolean horizontal)
/*     */   {
/*  89 */     if (radius < 1) {
/*  90 */       throw new IllegalArgumentException("Radius must be >= 1");
/*     */     }
/*     */     
/*  93 */     int size = radius * 2 + 1;
/*  94 */     float[] data = new float[size];
/*     */     
/*  96 */     float sigma = radius / 3.0F;
/*  97 */     float twoSigmaSquare = 2.0F * sigma * sigma;
/*  98 */     float sigmaRoot = (float)Math.sqrt(twoSigmaSquare * 3.141592653589793D);
/*  99 */     float total = 0.0F;
/*     */     
/* 101 */     for (int i = -radius; i <= radius; i++) {
/* 102 */       float distance = i * i;
/* 103 */       int index = i + radius;
/* 104 */       data[index] = ((float)Math.exp(-distance / twoSigmaSquare) / sigmaRoot);
/* 105 */       total += data[index];
/*     */     }
/*     */     
/* 108 */     for (int i = 0; i < data.length; i++) {
/* 109 */       data[i] /= total;
/*     */     }
/*     */     
/* 112 */     Kernel kernel = null;
/* 113 */     if (horizontal) {
/* 114 */       kernel = new Kernel(size, 1, data);
/*     */     }
/*     */     else {
/* 117 */       kernel = new Kernel(1, size, data);
/*     */     }
/* 119 */     return new ConvolveOp(kernel, 1, null);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\util\ShadowRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */