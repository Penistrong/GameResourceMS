/*     */ package greenfoot;
/*     */ 
/*     */ import greenfoot.util.GraphicsUtilities;
/*     */ import greenfoot.util.GraphicsUtilities.MultiLineStringDimensions;
/*     */ import greenfoot.util.GreenfootUtil;
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Composite;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.MediaTracker;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.image.AffineTransformOp;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ImageObserver;
/*     */ import java.awt.image.VolatileImage;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GreenfootImage
/*     */ {
/*  57 */   private static final Color DEFAULT_BACKGROUND = new Color(255, 255, 255, 0);
/*  58 */   private static final Color DEFAULT_FOREGROUND = Color.BLACK;
/*     */   
/*     */   private String imageFileName;
/*     */   
/*     */   private URL imageUrl;
/*     */   
/*     */   private BufferedImage image;
/*     */   
/*     */   private static MediaTracker tracker;
/*  67 */   private Color currentColor = DEFAULT_FOREGROUND;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Font currentFont;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */   private boolean copyOnWrite = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  84 */   private int transparency = 255;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GreenfootImage(String filename)
/*     */     throws IllegalArgumentException
/*     */   {
/* 100 */     GreenfootImage gImage = GreenfootUtil.getCachedImage(filename);
/* 101 */     if (gImage != null)
/*     */     {
/* 103 */       createClone(gImage);
/*     */     }
/*     */     else {
/*     */       try
/*     */       {
/* 108 */         loadFile(filename);
/*     */       }
/*     */       catch (IllegalArgumentException ile) {
/* 111 */         GreenfootUtil.addCachedImage(filename, null);
/* 112 */         throw ile;
/*     */       }
/*     */     }
/*     */     
/* 116 */     boolean success = GreenfootUtil.addCachedImage(filename, new GreenfootImage(this));
/* 117 */     if (success) {
/* 118 */       this.copyOnWrite = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GreenfootImage(int width, int height)
/*     */   {
/* 130 */     setImage(GraphicsUtilities.createCompatibleTranslucentImage(width, height));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public GreenfootImage(GreenfootImage image)
/*     */     throws IllegalArgumentException
/*     */   {
/* 139 */     if (!image.copyOnWrite) {
/* 140 */       setImage(GraphicsUtilities.createCompatibleTranslucentImage(image.getWidth(), image.getHeight()));
/* 141 */       Graphics2D g = getGraphics();
/* 142 */       g.setComposite(AlphaComposite.Src);
/* 143 */       g.drawImage(image.getAwtImage(), 0, 0, null);
/* 144 */       g.dispose();
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 149 */       this.image = image.image;
/* 150 */       this.copyOnWrite = true;
/*     */     }
/* 152 */     copyStates(image, this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GreenfootImage(String string, int size, Color foreground, Color background)
/*     */   {
/* 168 */     this(string, size, foreground, background, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GreenfootImage(String string, int size, Color foreground, Color background, Color outline)
/*     */   {
/* 185 */     String[] lines = GraphicsUtilities.splitLines(string);
/* 186 */     GraphicsUtilities.MultiLineStringDimensions d = GraphicsUtilities.getMultiLineStringDimensions(lines, 1, size);
/* 187 */     this.image = GraphicsUtilities.createCompatibleTranslucentImage(d.getWidth(), d.getHeight());
/* 188 */     Graphics2D g = (Graphics2D)this.image.getGraphics();
/* 189 */     g.setColor(background == null ? new Color(0, 0, 0, 0) : background);
/* 190 */     g.fillRect(0, 0, this.image.getWidth(), this.image.getHeight());
/* 191 */     GraphicsUtilities.drawOutlinedText(g, d, foreground, outline);
/* 192 */     g.dispose();
/*     */   }
/*     */   
/*     */   GreenfootImage(byte[] imageData)
/*     */   {
/*     */     try
/*     */     {
/* 199 */       this.image = GraphicsUtilities.loadCompatibleTranslucentImage(imageData);
/*     */     } catch (IOException ex) {
/* 201 */       throw new IllegalArgumentException("Could not load image" + (this.imageFileName != null ? " from: " + this.imageFileName : ""));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private GreenfootImage() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   GreenfootImage getCopyOnWriteClone()
/*     */   {
/* 216 */     GreenfootImage clone = new GreenfootImage();
/* 217 */     clone.copyOnWrite = true;
/* 218 */     clone.image = this.image;
/* 219 */     copyStates(this, clone);
/*     */     
/* 221 */     return clone;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void createClone(GreenfootImage cachedImage)
/*     */   {
/* 230 */     this.copyOnWrite = true;
/* 231 */     this.image = cachedImage.image;
/* 232 */     copyStates(cachedImage, this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void copyStates(GreenfootImage src, GreenfootImage dst)
/*     */   {
/* 240 */     dst.imageFileName = src.imageFileName;
/* 241 */     dst.imageUrl = src.imageUrl;
/* 242 */     dst.currentColor = src.currentColor;
/* 243 */     dst.currentFont = src.currentFont;
/* 244 */     dst.transparency = src.transparency;
/*     */   }
/*     */   
/*     */   private void loadURL(URL imageURL)
/*     */     throws IllegalArgumentException
/*     */   {
/* 250 */     if (imageURL == null) {
/* 251 */       throw new NullPointerException("Image URL must not be null.");
/*     */     }
/*     */     try {
/* 254 */       this.image = GraphicsUtilities.loadCompatibleTranslucentImage(imageURL);
/*     */     } catch (IOException ex) {
/* 256 */       throw new IllegalArgumentException("Could not load image from: " + this.imageFileName);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void loadFile(String filename)
/*     */     throws IllegalArgumentException
/*     */   {
/* 271 */     if (filename == null) {
/* 272 */       throw new NullPointerException("Filename must not be null.");
/*     */     }
/* 274 */     this.imageFileName = filename;
/*     */     try {
/* 276 */       this.imageUrl = GreenfootUtil.getURL(filename, "images");
/*     */     }
/*     */     catch (FileNotFoundException e) {
/* 279 */       throw new IllegalArgumentException(e);
/*     */     }
/* 281 */     loadURL(this.imageUrl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setImage(Image image)
/*     */     throws IllegalArgumentException
/*     */   {
/* 292 */     if (image == null) {
/* 293 */       throw new IllegalArgumentException("Image must not be null.");
/*     */     }
/* 295 */     this.image = getBufferedImage(image);
/* 296 */     this.copyOnWrite = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BufferedImage getAwtImage()
/*     */   {
/* 309 */     ensureWritableImage();
/* 310 */     return this.image;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Graphics2D getGraphics()
/*     */   {
/* 318 */     if (this.copyOnWrite) {
/* 319 */       ensureWritableImage();
/*     */     }
/* 321 */     Graphics2D graphics = this.image.createGraphics();
/* 322 */     initGraphics(graphics);
/* 323 */     return graphics;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initGraphics(Graphics2D graphics)
/*     */   {
/* 332 */     if (graphics != null) {
/* 333 */       graphics.setBackground(DEFAULT_BACKGROUND);
/* 334 */       graphics.setColor(this.currentColor);
/* 335 */       if (this.currentFont != null) {
/* 336 */         graphics.setFont(this.currentFont);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWidth()
/*     */   {
/* 348 */     return this.image.getWidth(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHeight()
/*     */   {
/* 358 */     return this.image.getHeight(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void rotate(int degrees)
/*     */   {
/* 369 */     AffineTransform tx = AffineTransform.getRotateInstance(Math.toRadians(degrees), getWidth() / 2.0D, getHeight() / 2.0D);
/* 370 */     AffineTransformOp op = new AffineTransformOp(tx, 1);
/* 371 */     BufferedImage newImage = GraphicsUtilities.createCompatibleTranslucentImage(getWidth(), getHeight());
/* 372 */     setImage(op.filter(this.image, newImage));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void scale(int width, int height)
/*     */   {
/* 383 */     if ((width == this.image.getWidth()) && (height == this.image.getHeight())) {
/* 384 */       return;
/*     */     }
/*     */     
/*     */ 
/* 388 */     BufferedImage scaled = GraphicsUtilities.createCompatibleTranslucentImage(width, height);
/* 389 */     Graphics2D g = scaled.createGraphics();
/* 390 */     g.setComposite(AlphaComposite.Src);
/* 391 */     g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
/* 392 */     g.drawImage(this.image, 0, 0, width, height, null);
/* 393 */     g.dispose();
/* 394 */     setImage(scaled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mirrorVertically()
/*     */   {
/* 402 */     AffineTransform tx = AffineTransform.getScaleInstance(1.0D, -1.0D);
/* 403 */     tx.translate(0.0D, -this.image.getHeight(null));
/* 404 */     AffineTransformOp op = new AffineTransformOp(tx, 1);
/* 405 */     setImage(op.filter(this.image, null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mirrorHorizontally()
/*     */   {
/* 413 */     AffineTransform tx = AffineTransform.getScaleInstance(-1.0D, 1.0D);
/* 414 */     tx.translate(-this.image.getWidth(null), 0.0D);
/* 415 */     AffineTransformOp op = new AffineTransformOp(tx, 1);
/* 416 */     setImage(op.filter(this.image, null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fill()
/*     */   {
/* 424 */     Graphics g = getGraphics();
/* 425 */     g.fillRect(0, 0, getWidth(), getHeight());
/* 426 */     g.dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void drawImage(GreenfootImage image, int x, int y)
/*     */   {
/* 438 */     Graphics2D g = getGraphics();
/* 439 */     image.drawImage(g, x, y, null, true);
/* 440 */     g.dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void drawImage(Graphics2D g, int x, int y, ImageObserver observer, boolean useTransparency)
/*     */   {
/* 451 */     Composite oldComposite = null;
/* 452 */     if (useTransparency) {
/* 453 */       float opacity = getTransparency() / 255.0F;
/* 454 */       if (opacity < 1.0F)
/*     */       {
/* 456 */         if (opacity < 0.0F) opacity = 0.0F;
/* 457 */         oldComposite = g.getComposite();
/* 458 */         g.setComposite(AlphaComposite.getInstance(3, opacity));
/*     */       }
/*     */     }
/*     */     
/* 462 */     g.drawImage(this.image, x, y, observer);
/*     */     
/* 464 */     if (oldComposite != null) {
/* 465 */       g.setComposite(oldComposite);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFont(Font f)
/*     */   {
/* 475 */     this.currentFont = f;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Font getFont()
/*     */   {
/* 483 */     if (this.currentFont == null) {
/* 484 */       this.currentFont = getGraphics().getFont();
/*     */     }
/* 486 */     return this.currentFont;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColor(Color color)
/*     */   {
/* 497 */     this.currentColor = color;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color getColor()
/*     */   {
/* 507 */     return this.currentColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color getColorAt(int x, int y)
/*     */   {
/* 518 */     return new Color(getRGBAt(x, y), true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setColorAt(int x, int y, Color color)
/*     */   {
/* 525 */     setRGBAt(x, y, color.getRGB());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTransparency(int t)
/*     */   {
/* 536 */     if ((t < 0) || (t > 255)) {
/* 537 */       throw new IllegalArgumentException("The transparency value has to be in the range 0 to 255. It was: " + t);
/*     */     }
/*     */     
/* 540 */     this.transparency = t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getTransparency()
/*     */   {
/* 551 */     return this.transparency;
/*     */   }
/*     */   
/*     */   private int getRGBAt(int x, int y)
/*     */   {
/* 556 */     if (x >= getWidth()) {
/* 557 */       throw new IndexOutOfBoundsException("X is out of bounds. It was: " + x + " and it should have been smaller than: " + getWidth());
/*     */     }
/*     */     
/* 560 */     if (y >= getHeight()) {
/* 561 */       throw new IndexOutOfBoundsException("Y is out of bounds. It was: " + y + " and it should have been smaller than: " + getHeight());
/*     */     }
/*     */     
/* 564 */     if (x < 0) {
/* 565 */       throw new IndexOutOfBoundsException("X is out of bounds. It was: " + x + " and it should have been at least: 0");
/*     */     }
/*     */     
/* 568 */     if (y < 0) {
/* 569 */       throw new IndexOutOfBoundsException("Y is out of bounds. It was: " + y + " and it should have been at least: 0");
/*     */     }
/*     */     
/*     */ 
/* 573 */     return this.image.getRGB(x, y);
/*     */   }
/*     */   
/*     */   private void setRGBAt(int x, int y, int rgb)
/*     */   {
/* 578 */     if (x >= getWidth()) {
/* 579 */       throw new IndexOutOfBoundsException("X is out of bounds. It was: " + x + " and it should have been smaller than: " + getWidth());
/*     */     }
/*     */     
/* 582 */     if (y >= getHeight()) {
/* 583 */       throw new IndexOutOfBoundsException("Y is out of bounds. It was: " + y + " and it should have been smaller than: " + getHeight());
/*     */     }
/*     */     
/* 586 */     if (x < 0) {
/* 587 */       throw new IndexOutOfBoundsException("X is out of bounds. It was: " + x + " and it should have been at least: 0");
/*     */     }
/*     */     
/* 590 */     if (y < 0) {
/* 591 */       throw new IndexOutOfBoundsException("Y is out of bounds. It was: " + y + " and it should have been at least: 0");
/*     */     }
/*     */     
/*     */ 
/* 595 */     ensureWritableImage();
/* 596 */     this.image.setRGB(x, y, rgb);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fillRect(int x, int y, int width, int height)
/*     */   {
/* 616 */     Graphics2D g = getGraphics();
/* 617 */     g.fillRect(x, y, width, height);
/* 618 */     g.dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 626 */     Graphics2D g = getGraphics();
/* 627 */     g.clearRect(0, 0, getWidth(), getHeight());
/* 628 */     g.dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void drawRect(int x, int y, int width, int height)
/*     */   {
/* 645 */     Graphics2D g = getGraphics();
/* 646 */     g.drawRect(x, y, width, height);
/* 647 */     g.dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void drawString(String string, int x, int y)
/*     */   {
/* 661 */     Graphics2D g = getGraphics();
/* 662 */     g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 663 */     int height = g.getFontMetrics(g.getFont()).getHeight();
/*     */     
/* 665 */     String[] lines = GraphicsUtilities.splitLines(string);
/* 666 */     for (int i = 0; i < lines.length; i++) {
/* 667 */       g.drawString(lines[i], x, y + i * height);
/*     */     }
/*     */     
/* 670 */     g.dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void drawShape(Shape shape)
/*     */   {
/* 681 */     Graphics2D g = getGraphics();
/* 682 */     g.draw(shape);
/* 683 */     g.dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fillShape(Shape shape)
/*     */   {
/* 694 */     Graphics2D g = getGraphics();
/* 695 */     g.fill(shape);
/* 696 */     g.dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fillOval(int x, int y, int width, int height)
/*     */   {
/* 712 */     Graphics2D g = getGraphics();
/* 713 */     g.fillOval(x, y, width, height);
/* 714 */     g.dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void drawOval(int x, int y, int width, int height)
/*     */   {
/* 730 */     Graphics2D g = getGraphics();
/* 731 */     g.drawOval(x, y, width, height);
/* 732 */     g.dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fillPolygon(int[] xPoints, int[] yPoints, int nPoints)
/*     */   {
/* 757 */     Graphics2D g = getGraphics();
/* 758 */     g.fillPolygon(xPoints, yPoints, nPoints);
/* 759 */     g.dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void drawPolygon(int[] xPoints, int[] yPoints, int nPoints)
/*     */   {
/* 781 */     Graphics2D g = getGraphics();
/* 782 */     g.drawPolygon(xPoints, yPoints, nPoints);
/* 783 */     g.dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void drawLine(int x1, int y1, int x2, int y2)
/*     */   {
/* 797 */     Graphics2D g = getGraphics();
/* 798 */     g.drawLine(x1, y1, x2, y2);
/* 799 */     g.dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 807 */     String superString = super.toString();
/* 808 */     if (this.imageFileName == null) {
/* 809 */       return superString;
/*     */     }
/*     */     
/* 812 */     return "Image file name: " + this.imageFileName + "   Image url: " + this.imageUrl + "  " + superString;
/*     */   }
/*     */   
/*     */ 
/*     */   static boolean equal(GreenfootImage image1, GreenfootImage image2)
/*     */   {
/* 818 */     if ((image1 == null) || (image2 == null)) {
/* 819 */       return image1 == image2;
/*     */     }
/*     */     
/* 822 */     return (image1.image == image2.image) || (image1.equals(image2));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void ensureWritableImage()
/*     */   {
/* 833 */     if (this.copyOnWrite) {
/* 834 */       BufferedImage bImage = GraphicsUtilities.createCompatibleTranslucentImage(this.image.getWidth(null), this.image.getHeight(null));
/* 835 */       Graphics2D graphics = bImage.createGraphics();
/* 836 */       initGraphics(graphics);
/* 837 */       graphics.drawImage(this.image, 0, 0, null);
/* 838 */       this.image = bImage;
/* 839 */       this.copyOnWrite = false;
/* 840 */       graphics.dispose();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static BufferedImage getBufferedImage(Image image)
/*     */   {
/* 850 */     if (!(image instanceof BufferedImage))
/* 851 */       if ((image instanceof VolatileImage)) {
/* 852 */         image = ((VolatileImage)image).getSnapshot();
/* 853 */         waitForImageLoad(image);
/*     */       }
/*     */       else {
/* 856 */         waitForImageLoad(image);
/* 857 */         BufferedImage bImage = GraphicsUtilities.createCompatibleTranslucentImage(image.getWidth(null), image.getHeight(null));
/* 858 */         Graphics g = bImage.getGraphics();
/* 859 */         g.drawImage(image, 0, 0, null);
/* 860 */         image = bImage;
/*     */       }
/* 862 */     return (BufferedImage)image;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void waitForImageLoad(Image image)
/*     */   {
/* 871 */     if (tracker == null) {
/* 872 */       tracker = new MediaTracker(new Component() {});
/*     */     }
/* 874 */     tracker.addImage(image, 0);
/*     */     try {
/* 876 */       tracker.waitForID(0);
/* 877 */       tracker.removeImage(image);
/*     */     }
/*     */     catch (InterruptedException e) {
/* 880 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\GreenfootImage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */