/*     */ package greenfoot.gui;
/*     */ 
/*     */ import bluej.Config;
/*     */ import greenfoot.actions.PauseSimulationAction;
/*     */ import greenfoot.actions.ResetWorldAction;
/*     */ import greenfoot.actions.RunOnceSimulationAction;
/*     */ import greenfoot.actions.RunSimulationAction;
/*     */ import greenfoot.core.Simulation;
/*     */ import greenfoot.event.SimulationEvent;
/*     */ import greenfoot.event.SimulationListener;
/*     */ import greenfoot.util.GreenfootUtil;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ControlPanel
/*     */   extends Box
/*     */   implements ChangeListener, SimulationListener
/*     */ {
/*     */   private RunSimulationAction runSimulationAction;
/*     */   private PauseSimulationAction pauseSimulationAction;
/*     */   private RunOnceSimulationAction runOnceSimulationAction;
/*     */   private ResetWorldAction resetWorldAction;
/*     */   private JSlider speedSlider;
/*     */   private Simulation simulation;
/*     */   private JPanel buttonPanel;
/*     */   private JButton pauseButton;
/*     */   private JButton runButton;
/*     */   
/*     */   public ControlPanel(Simulation simulation, boolean includeAllControls)
/*     */   {
/*  77 */     super(0);
/*     */     
/*  79 */     this.simulation = simulation;
/*     */     
/*  81 */     add(createButtonPanel(simulation, includeAllControls));
/*     */     
/*  83 */     if (includeAllControls) {
/*  84 */       add(createSpeedSlider());
/*     */     }
/*  86 */     simulation.addSimulationListener(this);
/*     */   }
/*     */   
/*     */ 
/*     */   private JPanel createButtonPanel(Simulation simulation, boolean includeAllControls)
/*     */   {
/*  92 */     this.buttonPanel = new JPanel(new FlowLayout(1, 10, 10));
/*     */     
/*  94 */     if (includeAllControls) {
/*  95 */       this.runOnceSimulationAction = RunOnceSimulationAction.getInstance();
/*  96 */       this.runOnceSimulationAction.attachSimulation(simulation);
/*  97 */       this.runOnceSimulationAction.putValue("LongDescription", Config.getString("controls.runonce.longDescription"));
/*     */       
/*  99 */       this.runOnceSimulationAction.putValue("ShortDescription", Config.getString("controls.runonce.shortDescription"));
/*     */       
/* 101 */       this.runOnceSimulationAction.setEnabled(false);
/* 102 */       AbstractButton stepButton = GreenfootUtil.createButton(this.runOnceSimulationAction);
/*     */       
/* 104 */       this.buttonPanel.add(stepButton);
/*     */     }
/*     */     
/* 107 */     this.runSimulationAction = RunSimulationAction.getInstance();
/* 108 */     this.runSimulationAction.attachSimulation(simulation);
/* 109 */     this.runSimulationAction.putValue("LongDescription", Config.getString("controls.run.longDescription"));
/*     */     
/* 111 */     this.runSimulationAction.putValue("ShortDescription", Config.getString("controls.run.shortDescription"));
/*     */     
/* 113 */     this.runSimulationAction.setEnabled(false);
/* 114 */     this.runButton = GreenfootUtil.createButton(this.runSimulationAction);
/*     */     
/* 116 */     this.pauseSimulationAction = PauseSimulationAction.getInstance();
/* 117 */     this.pauseSimulationAction.attachSimulation(simulation);
/* 118 */     this.pauseSimulationAction.putValue("LongDescription", Config.getString("controls.pause.longDescription"));
/*     */     
/* 120 */     this.pauseSimulationAction.putValue("ShortDescription", Config.getString("controls.pause.shortDescription"));
/*     */     
/* 122 */     this.pauseSimulationAction.setEnabled(false);
/* 123 */     this.pauseButton = GreenfootUtil.createButton(this.pauseSimulationAction);
/*     */     
/*     */ 
/* 126 */     if (this.pauseButton.getPreferredSize().getWidth() > this.runButton.getPreferredSize().getWidth()) {
/* 127 */       this.runButton.setPreferredSize(this.pauseButton.getPreferredSize());
/* 128 */       this.runButton.setMaximumSize(this.pauseButton.getMaximumSize());
/* 129 */       this.runButton.setMinimumSize(this.pauseButton.getMinimumSize());
/*     */     } else {
/* 131 */       this.pauseButton.setPreferredSize(this.runButton.getPreferredSize());
/* 132 */       this.pauseButton.setMaximumSize(this.runButton.getMaximumSize());
/* 133 */       this.pauseButton.setMinimumSize(this.runButton.getMinimumSize());
/*     */     }
/*     */     
/* 136 */     this.buttonPanel.add(this.runButton);
/*     */     
/* 138 */     this.resetWorldAction = ResetWorldAction.getInstance();
/* 139 */     this.resetWorldAction.putValue("LongDescription", Config.getString("controls.reset.longDescription"));
/* 140 */     this.resetWorldAction.putValue("ShortDescription", Config.getString("controls.reset.shortDescription"));
/* 141 */     this.resetWorldAction.attachSimulation(simulation);
/* 142 */     this.resetWorldAction.setEnabled(false);
/* 143 */     AbstractButton resetButton = GreenfootUtil.createButton(this.resetWorldAction);
/* 144 */     this.buttonPanel.add(resetButton);
/*     */     
/* 146 */     return this.buttonPanel;
/*     */   }
/*     */   
/*     */   private JComponent createSpeedSlider()
/*     */   {
/* 151 */     JPanel speedPanel = new JPanel(new FlowLayout());
/* 152 */     JLabel speedLabel = new JLabel(Config.getString("controls.speed.label"));
/* 153 */     speedPanel.add(speedLabel);
/*     */     
/* 155 */     int min = 0;
/* 156 */     int max = 100;
/* 157 */     this.speedSlider = new JSlider(0, min, max, this.simulation.getSpeed());
/* 158 */     this.speedSlider.setPaintLabels(false);
/* 159 */     this.speedSlider.setMajorTickSpacing(max / 2);
/* 160 */     this.speedSlider.setMinorTickSpacing(max / 4);
/* 161 */     this.speedSlider.setPaintTicks(true);
/* 162 */     this.speedSlider.setEnabled(false);
/* 163 */     this.speedSlider.addChangeListener(this);
/* 164 */     this.speedSlider.setToolTipText(Config.getString("controls.speedSlider.tooltip"));
/* 165 */     this.speedSlider.setFocusable(false);
/* 166 */     speedPanel.add(this.speedSlider);
/*     */     
/* 168 */     return speedPanel;
/*     */   }
/*     */   
/*     */ 
/*     */   public void simulationChanged(SimulationEvent e)
/*     */   {
/* 174 */     final int etype = e.getType();
/* 175 */     if ((etype == 5) || (etype == 6))
/*     */     {
/*     */ 
/*     */ 
/* 179 */       return;
/*     */     }
/*     */     
/* 182 */     SwingUtilities.invokeLater(new Thread()
/*     */     {
/*     */       public void run() {
/* 185 */         if (etype == 0) {
/* 186 */           if (ControlPanel.this.speedSlider != null) {
/* 187 */             ControlPanel.this.speedSlider.setEnabled(true);
/*     */           }
/* 189 */           ControlPanel.this.buttonPanel.remove(ControlPanel.this.runButton);
/* 190 */           ControlPanel.this.buttonPanel.add(ControlPanel.this.pauseButton, 1);
/* 191 */           ControlPanel.this.buttonPanel.validate();
/*     */         }
/* 193 */         else if (etype == 1) {
/* 194 */           if (ControlPanel.this.speedSlider != null) {
/* 195 */             ControlPanel.this.speedSlider.setEnabled(true);
/*     */           }
/* 197 */           ControlPanel.this.buttonPanel.remove(ControlPanel.this.pauseButton);
/* 198 */           ControlPanel.this.buttonPanel.add(ControlPanel.this.runButton, 1);
/* 199 */           ControlPanel.this.buttonPanel.validate();
/*     */         }
/* 201 */         else if (etype == 2) {
/* 202 */           if (ControlPanel.this.speedSlider != null) {
/* 203 */             ControlPanel.this.speedSlider.setEnabled(true);
/* 204 */             int newSpeed = ControlPanel.this.simulation.getSpeed();
/* 205 */             if (newSpeed != ControlPanel.this.speedSlider.getValue()) {
/* 206 */               ControlPanel.this.speedSlider.setValue(newSpeed);
/*     */             }
/*     */           }
/*     */         }
/* 210 */         else if ((etype == 3) && 
/* 211 */           (ControlPanel.this.speedSlider != null)) {
/* 212 */           ControlPanel.this.speedSlider.setEnabled(false);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stateChanged(ChangeEvent e)
/*     */   {
/* 224 */     this.simulation.setSpeed(this.speedSlider.getValue());
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\gui\ControlPanel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */