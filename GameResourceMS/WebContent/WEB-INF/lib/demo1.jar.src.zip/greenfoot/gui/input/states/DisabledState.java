/*    */ package greenfoot.gui.input.states;
/*    */ 
/*    */ import greenfoot.event.TriggeredKeyListener;
/*    */ import greenfoot.event.TriggeredMouseListener;
/*    */ import greenfoot.event.TriggeredMouseMotionListener;
/*    */ import greenfoot.gui.input.InputManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DisabledState
/*    */   extends State
/*    */ {
/*    */   protected static DisabledState instance;
/*    */   
/*    */   public static synchronized DisabledState getInstance()
/*    */     throws IllegalStateException
/*    */   {
/* 40 */     if (instance == null) {
/* 41 */       throw new IllegalStateException("Not initialized.");
/*    */     }
/* 43 */     return instance;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   private DisabledState(InputManager inputManager, TriggeredKeyListener keyListener, TriggeredMouseListener mouseListener, TriggeredMouseMotionListener mouseMotionListener)
/*    */   {
/* 50 */     super(inputManager, keyListener, mouseListener, mouseMotionListener);
/*    */   }
/*    */   
/*    */ 
/*    */   public static synchronized DisabledState initialize(InputManager inputManager, TriggeredKeyListener keyListener, TriggeredMouseListener mouseListener, TriggeredMouseMotionListener mouseMotionListener)
/*    */   {
/* 56 */     instance = new DisabledState(inputManager, keyListener, mouseListener, mouseMotionListener);
/* 57 */     return instance;
/*    */   }
/*    */   
/*    */ 
/*    */   public void switchToNextState(State.Event event, Object obj)
/*    */   {
/* 63 */     switch (event) {
/*    */     case WORLD_CREATED: 
/* 65 */       switchAndActivateState(IdleState.getInstance(), obj);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\gui\input\states\DisabledState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */