/*    */ package greenfoot.gui.input.states;
/*    */ 
/*    */ import greenfoot.event.TriggeredKeyListener;
/*    */ import greenfoot.event.TriggeredMouseListener;
/*    */ import greenfoot.event.TriggeredMouseMotionListener;
/*    */ import greenfoot.gui.input.InputManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstructorDragState
/*    */   extends State
/*    */ {
/*    */   protected static ConstructorDragState instance;
/*    */   
/*    */   public static synchronized ConstructorDragState getInstance()
/*    */     throws IllegalStateException
/*    */   {
/* 43 */     if (instance == null) {
/* 44 */       throw new IllegalStateException("Not initialized.");
/*    */     }
/* 46 */     return instance;
/*    */   }
/*    */   
/*    */ 
/*    */   private ConstructorDragState(InputManager inputManager, TriggeredKeyListener keyListener, TriggeredMouseListener mouseListener, TriggeredMouseMotionListener mouseMotionListener)
/*    */   {
/* 52 */     super(inputManager, keyListener, mouseListener, mouseMotionListener);
/*    */   }
/*    */   
/*    */ 
/*    */   public static synchronized ConstructorDragState initialize(InputManager inputManager, TriggeredKeyListener keyListener, TriggeredMouseListener mouseListener, TriggeredMouseMotionListener mouseMotionListener)
/*    */   {
/* 58 */     instance = new ConstructorDragState(inputManager, keyListener, mouseListener, mouseMotionListener);
/* 59 */     return instance;
/*    */   }
/*    */   
/*    */ 
/*    */   public void switchToNextState(State.Event event, Object obj)
/*    */   {
/* 65 */     super.switchToNextState(event, obj);
/* 66 */     switch (event) {
/*    */     case SHIFT_PRESSED: 
/* 68 */       switchAndActivateState(QuickAddDragState.getInstance(), obj);
/* 69 */       break;
/*    */     case MOUSE_RELEASED: 
/* 71 */       switchAndActivateState(IdleState.getInstance(), obj);
/* 72 */       break;
/*    */     case ESC_PRESSED: 
/* 74 */       switchAndActivateState(IdleState.getInstance(), obj);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\gui\input\states\ConstructorDragState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */