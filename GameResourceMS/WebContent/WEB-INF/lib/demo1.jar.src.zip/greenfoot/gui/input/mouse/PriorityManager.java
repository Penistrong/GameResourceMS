/*     */ package greenfoot.gui.input.mouse;
/*     */ 
/*     */ import java.awt.event.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PriorityManager
/*     */ {
/*     */   public static boolean isHigherPriority(MouseEvent newEvent, MouseEventData currentData)
/*     */   {
/*  59 */     int currentPriority = getPriority(currentData);
/*  60 */     int newPriority = getPriority(newEvent);
/*  61 */     return newPriority <= currentPriority;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int getPriority(MouseEvent event)
/*     */   {
/*  70 */     if (event.getID() == 502) {
/*  71 */       return 0;
/*     */     }
/*  73 */     if (event.getID() == 500) {
/*  74 */       return 1;
/*     */     }
/*  76 */     if (event.getID() == 501) {
/*  77 */       return 2;
/*     */     }
/*  79 */     if (event.getID() == 506) {
/*  80 */       return 3;
/*     */     }
/*  82 */     if (event.getID() == 503) {
/*  83 */       return 4;
/*     */     }
/*     */     
/*  86 */     return Integer.MAX_VALUE;
/*     */   }
/*     */   
/*     */ 
/*     */   private static int getPriority(MouseEventData data)
/*     */   {
/*  92 */     if (data.isMouseDragEnded(null)) {
/*  93 */       return 0;
/*     */     }
/*  95 */     if (data.isMouseClicked(null)) {
/*  96 */       return 1;
/*     */     }
/*  98 */     if (data.isMousePressed(null)) {
/*  99 */       return 2;
/*     */     }
/* 101 */     if (data.isMouseDragged(null)) {
/* 102 */       return 3;
/*     */     }
/* 104 */     if (data.isMouseMoved(null)) {
/* 105 */       return 4;
/*     */     }
/*     */     
/* 108 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\gui\input\mouse\PriorityManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */