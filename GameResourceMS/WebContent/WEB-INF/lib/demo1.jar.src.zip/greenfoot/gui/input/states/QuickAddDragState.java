/*    */ package greenfoot.gui.input.states;
/*    */ 
/*    */ import greenfoot.event.TriggeredKeyListener;
/*    */ import greenfoot.event.TriggeredMouseListener;
/*    */ import greenfoot.event.TriggeredMouseMotionListener;
/*    */ import greenfoot.gui.input.InputManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QuickAddDragState
/*    */   extends State
/*    */ {
/*    */   protected static QuickAddDragState instance;
/*    */   
/*    */   public static synchronized QuickAddDragState getInstance()
/*    */     throws IllegalStateException
/*    */   {
/* 41 */     if (instance == null) {
/* 42 */       throw new IllegalStateException("Not initialized.");
/*    */     }
/* 44 */     return instance;
/*    */   }
/*    */   
/*    */ 
/*    */   private QuickAddDragState(InputManager inputManager, TriggeredKeyListener keyListener, TriggeredMouseListener mouseListener, TriggeredMouseMotionListener mouseMotionListener)
/*    */   {
/* 50 */     super(inputManager, keyListener, mouseListener, mouseMotionListener);
/*    */   }
/*    */   
/*    */ 
/*    */   public static synchronized QuickAddDragState initialize(InputManager inputManager, TriggeredKeyListener keyListener, TriggeredMouseListener mouseListener, TriggeredMouseMotionListener mouseMotionListener)
/*    */   {
/* 56 */     instance = new QuickAddDragState(inputManager, keyListener, mouseListener, mouseMotionListener);
/* 57 */     return instance;
/*    */   }
/*    */   
/*    */ 
/*    */   public void switchToNextState(State.Event event, Object obj)
/*    */   {
/* 63 */     super.switchToNextState(event, obj);
/* 64 */     switch (event) {
/*    */     case SHIFT_RELEASED: 
/* 66 */       switchAndActivateState(IdleState.getInstance(), obj);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\gui\input\states\QuickAddDragState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */