/*    */ package greenfoot.gui.input.states;
/*    */ 
/*    */ import greenfoot.event.TriggeredKeyListener;
/*    */ import greenfoot.event.TriggeredMouseListener;
/*    */ import greenfoot.event.TriggeredMouseMotionListener;
/*    */ import greenfoot.gui.input.InputManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RunningState
/*    */   extends State
/*    */ {
/*    */   protected static RunningState instance;
/*    */   
/*    */   public static synchronized RunningState getInstance()
/*    */     throws IllegalStateException
/*    */   {
/* 40 */     if (instance == null) {
/* 41 */       throw new IllegalStateException("Not initialized.");
/*    */     }
/* 43 */     return instance;
/*    */   }
/*    */   
/*    */ 
/*    */   private RunningState(InputManager inputManager, TriggeredKeyListener keyListener, TriggeredMouseListener mouseListener, TriggeredMouseMotionListener mouseMotionListener)
/*    */   {
/* 49 */     super(inputManager, keyListener, mouseListener, mouseMotionListener);
/*    */   }
/*    */   
/*    */ 
/*    */   public static synchronized RunningState initialize(InputManager inputManager, TriggeredKeyListener keyListener, TriggeredMouseListener mouseListener, TriggeredMouseMotionListener mouseMotionListener)
/*    */   {
/* 55 */     instance = new RunningState(inputManager, keyListener, mouseListener, mouseMotionListener);
/* 56 */     return instance;
/*    */   }
/*    */   
/*    */ 
/*    */   public void switchToNextState(State.Event event, Object obj)
/*    */   {
/* 62 */     super.switchToNextState(event, obj);
/* 63 */     switch (event) {
/*    */     case SIMULATION_STOPPED: 
/* 65 */       switchAndActivateState(IdleState.getInstance(), obj);
/* 66 */       break;
/*    */     case CONSTRUCTOR_INVOKED: 
/* 68 */       switchAndActivateState(ConstructorDragWhileRunningState.getInstance(), obj);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\gui\input\states\RunningState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */