/*     */ package greenfoot.gui.input.mouse;
/*     */ 
/*     */ import greenfoot.core.WorldHandler;
/*     */ import greenfoot.gui.WorldCanvas;
/*     */ import java.awt.AWTEvent;
/*     */ import java.awt.Component;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.AWTEventListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseMotionAdapter;
/*     */ import javax.swing.SwingUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocationTracker
/*     */ {
/*     */   private static LocationTracker instance;
/*     */   private MouseEvent mouseButtonEvent;
/*     */   private Component sourceComponent;
/*     */   private MouseEvent mouseMovedEvent;
/*     */   
/*     */   static
/*     */   {
/*  54 */     instance();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void initialize()
/*     */   {
/*  64 */     MouseMotionAdapter mma = new MouseMotionAdapter()
/*     */     {
/*     */       public void mouseMoved(MouseEvent e)
/*     */       {
/*  68 */         LocationTracker.instance().move(e);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       public void mouseDragged(MouseEvent e) {}
/*  75 */     };
/*  76 */     MouseAdapter ma = new MouseAdapter()
/*     */     {
/*     */       public void mouseClicked(MouseEvent e)
/*     */       {
/*  80 */         LocationTracker.instance().click(e);
/*     */       }
/*     */       
/*     */ 
/*  84 */     };
/*  85 */     WorldCanvas canvas = WorldHandler.getInstance().getWorldCanvas();
/*  86 */     canvas.addMouseListener(ma);
/*  87 */     canvas.addMouseMotionListener(mma);
/*     */   }
/*     */   
/*     */   private LocationTracker()
/*     */   {
/*     */     try {
/*  93 */       AWTEventListener listener = new AWTEventListener()
/*     */       {
/*     */         public void eventDispatched(AWTEvent event) {
/*  96 */           MouseEvent me = (MouseEvent)event;
/*  97 */           if ((event.getID() & 0x20) != 0L) {
/*  98 */             LocationTracker.instance().move(me);
/*     */           }
/* 100 */           if ((event.getID() & 0x10) != 0L) {
/* 101 */             LocationTracker.instance().click(me);
/*     */           }
/*     */         }
/* 104 */       };
/* 105 */       Toolkit.getDefaultToolkit().addAWTEventListener(listener, 48L);
/*     */     }
/*     */     catch (SecurityException e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized LocationTracker instance()
/*     */   {
/* 117 */     if (instance == null) {
/* 118 */       instance = new LocationTracker();
/*     */     }
/* 120 */     return instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MouseEvent getMouseButtonEvent()
/*     */   {
/* 128 */     return this.mouseButtonEvent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MouseEvent getMouseMotionEvent()
/*     */   {
/* 136 */     return this.mouseMovedEvent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void move(MouseEvent e)
/*     */   {
/* 145 */     this.mouseMovedEvent = translateEvent(e);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void click(MouseEvent e)
/*     */   {
/* 153 */     this.mouseButtonEvent = translateEvent(e);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private MouseEvent translateEvent(MouseEvent e)
/*     */   {
/* 163 */     Component source = e.getComponent();
/* 164 */     if (source != this.sourceComponent) {
/* 165 */       e = SwingUtilities.convertMouseEvent(source, e, this.sourceComponent);
/*     */     }
/* 167 */     return e;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSourceComponent(Component source)
/*     */   {
/* 175 */     this.sourceComponent = source;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\gui\input\mouse\LocationTracker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */