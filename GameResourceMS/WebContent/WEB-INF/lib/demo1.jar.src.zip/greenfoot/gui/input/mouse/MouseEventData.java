/*     */ package greenfoot.gui.input.mouse;
/*     */ 
/*     */ import greenfoot.Actor;
/*     */ import greenfoot.MouseInfo;
/*     */ import greenfoot.MouseInfoVisitor;
/*     */ import greenfoot.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MouseEventData
/*     */ {
/*     */   private MouseInfo mouseInfo;
/*     */   private MouseInfo mouseDragEndedInfo;
/*     */   private MouseInfo mouseClickedInfo;
/*     */   private MouseInfo mousePressedInfo;
/*     */   private MouseInfo mouseDraggedInfo;
/*     */   private MouseInfo mouseMovedInfo;
/*     */   
/*     */   public void init()
/*     */   {
/*  53 */     this.mousePressedInfo = null;
/*  54 */     this.mouseClickedInfo = null;
/*  55 */     this.mouseDraggedInfo = null;
/*  56 */     this.mouseDragEndedInfo = null;
/*  57 */     this.mouseMovedInfo = null;
/*  58 */     if (this.mouseInfo != null)
/*     */     {
/*  60 */       MouseInfo blankedMouseInfo = MouseInfoVisitor.newMouseInfo();
/*     */       
/*  62 */       MouseInfoVisitor.setLoc(blankedMouseInfo, this.mouseInfo.getX(), this.mouseInfo.getY());
/*  63 */       this.mouseInfo = blankedMouseInfo;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public MouseInfo getMouseInfo()
/*     */   {
/*  70 */     return this.mouseInfo;
/*     */   }
/*     */   
/*     */   public boolean isMousePressed(Object obj)
/*     */   {
/*  75 */     return checkObject(obj, this.mousePressedInfo);
/*     */   }
/*     */   
/*     */   public void mousePressed(int x, int y, int button, Actor actor)
/*     */   {
/*  80 */     init();
/*  81 */     this.mousePressedInfo = MouseInfoVisitor.newMouseInfo();
/*  82 */     this.mouseInfo = this.mousePressedInfo;
/*  83 */     MouseInfoVisitor.setButton(this.mouseInfo, button);
/*  84 */     MouseInfoVisitor.setLoc(this.mouseInfo, x, y);
/*  85 */     MouseInfoVisitor.setActor(this.mouseInfo, actor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isMouseClicked(Object obj)
/*     */   {
/*  92 */     if ((obj != null) && (isMousePressed(null)) && (!isMousePressed(obj))) {
/*  93 */       return false;
/*     */     }
/*  95 */     return checkObject(obj, this.mouseClickedInfo);
/*     */   }
/*     */   
/*     */   public void mouseClicked(int x, int y, int button, int clickCount, Actor actor)
/*     */   {
/* 100 */     MouseInfo tempPressedInfo = this.mousePressedInfo;
/* 101 */     init();
/* 102 */     this.mousePressedInfo = tempPressedInfo;
/*     */     
/* 104 */     this.mouseClickedInfo = MouseInfoVisitor.newMouseInfo();
/* 105 */     this.mouseInfo = this.mouseClickedInfo;
/* 106 */     MouseInfoVisitor.setButton(this.mouseInfo, button);
/* 107 */     MouseInfoVisitor.setLoc(this.mouseInfo, x, y);
/* 108 */     MouseInfoVisitor.setActor(this.mouseInfo, actor);
/* 109 */     MouseInfoVisitor.setClickCount(this.mouseInfo, clickCount);
/*     */   }
/*     */   
/*     */   public boolean isMouseDragged(Object obj)
/*     */   {
/* 114 */     return checkObject(obj, this.mouseDraggedInfo);
/*     */   }
/*     */   
/*     */   public void mouseDragged(int x, int y, int button, Actor actor)
/*     */   {
/* 119 */     init();
/* 120 */     this.mouseDraggedInfo = MouseInfoVisitor.newMouseInfo();
/* 121 */     this.mouseInfo = this.mouseDraggedInfo;
/* 122 */     MouseInfoVisitor.setButton(this.mouseInfo, button);
/* 123 */     MouseInfoVisitor.setLoc(this.mouseInfo, x, y);
/* 124 */     MouseInfoVisitor.setActor(this.mouseInfo, actor);
/*     */   }
/*     */   
/*     */   public boolean isMouseDragEnded(Object obj)
/*     */   {
/* 129 */     return checkObject(obj, this.mouseDragEndedInfo);
/*     */   }
/*     */   
/*     */   public void mouseDragEnded(int x, int y, int button, Actor actor)
/*     */   {
/* 134 */     MouseInfo tempPressedInfo = this.mousePressedInfo;
/* 135 */     MouseInfo tempClickedInfo = this.mouseClickedInfo;
/* 136 */     init();
/* 137 */     this.mousePressedInfo = tempPressedInfo;
/* 138 */     this.mouseClickedInfo = tempClickedInfo;
/* 139 */     this.mouseDragEndedInfo = MouseInfoVisitor.newMouseInfo();
/* 140 */     this.mouseInfo = this.mouseDragEndedInfo;
/* 141 */     MouseInfoVisitor.setButton(this.mouseInfo, button);
/* 142 */     MouseInfoVisitor.setLoc(this.mouseInfo, x, y);
/* 143 */     MouseInfoVisitor.setActor(this.mouseInfo, actor);
/*     */   }
/*     */   
/*     */   public void mouseExited()
/*     */   {
/* 148 */     this.mouseInfo = this.mouseDraggedInfo;
/* 149 */     this.mouseMovedInfo = null;
/*     */   }
/*     */   
/*     */   public boolean isMouseMoved(Object obj)
/*     */   {
/* 154 */     return checkObject(obj, this.mouseMovedInfo);
/*     */   }
/*     */   
/*     */   public void mouseMoved(int x, int y, int button, Actor actor)
/*     */   {
/* 159 */     init();
/* 160 */     this.mouseMovedInfo = MouseInfoVisitor.newMouseInfo();
/* 161 */     this.mouseInfo = this.mouseMovedInfo;
/* 162 */     MouseInfoVisitor.setButton(this.mouseInfo, button);
/* 163 */     MouseInfoVisitor.setLoc(this.mouseInfo, x, y);
/* 164 */     MouseInfoVisitor.setActor(this.mouseInfo, actor);
/*     */   }
/*     */   
/*     */   public Actor getActor()
/*     */   {
/* 169 */     if (this.mouseInfo == null) {
/* 170 */       return null;
/*     */     }
/* 172 */     return this.mouseInfo.getActor();
/*     */   }
/*     */   
/*     */   public int getButton()
/*     */   {
/* 177 */     if (this.mouseInfo == null) {
/* 178 */       return 0;
/*     */     }
/* 180 */     return this.mouseInfo.getButton();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean checkObject(Object obj, MouseInfo info)
/*     */   {
/* 192 */     if (info == null) {
/* 193 */       return false;
/*     */     }
/* 195 */     Actor actor = info.getActor();
/* 196 */     return (obj == null) || (((obj instanceof World)) && (actor == null)) || (actor == obj);
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 202 */     String s = "MouseEventData ";
/* 203 */     if (this.mouseInfo != null) {
/* 204 */       s = s + this.mouseInfo.toString();
/*     */     }
/* 206 */     if (this.mousePressedInfo != null) {
/* 207 */       s = s + " pressed";
/*     */     }
/* 209 */     if (this.mouseClickedInfo != null) {
/* 210 */       s = s + " clicked";
/*     */     }
/* 212 */     if (this.mouseDraggedInfo != null) {
/* 213 */       s = s + " dragged";
/*     */     }
/* 215 */     if (this.mouseDragEndedInfo != null) {
/* 216 */       s = s + " dragEnded";
/*     */     }
/* 218 */     if (this.mouseMovedInfo != null) {
/* 219 */       s = s + " moved";
/*     */     }
/* 221 */     return s;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\gui\input\mouse\MouseEventData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */