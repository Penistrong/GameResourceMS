/*     */ package greenfoot.gui.input;
/*     */ 
/*     */ import greenfoot.event.TriggeredKeyListener;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyboardManager
/*     */   implements TriggeredKeyListener, FocusListener
/*     */ {
/*     */   private String lastKeyTyped;
/*  53 */   private int numKeys = 100;
/*  54 */   private boolean[] keyLatched = new boolean[this.numKeys];
/*  55 */   private boolean[] keyDown = new boolean[this.numKeys];
/*     */   
/*     */ 
/*  58 */   private int maxNamedKey = 0;
/*     */   
/*     */ 
/*     */   private String[] keyNames;
/*     */   
/*     */   private Map<String, Integer> keyCodeMap;
/*     */   
/*  65 */   private boolean hasNumLock = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyboardManager()
/*     */   {
/*  73 */     this.keyCodeMap = new HashMap();
/*  74 */     addAllKeys();
/*  75 */     buildKeyNameArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void clearLatchedKeys()
/*     */   {
/*  84 */     for (int i = 0; i < this.numKeys; i++) {
/*  85 */       this.keyLatched[i] &= this.keyDown[i];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addAllKeys()
/*     */   {
/*  97 */     addKey("up", 38);
/*  98 */     addKey("down", 40);
/*  99 */     addKey("left", 37);
/* 100 */     addKey("right", 39);
/* 101 */     addKey("space", 32);
/* 102 */     addKey("enter", 10);
/* 103 */     addKey("escape", 27);
/* 104 */     addKey("f1", 112);
/* 105 */     addKey("f2", 113);
/* 106 */     addKey("f3", 114);
/* 107 */     addKey("f4", 115);
/* 108 */     addKey("f5", 116);
/* 109 */     addKey("f6", 117);
/* 110 */     addKey("f7", 118);
/* 111 */     addKey("f8", 119);
/* 112 */     addKey("f9", 120);
/* 113 */     addKey("f10", 121);
/* 114 */     addKey("f11", 122);
/* 115 */     addKey("f12", 123);
/* 116 */     addKey("backspace", 8);
/* 117 */     addKey("'", 222);
/* 118 */     addKey("shift", 16);
/* 119 */     addKey("control", 17);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addKey(String keyName, int keyCode)
/*     */   {
/* 131 */     this.keyCodeMap.put(keyName, Integer.valueOf(keyCode));
/* 132 */     if (keyCode + 1 > this.maxNamedKey) {
/* 133 */       this.maxNamedKey = (keyCode + 1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void buildKeyNameArray()
/*     */   {
/* 142 */     this.keyNames = new String[this.maxNamedKey];
/* 143 */     Iterator<String> keyNamesIterator = this.keyCodeMap.keySet().iterator();
/* 144 */     while (keyNamesIterator.hasNext()) {
/* 145 */       String keyName = (String)keyNamesIterator.next();
/* 146 */       int keyCode = ((Integer)this.keyCodeMap.get(keyName)).intValue();
/* 147 */       this.keyNames[keyCode] = keyName;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 152 */     this.keyNames[32] = null;
/* 153 */     this.keyNames[10] = null;
/* 154 */     this.keyNames[27] = null;
/* 155 */     this.keyNames[9] = null;
/* 156 */     this.keyNames[8] = null;
/* 157 */     this.keyNames['Þ'] = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkKeyArrays(int keycode)
/*     */   {
/* 169 */     int nsize = keycode + 1;
/* 170 */     if (nsize > this.numKeys)
/*     */     {
/* 172 */       boolean[] newKeyLatched = new boolean[nsize];
/* 173 */       boolean[] newKeyDown = new boolean[nsize];
/* 174 */       for (int i = 0; i < this.numKeys; i++) {
/* 175 */         newKeyLatched[i] = this.keyLatched[i];
/* 176 */         newKeyDown[i] = this.keyDown[i];
/*     */       }
/* 178 */       this.keyLatched = newKeyLatched;
/* 179 */       this.keyDown = newKeyDown;
/* 180 */       this.numKeys = nsize;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized String getKey()
/*     */   {
/* 189 */     String r = this.lastKeyTyped;
/* 190 */     this.lastKeyTyped = null;
/* 191 */     return r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean isKeyDown(int keycode)
/*     */   {
/* 204 */     if (keycode < this.numKeys) {
/* 205 */       boolean pressed = (this.keyDown[keycode] != 0) || (this.keyLatched[keycode] != 0);
/* 206 */       this.keyLatched[keycode] = false;
/* 207 */       return pressed;
/*     */     }
/*     */     
/* 210 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isKeyDown(String keyId)
/*     */   {
/* 224 */     Integer code = (Integer)this.keyCodeMap.get(keyId.toLowerCase());
/* 225 */     if (code != null) {
/* 226 */       return isKeyDown(code.intValue());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 232 */     if (keyId.codePointCount(0, keyId.length()) == 1) {
/* 233 */       int keyChar = keyId.codePointAt(0);
/* 234 */       keyChar = Character.toUpperCase(keyChar);
/* 235 */       return isKeyDown(keyChar);
/*     */     }
/* 237 */     throw new IllegalArgumentException("\"" + keyId + "\" key doesn't exist. " + "Please change the key name while invoking Greenfoot.isKeyDown() method");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void keyPressed(KeyEvent event)
/*     */   {
/* 249 */     int keyCode = event.getKeyCode();
/* 250 */     pressKey(keyCode);
/*     */   }
/*     */   
/*     */   private void pressKey(int keyCode)
/*     */   {
/* 255 */     keyCode = numLockTranslate(keyCode);
/* 256 */     checkKeyArrays(keyCode);
/* 257 */     this.keyLatched[keyCode] = true;
/* 258 */     this.keyDown[keyCode] = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void keyReleased(KeyEvent event)
/*     */   {
/* 266 */     int keyCode = event.getKeyCode();
/* 267 */     releaseKey(keyCode);
/*     */   }
/*     */   
/*     */   private void releaseKey(int keyCode)
/*     */   {
/* 272 */     keyCode = numLockTranslate(keyCode);
/* 273 */     checkKeyArrays(keyCode);
/* 274 */     this.keyDown[keyCode] = false;
/* 275 */     if (keyCode < this.maxNamedKey) {
/* 276 */       String keyName = this.keyNames[keyCode];
/* 277 */       if (keyName != null) {
/* 278 */         this.lastKeyTyped = keyName;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void listeningStarted(Object obj) {}
/*     */   
/*     */ 
/*     */   public void listeningEnded()
/*     */   {
/* 289 */     releaseAllKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int numLockTranslate(int keycode)
/*     */   {
/* 300 */     if ((keycode >= 96) && (keycode <= 105))
/*     */     {
/*     */ 
/* 303 */       return keycode - 96 + 48;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 309 */     boolean numlock = true;
/* 310 */     if (this.hasNumLock) {
/*     */       try {
/* 312 */         numlock = Toolkit.getDefaultToolkit().getLockingKeyState(144);
/*     */       }
/*     */       catch (UnsupportedOperationException usoe)
/*     */       {
/* 316 */         this.hasNumLock = false;
/*     */       }
/*     */     }
/*     */     
/* 320 */     if (numlock)
/*     */     {
/* 322 */       if (keycode == 224) {
/* 323 */         keycode = 56;
/*     */       }
/* 325 */       else if (keycode == 225) {
/* 326 */         keycode = 50;
/*     */       }
/* 328 */       else if (keycode == 226) {
/* 329 */         keycode = 52;
/*     */       }
/* 331 */       else if (keycode == 227) {
/* 332 */         keycode = 54;
/*     */       }
/*     */       
/*     */ 
/*     */     }
/* 337 */     else if (keycode == 224) {
/* 338 */       keycode = 38;
/*     */     }
/* 340 */     else if (keycode == 225) {
/* 341 */       keycode = 40;
/*     */     }
/* 343 */     else if (keycode == 226) {
/* 344 */       keycode = 37;
/*     */     }
/* 346 */     else if (keycode == 227) {
/* 347 */       keycode = 39;
/*     */     }
/*     */     
/* 350 */     return keycode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void keyTyped(KeyEvent key)
/*     */   {
/* 359 */     char c = key.getKeyChar();
/* 360 */     if ((c == '\n') || (c == '\r')) {
/* 361 */       this.lastKeyTyped = "enter";
/*     */     }
/* 363 */     else if (c == '\t') {
/* 364 */       this.lastKeyTyped = "tab";
/*     */     }
/* 366 */     else if (c == '\b') {
/* 367 */       this.lastKeyTyped = "backspace";
/*     */     }
/* 369 */     else if (c == ' ') {
/* 370 */       this.lastKeyTyped = "space";
/*     */     }
/* 372 */     else if (c == '\033') {
/* 373 */       this.lastKeyTyped = "escape";
/*     */     }
/*     */     else {
/* 376 */       this.lastKeyTyped = ("" + c);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void focusGained(FocusEvent e) {}
/*     */   
/*     */ 
/*     */   public void focusLost(FocusEvent e)
/*     */   {
/* 387 */     releaseAllKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void releaseAllKeys()
/*     */   {
/* 395 */     for (int keyCode = 0; keyCode < this.keyDown.length; keyCode++) {
/* 396 */       this.keyDown[keyCode] = false;
/* 397 */       this.keyLatched[keyCode] = false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\gui\input\KeyboardManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */