/*    */ package greenfoot.gui.input.states;
/*    */ 
/*    */ import greenfoot.event.TriggeredKeyListener;
/*    */ import greenfoot.event.TriggeredMouseListener;
/*    */ import greenfoot.event.TriggeredMouseMotionListener;
/*    */ import greenfoot.gui.input.InputManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IdleState
/*    */   extends State
/*    */ {
/*    */   protected static IdleState instance;
/*    */   
/*    */   public static synchronized IdleState getInstance()
/*    */     throws IllegalStateException
/*    */   {
/* 41 */     if (instance == null) {
/* 42 */       throw new IllegalStateException("Not initialized.");
/*    */     }
/* 44 */     return instance;
/*    */   }
/*    */   
/*    */ 
/*    */   private IdleState(InputManager inputManager, TriggeredKeyListener keyListener, TriggeredMouseListener mouseListener, TriggeredMouseMotionListener mouseMotionListener)
/*    */   {
/* 50 */     super(inputManager, keyListener, mouseListener, mouseMotionListener);
/*    */   }
/*    */   
/*    */ 
/*    */   public static synchronized IdleState initialize(InputManager inputManager, TriggeredKeyListener keyListener, TriggeredMouseListener mouseListener, TriggeredMouseMotionListener mouseMotionListener)
/*    */   {
/* 56 */     instance = new IdleState(inputManager, keyListener, mouseListener, mouseMotionListener);
/* 57 */     return instance;
/*    */   }
/*    */   
/*    */ 
/*    */   public void switchToNextState(State.Event event, Object obj)
/*    */   {
/* 63 */     super.switchToNextState(event, obj);
/* 64 */     switch (event) {
/*    */     case CONSTRUCTOR_INVOKED: 
/* 66 */       switchAndActivateState(ConstructorDragState.getInstance(), obj);
/* 67 */       break;
/*    */     case OBJECT_MOVED: 
/* 69 */       switchAndActivateState(MoveState.getInstance(), obj);
/* 70 */       break;
/*    */     case SIMULATION_STARTED: 
/* 72 */       switchAndActivateState(RunningState.getInstance(), obj);
/* 73 */       break;
/*    */     case MOUSE_PRESSED: 
/* 75 */       switchAndActivateState(MoveState.getInstance(), obj);
/* 76 */       break;
/*    */     case SHIFT_PRESSED: 
/* 78 */       switchAndActivateState(QuickAddDragState.getInstance(), obj);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\gui\input\states\IdleState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */