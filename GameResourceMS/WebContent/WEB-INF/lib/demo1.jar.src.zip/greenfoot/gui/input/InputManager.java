/*     */ package greenfoot.gui.input;
/*     */ 
/*     */ import greenfoot.Actor;
/*     */ import greenfoot.event.SimulationEvent;
/*     */ import greenfoot.event.SimulationListener;
/*     */ import greenfoot.event.TriggeredKeyAdapter;
/*     */ import greenfoot.event.TriggeredKeyListener;
/*     */ import greenfoot.event.TriggeredMouseAdapter;
/*     */ import greenfoot.event.TriggeredMouseListener;
/*     */ import greenfoot.event.TriggeredMouseMotionAdapter;
/*     */ import greenfoot.event.TriggeredMouseMotionListener;
/*     */ import greenfoot.event.WorldEvent;
/*     */ import greenfoot.event.WorldListener;
/*     */ import greenfoot.gui.input.states.ConstructorDragState;
/*     */ import greenfoot.gui.input.states.ConstructorDragWhileRunningState;
/*     */ import greenfoot.gui.input.states.DisabledState;
/*     */ import greenfoot.gui.input.states.IdleState;
/*     */ import greenfoot.gui.input.states.MoveState;
/*     */ import greenfoot.gui.input.states.QuickAddDragState;
/*     */ import greenfoot.gui.input.states.RunningState;
/*     */ import greenfoot.gui.input.states.State;
/*     */ import greenfoot.gui.input.states.State.Event;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import javax.swing.SwingUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InputManager
/*     */   implements SimulationListener, KeyListener, MouseListener, MouseMotionListener, WorldListener
/*     */ {
/*  68 */   private State state = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private TriggeredKeyListener activeKeyListener;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private TriggeredMouseListener activeMouseListener;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private TriggeredMouseMotionListener activeMouseMotionListener;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputManager()
/*     */   {
/*  91 */     State disabledState = DisabledState.initialize(this, new TriggeredKeyAdapter(), new TriggeredMouseAdapter(), new TriggeredMouseMotionAdapter());
/*  92 */     switchAndActivateState(disabledState, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRunningListeners(TriggeredKeyListener runningKeyListener, TriggeredMouseListener runningMouseListener, TriggeredMouseMotionListener runningMouseMotionListener)
/*     */   {
/* 103 */     RunningState.initialize(this, runningKeyListener, runningMouseListener, runningMouseMotionListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIdleListeners(TriggeredKeyListener idleKeyListener, TriggeredMouseListener idleMouseListener, TriggeredMouseMotionListener idleMouseMotionListener)
/*     */   {
/* 114 */     IdleState.initialize(this, idleKeyListener, idleMouseListener, idleMouseMotionListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDragListeners(TriggeredKeyListener dragKeyListener, TriggeredMouseListener dragMouseListener, TriggeredMouseMotionListener dragMouseMotionListener)
/*     */   {
/* 126 */     QuickAddDragState.initialize(this, dragKeyListener, dragMouseListener, dragMouseMotionListener);
/* 127 */     ConstructorDragState.initialize(this, dragKeyListener, dragMouseListener, dragMouseMotionListener);
/* 128 */     ConstructorDragWhileRunningState.initialize(this, dragKeyListener, dragMouseListener, dragMouseMotionListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMoveListeners(TriggeredKeyListener moveKeyListener, TriggeredMouseListener moveMouseListener, TriggeredMouseMotionListener moveMouseMotionListener)
/*     */   {
/* 140 */     MoveState.initialize(this, moveKeyListener, moveMouseListener, moveMouseMotionListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init()
/*     */     throws IllegalStateException
/*     */   {
/* 156 */     DisabledState.getInstance();
/* 157 */     RunningState.getInstance();
/* 158 */     MoveState.getInstance();
/* 159 */     QuickAddDragState.getInstance();
/* 160 */     ConstructorDragState.getInstance();
/* 161 */     ConstructorDragWhileRunningState.getInstance();
/*     */     
/* 163 */     switchAndActivateState(IdleState.getInstance(), null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void activateListeners(TriggeredKeyListener keyL, TriggeredMouseListener mouseL, TriggeredMouseMotionListener mouseMotionL, Object obj)
/*     */   {
/* 172 */     if (this.activeKeyListener != null) {
/* 173 */       this.activeKeyListener.listeningEnded();
/*     */     }
/* 175 */     if (this.activeMouseListener != null) {
/* 176 */       this.activeMouseListener.listeningEnded();
/*     */     }
/* 178 */     if (this.activeMouseMotionListener != null) {
/* 179 */       this.activeMouseMotionListener.listeningEnded();
/*     */     }
/*     */     
/* 182 */     this.activeKeyListener = keyL;
/* 183 */     this.activeMouseListener = mouseL;
/* 184 */     this.activeMouseMotionListener = mouseMotionL;
/*     */     
/* 186 */     this.activeKeyListener.listeningStarted(obj);
/* 187 */     this.activeMouseListener.listeningStarted(obj);
/* 188 */     this.activeMouseMotionListener.listeningStarted(obj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void switchAndActivateState(State newState, Object obj)
/*     */   {
/* 199 */     this.state = newState;
/* 200 */     this.state.activate(obj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void simulationChanged(final SimulationEvent e)
/*     */   {
/* 209 */     EventQueue.invokeLater(new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 213 */         if (e.getType() == 0) {
/* 214 */           InputManager.this.state.switchToNextState(State.Event.SIMULATION_STARTED, null);
/*     */         }
/* 216 */         else if (e.getType() == 1) {
/* 217 */           InputManager.this.state.switchToNextState(State.Event.SIMULATION_STOPPED, null);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void objectCreated(Actor object)
/*     */   {
/* 229 */     this.state.switchToNextState(State.Event.CONSTRUCTOR_INVOKED, object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void objectMoved(Actor object)
/*     */   {
/* 239 */     this.state.switchToNextState(State.Event.OBJECT_MOVED, object);
/*     */   }
/*     */   
/*     */   public void keyPressed(KeyEvent e)
/*     */   {
/* 244 */     if (e.getKeyCode() == 16) {
/* 245 */       this.state.switchToNextState(State.Event.SHIFT_PRESSED, null);
/*     */     }
/* 247 */     if (e.getKeyCode() == 27) {
/* 248 */       this.state.switchToNextState(State.Event.ESC_PRESSED, null);
/*     */     }
/* 250 */     this.activeKeyListener.keyPressed(e);
/*     */   }
/*     */   
/*     */   public void keyReleased(KeyEvent e)
/*     */   {
/* 255 */     this.activeKeyListener.keyReleased(e);
/* 256 */     if (e.getKeyCode() == 16) {
/* 257 */       this.state.switchToNextState(State.Event.SHIFT_RELEASED, null);
/*     */     }
/*     */   }
/*     */   
/*     */   public void keyTyped(KeyEvent e)
/*     */   {
/* 263 */     this.activeKeyListener.keyTyped(e);
/*     */   }
/*     */   
/*     */   public void mouseClicked(MouseEvent e)
/*     */   {
/* 268 */     checkShift(e);
/* 269 */     this.activeMouseListener.mouseClicked(e);
/*     */   }
/*     */   
/*     */   public void mousePressed(MouseEvent e)
/*     */   {
/* 274 */     checkShift(e);
/* 275 */     this.activeMouseListener.mousePressed(e);
/* 276 */     if ((SwingUtilities.isLeftMouseButton(e)) && (!e.isShiftDown())) {
/* 277 */       this.state.switchToNextState(State.Event.MOUSE_PRESSED, null);
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseReleased(MouseEvent e)
/*     */   {
/* 283 */     checkShift(e);
/* 284 */     this.activeMouseListener.mouseReleased(e);
/* 285 */     this.state.switchToNextState(State.Event.MOUSE_RELEASED, null);
/*     */   }
/*     */   
/*     */   public void mouseEntered(MouseEvent e)
/*     */   {
/* 290 */     checkShift(e);
/* 291 */     this.activeMouseListener.mouseEntered(e);
/*     */   }
/*     */   
/*     */   public void mouseExited(MouseEvent e)
/*     */   {
/* 296 */     checkShift(e);
/* 297 */     this.activeMouseListener.mouseExited(e);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkShift(MouseEvent e)
/*     */   {
/* 306 */     if ((this.state == QuickAddDragState.getInstance()) && (!e.isShiftDown())) {
/* 307 */       this.state.switchToNextState(State.Event.SHIFT_RELEASED, null);
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseDragged(MouseEvent e)
/*     */   {
/* 313 */     checkShift(e);
/* 314 */     this.activeMouseMotionListener.mouseDragged(e);
/*     */   }
/*     */   
/*     */   public void mouseMoved(MouseEvent e)
/*     */   {
/* 319 */     checkShift(e);
/* 320 */     this.activeMouseMotionListener.mouseMoved(e);
/*     */   }
/*     */   
/*     */   public void worldCreated(WorldEvent e)
/*     */   {
/* 325 */     this.state.switchToNextState(State.Event.WORLD_CREATED, null);
/*     */   }
/*     */   
/*     */   public void worldRemoved(WorldEvent e)
/*     */   {
/* 330 */     this.state.switchToNextState(State.Event.WORLD_REMOVED, null);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\gui\input\InputManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */