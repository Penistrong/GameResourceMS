/*     */ package greenfoot.gui.input.mouse;
/*     */ 
/*     */ import bluej.Config;
/*     */ import greenfoot.Actor;
/*     */ import greenfoot.MouseInfo;
/*     */ import greenfoot.event.TriggeredMouseListener;
/*     */ import greenfoot.event.TriggeredMouseMotionListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MousePollingManager
/*     */   implements TriggeredMouseListener, TriggeredMouseMotionListener
/*     */ {
/*  92 */   private MouseEventData currentData = new MouseEventData();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */   private MouseEventData futureData = new MouseEventData();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 112 */   private MouseEventData potentialNewDragData = new MouseEventData();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorldLocator locator;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */   private MouseEventData dragStartData = new MouseEventData();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isDragging;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean gotNewEvent;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MousePollingManager(WorldLocator locator)
/*     */   {
/* 154 */     this.locator = locator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWorldLocator(WorldLocator locator)
/*     */   {
/* 162 */     this.locator = locator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void newActStarted()
/*     */   {
/* 173 */     if (this.gotNewEvent) {
/* 174 */       MouseEventData newData = new MouseEventData();
/* 175 */       this.currentData = this.futureData;
/* 176 */       this.futureData = newData;
/* 177 */       this.potentialNewDragData = new MouseEventData();
/*     */       
/*     */ 
/* 180 */       this.gotNewEvent = false;
/*     */     }
/*     */     else {
/* 183 */       this.currentData.init();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void registerEventRecieved()
/*     */   {
/* 196 */     this.gotNewEvent = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMousePressed(Object obj)
/*     */   {
/* 220 */     return this.currentData.isMousePressed(obj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMouseClicked(Object obj)
/*     */   {
/* 238 */     return this.currentData.isMouseClicked(obj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMouseDragged(Object obj)
/*     */   {
/* 259 */     return this.currentData.isMouseDragged(obj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMouseDragEnded(Object obj)
/*     */   {
/* 280 */     return this.currentData.isMouseDragEnded(obj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMouseMoved(Object obj)
/*     */   {
/* 301 */     return this.currentData.isMouseMoved(obj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MouseInfo getMouseInfo()
/*     */   {
/* 314 */     return this.currentData.getMouseInfo();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mouseClicked(MouseEvent e)
/*     */   {
/* 328 */     Actor actor = this.locator.getTopMostActorAt(e);
/* 329 */     synchronized (this) {
/* 330 */       MouseEventData mouseData = this.futureData;
/*     */       
/*     */ 
/* 333 */       if (this.futureData.isMouseDragEnded(null)) {
/* 334 */         mouseData = this.potentialNewDragData;
/*     */       }
/* 336 */       if (!PriorityManager.isHigherPriority(e, mouseData)) return;
/* 337 */       registerEventRecieved();
/* 338 */       int x = this.locator.getTranslatedX(e);
/* 339 */       int y = this.locator.getTranslatedY(e);
/* 340 */       int button = getButton(e);
/*     */       
/* 342 */       mouseData.mouseClicked(x, y, button, e.getClickCount(), actor);
/* 343 */       this.isDragging = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getButton(MouseEvent e)
/*     */   {
/* 353 */     int button = e.getButton();
/* 354 */     if ((Config.isMacOS()) && (button == 1))
/*     */     {
/*     */ 
/*     */ 
/* 358 */       if ((e.getModifiersEx() & 0x80) == 128) {
/* 359 */         button = 3;
/*     */       }
/*     */     }
/* 362 */     return button;
/*     */   }
/*     */   
/*     */ 
/*     */   public void mouseEntered(MouseEvent e) {}
/*     */   
/*     */ 
/*     */   public void mouseExited(MouseEvent e)
/*     */   {
/* 371 */     synchronized (this) {
/* 372 */       this.futureData.mouseExited();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mousePressed(MouseEvent e)
/*     */   {
/* 383 */     Actor actor = this.locator.getTopMostActorAt(e);
/* 384 */     synchronized (this) {
/* 385 */       MouseEventData mouseData = this.futureData;
/*     */       
/*     */ 
/* 388 */       if (this.futureData.isMouseDragEnded(null)) {
/* 389 */         mouseData = this.potentialNewDragData;
/*     */       }
/*     */       
/*     */ 
/* 393 */       this.dragStartData = new MouseEventData();
/* 394 */       int x = this.locator.getTranslatedX(e);
/* 395 */       int y = this.locator.getTranslatedY(e);
/* 396 */       int button = getButton(e);
/* 397 */       this.dragStartData.mousePressed(x, y, button, actor);
/*     */       
/*     */ 
/* 400 */       if (!PriorityManager.isHigherPriority(e, mouseData)) return;
/* 401 */       registerEventRecieved();
/* 402 */       mouseData.mousePressed(x, y, button, actor);
/* 403 */       this.isDragging = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mouseReleased(MouseEvent e)
/*     */   {
/* 414 */     Actor clickActor = this.locator.getTopMostActorAt(e);
/* 415 */     synchronized (this)
/*     */     {
/* 417 */       if (this.isDragging)
/*     */       {
/*     */ 
/* 420 */         if (this.futureData.isMouseDragEnded(null)) {
/* 421 */           this.futureData = this.potentialNewDragData;
/*     */         }
/*     */         
/* 424 */         if (!PriorityManager.isHigherPriority(e, this.futureData)) return;
/* 425 */         registerEventRecieved();
/* 426 */         int x = this.locator.getTranslatedX(e);
/* 427 */         int y = this.locator.getTranslatedY(e);
/* 428 */         int button = getButton(e);
/*     */         
/* 430 */         this.futureData.mouseClicked(x, y, button, 1, clickActor);
/*     */         
/* 432 */         Actor actor = this.dragStartData.getActor();
/* 433 */         this.futureData.mouseDragEnded(x, y, button, actor);
/* 434 */         this.isDragging = false;
/* 435 */         this.potentialNewDragData = new MouseEventData();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseDragged(MouseEvent e)
/*     */   {
/* 442 */     synchronized (this) {
/* 443 */       this.isDragging = true;
/*     */       
/* 445 */       if (!PriorityManager.isHigherPriority(e, this.futureData)) return;
/* 446 */       registerEventRecieved();
/*     */       
/*     */ 
/* 449 */       int x = this.locator.getTranslatedX(e);
/* 450 */       int y = this.locator.getTranslatedY(e);
/* 451 */       this.futureData.mouseDragged(x, y, this.dragStartData.getButton(), this.dragStartData.getActor());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mouseMoved(MouseEvent e)
/*     */   {
/* 462 */     Actor actor = this.locator.getTopMostActorAt(e);
/* 463 */     synchronized (this) {
/* 464 */       if (!PriorityManager.isHigherPriority(e, this.futureData)) return;
/* 465 */       registerEventRecieved();
/* 466 */       int x = this.locator.getTranslatedX(e);
/* 467 */       int y = this.locator.getTranslatedY(e);
/* 468 */       int button = getButton(e);
/* 469 */       this.futureData.mouseMoved(x, y, button, actor);
/* 470 */       this.isDragging = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public void listeningEnded() {}
/*     */   
/*     */   public void listeningStarted(Object obj) {}
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\gui\input\mouse\MousePollingManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */