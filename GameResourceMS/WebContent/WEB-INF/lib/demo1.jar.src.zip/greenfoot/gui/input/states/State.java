/*     */ package greenfoot.gui.input.states;
/*     */ 
/*     */ import greenfoot.event.TriggeredKeyAdapter;
/*     */ import greenfoot.event.TriggeredKeyListener;
/*     */ import greenfoot.event.TriggeredMouseAdapter;
/*     */ import greenfoot.event.TriggeredMouseListener;
/*     */ import greenfoot.event.TriggeredMouseMotionAdapter;
/*     */ import greenfoot.event.TriggeredMouseMotionListener;
/*     */ import greenfoot.gui.input.InputManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class State
/*     */ {
/*     */   protected InputManager inputManager;
/*     */   private TriggeredKeyListener keyListener;
/*     */   private TriggeredMouseListener mouseListener;
/*     */   private TriggeredMouseMotionListener mouseMotionListener;
/*     */   
/*     */   public static enum Event
/*     */   {
/*  48 */     CONSTRUCTOR_INVOKED,  MOUSE_RELEASED,  SHIFT_PRESSED,  SHIFT_RELEASED,  MOUSE_PRESSED,  SIMULATION_STARTED,  SIMULATION_STOPPED,  WORLD_CREATED,  WORLD_REMOVED,  OBJECT_MOVED,  ESC_PRESSED;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Event() {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   State(InputManager inputManager, TriggeredKeyListener keyListener, TriggeredMouseListener mouseListener, TriggeredMouseMotionListener mouseMotionListener)
/*     */   {
/*  60 */     this.inputManager = inputManager;
/*     */     
/*  62 */     if (keyListener != null) {
/*  63 */       this.keyListener = keyListener;
/*     */     }
/*     */     else {
/*  66 */       this.keyListener = new TriggeredKeyAdapter();
/*     */     }
/*     */     
/*  69 */     if (mouseListener != null) {
/*  70 */       this.mouseListener = mouseListener;
/*     */     }
/*     */     else {
/*  73 */       this.mouseListener = new TriggeredMouseAdapter();
/*     */     }
/*     */     
/*  76 */     if (mouseMotionListener != null) {
/*  77 */       this.mouseMotionListener = mouseMotionListener;
/*     */     }
/*     */     else {
/*  80 */       this.mouseMotionListener = new TriggeredMouseMotionAdapter();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void switchToNextState(Event event, Object obj)
/*     */   {
/*  94 */     switch (event) {
/*     */     case WORLD_REMOVED: 
/*  96 */       this.inputManager.switchAndActivateState(DisabledState.getInstance(), obj);
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void activate(Object obj)
/*     */   {
/* 112 */     this.inputManager.activateListeners(this.keyListener, this.mouseListener, this.mouseMotionListener, obj);
/*     */   }
/*     */   
/*     */   void switchAndActivateState(State state, Object obj)
/*     */   {
/* 117 */     this.inputManager.switchAndActivateState(state, obj);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\gui\input\states\State.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */