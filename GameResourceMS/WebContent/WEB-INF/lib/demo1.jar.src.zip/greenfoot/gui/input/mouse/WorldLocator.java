package greenfoot.gui.input.mouse;

import greenfoot.Actor;
import java.awt.event.MouseEvent;

public abstract interface WorldLocator
{
  public abstract Actor getTopMostActorAt(MouseEvent paramMouseEvent);
  
  public abstract int getTranslatedX(MouseEvent paramMouseEvent);
  
  public abstract int getTranslatedY(MouseEvent paramMouseEvent);
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\gui\input\mouse\WorldLocator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */