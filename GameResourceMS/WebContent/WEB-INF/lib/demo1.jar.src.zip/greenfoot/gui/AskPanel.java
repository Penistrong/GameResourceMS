/*     */ package greenfoot.gui;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AskPanel
/*     */   implements ActionListener
/*     */ {
/*  44 */   private static final Color BACKGROUND = new Color(222, 166, 41);
/*     */   
/*     */   private JLabel promptDisplay;
/*     */   
/*     */   private JPanel panel;
/*     */   
/*     */   private JTextField answer;
/*     */   private JButton ok;
/*     */   private AnswerListener answerListener;
/*     */   
/*     */   public AskPanel()
/*     */   {
/*  56 */     this.panel = new JPanel();
/*  57 */     this.panel.setLayout(new BoxLayout(this.panel, 1));
/*  58 */     this.panel.setOpaque(false);
/*     */     
/*  60 */     this.promptDisplay = new JLabel("");
/*  61 */     this.promptDisplay.setOpaque(true);
/*  62 */     this.promptDisplay.setBackground(BACKGROUND);
/*  63 */     this.promptDisplay.setAlignmentX(0.0F);
/*  64 */     this.promptDisplay.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(2, 0, 0, 0, Color.DARK_GRAY), BorderFactory.createEmptyBorder(4, 20, 4, 20)));
/*  65 */     JPanel promptPanel = new JPanel();
/*  66 */     promptPanel.setLayout(new BorderLayout());
/*  67 */     promptPanel.setOpaque(false);
/*     */     
/*  69 */     promptPanel.add(this.promptDisplay, "South");
/*     */     
/*  71 */     this.panel.add(promptPanel);
/*     */     
/*  73 */     JPanel answerPanel = new JPanel();
/*  74 */     answerPanel.setLayout(new BoxLayout(answerPanel, 0));
/*  75 */     answerPanel.setBackground(BACKGROUND);
/*     */     
/*  77 */     this.answer = new JTextField();
/*  78 */     this.answer.setMaximumSize(new Dimension(Integer.MAX_VALUE, this.answer.getPreferredSize().height));
/*     */     
/*  80 */     this.answer.addActionListener(this);
/*  81 */     answerPanel.add(this.answer);
/*     */     
/*  83 */     this.ok = new JButton("OK");
/*  84 */     this.ok.addActionListener(this);
/*  85 */     this.ok.setMaximumSize(new Dimension(50, this.answer.getMaximumSize().height));
/*  86 */     answerPanel.add(this.ok);
/*     */     
/*  88 */     answerPanel.setBorder(BorderFactory.createEmptyBorder(3, 20, 8, 20));
/*  89 */     this.panel.add(answerPanel);
/*     */     
/*  91 */     hidePanel();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void showPanel(int width, String prompt, AnswerListener listener)
/*     */   {
/* 111 */     this.answerListener = listener;
/* 112 */     this.panel.setVisible(true);
/*     */     
/* 114 */     this.answer.setText("");
/* 115 */     this.promptDisplay.setText("<html>" + prompt + "</html>");
/* 116 */     this.answer.requestFocusInWindow();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void hidePanel()
/*     */   {
/* 124 */     this.panel.setVisible(false);
/*     */   }
/*     */   
/*     */ 
/*     */   public void actionPerformed(ActionEvent e)
/*     */   {
/* 130 */     hidePanel();
/* 131 */     if (this.answerListener != null) {
/* 132 */       this.answerListener.answered(this.answer.getText());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isPanelShowing()
/*     */   {
/* 140 */     return this.panel.isVisible();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JPanel getComponent()
/*     */   {
/* 148 */     return this.panel;
/*     */   }
/*     */   
/*     */   public static abstract interface AnswerListener
/*     */   {
/*     */     public abstract void answered(String paramString);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\gui\AskPanel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */