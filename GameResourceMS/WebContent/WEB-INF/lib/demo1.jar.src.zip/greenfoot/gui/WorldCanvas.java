/*     */ package greenfoot.gui;
/*     */ 
/*     */ import greenfoot.Actor;
/*     */ import greenfoot.ActorVisitor;
/*     */ import greenfoot.GreenfootImage;
/*     */ import greenfoot.ImageVisitor;
/*     */ import greenfoot.World;
/*     */ import greenfoot.WorldVisitor;
/*     */ import greenfoot.core.TextLabel;
/*     */ import greenfoot.core.WorldHandler;
/*     */ import greenfoot.util.GreenfootUtil;
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.Scrollable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WorldCanvas
/*     */   extends JPanel
/*     */   implements DropTarget, Scrollable
/*     */ {
/*     */   private World world;
/*     */   private DropTarget dropTargetListener;
/*     */   private Actor dragActor;
/*     */   private Point dragLocation;
/*     */   private BufferedImage dragImage;
/*     */   private Dimension size;
/*     */   private Font textLabelFont;
/*     */   private Image overrideImage;
/*     */   
/*     */   public WorldCanvas(World world)
/*     */   {
/*  80 */     setWorld(world);
/*  81 */     setBackground(Color.WHITE);
/*  82 */     setOpaque(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWorld(World world)
/*     */   {
/*  91 */     this.world = world;
/*  92 */     setOverrideImage(null);
/*  93 */     if (world != null) {
/*  94 */       setSize(getPreferredSize());
/*  95 */       revalidate();
/*  96 */       repaint();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWorldSize(int xsize, int ysize)
/*     */   {
/* 109 */     if (this.world == null) {
/* 110 */       this.size = new Dimension(xsize, ysize);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void paintObjects(Graphics2D g)
/*     */   {
/* 121 */     Set<Actor> objects = WorldVisitor.getObjectsListInPaintOrder(this.world);
/* 122 */     int paintSeq = 0;
/* 123 */     for (Iterator<Actor> iter = objects.iterator(); iter.hasNext();) {
/* 124 */       Actor thing = (Actor)iter.next();
/* 125 */       int cellSize = WorldVisitor.getCellSize(this.world);
/*     */       
/* 127 */       GreenfootImage image = ActorVisitor.getDisplayImage(thing);
/* 128 */       if (image != null) {
/* 129 */         ActorVisitor.setLastPaintSeqNum(thing, paintSeq++);
/*     */         
/* 131 */         double halfWidth = image.getWidth() / 2.0D;
/* 132 */         double halfHeight = image.getHeight() / 2.0D;
/*     */         
/* 134 */         AffineTransform oldTx = null;
/*     */         try {
/* 136 */           int ax = ActorVisitor.getX(thing);
/* 137 */           int ay = ActorVisitor.getY(thing);
/* 138 */           double xCenter = ax * cellSize + cellSize / 2.0D;
/* 139 */           int paintX = (int)Math.floor(xCenter - halfWidth);
/* 140 */           double yCenter = ay * cellSize + cellSize / 2.0D;
/* 141 */           int paintY = (int)Math.floor(yCenter - halfHeight);
/*     */           
/* 143 */           int rotation = ActorVisitor.getRotation(thing);
/* 144 */           if (rotation != 0)
/*     */           {
/*     */ 
/* 147 */             oldTx = g.getTransform();
/* 148 */             g.rotate(Math.toRadians(rotation), xCenter, yCenter);
/*     */           }
/*     */           
/* 151 */           ImageVisitor.drawImage(image, g, paintX, paintY, this, true);
/*     */         }
/*     */         catch (IllegalStateException e) {}
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 161 */         if (oldTx != null) {
/* 162 */           g.setTransform(oldTx);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void paintComponent(Graphics g)
/*     */   {
/* 171 */     if (this.overrideImage != null)
/*     */     {
/* 173 */       g.drawImage(this.overrideImage, 1, 1, null);
/* 174 */       return;
/*     */     }
/*     */     
/* 177 */     if (this.world == null) {
/* 178 */       Color c = g.getColor();
/* 179 */       g.setColor(getParent().getBackground());
/* 180 */       g.fillRect(0, 0, getWidth(), getHeight());
/* 181 */       WorldHandler.getInstance().repainted();
/* 182 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 195 */       ReentrantReadWriteLock lock = WorldHandler.getInstance().getWorldLock();
/* 196 */       int timeout = 500;
/* 197 */       if (lock.readLock().tryLock(timeout, TimeUnit.MILLISECONDS)) {
/*     */         try {
/* 199 */           Insets insets = getInsets();
/* 200 */           Graphics2D g2 = (Graphics2D)g;
/* 201 */           g.translate(insets.left, insets.top);
/* 202 */           paintBackground(g2);
/* 203 */           paintObjects(g2);
/* 204 */           paintDraggedObject(g2);
/* 205 */           WorldVisitor.paintDebug(this.world, g2);
/* 206 */           paintWorldText(g2, this.world);
/* 207 */           g.translate(-insets.left, -insets.top);
/*     */         }
/*     */         finally {
/* 210 */           lock.readLock().unlock();
/* 211 */           WorldHandler.getInstance().repainted();
/*     */         }
/*     */         
/*     */       } else {
/* 215 */         WorldHandler.getInstance().repainted();
/*     */       }
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/* 220 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void paintWorldText(Graphics2D g, World world)
/*     */   {
/* 231 */     List<TextLabel> labels = WorldVisitor.getTextLabels(world);
/*     */     
/* 233 */     if (labels.isEmpty()) {
/* 234 */       return;
/*     */     }
/*     */     
/*     */ 
/* 238 */     Font origFont = g.getFont();
/* 239 */     Color orig = g.getColor();
/* 240 */     Object origAntiAliasing = g.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
/*     */     
/* 242 */     int cellsize = WorldVisitor.getCellSize(world);
/* 243 */     for (TextLabel label : labels) {
/* 244 */       label.draw(g, cellsize);
/*     */     }
/*     */     
/*     */ 
/* 248 */     g.setFont(origFont);
/* 249 */     g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, origAntiAliasing);
/* 250 */     g.setColor(orig);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void paintDraggedObject(Graphics g)
/*     */   {
/* 260 */     if (this.dragImage != null) {
/* 261 */       int x = (int)this.dragLocation.getX();
/* 262 */       int y = (int)this.dragLocation.getY();
/* 263 */       int xCell = WorldVisitor.toCellFloor(this.world, x);
/* 264 */       int yCell = WorldVisitor.toCellFloor(this.world, y);
/* 265 */       int cellSize = WorldVisitor.getCellSize(this.world);
/* 266 */       x = (int)((xCell + 0.5D) * cellSize - this.dragImage.getWidth() / 2);
/* 267 */       y = (int)((yCell + 0.5D) * cellSize - this.dragImage.getHeight() / 2);
/*     */       
/* 269 */       g.drawImage(this.dragImage, x, y, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void paintBackground(Graphics2D g)
/*     */   {
/* 279 */     if (this.world != null) {
/* 280 */       GreenfootImage backgroundImage = WorldVisitor.getBackgroundImage(this.world);
/* 281 */       if (backgroundImage != null) {
/* 282 */         ImageVisitor.drawImage(backgroundImage, g, 0, 0, this, true);
/*     */       }
/*     */       else {
/* 285 */         Color oldColor = g.getColor();
/* 286 */         g.setColor(getBackground());
/* 287 */         g.fillRect(0, 0, getWidth(), getHeight());
/* 288 */         g.setColor(oldColor);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Dimension getMinimumSize()
/*     */   {
/* 296 */     return getPreferredSize();
/*     */   }
/*     */   
/*     */ 
/*     */   public Dimension getPreferredSize()
/*     */   {
/* 302 */     if (this.world != null) {
/* 303 */       this.size = new Dimension();
/* 304 */       this.size.width = WorldVisitor.getWidthInPixels(this.world);
/* 305 */       this.size.height = WorldVisitor.getHeightInPixels(this.world);
/* 306 */       Insets insets = getInsets();
/* 307 */       this.size.width += insets.left + insets.right;
/* 308 */       this.size.height += insets.top + insets.bottom;
/* 309 */       return this.size;
/*     */     }
/* 311 */     if (this.size != null) {
/* 312 */       return this.size;
/*     */     }
/*     */     
/* 315 */     return super.getPreferredSize();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setDropTargetListener(DropTarget dropTargetListener)
/*     */   {
/* 321 */     this.dropTargetListener = dropTargetListener;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean drop(Object o, Point p)
/*     */   {
/* 327 */     Insets insets = getInsets();
/* 328 */     Point p2 = new Point(p.x - insets.left, p.y - insets.top);
/* 329 */     clearDragInfo();
/* 330 */     if (this.dropTargetListener != null) {
/* 331 */       return this.dropTargetListener.drop(o, p2);
/*     */     }
/*     */     
/* 334 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean drag(Object o, Point p)
/*     */   {
/* 344 */     Insets insets = getInsets();
/* 345 */     Point p2 = new Point(p.x - insets.left, p.y - insets.top);
/* 346 */     if (((o instanceof Actor)) && (ActorVisitor.getWorld((Actor)o) == null)) {
/* 347 */       if (!getVisibleRect().contains(p)) {
/* 348 */         return false;
/*     */       }
/* 350 */       if (o != this.dragActor)
/*     */       {
/* 352 */         this.dragActor = ((Actor)o);
/* 353 */         this.dragImage = GreenfootUtil.createDragShadow(ActorVisitor.getDragImage(this.dragActor).getAwtImage());
/*     */       }
/* 355 */       this.dragLocation = p2;
/* 356 */       repaint();
/* 357 */       return true;
/*     */     }
/* 359 */     if (this.dropTargetListener != null) {
/* 360 */       return this.dropTargetListener.drag(o, p2);
/*     */     }
/*     */     
/* 363 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public void dragEnded(Object o)
/*     */   {
/* 369 */     clearDragInfo();
/* 370 */     if (this.dropTargetListener != null) {
/* 371 */       this.dropTargetListener.dragEnded(o);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void clearDragInfo()
/*     */   {
/* 381 */     this.dragLocation = null;
/* 382 */     this.dragActor = null;
/* 383 */     this.dragImage = null;
/* 384 */     repaint();
/*     */   }
/*     */   
/*     */   public Dimension getPreferredScrollableViewportSize()
/*     */   {
/* 389 */     return getPreferredSize();
/*     */   }
/*     */   
/*     */   public int getScrollableUnitIncrement(Rectangle visibleRect, int orientation, int direction)
/*     */   {
/* 394 */     int cellSize = this.world.getCellSize();
/* 395 */     double scrollPos = 0.0D;
/* 396 */     if (orientation == 0)
/*     */     {
/* 398 */       if (direction < 0) {
/* 399 */         scrollPos = visibleRect.getMinX();
/*     */ 
/*     */ 
/*     */       }
/* 403 */       else if (direction > 0) {
/* 404 */         scrollPos = visibleRect.getMaxX();
/*     */       }
/*     */       
/*     */     }
/* 408 */     else if (direction < 0) {
/* 409 */       scrollPos = visibleRect.getMinY();
/*     */ 
/*     */     }
/* 412 */     else if (direction > 0) {
/* 413 */       scrollPos = visibleRect.getMaxY();
/*     */     }
/*     */     
/* 416 */     int increment = Math.abs((int)Math.IEEEremainder(scrollPos, cellSize));
/* 417 */     if (increment == 0) {
/* 418 */       increment = cellSize;
/*     */     }
/*     */     
/* 421 */     return increment;
/*     */   }
/*     */   
/*     */   public int getScrollableBlockIncrement(Rectangle visibleRect, int orientation, int direction)
/*     */   {
/* 426 */     return getScrollableUnitIncrement(visibleRect, orientation, direction);
/*     */   }
/*     */   
/*     */   public boolean getScrollableTracksViewportWidth()
/*     */   {
/* 431 */     return false;
/*     */   }
/*     */   
/*     */   public boolean getScrollableTracksViewportHeight()
/*     */   {
/* 436 */     return false;
/*     */   }
/*     */   
/*     */   public void setOverrideImage(Image snapshot)
/*     */   {
/* 441 */     this.overrideImage = snapshot;
/* 442 */     repaint();
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\gui\WorldCanvas.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */