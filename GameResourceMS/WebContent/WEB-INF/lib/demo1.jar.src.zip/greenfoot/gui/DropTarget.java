package greenfoot.gui;

import java.awt.Point;

public abstract interface DropTarget
{
  public abstract boolean drag(Object paramObject, Point paramPoint);
  
  public abstract boolean drop(Object paramObject, Point paramPoint);
  
  public abstract void dragEnded(Object paramObject);
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\gui\DropTarget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */