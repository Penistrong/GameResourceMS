/*      */ package greenfoot;
/*      */ 
/*      */ import greenfoot.collision.ibsp.Rect;
/*      */ import greenfoot.core.WorldHandler;
/*      */ import greenfoot.platforms.ActorDelegate;
/*      */ import greenfoot.util.GreenfootUtil;
/*      */ import java.io.PrintStream;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Actor
/*      */ {
/*      */   private static final String NO_WORLD = "An actor is trying to access the world, when no world has been instantiated.";
/*      */   private static final String ACTOR_NOT_IN_WORLD = "Actor not in world. An attempt was made to use the actor's location while it is not in the world. Either it has not yet been inserted, or it has been removed.";
/*   57 */   private static int sequenceNumber = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int x;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   int y;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int mySequenceNumber;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int lastPaintSequenceNumber;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   83 */   int rotation = 0;
/*      */   
/*      */ 
/*      */   World world;
/*      */   
/*      */ 
/*      */   private GreenfootImage image;
/*      */   
/*      */ 
/*      */   private Object data;
/*      */   
/*      */ 
/*      */   static GreenfootImage greenfootImage;
/*      */   
/*      */   private Rect boundingRect;
/*      */   
/*   99 */   private int[] boundingXs = new int[4];
/*      */   
/*  101 */   private int[] boundingYs = new int[4];
/*      */   private static ActorDelegate delegate;
/*      */   
/*      */   static {
/*      */     try {
/*  106 */       greenfootImage = new GreenfootImage(GreenfootUtil.getGreenfootLogoPath());
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  110 */       e.printStackTrace();
/*  111 */       System.err.println("Greenfoot installation is broken - reinstalling Greenfoot might help.");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Actor()
/*      */   {
/*  123 */     this.mySequenceNumber = (sequenceNumber++);
/*  124 */     GreenfootImage image = getClassImage();
/*  125 */     if (image == null) {
/*  126 */       image = greenfootImage;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  131 */     image = image.getCopyOnWriteClone();
/*      */     
/*  133 */     setImage(image);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getX()
/*      */     throws IllegalStateException
/*      */   {
/*  157 */     failIfNotInWorld();
/*  158 */     return this.x;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getY()
/*      */   {
/*  170 */     failIfNotInWorld();
/*  171 */     return this.y;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRotation()
/*      */   {
/*  185 */     return this.rotation;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRotation(int rotation)
/*      */   {
/*  200 */     if (rotation >= 360)
/*      */     {
/*      */ 
/*  203 */       if (rotation < 720) {
/*  204 */         rotation -= 360;
/*      */       }
/*      */       else {
/*  207 */         rotation %= 360;
/*      */       }
/*      */     }
/*  210 */     else if (rotation < 0)
/*      */     {
/*      */ 
/*  213 */       if (rotation >= 65176) {
/*  214 */         rotation += 360;
/*      */       }
/*      */       else {
/*  217 */         rotation = 360 + rotation % 360;
/*      */       }
/*      */     }
/*      */     
/*  221 */     if (this.rotation != rotation) {
/*  222 */       this.rotation = rotation;
/*      */       
/*  224 */       this.boundingRect = null;
/*      */       
/*  226 */       sizeChanged();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void turnTowards(int x, int y)
/*      */   {
/*  238 */     double a = Math.atan2(y - this.y, x - this.x);
/*  239 */     setRotation((int)Math.toDegrees(a));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAtEdge()
/*      */   {
/*  254 */     failIfNotInWorld();
/*      */     
/*      */ 
/*  257 */     return (this.x <= 0) || (this.y <= 0) || (this.x >= getWorld().getWidth() - 1) || (this.y >= getWorld().getHeight() - 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocation(int x, int y)
/*      */   {
/*  274 */     setLocationDrag(x, y);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void move(int distance)
/*      */   {
/*  290 */     double radians = Math.toRadians(this.rotation);
/*      */     
/*      */ 
/*      */ 
/*  294 */     int dx = (int)Math.round(Math.cos(radians) * distance);
/*  295 */     int dy = (int)Math.round(Math.sin(radians) * distance);
/*  296 */     setLocation(this.x + dx, this.y + dy);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void turn(int amount)
/*      */   {
/*  308 */     setRotation(this.rotation + amount);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setLocationDrag(int x, int y)
/*      */   {
/*  327 */     if (this.world != null) {
/*  328 */       int oldX = this.x;
/*  329 */       int oldY = this.y;
/*      */       
/*  331 */       if (this.world.isBounded()) {
/*  332 */         this.x = limitValue(x, this.world.width);
/*  333 */         this.y = limitValue(y, this.world.height);
/*      */       }
/*      */       else {
/*  336 */         this.x = x;
/*  337 */         this.y = y;
/*      */       }
/*      */       
/*  340 */       if ((this.x != oldX) || (this.y != oldY)) {
/*  341 */         if (this.boundingRect != null) {
/*  342 */           int dx = (this.x - oldX) * this.world.cellSize;
/*  343 */           int dy = (this.y - oldY) * this.world.cellSize;
/*      */           
/*  345 */           this.boundingRect.setX(this.boundingRect.getX() + dx);
/*  346 */           this.boundingRect.setY(this.boundingRect.getY() + dy);
/*      */           
/*  348 */           for (int i = 0; i < 4; i++) {
/*  349 */             this.boundingXs[i] += dx;
/*  350 */             this.boundingYs[i] += dy;
/*      */           }
/*      */         }
/*  353 */         locationChanged(oldX, oldY);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int limitValue(int v, int limit)
/*      */   {
/*  363 */     if (v < 0) {
/*  364 */       v = 0;
/*      */     }
/*  366 */     if (limit <= v) {
/*  367 */       v = limit - 1;
/*      */     }
/*  369 */     return v;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public World getWorld()
/*      */   {
/*  379 */     return this.world;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public GreenfootImage getImage()
/*      */   {
/*  402 */     return this.image;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setImage(String filename)
/*      */     throws IllegalArgumentException
/*      */   {
/*  415 */     setImage(new GreenfootImage(filename));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setImage(GreenfootImage image)
/*      */   {
/*  426 */     if ((image == null) && (this.image == null)) {
/*  427 */       return;
/*      */     }
/*      */     
/*  430 */     boolean sizeChanged = true;
/*      */     
/*  432 */     if ((image != null) && (this.image != null) && 
/*  433 */       (image.getWidth() == this.image.getWidth()) && (image.getHeight() == this.image.getHeight())) {
/*  434 */       sizeChanged = false;
/*      */     }
/*      */     
/*      */ 
/*  438 */     this.image = image;
/*      */     
/*  440 */     if (sizeChanged) {
/*  441 */       this.boundingRect = null;
/*  442 */       sizeChanged();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setLocationInPixels(int x, int y)
/*      */   {
/*  464 */     int xCell = this.world.toCellFloor(x);
/*  465 */     int yCell = this.world.toCellFloor(y);
/*      */     
/*  467 */     if ((xCell == this.x) && (yCell == this.y)) {
/*  468 */       return;
/*      */     }
/*      */     
/*  471 */     setLocationDrag(xCell, yCell);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setWorld(World world)
/*      */   {
/*  481 */     this.world = world;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addToWorld(int x, int y, World world)
/*      */   {
/*  490 */     if (world.isBounded()) {
/*  491 */       x = limitValue(x, world.getWidth());
/*  492 */       y = limitValue(y, world.getHeight());
/*      */     }
/*      */     
/*  495 */     this.x = x;
/*  496 */     this.y = y;
/*  497 */     this.boundingRect = null;
/*      */     
/*  499 */     setWorld(world);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  504 */     setLocation(x, y);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Rect getBoundingRect()
/*      */   {
/*  515 */     if (this.boundingRect == null) {
/*  516 */       calcBounds();
/*      */     }
/*  518 */     return this.boundingRect;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void calcBounds()
/*      */   {
/*  526 */     World w = getActiveWorld();
/*  527 */     if (w == null) {
/*  528 */       return;
/*      */     }
/*  530 */     int cellSize = w.getCellSize();
/*      */     
/*  532 */     if (this.image == null) {
/*  533 */       int wx = this.x * cellSize + cellSize / 2;
/*  534 */       int wy = this.y * cellSize + cellSize / 2;
/*  535 */       this.boundingRect = new Rect(wx, wy, 0, 0);
/*  536 */       for (int i = 0; i < 4; i++) {
/*  537 */         this.boundingXs[i] = wx;
/*  538 */         this.boundingYs[i] = wy;
/*      */       }
/*  540 */       return;
/*      */     }
/*      */     
/*  543 */     if (this.rotation % 90 == 0)
/*      */     {
/*  545 */       int width = 0;
/*  546 */       int height = 0;
/*      */       
/*  548 */       if (this.rotation % 180 == 0)
/*      */       {
/*  550 */         width = this.image.getWidth();
/*  551 */         height = this.image.getHeight();
/*      */       }
/*      */       else {
/*  554 */         width = this.image.getHeight();
/*  555 */         height = this.image.getWidth();
/*      */       }
/*      */       
/*  558 */       int x = cellSize * this.x + (cellSize - width - 1) / 2;
/*  559 */       int y = cellSize * this.y + (cellSize - height - 1) / 2;
/*  560 */       this.boundingRect = new Rect(x, y, width, height);
/*  561 */       this.boundingXs[0] = x;this.boundingYs[0] = y;
/*  562 */       this.boundingXs[1] = (x + width - 1);this.boundingYs[1] = y;
/*  563 */       this.boundingXs[2] = this.boundingXs[1];this.boundingYs[2] = (y + height - 1);
/*  564 */       this.boundingXs[3] = x;this.boundingYs[3] = this.boundingYs[2];
/*      */     }
/*      */     else {
/*  567 */       getRotatedCorners(this.boundingXs, this.boundingYs, cellSize);
/*      */       
/*  569 */       int minX = Integer.MAX_VALUE;
/*  570 */       int maxX = Integer.MIN_VALUE;
/*  571 */       int minY = Integer.MAX_VALUE;
/*  572 */       int maxY = Integer.MIN_VALUE;
/*      */       
/*  574 */       for (int i = 0; i < 4; i++) {
/*  575 */         minX = Math.min(this.boundingXs[i] - 1, minX);
/*  576 */         maxX = Math.max(this.boundingXs[i] + 1, maxX);
/*  577 */         minY = Math.min(this.boundingYs[i] - 1, minY);
/*  578 */         maxY = Math.max(this.boundingYs[i] + 1, maxY);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  588 */       this.boundingRect = new Rect(minX, minY, maxX - minX + 1, maxY - minY + 1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void setData(Object o)
/*      */   {
/*  597 */     this.data = o;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Object getData()
/*      */   {
/*  606 */     return this.data;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   int toPixel(int x)
/*      */   {
/*  614 */     World aWorld = getActiveWorld();
/*  615 */     if (aWorld == null)
/*      */     {
/*  617 */       throw new IllegalStateException("An actor is trying to access the world, when no world has been instantiated.");
/*      */     }
/*  619 */     return x * aWorld.getCellSize() + aWorld.getCellSize() / 2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private GreenfootImage getClassImage()
/*      */   {
/*  634 */     Class<?> clazz = getClass();
/*  635 */     while (clazz != null) {
/*  636 */       GreenfootImage image = null;
/*      */       try {
/*  638 */         image = getImage(clazz);
/*      */       }
/*      */       catch (Throwable e) {}
/*      */       
/*      */ 
/*  643 */       if (image != null) {
/*  644 */         return image;
/*      */       }
/*  646 */       clazz = clazz.getSuperclass();
/*      */     }
/*      */     
/*  649 */     return greenfootImage;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void sizeChanged()
/*      */   {
/*  658 */     if (this.world != null) {
/*  659 */       this.world.updateObjectSize(this);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void locationChanged(int oldX, int oldY)
/*      */   {
/*  668 */     if (this.world != null) {
/*  669 */       this.world.updateObjectLocation(this, oldX, oldY);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void failIfNotInWorld()
/*      */   {
/*  680 */     if (this.world == null) {
/*  681 */       throw new IllegalStateException("Actor not in world. An attempt was made to use the actor's location while it is not in the world. Either it has not yet been inserted, or it has been removed.");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void getRotatedCorners(int[] xs, int[] ys, int cellSize)
/*      */   {
/*  695 */     int width = this.image.getWidth();
/*  696 */     int height = this.image.getHeight();
/*      */     
/*  698 */     xs[0] = (-width / 2);
/*  699 */     xs[1] = (xs[0] + width - 1);
/*  700 */     xs[2] = xs[1];
/*  701 */     xs[3] = xs[0];
/*      */     
/*  703 */     ys[0] = (-height / 2);
/*  704 */     ys[1] = ys[0];
/*  705 */     ys[2] = (ys[1] + height - 1);
/*  706 */     ys[3] = ys[2];
/*      */     
/*  708 */     double rotR = Math.toRadians(this.rotation);
/*  709 */     double sinR = Math.sin(rotR);
/*  710 */     double cosR = Math.cos(rotR);
/*      */     
/*  712 */     double xc = cellSize * this.x + cellSize / 2.0D;
/*  713 */     double yc = cellSize * this.y + cellSize / 2.0D;
/*      */     
/*      */ 
/*  716 */     for (int i = 0; i < 4; i++) {
/*  717 */       int nx = (int)(xs[i] * cosR - ys[i] * sinR + xc);
/*  718 */       int ny = (int)(ys[i] * cosR + xs[i] * sinR + yc);
/*  719 */       xs[i] = nx;
/*  720 */       ys[i] = ny;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean checkOutside(int[] myX, int[] myY, int[] otherX, int[] otherY)
/*      */   {
/*      */     label113:
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  739 */     for (int v = 0; v < 4; v++) {
/*  740 */       int v1 = v + 1 & 0x3;
/*  741 */       int edgeX = myX[v] - myX[v1];
/*  742 */       int edgeY = myY[v] - myY[v1];
/*  743 */       int reX = -edgeY;
/*  744 */       int reY = edgeX;
/*      */       
/*  746 */       if ((reX != 0) || (reY != 0))
/*      */       {
/*      */ 
/*      */ 
/*  750 */         for (int e = 0; e < 4; e++) {
/*  751 */           int scalar = reX * (otherX[e] - myX[v1]) + reY * (otherY[e] - myY[v1]);
/*  752 */           if (scalar < 0) {
/*      */             break label113;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  759 */         return true;
/*      */       }
/*      */     }
/*  762 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean intersects(Actor other)
/*      */   {
/*  778 */     if (this.image == null) {
/*  779 */       if (other.image == null)
/*      */       {
/*      */ 
/*  782 */         return (this.x == other.x) && (this.y == other.y);
/*      */       }
/*      */       
/*  785 */       int cellSize = this.world.getCellSize();
/*      */       
/*      */ 
/*  788 */       return other.containsPoint(this.x * cellSize + cellSize / 2, this.y * cellSize + cellSize / 2);
/*      */     }
/*  790 */     if (other.image == null)
/*      */     {
/*  792 */       int cellSize = this.world.getCellSize();
/*  793 */       return containsPoint(other.x * cellSize + cellSize / 2, other.y * cellSize + cellSize / 2);
/*      */     }
/*      */     
/*  796 */     Rect thisBounds = getBoundingRect();
/*  797 */     Rect otherBounds = other.getBoundingRect();
/*  798 */     if ((this.rotation == 0) && (other.rotation == 0)) {
/*  799 */       return thisBounds.intersects(otherBounds);
/*      */     }
/*      */     
/*      */ 
/*  803 */     if (!thisBounds.intersects(otherBounds)) {
/*  804 */       return false;
/*      */     }
/*      */     
/*  807 */     int[] myX = this.boundingXs;
/*  808 */     int[] myY = this.boundingYs;
/*  809 */     int[] otherX = other.boundingXs;
/*  810 */     int[] otherY = other.boundingYs;
/*      */     
/*  812 */     if (checkOutside(myX, myY, otherX, otherY)) {
/*  813 */       return false;
/*      */     }
/*  815 */     if (checkOutside(otherX, otherY, myX, myY)) {
/*  816 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  821 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List getNeighbours(int distance, boolean diagonal, Class cls)
/*      */   {
/*  847 */     failIfNotInWorld();
/*      */     
/*  849 */     return this.world.getNeighbours(this, distance, diagonal, cls);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List getObjectsAtOffset(int dx, int dy, Class cls)
/*      */   {
/*  866 */     failIfNotInWorld();
/*  867 */     return this.world.getObjectsAt(this.x + dx, this.y + dy, cls);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Actor getOneObjectAtOffset(int dx, int dy, Class cls)
/*      */   {
/*  885 */     failIfNotInWorld();
/*  886 */     return this.world.getOneObjectAt(this, this.x + dx, this.y + dy, cls);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List getObjectsInRange(int radius, Class cls)
/*      */   {
/*  900 */     failIfNotInWorld();
/*  901 */     List inRange = this.world.getObjectsInRange(this.x, this.y, radius, cls);
/*  902 */     inRange.remove(this);
/*  903 */     return inRange;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List getIntersectingObjects(Class cls)
/*      */   {
/*  915 */     failIfNotInWorld();
/*  916 */     List l = this.world.getIntersectingObjects(this, cls);
/*  917 */     l.remove(this);
/*  918 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Actor getOneIntersectingObject(Class cls)
/*      */   {
/*  930 */     failIfNotInWorld();
/*  931 */     return this.world.getOneIntersectingObject(this, cls);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isTouching(Class cls)
/*      */   {
/*  943 */     failIfNotInWorld();
/*  944 */     return getOneIntersectingObject(cls) != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void removeTouching(Class cls)
/*      */   {
/*  956 */     failIfNotInWorld();
/*  957 */     Actor a = getOneIntersectingObject(cls);
/*  958 */     if (a != null)
/*      */     {
/*  960 */       this.world.removeObject(a);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean containsPoint(int px, int py)
/*      */   {
/*  974 */     failIfNotInWorld();
/*  975 */     if (this.image == null) {
/*  976 */       return false;
/*      */     }
/*      */     
/*  979 */     if (this.boundingRect == null) {
/*  980 */       calcBounds();
/*      */     }
/*      */     
/*  983 */     if ((this.rotation == 0) || (this.rotation == 90) || (this.rotation == 270))
/*      */     {
/*  985 */       return (px >= this.boundingRect.getX()) && (px < this.boundingRect.getRight()) && (py >= this.boundingRect.getY()) && (py < this.boundingRect.getTop());
/*      */     }
/*      */     
/*      */ 
/*  989 */     for (int v = 0; v < 4; v++) {
/*  990 */       int v1 = v + 1 & 0x3;
/*  991 */       int edgeX = this.boundingXs[v] - this.boundingXs[v1];
/*  992 */       int edgeY = this.boundingYs[v] - this.boundingYs[v1];
/*  993 */       int reX = -edgeY;
/*  994 */       int reY = edgeX;
/*      */       
/*  996 */       if ((reX != 0) || (reY != 0))
/*      */       {
/*      */ 
/*      */ 
/* 1000 */         int scalar = reX * (px - this.boundingXs[v1]) + reY * (py - this.boundingYs[v1]);
/* 1001 */         if (scalar >= 0)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1007 */           return false; }
/*      */       }
/*      */     }
/* 1010 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final int getSequenceNumber()
/*      */   {
/* 1019 */     return this.mySequenceNumber;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final int getLastPaintSeqNum()
/*      */   {
/* 1028 */     return this.lastPaintSequenceNumber;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   final void setLastPaintSeqNum(int num)
/*      */   {
/* 1036 */     this.lastPaintSequenceNumber = num;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void setDelegate(ActorDelegate d)
/*      */   {
/* 1055 */     delegate = d;
/*      */   }
/*      */   
/*      */   static ActorDelegate getDelegate()
/*      */   {
/* 1060 */     return delegate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   GreenfootImage getImage(Class<?> clazz)
/*      */   {
/* 1068 */     return delegate.getImage(clazz.getName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   World getActiveWorld()
/*      */   {
/* 1077 */     if (this.world != null) {
/* 1078 */       return this.world;
/*      */     }
/* 1080 */     WorldHandler handler = WorldHandler.getInstance();
/* 1081 */     if (handler != null) {
/* 1082 */       return handler.getWorld();
/*      */     }
/*      */     
/* 1085 */     return null;
/*      */   }
/*      */   
/*      */   public void act() {}
/*      */   
/*      */   protected void addedToWorld(World world) {}
/*      */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\Actor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */