/*     */ package greenfoot.export;
/*     */ 
/*     */ import bluej.Config;
/*     */ import greenfoot.util.StandalonePropStringManager;
/*     */ import java.awt.EventQueue;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.net.URL;
/*     */ import java.util.Properties;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JFrame;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GreenfootScenarioMain
/*     */ {
/*     */   public static String scenarioName;
/*     */   public static String[] args;
/*     */   
/*     */   public static void main(String[] args)
/*     */   {
/*  69 */     System.setProperty("apple.laf.useScreenMenuBar", "true");
/*  70 */     if ((args.length != 3) && (args.length != 0)) {
/*  71 */       System.err.println("Wrong number of arguments");
/*     */     }
/*     */     
/*  74 */     args = args;
/*  75 */     initProperties();
/*  76 */     System.setProperty("com.apple.mrj.application.apple.menu.about.name", scenarioName);
/*     */     
/*  78 */     final GreenfootScenarioViewer[] gsv = new GreenfootScenarioViewer[1];
/*  79 */     JFrame[] frame = new JFrame[1];
/*     */     try
/*     */     {
/*  82 */       EventQueue.invokeAndWait(new Runnable()
/*     */       {
/*     */         public void run() {
/*  85 */           this.val$frame[0] = new JFrame(GreenfootScenarioMain.scenarioName);
/*  86 */           gsv[0] = new GreenfootScenarioViewer(this.val$frame[0]);
/*  87 */           this.val$frame[0].setDefaultCloseOperation(3);
/*  88 */           this.val$frame[0].setResizable(false);
/*     */           
/*  90 */           URL resource = getClass().getClassLoader().getResource("greenfoot.png");
/*  91 */           ImageIcon icon = new ImageIcon(resource);
/*  92 */           this.val$frame[0].setIconImage(icon.getImage());
/*     */         }
/*     */         
/*     */ 
/*  96 */       });
/*  97 */       gsv[0].init();
/*     */       
/*  99 */       EventQueue.invokeAndWait(new Runnable()
/*     */       {
/*     */         public void run() {
/* 102 */           this.val$frame[0].pack();
/* 103 */           this.val$frame[0].setVisible(true);
/*     */         }
/*     */       });
/*     */     }
/*     */     catch (InterruptedException e) {
/* 108 */       e.printStackTrace();
/*     */     } catch (InvocationTargetException e) {
/* 110 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void initProperties()
/*     */   {
/* 119 */     if (scenarioName != null) {
/* 120 */       return;
/*     */     }
/*     */     
/* 123 */     Properties p = new Properties();
/*     */     try {
/* 125 */       ClassLoader loader = GreenfootScenarioMain.class.getClassLoader();
/* 126 */       InputStream is = loader.getResourceAsStream("standalone.properties");
/*     */       
/* 128 */       if ((is == null) && (args.length == 3))
/*     */       {
/*     */ 
/* 131 */         p.put("project.name", args[0]);
/* 132 */         p.put("main.class", args[1]);
/* 133 */         p.put("scenario.lock", "true");
/* 134 */         File f = new File(args[2]);
/* 135 */         if (f.canRead()) {
/* 136 */           is = new FileInputStream(f);
/*     */         }
/*     */       }
/*     */       
/* 140 */       if (is != null) {
/* 141 */         p.load(is);
/*     */       }
/*     */       
/* 144 */       scenarioName = p.getProperty("project.name");
/*     */       
/*     */ 
/* 147 */       Config.initializeStandalone(new StandalonePropStringManager(p));
/* 148 */       if (is != null) {
/* 149 */         is.close();
/*     */       }
/*     */     }
/*     */     catch (FileNotFoundException e) {
/* 153 */       e.printStackTrace();
/*     */     }
/*     */     catch (IOException e) {
/* 156 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\export\GreenfootScenarioMain.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */