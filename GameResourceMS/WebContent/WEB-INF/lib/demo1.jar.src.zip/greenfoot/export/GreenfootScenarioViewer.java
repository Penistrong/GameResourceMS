/*     */ package greenfoot.export;
/*     */ 
/*     */ import bluej.Config;
/*     */ import bluej.utility.Debug;
/*     */ import greenfoot.World;
/*     */ import greenfoot.core.ProjectProperties;
/*     */ import greenfoot.core.Simulation;
/*     */ import greenfoot.core.WorldHandler;
/*     */ import greenfoot.event.SimulationEvent;
/*     */ import greenfoot.event.SimulationListener;
/*     */ import greenfoot.gui.AskPanel;
/*     */ import greenfoot.gui.ControlPanel;
/*     */ import greenfoot.gui.WorldCanvas;
/*     */ import greenfoot.gui.input.mouse.LocationTracker;
/*     */ import greenfoot.platforms.standalone.ActorDelegateStandAlone;
/*     */ import greenfoot.platforms.standalone.GreenfootUtilDelegateStandAlone;
/*     */ import greenfoot.platforms.standalone.SimulationDelegateStandAlone;
/*     */ import greenfoot.platforms.standalone.WorldHandlerDelegateStandAlone;
/*     */ import greenfoot.sound.SoundFactory;
/*     */ import greenfoot.util.AskHandler;
/*     */ import greenfoot.util.GreenfootUtil;
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JApplet;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRootPane;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.OverlayLayout;
/*     */ import javax.swing.RootPaneContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GreenfootScenarioViewer
/*     */   extends JApplet
/*     */ {
/*     */   private static final int EMPTY_BORDER_SIZE = 5;
/*     */   private static String scenarioName;
/*     */   private boolean isApplet;
/*     */   private ProjectProperties properties;
/*     */   private Simulation sim;
/*     */   private WorldCanvas canvas;
/*     */   private AskPanel askPanel;
/*     */   private ControlPanel controls;
/*     */   private RootPaneContainer rootPaneContainer;
/*     */   private Constructor<?> worldConstructor;
/*     */   private AskHandler askHandler;
/*     */   
/*     */   public GreenfootScenarioViewer()
/*     */   {
/*  98 */     this.isApplet = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GreenfootScenarioViewer(RootPaneContainer rootPane)
/*     */   {
/* 107 */     this.rootPaneContainer = rootPane;
/* 108 */     this.isApplet = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Dimension getControlsBorderSize()
/*     */   {
/* 116 */     return new Dimension(10, 10);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Dimension getWorldBorderSize()
/*     */   {
/* 124 */     return new Dimension(12, 7);
/*     */   }
/*     */   
/*     */   private void buildGUI()
/*     */   {
/* 129 */     if (this.rootPaneContainer == null)
/*     */     {
/* 131 */       this.rootPaneContainer = this;
/*     */     }
/*     */     
/* 134 */     JPanel centerPanel = new JPanel();
/* 135 */     centerPanel.setLayout(new OverlayLayout(centerPanel));
/* 136 */     this.canvas.setAlignmentX(0.5F);
/* 137 */     this.canvas.setAlignmentY(1.0F);
/*     */     
/*     */ 
/* 140 */     this.askPanel = new AskPanel();
/* 141 */     this.askPanel.getComponent().setAlignmentX(0.5F);
/* 142 */     this.askPanel.getComponent().setAlignmentY(1.0F);
/* 143 */     centerPanel.add(this.askPanel.getComponent());
/* 144 */     centerPanel.add(this.canvas);
/* 145 */     centerPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
/* 146 */     this.askHandler = new AskHandler(this.askPanel, this.canvas);
/*     */     
/*     */ 
/* 149 */     JScrollPane outer = new JScrollPane(centerPanel);
/* 150 */     outer.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
/* 151 */     this.controls.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(0, 5, 5, 5), BorderFactory.createEtchedBorder()));
/*     */     
/* 153 */     this.rootPaneContainer.getContentPane().add(outer, "Center");
/* 154 */     this.rootPaneContainer.getContentPane().add(this.controls, "South");
/*     */   }
/*     */   
/*     */ 
/*     */   public String getParameter(String name)
/*     */   {
/* 160 */     if (this.isApplet) {
/* 161 */       return super.getParameter(name);
/*     */     }
/* 163 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init()
/*     */   {
/* 173 */     GreenfootScenarioMain.initProperties();
/*     */     
/* 175 */     boolean storageStandalone = getParameter("storage.standalone") != null;
/* 176 */     String storageHost = getParameter("storage.server");
/* 177 */     String storagePort = getParameter("storage.serverPort");
/* 178 */     String storagePasscode = getParameter("storage.passcode");
/* 179 */     String storageScenarioId = getParameter("storage.scenarioId");
/* 180 */     String storageUserId = getParameter("storage.userId");
/* 181 */     String storageUserName = getParameter("storage.userName");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 187 */     JRootPane rootPane = getRootPane();
/* 188 */     rootPane.putClientProperty("defeatSystemEventQueueCheck", Boolean.TRUE);
/*     */     
/* 190 */     final String worldClassName = Config.getPropString("main.class");
/* 191 */     final boolean lockScenario = Config.getPropBoolean("scenario.lock");
/*     */     try
/*     */     {
/* 194 */       GreenfootUtil.initialise(new GreenfootUtilDelegateStandAlone(storageStandalone, storageHost, storagePort, storagePasscode, storageScenarioId, storageUserId, storageUserName));
/* 195 */       this.properties = new ProjectProperties();
/*     */       
/* 197 */       ActorDelegateStandAlone.setupAsActorDelegate();
/* 198 */       ActorDelegateStandAlone.initProperties(this.properties);
/*     */       
/*     */ 
/*     */ 
/* 202 */       Simulation.initialize(new SimulationDelegateStandAlone());
/*     */       
/* 204 */       EventQueue.invokeAndWait(new Runnable()
/*     */       {
/*     */         public void run()
/*     */         {
/* 208 */           GreenfootScenarioViewer.this.guiSetup(lockScenario, worldClassName);
/*     */         }
/*     */         
/* 211 */       });
/* 212 */       WorldHandler worldHandler = WorldHandler.getInstance();
/* 213 */       Class<?> worldClass = Class.forName(worldClassName);
/* 214 */       this.worldConstructor = worldClass.getConstructor(new Class[0]);
/* 215 */       World world = instantiateNewWorld();
/* 216 */       if (!worldHandler.checkWorldSet()) {
/* 217 */         worldHandler.setWorld(world);
/*     */       }
/*     */       
/* 220 */       EventQueue.invokeAndWait(new Runnable()
/*     */       {
/*     */         public void run()
/*     */         {
/* 224 */           GreenfootScenarioViewer.this.buildGUI();
/*     */         }
/*     */       });
/*     */     }
/*     */     catch (SecurityException e) {
/* 229 */       e.printStackTrace();
/*     */     }
/*     */     catch (IllegalArgumentException e) {
/* 232 */       e.printStackTrace();
/*     */     }
/*     */     catch (InvocationTargetException ite) {
/* 235 */       ite.printStackTrace();
/*     */     }
/*     */     catch (InterruptedException ie) {
/* 238 */       ie.printStackTrace();
/*     */     }
/*     */     catch (ClassNotFoundException e) {
/* 241 */       e.printStackTrace();
/*     */     }
/*     */     catch (NoSuchMethodException e) {
/* 244 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void guiSetup(boolean lockScenario, String worldClassName)
/*     */   {
/* 255 */     this.canvas = new WorldCanvas(null);
/* 256 */     this.canvas.addMouseListener(new MouseAdapter()
/*     */     {
/*     */       public void mouseClicked(MouseEvent e) {
/* 259 */         GreenfootScenarioViewer.this.canvas.requestFocusInWindow();
/*     */         
/*     */ 
/*     */ 
/* 263 */         GreenfootScenarioViewer.this.canvas.requestFocus();
/*     */       }
/*     */       
/* 266 */     });
/* 267 */     WorldHandler.initialise(this.canvas, new WorldHandlerDelegateStandAlone(this, lockScenario));
/* 268 */     WorldHandler worldHandler = WorldHandler.getInstance();
/* 269 */     this.sim = Simulation.getInstance();
/* 270 */     this.sim.attachWorldHandler(worldHandler);
/* 271 */     LocationTracker.initialize();
/* 272 */     this.controls = new ControlPanel(this.sim, !lockScenario);
/*     */     
/*     */ 
/* 275 */     this.sim.addSimulationListener(SoundFactory.getInstance().getSoundCollection());
/*     */     
/* 277 */     this.sim.addSimulationListener(new SimulationListener()
/*     */     {
/*     */ 
/*     */       public void simulationChanged(SimulationEvent e)
/*     */       {
/*     */ 
/* 283 */         if (e.getType() == 0) {
/* 284 */           GreenfootScenarioViewer.this.canvas.requestFocusInWindow();
/*     */           
/*     */ 
/*     */ 
/* 288 */           GreenfootScenarioViewer.this.canvas.requestFocus();
/*     */         }
/*     */       }
/*     */     });
/*     */     try
/*     */     {
/* 294 */       int initialSpeed = this.properties.getInt("simulation.speed");
/* 295 */       this.sim.setSpeed(initialSpeed);
/*     */     }
/*     */     catch (NumberFormatException nfe) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */   {
/* 318 */     this.sim.setPaused(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 328 */     this.sim.abort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAppletInfo()
/*     */   {
/* 341 */     return Config.getString("scenario.viewer.appletInfo") + " " + scenarioName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[][] getParameterInfo()
/*     */   {
/* 357 */     String[][] paramInfo = new String[0][];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 363 */     return paramInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public World instantiateNewWorld()
/*     */   {
/*     */     try
/*     */     {
/* 373 */       return (World)this.worldConstructor.newInstance(new Object[0]);
/*     */     }
/*     */     catch (IllegalArgumentException e)
/*     */     {
/* 377 */       e.printStackTrace();
/*     */     }
/*     */     catch (InstantiationException e) {
/* 380 */       e.printStackTrace();
/*     */     }
/*     */     catch (IllegalAccessException e) {
/* 383 */       e.printStackTrace();
/*     */     }
/*     */     catch (InvocationTargetException e) {
/* 386 */       e.getCause().printStackTrace();
/*     */     }
/* 388 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public World getWorld()
/*     */   {
/* 397 */     return WorldHandler.getInstance().getWorld();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReentrantReadWriteLock getWorldLock(World world)
/*     */   {
/* 405 */     return WorldHandler.getInstance().getWorldLock();
/*     */   }
/*     */   
/*     */   public String ask(final String prompt)
/*     */   {
/* 410 */     final AtomicReference<Callable<String>> c = new AtomicReference();
/*     */     try
/*     */     {
/* 413 */       EventQueue.invokeAndWait(new Runnable() {
/* 414 */         public void run() { c.set(GreenfootScenarioViewer.this.askHandler.ask(prompt, GreenfootScenarioViewer.this.canvas.getPreferredSize().width)); }
/*     */       });
/*     */     }
/*     */     catch (InvocationTargetException e)
/*     */     {
/* 419 */       Debug.reportError(e);
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/* 423 */       Debug.reportError(e);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 428 */       return (String)((Callable)c.get()).call();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 432 */       Debug.reportError(e); }
/* 433 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\export\GreenfootScenarioViewer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */