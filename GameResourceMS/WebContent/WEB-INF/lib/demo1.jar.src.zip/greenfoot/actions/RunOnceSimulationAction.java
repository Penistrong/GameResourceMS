/*     */ package greenfoot.actions;
/*     */ 
/*     */ import bluej.Config;
/*     */ import bluej.utility.Debug;
/*     */ import greenfoot.core.Simulation;
/*     */ import greenfoot.event.SimulationEvent;
/*     */ import greenfoot.event.SimulationListener;
/*     */ import greenfoot.event.SimulationUIListener;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.event.ActionEvent;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.ImageIcon;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RunOnceSimulationAction
/*     */   extends AbstractAction
/*     */   implements SimulationListener
/*     */ {
/*     */   private static final String iconFile = "step.png";
/*  47 */   private static RunOnceSimulationAction instance = new RunOnceSimulationAction();
/*     */   
/*     */   private Simulation simulation;
/*     */   
/*     */   protected boolean stateOnDebugResume;
/*     */   
/*     */   private SimulationUIListener listener;
/*     */   
/*     */ 
/*     */   public static RunOnceSimulationAction getInstance()
/*     */   {
/*  58 */     return instance;
/*     */   }
/*     */   
/*     */   private RunOnceSimulationAction()
/*     */   {
/*  63 */     super(Config.getString("run.once"), new ImageIcon(RunOnceSimulationAction.class.getClassLoader().getResource("step.png")));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void attachSimulation(Simulation simulation)
/*     */   {
/*  71 */     this.simulation = simulation;
/*  72 */     simulation.addSimulationListener(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void attachListener(SimulationUIListener listener)
/*     */   {
/*  80 */     this.listener = listener;
/*     */   }
/*     */   
/*     */   public void actionPerformed(ActionEvent e)
/*     */   {
/*  85 */     if (this.simulation == null) {
/*  86 */       Debug.reportError("attempt to pause a simulation while none exists.");
/*  87 */       return;
/*     */     }
/*     */     
/*  90 */     if (this.listener != null) {
/*  91 */       this.listener.simulationActive();
/*     */     }
/*  93 */     this.simulation.runOnce();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void simulationChanged(final SimulationEvent e)
/*     */   {
/* 101 */     EventQueue.invokeLater(new Runnable()
/*     */     {
/*     */       public void run() {
/* 104 */         int eventType = e.getType();
/* 105 */         if (eventType == 1) {
/* 106 */           RunOnceSimulationAction.this.setEnabled(RunOnceSimulationAction.this.stateOnDebugResume = 1);
/*     */         }
/* 108 */         else if (eventType == 0) {
/* 109 */           RunOnceSimulationAction.this.setEnabled(RunOnceSimulationAction.this.stateOnDebugResume = 0);
/*     */         }
/* 111 */         else if (eventType == 3) {
/* 112 */           RunOnceSimulationAction.this.setEnabled(RunOnceSimulationAction.this.stateOnDebugResume = 0);
/*     */         }
/* 114 */         else if (eventType == 5) {
/* 115 */           RunOnceSimulationAction.this.stateOnDebugResume = RunOnceSimulationAction.this.isEnabled();
/* 116 */           RunOnceSimulationAction.this.setEnabled(false);
/*     */         }
/* 118 */         else if (eventType == 6) {
/* 119 */           RunOnceSimulationAction.this.setEnabled(RunOnceSimulationAction.this.stateOnDebugResume);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\actions\RunOnceSimulationAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */