/*     */ package greenfoot.actions;
/*     */ 
/*     */ import bluej.Config;
/*     */ import bluej.utility.Debug;
/*     */ import greenfoot.core.Simulation;
/*     */ import greenfoot.event.SimulationEvent;
/*     */ import greenfoot.event.SimulationListener;
/*     */ import greenfoot.event.SimulationUIListener;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.event.ActionEvent;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.ImageIcon;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RunSimulationAction
/*     */   extends AbstractAction
/*     */   implements SimulationListener
/*     */ {
/*     */   private static final String iconFile = "run.png";
/*  47 */   private static RunSimulationAction instance = new RunSimulationAction();
/*     */   
/*     */   private Simulation simulation;
/*     */   
/*     */   protected boolean stateOnDebugResume;
/*     */   
/*     */   private SimulationUIListener listener;
/*     */   
/*     */ 
/*     */   public static RunSimulationAction getInstance()
/*     */   {
/*  58 */     return instance;
/*     */   }
/*     */   
/*     */   private RunSimulationAction()
/*     */   {
/*  63 */     super(Config.getString("run.simulation"), new ImageIcon(RunSimulationAction.class.getClassLoader().getResource("run.png")));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void attachSimulation(Simulation simulation)
/*     */   {
/*  71 */     this.simulation = simulation;
/*  72 */     simulation.addSimulationListener(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void attachListener(SimulationUIListener listener)
/*     */   {
/*  80 */     this.listener = listener;
/*     */   }
/*     */   
/*     */   public void actionPerformed(ActionEvent e)
/*     */   {
/*  85 */     if (this.simulation == null) {
/*  86 */       Debug.reportError("attempt to run a simulation while none exists.");
/*  87 */       return;
/*     */     }
/*     */     
/*  90 */     if (this.listener != null) {
/*  91 */       this.listener.simulationActive();
/*     */     }
/*  93 */     this.simulation.setPaused(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void simulationChanged(final SimulationEvent e)
/*     */   {
/* 101 */     EventQueue.invokeLater(new Runnable()
/*     */     {
/*     */       public void run() {
/* 104 */         int eventType = e.getType();
/* 105 */         if (eventType == 1) {
/* 106 */           RunSimulationAction.this.setEnabled(RunSimulationAction.this.stateOnDebugResume = 1);
/*     */         }
/* 108 */         else if (eventType == 0) {
/* 109 */           RunSimulationAction.this.setEnabled(RunSimulationAction.this.stateOnDebugResume = 0);
/*     */         }
/* 111 */         else if (eventType == 3) {
/* 112 */           RunSimulationAction.this.setEnabled(RunSimulationAction.this.stateOnDebugResume = 0);
/*     */         }
/* 114 */         else if (eventType == 5) {
/* 115 */           RunSimulationAction.this.stateOnDebugResume = RunSimulationAction.this.isEnabled();
/* 116 */           RunSimulationAction.this.setEnabled(false);
/*     */         }
/* 118 */         else if (eventType == 6) {
/* 119 */           RunSimulationAction.this.setEnabled(RunSimulationAction.this.stateOnDebugResume);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\actions\RunSimulationAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */