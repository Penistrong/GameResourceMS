/*    */ package greenfoot.actions;
/*    */ 
/*    */ import bluej.Config;
/*    */ import bluej.utility.Debug;
/*    */ import greenfoot.core.Simulation;
/*    */ import greenfoot.event.SimulationEvent;
/*    */ import greenfoot.event.SimulationListener;
/*    */ import java.awt.EventQueue;
/*    */ import java.awt.event.ActionEvent;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.ImageIcon;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PauseSimulationAction
/*    */   extends AbstractAction
/*    */   implements SimulationListener
/*    */ {
/*    */   private static final String iconFile = "pause.png";
/* 45 */   private static PauseSimulationAction instance = new PauseSimulationAction();
/*    */   
/*    */   private Simulation simulation;
/*    */   protected boolean stateOnDebugResume;
/*    */   
/*    */   public static PauseSimulationAction getInstance()
/*    */   {
/* 52 */     return instance;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private PauseSimulationAction()
/*    */   {
/* 60 */     super(Config.getString("pause.simulation"), new ImageIcon(PauseSimulationAction.class.getClassLoader().getResource("pause.png")));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void attachSimulation(Simulation simulation)
/*    */   {
/* 68 */     this.simulation = simulation;
/* 69 */     simulation.addSimulationListener(this);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void actionPerformed(ActionEvent e)
/*    */   {
/* 77 */     if (this.simulation == null) {
/* 78 */       Debug.reportError("attempt to pause a simulation while none exists.");
/*    */     }
/*    */     else {
/* 81 */       this.simulation.setPaused(true);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void simulationChanged(final SimulationEvent e)
/*    */   {
/* 90 */     EventQueue.invokeLater(new Runnable()
/*    */     {
/*    */       public void run() {
/* 93 */         int eventType = e.getType();
/* 94 */         if (eventType == 1) {
/* 95 */           PauseSimulationAction.this.setEnabled(PauseSimulationAction.this.stateOnDebugResume = 0);
/*    */         }
/* 97 */         else if (eventType == 0) {
/* 98 */           PauseSimulationAction.this.setEnabled(PauseSimulationAction.this.stateOnDebugResume = 1);
/*    */         }
/* :0 */         else if (eventType == 3) {
/* :1 */           PauseSimulationAction.this.setEnabled(PauseSimulationAction.this.stateOnDebugResume = 0);
/*    */         }
/* :3 */         else if (eventType == 5) {
/* :4 */           PauseSimulationAction.this.stateOnDebugResume = PauseSimulationAction.this.isEnabled();
/* :5 */           PauseSimulationAction.this.setEnabled(false);
/*    */         }
/* :7 */         else if (eventType == 6) {
/* :8 */           PauseSimulationAction.this.setEnabled(PauseSimulationAction.this.stateOnDebugResume);
/*    */         }
/*    */       }
/*    */     });
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\actions\PauseSimulationAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */