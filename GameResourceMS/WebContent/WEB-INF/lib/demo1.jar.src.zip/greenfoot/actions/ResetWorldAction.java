/*    */ package greenfoot.actions;
/*    */ 
/*    */ import bluej.Config;
/*    */ import bluej.utility.Debug;
/*    */ import greenfoot.core.Simulation;
/*    */ import greenfoot.core.WorldHandler;
/*    */ import greenfoot.event.SimulationEvent;
/*    */ import greenfoot.event.SimulationListener;
/*    */ import java.awt.EventQueue;
/*    */ import java.awt.event.ActionEvent;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.ImageIcon;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResetWorldAction
/*    */   extends AbstractAction
/*    */   implements SimulationListener
/*    */ {
/*    */   private Simulation simulation;
/* 42 */   private static ResetWorldAction instance = new ResetWorldAction();
/*    */   
/*    */   private static final String iconFile = "reset.png";
/*    */   
/*    */   public static final String RESET_WORLD = "resetWorld";
/*    */   
/*    */ 
/*    */   public static ResetWorldAction getInstance()
/*    */   {
/* 51 */     return instance;
/*    */   }
/*    */   
/*    */   private ResetWorldAction()
/*    */   {
/* 56 */     super(Config.getString("reset.world"), new ImageIcon(ResetWorldAction.class.getClassLoader().getResource("reset.png")));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void attachSimulation(Simulation simulation)
/*    */   {
/* 64 */     this.simulation = simulation;
/* 65 */     simulation.addSimulationListener(this);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void actionPerformed(ActionEvent e)
/*    */   {
/* 74 */     if (this.simulation == null)
/*    */     {
/* 76 */       Debug.reportError("attempt to reset a simulation while none exists.");
/*    */     }
/*    */     else {
/* 79 */       resetWorld();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   private void resetWorld()
/*    */   {
/* 87 */     this.simulation.setEnabled(false);
/* 88 */     WorldHandler.getInstance().discardWorld();
/* 89 */     WorldHandler.getInstance().instantiateNewWorld();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void simulationChanged(final SimulationEvent e)
/*    */   {
/* 97 */     EventQueue.invokeLater(new Runnable()
/*    */     {
/*    */       public void run() {
/* :0 */         int eventType = e.getType();
/* :1 */         if (eventType == 1) {
/* :2 */           ResetWorldAction.this.setEnabled(true);
/*    */         }
/* :4 */         else if (eventType == 0) {
/* :5 */           ResetWorldAction.this.setEnabled(true);
/*    */         }
/* :7 */         else if (eventType == 3) {
/* :8 */           ResetWorldAction.this.setEnabled(false);
/*    */         }
/*    */       }
/*    */     });
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\actions\ResetWorldAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */