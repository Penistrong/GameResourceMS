package greenfoot.event;

import java.awt.event.KeyEvent;

public class TriggeredKeyAdapter
  implements TriggeredKeyListener
{
  public void keyPressed(KeyEvent e) {}
  
  public void keyReleased(KeyEvent e) {}
  
  public void keyTyped(KeyEvent e) {}
  
  public void listeningEnded() {}
  
  public void listeningStarted(Object obj) {}
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\event\TriggeredKeyAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */