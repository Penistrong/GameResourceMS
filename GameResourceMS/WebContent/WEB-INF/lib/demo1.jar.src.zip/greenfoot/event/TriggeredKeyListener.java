package greenfoot.event;

import java.awt.event.KeyListener;

public abstract interface TriggeredKeyListener
  extends KeyListener, TriggeredListener
{}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\event\TriggeredKeyListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */