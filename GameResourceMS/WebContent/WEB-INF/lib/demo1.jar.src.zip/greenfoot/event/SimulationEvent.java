/*    */ package greenfoot.event;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimulationEvent
/*    */   extends EventObject
/*    */ {
/*    */   public static final int STARTED = 0;
/*    */   public static final int STOPPED = 1;
/*    */   public static final int CHANGED_SPEED = 2;
/*    */   public static final int DISABLED = 3;
/*    */   public static final int DEBUGGER_PAUSED = 5;
/*    */   public static final int DEBUGGER_RESUMED = 6;
/*    */   private int type;
/*    */   
/*    */   public SimulationEvent(Object source, int type)
/*    */   {
/* 72 */     super(source);
/* 73 */     this.type = type;
/*    */   }
/*    */   
/*    */   public int getType()
/*    */   {
/* 78 */     return this.type;
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 84 */     switch (this.type) {
/*    */     case 0: 
/* 86 */       return "STARTED";
/*    */     case 1: 
/* 88 */       return "STOPPED";
/*    */     case 2: 
/* 90 */       return "CHANGED_SPEED";
/*    */     case 3: 
/* 92 */       return "DISABLED";
/*    */     case 5: 
/* 94 */       return "DEBUGGER_PAUSED";
/*    */     case 6: 
/* 96 */       return "DEBUGGER_RESUMED";
/*    */     }
/* 98 */     return super.toString();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\event\SimulationEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */