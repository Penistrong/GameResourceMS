package greenfoot.event;

import java.util.EventListener;

public abstract interface SimulationListener
  extends EventListener
{
  public abstract void simulationChanged(SimulationEvent paramSimulationEvent);
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\event\SimulationListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */