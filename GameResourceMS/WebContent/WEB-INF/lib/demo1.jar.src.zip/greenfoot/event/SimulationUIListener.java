package greenfoot.event;

public abstract interface SimulationUIListener
{
  public abstract void simulationActive();
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\event\SimulationUIListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */