package greenfoot.event;

import java.awt.event.MouseEvent;

public class TriggeredMouseMotionAdapter
  implements TriggeredMouseMotionListener
{
  public void mouseDragged(MouseEvent e) {}
  
  public void mouseMoved(MouseEvent e) {}
  
  public void listeningEnded() {}
  
  public void listeningStarted(Object obj) {}
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\event\TriggeredMouseMotionAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */