/*     */ package greenfoot;
/*     */ 
/*     */ import greenfoot.collision.ColManager;
/*     */ import greenfoot.collision.CollisionChecker;
/*     */ import greenfoot.collision.ibsp.Rect;
/*     */ import greenfoot.core.TextLabel;
/*     */ import greenfoot.core.WorldHandler;
/*     */ import greenfoot.platforms.ActorDelegate;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class World
/*     */ {
/*  60 */   private static final Color DEFAULT_BACKGROUND_COLOR = Color.WHITE;
/*     */   
/*     */ 
/*     */ 
/*  64 */   private CollisionChecker collisionChecker = new ColManager();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  75 */   private TreeActorSet objectsDisordered = new TreeActorSet();
/*     */   
/*     */   private TreeActorSet objectsInPaintOrder;
/*     */   
/*     */   private TreeActorSet objectsInActOrder;
/*  80 */   List<TextLabel> textLabels = new ArrayList();
/*     */   
/*     */ 
/*  83 */   int cellSize = 1;
/*     */   
/*     */ 
/*     */   int width;
/*     */   
/*     */ 
/*     */   int height;
/*     */   
/*     */   private GreenfootImage backgroundImage;
/*     */   
/*  93 */   private boolean backgroundIsClassImage = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isBounded;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public World(int worldWidth, int worldHeight, int cellSize)
/*     */   {
/* 108 */     this(worldWidth, worldHeight, cellSize, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public World(int worldWidth, int worldHeight, int cellSize, boolean bounded)
/*     */   {
/* 124 */     initialize(worldWidth, worldHeight, cellSize);
/* 125 */     this.isBounded = bounded;
/*     */     
/* 127 */     this.backgroundIsClassImage = true;
/* 128 */     setBackground(getClassImage());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */     WorldHandler wHandler = WorldHandler.getInstance();
/* 135 */     if (wHandler != null) {
/* 136 */       wHandler.setInitialisingWorld(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setBackground(GreenfootImage image)
/*     */   {
/* 151 */     if (image != null) {
/* 152 */       int imgWidth = image.getWidth();
/* 153 */       int imgHeight = image.getHeight();
/* 154 */       int worldWidth = getWidthInPixels();
/* 155 */       int worldHeight = getHeightInPixels();
/* 156 */       boolean tile = (imgWidth < worldWidth) || (imgHeight < worldHeight);
/*     */       
/* 158 */       if (tile) {
/* 159 */         this.backgroundIsClassImage = false;
/* 160 */         this.backgroundImage = new GreenfootImage(worldWidth, worldHeight);
/* 161 */         this.backgroundImage.setColor(DEFAULT_BACKGROUND_COLOR);
/* 162 */         this.backgroundImage.fill();
/*     */         
/* 164 */         for (int x = 0; x < worldWidth; x += imgWidth) {
/* 165 */           for (int y = 0; y < worldHeight; y += imgHeight) {
/* 166 */             this.backgroundImage.drawImage(image, x, y);
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 176 */         this.backgroundImage = image;
/*     */       }
/*     */     }
/*     */     else {
/* 180 */       this.backgroundIsClassImage = false;
/* 181 */       this.backgroundImage = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setBackground(String filename)
/*     */     throws IllegalArgumentException
/*     */   {
/* 199 */     GreenfootImage bg = new GreenfootImage(filename);
/* 200 */     setBackground(bg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GreenfootImage getBackground()
/*     */   {
/* 211 */     if (this.backgroundImage == null) {
/* 212 */       this.backgroundImage = new GreenfootImage(getWidthInPixels(), getHeightInPixels());
/* 213 */       this.backgroundImage.setColor(DEFAULT_BACKGROUND_COLOR);
/* 214 */       this.backgroundImage.fill();
/* 215 */       this.backgroundIsClassImage = false;
/*     */     }
/* 217 */     else if (this.backgroundIsClassImage)
/*     */     {
/*     */ 
/* 220 */       this.backgroundImage = this.backgroundImage.getCopyOnWriteClone();
/* 221 */       this.backgroundIsClassImage = false;
/*     */     }
/* 223 */     return this.backgroundImage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color getColorAt(int x, int y)
/*     */   {
/* 239 */     ensureWithinXBounds(x);
/* 240 */     ensureWithinYBounds(y);
/*     */     
/* 242 */     int xPixel = (int)Math.floor(getCellCenter(x));
/* 243 */     int yPixel = (int)Math.floor(getCellCenter(y));
/*     */     
/* 245 */     if (xPixel >= this.backgroundImage.getWidth()) {
/* 246 */       return DEFAULT_BACKGROUND_COLOR;
/*     */     }
/* 248 */     if (yPixel >= this.backgroundImage.getHeight()) {
/* 249 */       return DEFAULT_BACKGROUND_COLOR;
/*     */     }
/*     */     
/* 252 */     return this.backgroundImage.getColorAt(xPixel, yPixel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWidth()
/*     */   {
/* 260 */     return this.width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHeight()
/*     */   {
/* 268 */     return this.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCellSize()
/*     */   {
/* 276 */     return this.cellSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPaintOrder(Class... classes)
/*     */   {
/* 298 */     if (classes == null)
/*     */     {
/* 300 */       if (this.objectsInPaintOrder == this.objectsDisordered) {
/* 301 */         if (this.objectsInActOrder == null) {
/* 302 */           classes = new Class[0];
/* 303 */           this.objectsDisordered.setClassOrder(true, classes);
/*     */         }
/*     */         else {
/* 306 */           this.objectsDisordered = this.objectsInActOrder;
/*     */         }
/*     */       }
/* 309 */       this.objectsInPaintOrder = null;
/* 310 */       return;
/*     */     }
/*     */     
/* 313 */     if (this.objectsInPaintOrder == null)
/*     */     {
/*     */ 
/* 316 */       if (this.objectsInActOrder == this.objectsDisordered)
/*     */       {
/*     */ 
/* 319 */         this.objectsInPaintOrder = new TreeActorSet();
/* 320 */         this.objectsInPaintOrder.setClassOrder(true, classes);
/* 321 */         this.objectsInPaintOrder.addAll(this.objectsDisordered);
/* 322 */         return;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 327 */       this.objectsInPaintOrder = this.objectsDisordered;
/*     */     }
/* 329 */     this.objectsInPaintOrder.setClassOrder(true, classes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setActOrder(Class... classes)
/*     */   {
/* 353 */     if (classes == null)
/*     */     {
/* 355 */       if (this.objectsInActOrder == this.objectsDisordered) {
/* 356 */         if (this.objectsInPaintOrder == null) {
/* 357 */           classes = new Class[0];
/* 358 */           this.objectsDisordered.setClassOrder(false, classes);
/*     */         }
/*     */         else {
/* 361 */           this.objectsDisordered = this.objectsInPaintOrder;
/*     */         }
/*     */       }
/* 364 */       this.objectsInActOrder = null;
/* 365 */       return;
/*     */     }
/*     */     
/* 368 */     if (this.objectsInActOrder == null)
/*     */     {
/*     */ 
/* 371 */       if (this.objectsInPaintOrder == this.objectsDisordered)
/*     */       {
/*     */ 
/* 374 */         this.objectsInActOrder = new TreeActorSet();
/* 375 */         this.objectsInActOrder.setClassOrder(false, classes);
/* 376 */         this.objectsInActOrder.addAll(this.objectsDisordered);
/* 377 */         return;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 382 */       this.objectsInActOrder = this.objectsDisordered;
/*     */     }
/* 384 */     this.objectsInActOrder.setClassOrder(false, classes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addObject(Actor object, int x, int y)
/*     */   {
/* 396 */     if (object.world != null) {
/* 397 */       if (object.world == this) {
/* 398 */         return;
/*     */       }
/* 400 */       object.world.removeObject(object);
/*     */     }
/*     */     
/* 403 */     this.objectsDisordered.add(object);
/* 404 */     addInPaintOrder(object);
/* 405 */     addInActOrder(object);
/*     */     
/*     */ 
/*     */ 
/* 409 */     object.addToWorld(x, y, this);
/*     */     
/* 411 */     this.collisionChecker.addObject(object);
/* 412 */     object.addedToWorld(this);
/*     */     
/* 414 */     WorldHandler whInstance = WorldHandler.getInstance();
/* 415 */     if (whInstance != null) {
/* 416 */       WorldHandler.getInstance().objectAddedToWorld(object);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeObject(Actor object)
/*     */   {
/* 427 */     if ((object == null) || (object.world != this)) {
/* 428 */       return;
/*     */     }
/*     */     
/* 431 */     this.objectsDisordered.remove(object);
/* 432 */     this.collisionChecker.removeObject(object);
/* 433 */     if ((this.objectsDisordered != this.objectsInActOrder) && (this.objectsInActOrder != null)) {
/* 434 */       this.objectsInActOrder.remove(object);
/*     */     }
/* 436 */     else if ((this.objectsDisordered != this.objectsInPaintOrder) && (this.objectsInPaintOrder != null)) {
/* 437 */       this.objectsInPaintOrder.remove(object);
/*     */     }
/* 439 */     object.setWorld(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeObjects(Collection objects)
/*     */   {
/* 450 */     for (Iterator iter = objects.iterator(); iter.hasNext();) {
/* 451 */       Actor actor = (Actor)iter.next();
/* 452 */       removeObject(actor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getObjects(Class cls)
/*     */   {
/* 470 */     List<Actor> result = new ArrayList();
/*     */     
/* 472 */     Iterator<Actor> i = this.objectsDisordered.iterator();
/* 473 */     while (i.hasNext()) {
/* 474 */       Actor actor = (Actor)i.next();
/* 475 */       if ((cls == null) || (cls.isInstance(actor))) {
/* 476 */         result.add(actor);
/*     */       }
/*     */     }
/*     */     
/* 480 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int numberOfObjects()
/*     */   {
/* 490 */     return this.objectsDisordered.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void repaint()
/*     */   {
/* 498 */     WorldHandler.getInstance().repaintAndWait();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void act() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void started() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stopped() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getObjectsAt(int x, int y, Class cls)
/*     */   {
/* 559 */     return this.collisionChecker.getObjectsAt(x, y, cls);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void showText(String text, int x, int y)
/*     */   {
/* 573 */     for (Iterator<TextLabel> i = this.textLabels.iterator(); i.hasNext();) {
/* 574 */       TextLabel label = (TextLabel)i.next();
/* 575 */       if ((label.getX() == x) && (label.getY() == y)) {
/* 576 */         if (label.getText().equals(text))
/*     */         {
/* 578 */           return;
/*     */         }
/*     */         
/* 581 */         i.remove();
/* 582 */         break;
/*     */       }
/*     */     }
/*     */     
/* 586 */     if ((text != null) && (text.length() != 0)) {
/* 587 */       this.textLabels.add(new TextLabel(text, x, y));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   GreenfootImage getBackgroundNoInit()
/*     */   {
/* 604 */     return this.backgroundImage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isBounded()
/*     */   {
/* 612 */     return this.isBounded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   List getIntersectingObjects(Actor actor, Class cls)
/*     */   {
/* 626 */     return this.collisionChecker.getIntersectingObjects(actor, cls);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   List getObjectsInRange(int x, int y, int r, Class cls)
/*     */   {
/* 643 */     return this.collisionChecker.getObjectsInRange(x, y, r, cls);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   List getNeighbours(Actor actor, int distance, boolean diag, Class cls)
/*     */   {
/* 661 */     if (distance < 0) {
/* 662 */       throw new IllegalArgumentException("Distance must not be less than 0. It was: " + distance);
/*     */     }
/* 664 */     return this.collisionChecker.getNeighbours(actor, distance, diag, cls);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   List getObjectsInDirection(int x0, int y0, int angle, int length, Class cls)
/*     */   {
/* 682 */     return this.collisionChecker.getObjectsInDirection(x0, y0, angle, length, cls);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int getHeightInPixels()
/*     */   {
/* 690 */     return this.height * this.cellSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int getWidthInPixels()
/*     */   {
/* 698 */     return this.width * this.cellSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int toCellCeil(int pixel)
/*     */   {
/* 706 */     return (int)Math.ceil(pixel / this.cellSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int toCellFloor(int pixel)
/*     */   {
/* 714 */     return (int)Math.floor(pixel / this.cellSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   double getCellCenter(int l)
/*     */   {
/* 724 */     double cellCenter = l * this.cellSize + this.cellSize / 2.0D;
/* 725 */     return cellCenter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Collection<Actor> getObjectsAtPixel(int x, int y)
/*     */   {
/* 738 */     List<Actor> result = new LinkedList();
/* 739 */     TreeActorSet objects = getObjectsListInPaintOrder();
/* 740 */     for (Actor actor : objects) {
/* 741 */       Rect bounds = actor.getBoundingRect();
/* 742 */       if ((x >= bounds.getX()) && (x <= bounds.getRight()) && (y >= bounds.getY()) && (y <= bounds.getTop()) && 
/* 743 */         (actor.containsPoint(x, y))) {
/* 744 */         result.add(actor);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 749 */     return result;
/*     */   }
/*     */   
/*     */   void updateObjectLocation(Actor object, int oldX, int oldY)
/*     */   {
/* 754 */     this.collisionChecker.updateObjectLocation(object, oldX, oldY);
/*     */   }
/*     */   
/*     */   void updateObjectSize(Actor object)
/*     */   {
/* 759 */     this.collisionChecker.updateObjectSize(object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void startSequence()
/*     */   {
/* 770 */     this.collisionChecker.startSequence();
/*     */   }
/*     */   
/*     */ 
/*     */   Actor getOneObjectAt(Actor object, int dx, int dy, Class cls)
/*     */   {
/* 776 */     return this.collisionChecker.getOneObjectAt(object, dx, dy, cls);
/*     */   }
/*     */   
/*     */ 
/*     */   Actor getOneIntersectingObject(Actor object, Class cls)
/*     */   {
/* 782 */     return this.collisionChecker.getOneIntersectingObject(object, cls);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   TreeActorSet getObjectsListInPaintOrder()
/*     */   {
/* 793 */     if (this.objectsInPaintOrder != null) {
/* 794 */       return this.objectsInPaintOrder;
/*     */     }
/*     */     
/* 797 */     return this.objectsDisordered;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   TreeActorSet getObjectsListInActOrder()
/*     */   {
/* 808 */     if (this.objectsInActOrder != null) {
/* 809 */       return this.objectsInActOrder;
/*     */     }
/*     */     
/* 812 */     return this.objectsDisordered;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void paintDebug(Graphics g) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initialize(int width, int height, int cellSize)
/*     */   {
/* 836 */     this.width = width;
/* 837 */     this.height = height;
/* 838 */     this.cellSize = cellSize;
/* 839 */     this.collisionChecker.initialize(width, height, cellSize, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private GreenfootImage getClassImage()
/*     */   {
/* 847 */     Class<?> clazz = getClass();
/* 848 */     while (clazz != null) {
/* 849 */       GreenfootImage image = null;
/*     */       try {
/* 851 */         image = Actor.getDelegate().getImage(clazz.getName());
/*     */       }
/*     */       catch (Throwable e) {}
/*     */       
/*     */ 
/* 856 */       if (image != null) {
/* 857 */         return image;
/*     */       }
/* 859 */       clazz = clazz.getSuperclass();
/*     */     }
/*     */     
/* 862 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void ensureWithinXBounds(int x)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 873 */     if (x >= getWidth()) {
/* 874 */       throw new IndexOutOfBoundsException("The x-coordinate is: " + x + ". It must be smaller than: " + getWidth());
/*     */     }
/*     */     
/* 877 */     if (x < 0) {
/* 878 */       throw new IndexOutOfBoundsException("The x-coordinate is: " + x + ". It must be larger than: 0");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void ensureWithinYBounds(int y)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 890 */     if (y >= getHeight()) {
/* 891 */       throw new IndexOutOfBoundsException("The y-coordinate is: " + y + ". It must be smaller than: " + getHeight());
/*     */     }
/*     */     
/* 894 */     if (y < 0) {
/* 895 */       throw new IndexOutOfBoundsException("The x-coordinate is: " + y + ". It must be larger than: 0");
/*     */     }
/*     */   }
/*     */   
/*     */   private void addInActOrder(Actor object)
/*     */   {
/* 901 */     if (this.objectsInActOrder != null) {
/* 902 */       this.objectsInActOrder.add(object);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addInPaintOrder(Actor object)
/*     */   {
/* 908 */     if (this.objectsInPaintOrder != null) {
/* 909 */       this.objectsInPaintOrder.add(object);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\World.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */