package greenfoot.platforms;

import greenfoot.GreenfootImage;
import greenfoot.UserInfo;
import java.awt.Component;
import java.net.URL;
import java.util.List;

public abstract interface GreenfootUtilDelegate
{
  public abstract URL getResource(String paramString);
  
  public abstract Iterable<String> getSoundFiles();
  
  public abstract String getGreenfootLogoPath();
  
  public abstract void displayMessage(Component paramComponent, String paramString);
  
  public abstract boolean isStorageSupported();
  
  public abstract UserInfo getCurrentUserInfo();
  
  public abstract boolean storeCurrentUserInfo(UserInfo paramUserInfo);
  
  public abstract List<UserInfo> getTopUserInfo(int paramInt);
  
  public abstract GreenfootImage getUserImage(String paramString);
  
  public abstract String getUserName();
  
  public abstract List<UserInfo> getNearbyUserInfo(int paramInt);
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\platforms\GreenfootUtilDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */