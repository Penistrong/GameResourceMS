package greenfoot.platforms;

import greenfoot.GreenfootImage;

public abstract interface ActorDelegate
{
  public abstract GreenfootImage getImage(String paramString);
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\platforms\ActorDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */