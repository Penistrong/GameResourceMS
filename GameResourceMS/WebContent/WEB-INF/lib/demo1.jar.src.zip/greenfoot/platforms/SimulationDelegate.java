package greenfoot.platforms;

public abstract interface SimulationDelegate
{
  public abstract void setSpeed(int paramInt);
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\platforms\SimulationDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */