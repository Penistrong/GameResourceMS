/*    */ package greenfoot.platforms.standalone;
/*    */ 
/*    */ import greenfoot.ActorVisitor;
/*    */ import greenfoot.GreenfootImage;
/*    */ import greenfoot.core.ProjectProperties;
/*    */ import greenfoot.platforms.ActorDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActorDelegateStandAlone
/*    */   implements ActorDelegate
/*    */ {
/* 38 */   private static ActorDelegateStandAlone instance = new ActorDelegateStandAlone();
/*    */   
/*    */ 
/*    */   private ProjectProperties properties;
/*    */   
/*    */ 
/*    */ 
/*    */   public static void setupAsActorDelegate()
/*    */   {
/* 47 */     ActorVisitor.setDelegate(instance);
/*    */   }
/*    */   
/*    */   public static void initProperties(ProjectProperties properties)
/*    */   {
/* 52 */     instance.properties = properties;
/*    */   }
/*    */   
/*    */   public GreenfootImage getImage(String name)
/*    */   {
/* 57 */     return this.properties.getImage(name);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\platforms\standalone\ActorDelegateStandAlone.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */