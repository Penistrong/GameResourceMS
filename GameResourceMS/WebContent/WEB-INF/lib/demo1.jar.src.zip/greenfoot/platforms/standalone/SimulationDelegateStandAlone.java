package greenfoot.platforms.standalone;

import greenfoot.platforms.SimulationDelegate;

public class SimulationDelegateStandAlone
  implements SimulationDelegate
{
  public void setSpeed(int speed) {}
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\platforms\standalone\SimulationDelegateStandAlone.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */