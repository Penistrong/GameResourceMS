/*     */ package greenfoot.platforms.standalone;
/*     */ 
/*     */ import greenfoot.GreenfootImage;
/*     */ import greenfoot.UserInfo;
/*     */ import greenfoot.UserInfoVisitor;
/*     */ import greenfoot.platforms.GreenfootUtilDelegate;
/*     */ import greenfoot.util.GreenfootStorageException;
/*     */ import java.awt.Component;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URL;
/*     */ import java.nio.BufferUnderflowException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GreenfootUtilDelegateStandAlone
/*     */   implements GreenfootUtilDelegate
/*     */ {
/*     */   private SocketChannel socket;
/*     */   private boolean failedLastConnection;
/*  50 */   private boolean firstStorageException = true;
/*     */   
/*     */   private boolean storageStandalone;
/*     */   
/*     */   private String storageHost;
/*     */   
/*     */   private String storagePort;
/*     */   private String storagePasscode;
/*     */   private String storageScenarioId;
/*     */   private String storageUserId;
/*     */   private String storageUserName;
/*     */   
/*     */   public GreenfootUtilDelegateStandAlone(boolean storageStandalone, String storageHost, String storagePort, String storagePasscode, String storageScenarioId, String storageUserId, String storageUserName)
/*     */   {
/*  64 */     this.storageStandalone = storageStandalone;
/*  65 */     this.storageHost = storageHost;
/*  66 */     this.storagePort = storagePort;
/*  67 */     this.storagePasscode = storagePasscode;
/*  68 */     this.storageScenarioId = storageScenarioId;
/*  69 */     this.storageUserId = storageUserId;
/*  70 */     this.storageUserName = storageUserName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URL getResource(String path)
/*     */   {
/*  84 */     URL res = getClass().getClassLoader().getResource(path);
/*  85 */     if ((res != null) && ((res.toString().contains("!")) || (res.getProtocol().equals("file")))) {
/*  86 */       return res;
/*     */     }
/*     */     
/*  89 */     if (path.indexOf('\\') != -1)
/*     */     {
/*  91 */       path = path.replace('\\', '/');
/*  92 */       res = getClass().getClassLoader().getResource(path);
/*  93 */       if ((res != null) && (res.toString().contains("!"))) {
/*  94 */         return res;
/*     */       }
/*     */     }
/*  97 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Iterable<String> getSoundFiles()
/*     */   {
/* 104 */     InputStream is = getClass().getClassLoader().getResourceAsStream("soundindex.list");
/* 105 */     ArrayList<String> r = new ArrayList();
/*     */     
/* 107 */     if (is != null)
/*     */     {
/* 109 */       BufferedReader reader = new BufferedReader(new InputStreamReader(is));
/*     */       try
/*     */       {
/*     */         String line;
/* 113 */         while ((line = reader.readLine()) != null)
/*     */         {
/* 115 */           r.add(line);
/*     */         }
/*     */       }
/*     */       catch (IOException e) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */     return r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getGreenfootLogoPath()
/*     */   {
/* 134 */     return getClass().getClassLoader().getResource("greenfoot.png").toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public void displayMessage(Component parent, String messageText)
/*     */   {
/* 140 */     System.err.println(messageText);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void closeConnection(Exception e)
/*     */   {
/* 149 */     e.printStackTrace();
/* 150 */     this.socket = null;
/* 151 */     this.failedLastConnection = false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isStorageSupported()
/*     */   {
/*     */     try
/*     */     {
/* 159 */       ensureStorageConnected();
/* 160 */       return getCurrentUserInfo() != null;
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (GreenfootStorageException e)
/*     */     {
/*     */ 
/*     */ 
/* 169 */       if (this.firstStorageException)
/*     */       {
/* 171 */         e.printStackTrace();
/*     */       }
/* 173 */       this.firstStorageException = false; }
/* 174 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void ensureStorageConnected()
/*     */     throws GreenfootStorageException
/*     */   {
/* 187 */     if ((this.socket != null) && (this.socket.isConnected())) {
/* 188 */       return;
/*     */     }
/* 190 */     if (((this.socket == null) || (!this.socket.isConnected())) && (this.failedLastConnection)) {
/* 191 */       throw new GreenfootStorageException("Already failed to connect to storage server on last attempt");
/*     */     }
/*     */     
/* 194 */     if (!this.storageStandalone) {
/* 195 */       throw new GreenfootStorageException("Standalone storage not supported");
/*     */     }
/*     */     
/* 198 */     System.err.println("Attempting to reconnect to storage server");
/*     */     
/*     */     int userId;
/*     */     try
/*     */     {
/* 203 */       userId = Integer.parseInt(this.storageUserId);
/* 204 */       if (userId < 0) {
/* 205 */         throw new GreenfootStorageException("User not logged in");
/*     */       }
/*     */     }
/*     */     catch (NumberFormatException e) {
/* 209 */       throw new GreenfootStorageException("Invalid user ID");
/*     */     }
/*     */     
/*     */     short port;
/*     */     try
/*     */     {
/* 215 */       port = Short.parseShort(this.storagePort);
/*     */     }
/*     */     catch (NumberFormatException e)
/*     */     {
/* 219 */       throw new GreenfootStorageException("Error connecting to storage server -- invalid port: " + e.getMessage());
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 224 */       if (this.storagePasscode == null) {
/* 225 */         throw new GreenfootStorageException("Could not find passcode to send back to server");
/*     */       }
/* 227 */       this.failedLastConnection = true;
/*     */       
/* 229 */       this.socket = SocketChannel.open();
/* 230 */       if (!this.socket.connect(new InetSocketAddress(this.storageHost, port)))
/*     */       {
/* 232 */         this.socket = null;
/* 233 */         throw new GreenfootStorageException("Could not connect to storage server");
/*     */       }
/*     */       
/* 236 */       ByteBuffer buffer = makeRequest(this.storagePasscode.length() / 2 + 4 + 4);
/* 237 */       for (int i = 0; i < this.storagePasscode.length() / 2; i++)
/*     */       {
/*     */ 
/* 240 */         byte b = (byte)(0xFF & Short.parseShort(this.storagePasscode.substring(i * 2, i * 2 + 2), 16));
/* 241 */         buffer.put(b);
/*     */       }
/*     */       try
/*     */       {
/* 245 */         buffer.putInt(Integer.parseInt(this.storageScenarioId));
/* 246 */         buffer.putInt(userId);
/*     */       }
/*     */       catch (NumberFormatException e)
/*     */       {
/* 250 */         this.socket = null;
/* 251 */         throw new GreenfootStorageException("Invalid scenario ID: " + e.getMessage());
/*     */       }
/* 253 */       buffer.flip();
/* 254 */       this.socket.write(buffer);
/*     */       
/* 256 */       this.failedLastConnection = false;
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 260 */       this.socket = null;
/* 261 */       throw new GreenfootStorageException("Error connecting to storage server: " + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */   private ByteBuffer makeRequest(int plusBytes)
/*     */   {
/* 267 */     ByteBuffer buf = ByteBuffer.allocate(4 + plusBytes);
/* 268 */     buf.putInt(plusBytes);
/*     */     
/* 270 */     return buf;
/*     */   }
/*     */   
/*     */   private void readFullBuffer(ByteBuffer buf, int amount) throws IOException
/*     */   {
/* 275 */     int totalBytes = 0;
/* 276 */     while (totalBytes < amount)
/*     */     {
/* 278 */       int bytesRead = this.socket.read(buf);
/* 279 */       if (bytesRead > 0) {
/* 280 */         totalBytes += bytesRead;
/*     */       } else
/* 282 */         throw new IOException("Zero or negative bytes read from socket");
/*     */     }
/* 284 */     buf.flip();
/*     */   }
/*     */   
/*     */   private ByteBuffer readResponse() throws IOException
/*     */   {
/* 289 */     ByteBuffer buf = ByteBuffer.allocate(4);
/* 290 */     readFullBuffer(buf, 4);
/* 291 */     int size = buf.getInt();
/* 292 */     buf = ByteBuffer.allocate(size);
/* 293 */     readFullBuffer(buf, size);
/* 294 */     return buf;
/*     */   }
/*     */   
/*     */ 
/*     */   public UserInfo getCurrentUserInfo()
/*     */   {
/*     */     try
/*     */     {
/* 302 */       ensureStorageConnected();
/* 303 */       ByteBuffer buf = makeRequest(1);
/* 304 */       buf.put((byte)1);
/* 305 */       buf.flip();
/* 306 */       this.socket.write(buf);
/*     */       
/* 308 */       buf = readResponse();
/* 309 */       if (1 != buf.getInt())
/* 310 */         return null;
/* 311 */       return readLines(buf, 1, true)[0];
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 315 */       closeConnection(e);
/*     */       
/* 317 */       return null;
/*     */     }
/*     */     catch (BufferUnderflowException e)
/*     */     {
/* 321 */       closeConnection(e);
/*     */       
/* 323 */       return null;
/*     */     }
/*     */     catch (GreenfootStorageException e)
/*     */     {
/* 327 */       closeConnection(e); }
/* 328 */     return null;
/*     */   }
/*     */   
/*     */   private static String getString(ByteBuffer buf)
/*     */     throws BufferUnderflowException
/*     */   {
/* 334 */     int len = buf.getShort();
/* 335 */     if (len == -1) {
/* 336 */       return null;
/*     */     }
/* 338 */     char[] cs = new char[len];
/* 339 */     for (int i = 0; i < len; i++)
/*     */     {
/* 341 */       cs[i] = buf.getChar();
/*     */     }
/* 343 */     return new String(cs);
/*     */   }
/*     */   
/*     */   private static void putString(ByteBuffer buf, String value)
/*     */   {
/* 348 */     if (value == null)
/*     */     {
/* 350 */       buf.putShort((short)-1);
/*     */     }
/*     */     else
/*     */     {
/* 354 */       buf.putShort((short)value.length());
/* 355 */       for (int i = 0; i < value.length(); i++)
/*     */       {
/* 357 */         buf.putChar(value.charAt(i));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private UserInfo[] readLines(ByteBuffer buf, int numLines, boolean useSingleton)
/*     */     throws BufferUnderflowException
/*     */   {
/* 365 */     int numInts = buf.getInt();
/* 366 */     int numStrings = buf.getInt();
/*     */     
/* 368 */     UserInfo[] r = new UserInfo[numLines];
/*     */     
/* 370 */     for (int line = 0; line < numLines; line++)
/*     */     {
/* 372 */       String userName = getString(buf);
/* 373 */       int score = buf.getInt();
/* 374 */       int rank = buf.getInt();
/* 375 */       r[line] = UserInfoVisitor.allocate(userName, rank, useSingleton ? getUserName() : null);
/* 376 */       r[line].setScore(score);
/* 377 */       for (int i = 0; i < numInts; i++)
/*     */       {
/* 379 */         int x = buf.getInt();
/* 380 */         if (i < 10)
/* 381 */           r[line].setInt(i, x);
/*     */       }
/* 383 */       for (int i = 0; i < numStrings; i++)
/*     */       {
/* 385 */         String s = getString(buf);
/* 386 */         if (i < 5)
/* 387 */           r[line].setString(i, s);
/*     */       }
/*     */     }
/* 390 */     return r;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean storeCurrentUserInfo(UserInfo data)
/*     */   {
/*     */     try
/*     */     {
/* 398 */       ensureStorageConnected();
/* 399 */       int payloadLength = 0;
/* 400 */       payloadLength += 52;
/* 401 */       for (int i = 0; i < 5; i++) {
/* 402 */         payloadLength += stringSize(data.getString(i));
/*     */       }
/* 404 */       ByteBuffer buf = makeRequest(1 + payloadLength);
/* 405 */       buf.put((byte)2);
/* 406 */       buf.putInt(data.getScore());
/* 407 */       buf.putInt(10);
/* 408 */       buf.putInt(5);
/* 409 */       for (int i = 0; i < 10; i++)
/* 410 */         buf.putInt(data.getInt(i));
/* 411 */       for (int i = 0; i < 5; i++)
/* 412 */         putString(buf, data.getString(i));
/* 413 */       buf.flip();
/* 414 */       this.socket.write(buf);
/*     */       
/* 416 */       buf = readResponse();
/* 417 */       byte code = buf.get();
/* 418 */       if (code != 0)
/*     */       {
/*     */ 
/* 421 */         throw new GreenfootStorageException("Error storing data, code: " + Byte.toString(code));
/*     */       }
/*     */       
/* 424 */       return true;
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 428 */       closeConnection(e);
/*     */       
/* 430 */       return false;
/*     */     }
/*     */     catch (BufferUnderflowException e)
/*     */     {
/* 434 */       closeConnection(e);
/*     */       
/* 436 */       return false;
/*     */     }
/*     */     catch (GreenfootStorageException e)
/*     */     {
/* 440 */       closeConnection(e); }
/* 441 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   private static int stringSize(String string)
/*     */   {
/* 447 */     if (string == null) {
/* 448 */       return 2;
/*     */     }
/* 450 */     return 2 + 2 * string.length();
/*     */   }
/*     */   
/*     */ 
/*     */   public List<UserInfo> getTopUserInfo(int limit)
/*     */   {
/*     */     try
/*     */     {
/* 458 */       ensureStorageConnected();
/* 459 */       ByteBuffer buf = makeRequest(5);
/* 460 */       buf.put((byte)3);
/* 461 */       buf.putInt(limit);
/* 462 */       buf.flip();
/* 463 */       this.socket.write(buf);
/*     */       
/* 465 */       buf = readResponse();
/* 466 */       int numUsers = buf.getInt();
/* 467 */       UserInfo[] storage = readLines(buf, numUsers, false);
/*     */       
/* 469 */       List<UserInfo> r = new ArrayList();
/* 470 */       for (UserInfo s : storage)
/*     */       {
/* 472 */         r.add(s);
/*     */       }
/* 474 */       return r;
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 478 */       closeConnection(e);
/*     */       
/* 480 */       return null;
/*     */     }
/*     */     catch (BufferUnderflowException e)
/*     */     {
/* 484 */       closeConnection(e);
/*     */       
/* 486 */       return null;
/*     */     }
/*     */     catch (GreenfootStorageException e)
/*     */     {
/* 490 */       closeConnection(e); }
/* 491 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<UserInfo> getNearbyUserInfo(int limit)
/*     */   {
/*     */     try
/*     */     {
/* 500 */       ensureStorageConnected();
/* 501 */       ByteBuffer buf = makeRequest(5);
/* 502 */       buf.put((byte)5);
/* 503 */       buf.putInt(limit);
/* 504 */       buf.flip();
/* 505 */       this.socket.write(buf);
/*     */       
/* 507 */       buf = readResponse();
/* 508 */       int numUsers = buf.getInt();
/* 509 */       if (numUsers < 0) {
/* 510 */         return null;
/*     */       }
/* 512 */       UserInfo[] storage = readLines(buf, numUsers, false);
/*     */       
/* 514 */       List<UserInfo> r = new ArrayList();
/* 515 */       for (UserInfo s : storage)
/*     */       {
/* 517 */         r.add(s);
/*     */       }
/* 519 */       return r;
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 523 */       closeConnection(e);
/*     */       
/* 525 */       return null;
/*     */     }
/*     */     catch (BufferUnderflowException e)
/*     */     {
/* 529 */       closeConnection(e);
/*     */       
/* 531 */       return null;
/*     */     }
/*     */     catch (GreenfootStorageException e)
/*     */     {
/* 535 */       closeConnection(e); }
/* 536 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public GreenfootImage getUserImage(String userName)
/*     */   {
/* 543 */     if ((userName == null) || (userName.equals(""))) {
/* 544 */       userName = this.storageUserName;
/*     */     }
/*     */     try
/*     */     {
/* 548 */       ensureStorageConnected();
/* 549 */       ByteBuffer buf = makeRequest(3 + 2 * userName.length());
/* 550 */       buf.put((byte)4);
/* 551 */       putString(buf, userName);
/* 552 */       buf.flip();
/* 553 */       this.socket.write(buf);
/*     */       
/* 555 */       buf = readResponse();
/* 556 */       int numBytes = buf.getInt();
/* 557 */       byte[] fileData = new byte[numBytes];
/* 558 */       buf.get(fileData);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 566 */         return UserInfoVisitor.readImage(fileData);
/*     */ 
/*     */       }
/*     */       catch (IllegalArgumentException e)
/*     */       {
/* 571 */         return null;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 583 */       return null;
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 576 */       closeConnection(e);
/*     */       
/* 578 */       return null;
/*     */     }
/*     */     catch (GreenfootStorageException e)
/*     */     {
/* 582 */       closeConnection(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getUserName()
/*     */   {
/* 590 */     return this.storageUserName;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\platforms\standalone\GreenfootUtilDelegateStandAlone.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */