/*     */ package greenfoot.platforms.standalone;
/*     */ 
/*     */ import greenfoot.Actor;
/*     */ import greenfoot.World;
/*     */ import greenfoot.core.WorldHandler;
/*     */ import greenfoot.export.GreenfootScenarioViewer;
/*     */ import greenfoot.gui.input.InputManager;
/*     */ import greenfoot.platforms.WorldHandlerDelegate;
/*     */ import java.awt.event.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WorldHandlerDelegateStandAlone
/*     */   implements WorldHandlerDelegate
/*     */ {
/*     */   private WorldHandler worldHandler;
/*     */   private GreenfootScenarioViewer viewer;
/*     */   private boolean lockScenario;
/*     */   
/*     */   public WorldHandlerDelegateStandAlone(GreenfootScenarioViewer viewer, boolean lockScenario)
/*     */   {
/*  47 */     this.viewer = viewer;
/*  48 */     this.lockScenario = lockScenario;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean maybeShowPopup(MouseEvent e)
/*     */   {
/*  54 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mouseClicked(MouseEvent e) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mouseMoved(MouseEvent e) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void setWorld(World oldWorld, World newWorld) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void setWorldHandler(WorldHandler handler)
/*     */   {
/*  75 */     this.worldHandler = handler;
/*     */   }
/*     */   
/*     */   public void instantiateNewWorld()
/*     */   {
/*  80 */     WorldHandler.getInstance().clearWorldSet();
/*  81 */     World newWorld = this.viewer.instantiateNewWorld();
/*  82 */     if (!WorldHandler.getInstance().checkWorldSet()) {
/*  83 */       WorldHandler.getInstance().setWorld(newWorld);
/*     */     }
/*     */   }
/*     */   
/*     */   public InputManager getInputManager()
/*     */   {
/*  89 */     InputManager inputManager = new InputManager();
/*  90 */     inputManager.setDragListeners(null, null, null);
/*  91 */     if (this.lockScenario) {
/*  92 */       inputManager.setIdleListeners(null, null, null);
/*  93 */       inputManager.setMoveListeners(null, null, null);
/*     */     }
/*     */     else {
/*  96 */       inputManager.setIdleListeners(this.worldHandler, this.worldHandler, this.worldHandler);
/*  97 */       inputManager.setMoveListeners(this.worldHandler, this.worldHandler, this.worldHandler);
/*     */     }
/*  99 */     return inputManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void discardWorld(World world) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addActor(Actor actor, int x, int y) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void actorDragged(Actor actor, int xCell, int yCell) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void objectAddedToWorld(Actor actor) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public String ask(String prompt)
/*     */   {
/* 125 */     return this.viewer.ask(prompt);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\platforms\standalone\WorldHandlerDelegateStandAlone.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */