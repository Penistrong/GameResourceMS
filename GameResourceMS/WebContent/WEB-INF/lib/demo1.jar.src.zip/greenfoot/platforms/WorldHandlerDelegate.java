package greenfoot.platforms;

import greenfoot.Actor;
import greenfoot.World;
import greenfoot.core.WorldHandler;
import greenfoot.gui.input.InputManager;
import java.awt.event.MouseEvent;

public abstract interface WorldHandlerDelegate
{
  public abstract boolean maybeShowPopup(MouseEvent paramMouseEvent);
  
  public abstract void mouseClicked(MouseEvent paramMouseEvent);
  
  public abstract void mouseMoved(MouseEvent paramMouseEvent);
  
  public abstract void setWorld(World paramWorld1, World paramWorld2);
  
  public abstract void setWorldHandler(WorldHandler paramWorldHandler);
  
  public abstract void addActor(Actor paramActor, int paramInt1, int paramInt2);
  
  public abstract void instantiateNewWorld();
  
  public abstract InputManager getInputManager();
  
  public abstract void discardWorld(World paramWorld);
  
  public abstract void actorDragged(Actor paramActor, int paramInt1, int paramInt2);
  
  public abstract void objectAddedToWorld(Actor paramActor);
  
  public abstract String ask(String paramString);
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\platforms\WorldHandlerDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */