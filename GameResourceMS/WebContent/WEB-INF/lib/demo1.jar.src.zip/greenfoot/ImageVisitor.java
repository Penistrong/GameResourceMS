/*    */ package greenfoot;
/*    */ 
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.image.ImageObserver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImageVisitor
/*    */ {
/*    */   public static void drawImage(GreenfootImage image, Graphics2D g, int x, int y, ImageObserver observer, boolean useTranparency)
/*    */   {
/* 41 */     image.drawImage(g, x, y, observer, useTranparency);
/*    */   }
/*    */   
/*    */   public static boolean equal(GreenfootImage image1, GreenfootImage image2)
/*    */   {
/* 46 */     return GreenfootImage.equal(image1, image2);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\ImageVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */