/*     */ package greenfoot;
/*     */ 
/*     */ import greenfoot.core.TextLabel;
/*     */ import java.awt.Graphics;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WorldVisitor
/*     */ {
/*     */   public static int getWidthInCells(World w)
/*     */   {
/*  42 */     return w.width;
/*     */   }
/*     */   
/*     */   public static int getHeightInCells(World w)
/*     */   {
/*  47 */     return w.height;
/*     */   }
/*     */   
/*     */   public static int getWidthInPixels(World w)
/*     */   {
/*  52 */     return w.getWidthInPixels();
/*     */   }
/*     */   
/*     */   public static int getHeightInPixels(World w)
/*     */   {
/*  57 */     return w.getHeightInPixels();
/*     */   }
/*     */   
/*     */   public static int getCellSize(World w)
/*     */   {
/*  62 */     return w.cellSize;
/*     */   }
/*     */   
/*     */   public static Collection<Actor> getObjectsAtPixel(World w, int x, int y)
/*     */   {
/*  67 */     return w.getObjectsAtPixel(x, y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void startSequence(World w)
/*     */   {
/*  76 */     w.startSequence();
/*     */   }
/*     */   
/*     */   public static void paintDebug(World world, Graphics g)
/*     */   {
/*  81 */     world.paintDebug(g);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int toCellFloor(World world, int x)
/*     */   {
/*  89 */     return world.toCellFloor(x);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double getCellCenter(World w, int c)
/*     */   {
/*  99 */     return w.getCellCenter(c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TreeActorSet getObjectsListInPaintOrder(World world)
/*     */   {
/* 109 */     return world.getObjectsListInPaintOrder();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TreeActorSet getObjectsListInActOrder(World world)
/*     */   {
/* 119 */     return world.getObjectsListInActOrder();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static GreenfootImage getBackgroundImage(World world)
/*     */   {
/* 129 */     return world.getBackgroundNoInit();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<TextLabel> getTextLabels(World world)
/*     */   {
/* 137 */     return world.textLabels;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\WorldVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */