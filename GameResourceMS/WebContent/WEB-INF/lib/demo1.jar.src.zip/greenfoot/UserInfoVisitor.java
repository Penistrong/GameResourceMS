/*    */ package greenfoot;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserInfoVisitor
/*    */ {
/*    */   private static UserInfo myInfo;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static UserInfo allocate(String userName, int rank, String singletonUserName)
/*    */   {
/* 30 */     if ((singletonUserName != null) && (singletonUserName.equals(userName)))
/*    */     {
/* 32 */       if ((myInfo != null) && (myInfo.getUserName().equals(singletonUserName)))
/*    */       {
/* 34 */         myInfo.setRank(rank);
/*    */       }
/*    */       else
/*    */       {
/* 38 */         myInfo = new UserInfo(userName, rank);
/*    */       }
/* 40 */       return myInfo;
/*    */     }
/*    */     
/*    */ 
/* 44 */     return new UserInfo(userName, rank);
/*    */   }
/*    */   
/*    */ 
/*    */   public static GreenfootImage readImage(byte[] imageFileContents)
/*    */   {
/* 50 */     return new GreenfootImage(imageFileContents);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\UserInfoVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */