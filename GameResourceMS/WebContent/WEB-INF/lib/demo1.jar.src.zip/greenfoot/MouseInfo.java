/*     */ package greenfoot;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MouseInfo
/*     */ {
/*     */   private Actor actor;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int button;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int x;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int y;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int clickCount;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getX()
/*     */   {
/*  55 */     return this.x;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getY()
/*     */   {
/*  65 */     return this.y;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Actor getActor()
/*     */   {
/*  80 */     return this.actor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getButton()
/*     */   {
/*  90 */     return this.button;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getClickCount()
/*     */   {
/*  98 */     return this.clickCount;
/*     */   }
/*     */   
/*     */   void setButton(int button)
/*     */   {
/* 103 */     this.button = button;
/*     */   }
/*     */   
/*     */   void setLoc(int x, int y)
/*     */   {
/* 108 */     this.x = x;
/* 109 */     this.y = y;
/*     */   }
/*     */   
/*     */   void setActor(Actor actor)
/*     */   {
/* 114 */     this.actor = actor;
/*     */   }
/*     */   
/*     */   void setClickCount(int clickCount)
/*     */   {
/* 119 */     this.clickCount = clickCount;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 124 */     return "MouseInfo. Actor: " + this.actor + "  Location: (" + this.x + "," + this.y + ")  Button: " + this.button + " Click Count: " + this.clickCount;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\MouseInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */