/*     */ package greenfoot;
/*     */ 
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActorSet
/*     */   extends AbstractSet<Actor>
/*     */ {
/*     */   private ListNode listHeadTail;
/*     */   private ListNode[] hashMap;
/*     */   private int numActors;
/*     */   private int myHashCode;
/*     */   
/*     */   public ActorSet()
/*     */   {
/*  34 */     this.listHeadTail = new ListNode();
/*     */     
/*  36 */     this.hashMap = new ListNode[0];
/*     */     
/*  38 */     this.numActors = 0;
/*     */     
/*     */ 
/*  41 */     this.myHashCode = 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  47 */     return this.myHashCode;
/*     */   }
/*     */   
/*     */   public boolean add(Actor actor)
/*     */   {
/*  52 */     if (contains(actor)) {
/*  53 */       return false;
/*     */     }
/*     */     
/*  56 */     this.numActors += 1;
/*  57 */     ListNode newNode = new ListNode(actor, this.listHeadTail.prev);
/*     */     
/*  59 */     int seq = ActorVisitor.getSequenceNumber(actor);
/*  60 */     if (this.numActors >= 2 * this.hashMap.length)
/*     */     {
/*  62 */       resizeHashmap();
/*     */     }
/*     */     else {
/*  65 */       int hash = seq % this.hashMap.length;
/*  66 */       ListNode hashHead = this.hashMap[hash];
/*  67 */       this.hashMap[hash] = newNode;
/*  68 */       newNode.setHashListHead(hashHead);
/*     */     }
/*     */     
/*  71 */     this.myHashCode += seq;
/*  72 */     return true;
/*     */   }
/*     */   
/*     */   private void resizeHashmap()
/*     */   {
/*  77 */     this.hashMap = new ListNode[this.numActors];
/*  78 */     ListNode currentActor = this.listHeadTail.next;
/*  79 */     while (currentActor != this.listHeadTail) {
/*  80 */       int seq = ActorVisitor.getSequenceNumber(currentActor.actor);
/*  81 */       int hash = seq % this.numActors;
/*  82 */       ListNode hashHead = this.hashMap[hash];
/*  83 */       this.hashMap[hash] = currentActor;
/*  84 */       currentActor.setHashListHead(hashHead);
/*     */       
/*  86 */       currentActor = currentActor.next;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean contains(Actor actor)
/*     */   {
/*  92 */     return getActorNode(actor) != null;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean contains(Object o)
/*     */   {
/*  98 */     if ((o instanceof Actor)) {
/*  99 */       Actor a = (Actor)o;
/* 100 */       return contains(a);
/*     */     }
/* 102 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ListNode getActorNode(Actor actor)
/*     */   {
/* 110 */     if (this.hashMap.length == 0) {
/* 111 */       return null;
/*     */     }
/*     */     
/* 114 */     int seq = ActorVisitor.getSequenceNumber(actor);
/* 115 */     int hash = seq % this.hashMap.length;
/* 116 */     ListNode hashHead = this.hashMap[hash];
/*     */     
/* 118 */     if (hashHead == null) {
/* 119 */       return null;
/*     */     }
/* 121 */     if (hashHead.actor == actor) {
/* 122 */       return hashHead;
/*     */     }
/*     */     
/* 125 */     ListNode curNode = hashHead.nextHash;
/* 126 */     while (curNode != hashHead) {
/* 127 */       if (curNode.actor == actor) {
/* 128 */         return curNode;
/*     */       }
/* 130 */       curNode = curNode.nextHash;
/*     */     }
/*     */     
/* 133 */     return null;
/*     */   }
/*     */   
/*     */   public boolean remove(Actor actor)
/*     */   {
/* 138 */     ListNode actorNode = getActorNode(actor);
/*     */     
/* 140 */     if (actorNode != null) {
/* 141 */       remove(actorNode);
/* 142 */       this.myHashCode -= ActorVisitor.getSequenceNumber(actor);
/* 143 */       return true;
/*     */     }
/*     */     
/* 146 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   private void remove(ListNode actorNode)
/*     */   {
/* 152 */     int seq = ActorVisitor.getSequenceNumber(actorNode.actor);
/* 153 */     int hash = seq % this.hashMap.length;
/* 154 */     if (this.hashMap[hash] == actorNode) {
/* 155 */       this.hashMap[hash] = actorNode.nextHash;
/* 156 */       if (this.hashMap[hash] == actorNode)
/*     */       {
/* 158 */         this.hashMap[hash] = null;
/*     */       }
/*     */     }
/*     */     
/* 162 */     actorNode.remove();
/* 163 */     this.numActors -= 1;
/* 164 */     if (this.numActors <= this.hashMap.length / 2)
/*     */     {
/* 166 */       resizeHashmap();
/*     */     }
/*     */   }
/*     */   
/*     */   public int size()
/*     */   {
/* 172 */     return this.numActors;
/*     */   }
/*     */   
/*     */ 
/*     */   public Iterator<Actor> iterator()
/*     */   {
/* 178 */     return new ActorSetIterator();
/*     */   }
/*     */   
/*     */ 
/*     */   private class ListNode
/*     */   {
/*     */     Actor actor;
/*     */     
/*     */     ListNode next;
/*     */     
/*     */     ListNode prev;
/*     */     ListNode nextHash;
/*     */     ListNode prevHash;
/*     */     
/*     */     public ListNode()
/*     */     {
/* 194 */       this.next = this;
/* 195 */       this.prev = this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ListNode(Actor actor, ListNode listTail)
/*     */     {
/* 205 */       this.actor = actor;
/* 206 */       this.next = listTail.next;
/* 207 */       this.prev = listTail;
/* 208 */       listTail.next = this;
/* 209 */       this.next.prev = this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setHashListHead(ListNode oldHead)
/*     */     {
/* 218 */       if (oldHead == null) {
/* 219 */         this.nextHash = this;
/* 220 */         this.prevHash = this;
/*     */       }
/*     */       else {
/* 223 */         this.nextHash = oldHead;
/* 224 */         this.prevHash = oldHead.prevHash;
/* 225 */         oldHead.prevHash = this;
/* 226 */         this.prevHash.nextHash = this;
/*     */       }
/*     */     }
/*     */     
/*     */     public void remove()
/*     */     {
/* 232 */       this.next.prev = this.prev;
/* 233 */       this.prev.next = this.next;
/* 234 */       this.nextHash.prevHash = this.prevHash;
/* 235 */       this.prevHash.nextHash = this.nextHash;
/*     */     }
/*     */   }
/*     */   
/*     */   private class ActorSetIterator implements Iterator<Actor>
/*     */   {
/*     */     ActorSet.ListNode currentNode;
/*     */     
/*     */     public ActorSetIterator()
/*     */     {
/* 245 */       this.currentNode = ActorSet.this.listHeadTail;
/*     */     }
/*     */     
/*     */     public boolean hasNext()
/*     */     {
/* 250 */       return this.currentNode.next != ActorSet.this.listHeadTail;
/*     */     }
/*     */     
/*     */     public Actor next()
/*     */     {
/* 255 */       this.currentNode = this.currentNode.next;
/* 256 */       return this.currentNode.actor;
/*     */     }
/*     */     
/*     */     public void remove()
/*     */     {
/* 261 */       ActorSet.this.remove(this.currentNode);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\ActorSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */