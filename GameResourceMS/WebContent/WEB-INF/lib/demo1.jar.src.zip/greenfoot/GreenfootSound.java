/*     */ package greenfoot;
/*     */ 
/*     */ import greenfoot.sound.Sound;
/*     */ import greenfoot.sound.SoundFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GreenfootSound
/*     */ {
/*     */   private Sound sound;
/*     */   private String filename;
/*     */   
/*     */   public GreenfootSound(String filename)
/*     */   {
/*  53 */     this.filename = filename;
/*  54 */     this.sound = SoundFactory.getInstance().createSound(filename, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void play()
/*     */   {
/*  65 */     this.sound.play();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void playLoop()
/*     */   {
/*  76 */     this.sound.loop();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */   {
/*  86 */     this.sound.stop();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void pause()
/*     */   {
/* 101 */     this.sound.pause();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPlaying()
/*     */   {
/* 110 */     return this.sound.isPlaying();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getVolume()
/*     */   {
/* 118 */     return this.sound.getVolume();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVolume(int level)
/*     */   {
/* 127 */     this.sound.setVolume(level);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 136 */     String s = super.toString() + " file: " + this.filename + " ";
/* 137 */     if (this.sound != null) {
/* 138 */       s = s + ". Is playing: " + isPlaying();
/*     */     }
/*     */     else {
/* 141 */       s = s + ". Not found.";
/*     */     }
/* 143 */     return s;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\GreenfootSound.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */