/*    */ package greenfoot.sound;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ import javax.sound.sampled.Clip;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClipCloserThread
/*    */   implements Runnable
/*    */ {
/* 37 */   private LinkedList<Clip> clips = new LinkedList();
/*    */   
/*    */ 
/*    */ 
/*    */   private Thread thread;
/*    */   
/*    */ 
/*    */ 
/*    */   public void addClip(Clip clip)
/*    */   {
/* 47 */     synchronized (this.clips) {
/* 48 */       this.clips.add(clip);
/* 49 */       this.clips.notify();
/*    */       
/* 51 */       if ((this.thread == null) || (!this.thread.isAlive())) {
/* 52 */         this.thread = new Thread(this);
/* 53 */         this.thread.setDaemon(true);
/* 54 */         this.thread.start();
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void run()
/*    */   {
/*    */     try
/*    */     {
/*    */       for (;;) {
/*    */         Clip clip;
/* 65 */         synchronized (this.clips) {
/* 66 */           if (this.clips.isEmpty()) {
/* 67 */             this.clips.wait(); continue;
/*    */           }
/* 69 */           clip = (Clip)this.clips.removeFirst();
/*    */         }
/*    */         
/* 72 */         clip.close();
/*    */       }
/*    */     }
/*    */     catch (InterruptedException ie) {}
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\ClipCloserThread.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */