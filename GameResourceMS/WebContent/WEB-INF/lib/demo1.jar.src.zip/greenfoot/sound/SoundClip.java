/*     */ package greenfoot.sound;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ import javax.sound.sampled.AudioSystem;
/*     */ import javax.sound.sampled.Clip;
/*     */ import javax.sound.sampled.DataLine.Info;
/*     */ import javax.sound.sampled.FloatControl;
/*     */ import javax.sound.sampled.FloatControl.Type;
/*     */ import javax.sound.sampled.LineEvent;
/*     */ import javax.sound.sampled.LineEvent.Type;
/*     */ import javax.sound.sampled.LineListener;
/*     */ import javax.sound.sampled.LineUnavailableException;
/*     */ import javax.sound.sampled.UnsupportedAudioFileException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SoundClip
/*     */   implements Sound, LineListener
/*     */ {
/*  52 */   private static ClipCache clipCache = new ClipCache();
/*  53 */   private static ClipProcessThread processThread = new ClipProcessThread();
/*  54 */   private static ClipCloserThread closerThread = new ClipCloserThread();
/*     */   
/*     */ 
/*     */ 
/*     */   private final URL url;
/*     */   
/*     */ 
/*     */ 
/*     */   private ClipData clipData;
/*     */   
/*     */ 
/*     */   private Clip soundClip;
/*     */   
/*     */ 
/*     */ 
/*     */   private static enum ClipState
/*     */   {
/*  71 */     STOPPED,  PLAYING,  PAUSED_LOOPING,  PAUSED_PLAYING,  CLOSED,  LOOPING,  STOPPING;
/*     */     
/*     */     private ClipState() {} }
/*     */   
/*  75 */   private ClipState clipState = ClipState.CLOSED;
/*     */   
/*     */ 
/*  78 */   private ClipState currentState = ClipState.STOPPED;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  83 */   private int masterVolume = 100;
/*     */   
/*     */ 
/*     */   private SoundPlaybackListener playbackListener;
/*     */   
/*     */ 
/*     */   private boolean resumedLoop;
/*     */   
/*     */ 
/*     */   private boolean resetToStart;
/*     */   
/*     */ 
/*     */ 
/*     */   public SoundClip(String name, URL url, SoundPlaybackListener listener)
/*     */   {
/*  98 */     this.url = url;
/*  99 */     this.playbackListener = listener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean open()
/*     */   {
/*     */     try
/*     */     {
/* 108 */       load();
/* 109 */       this.soundClip.addLineListener(this);
/* 110 */       return true;
/*     */     }
/*     */     catch (SecurityException e) {
/* 113 */       SoundExceptionHandler.handleSecurityException(e, this.url.toString());
/*     */     }
/*     */     catch (IllegalArgumentException e) {
/* 116 */       SoundExceptionHandler.handleIllegalArgumentException(e, this.url.toString());
/*     */     }
/*     */     catch (FileNotFoundException e) {
/* 119 */       SoundExceptionHandler.handleFileNotFoundException(e, this.url.toString());
/*     */     }
/*     */     catch (IOException e) {
/* 122 */       SoundExceptionHandler.handleIOException(e, this.url.toString());
/*     */     }
/*     */     catch (UnsupportedAudioFileException e) {
/* 125 */       SoundExceptionHandler.handleUnsupportedAudioFileException(e, this.url.toString());
/*     */     }
/*     */     catch (LineUnavailableException e)
/*     */     {
/* 129 */       SoundExceptionHandler.handleLineUnavailableException(e);
/*     */     }
/* 131 */     return false;
/*     */   }
/*     */   
/*     */   private void load()
/*     */     throws UnsupportedAudioFileException, IOException, LineUnavailableException
/*     */   {
/* 137 */     this.clipData = clipCache.getCachedClip(this.url);
/* 138 */     InputStream is = new ByteArrayInputStream(this.clipData.getBuffer());
/* 139 */     AudioFormat format = this.clipData.getFormat();
/* 140 */     AudioInputStream stream = new AudioInputStream(is, format, this.clipData.getLength());
/* 141 */     DataLine.Info info = new DataLine.Info(Clip.class, format);
/*     */     
/*     */ 
/* 144 */     this.soundClip = ((Clip)AudioSystem.getLine(info));
/* 145 */     this.soundClip.open(stream);
/*     */     
/*     */ 
/*     */ 
/* 149 */     setVolume(this.masterVolume);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void preLoad()
/*     */   {
/*     */     try
/*     */     {
/* 160 */       this.clipData = clipCache.getCachedClip(this.url);
/* 161 */       clipCache.releaseClipData(this.clipData);
/*     */     }
/*     */     catch (IOException e) {}catch (UnsupportedAudioFileException e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void play()
/*     */   {
/* 177 */     if (this.clipState == ClipState.PLAYING) {
/* 178 */       return;
/*     */     }
/* 180 */     this.resumedLoop = false;
/* 181 */     if (this.soundClip == null)
/*     */     {
/* 183 */       processThread.addToQueue(this);
/* 184 */       this.currentState = ClipState.STOPPED;
/*     */     }
/* 186 */     else if (this.currentState == ClipState.STOPPED) {
/* 187 */       if (this.resetToStart) {
/* 188 */         this.resetToStart = false;
/* 189 */         this.soundClip.setFramePosition(0);
/*     */       }
/* 191 */       this.soundClip.loop(0);
/* 192 */       this.soundClip.start();
/*     */     } else {
/* 194 */       if (this.currentState == ClipState.STOPPING)
/*     */       {
/*     */ 
/* 197 */         setState(ClipState.PLAYING);
/*     */         
/* 199 */         return;
/*     */       }
/* 201 */       if (this.currentState == ClipState.LOOPING)
/* 202 */         this.soundClip.loop(0);
/*     */     }
/* 204 */     setState(ClipState.PLAYING);
/* 205 */     if (this.soundClip != null) {
/* 206 */       this.currentState = ClipState.PLAYING;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void loop()
/*     */   {
/* 217 */     if (this.clipState == ClipState.LOOPING) {
/* 218 */       return;
/*     */     }
/* 220 */     if (this.soundClip == null)
/*     */     {
/* 222 */       processThread.addToQueue(this);
/* 223 */       this.currentState = ClipState.STOPPED;
/*     */     }
/* 225 */     else if (this.currentState == ClipState.STOPPED) {
/* 226 */       if (this.resetToStart) {
/* 227 */         this.resetToStart = false;
/* 228 */         this.soundClip.setFramePosition(0);
/*     */       }
/* 230 */       this.soundClip.setLoopPoints(0, -1);
/* 231 */       this.soundClip.loop(-1);
/*     */     } else {
/* 233 */       if (this.currentState == ClipState.STOPPING)
/*     */       {
/*     */ 
/* 236 */         setState(ClipState.LOOPING);
/*     */         
/* 238 */         return;
/*     */       }
/* 240 */       if (this.currentState == ClipState.PLAYING) {
/* 241 */         this.soundClip.setLoopPoints(0, -1);
/* 242 */         this.soundClip.loop(-1);
/* 243 */         this.resumedLoop = true;
/*     */       } }
/* 245 */     setState(ClipState.LOOPING);
/* 246 */     if (this.soundClip != null) {
/* 247 */       this.currentState = ClipState.LOOPING;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void processState()
/*     */   {
/*     */     ClipState toState;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     Clip soundClip;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 267 */     synchronized (this) {
/* 268 */       toState = this.clipState;
/* 269 */       soundClip = this.soundClip;
/*     */       
/* 271 */       if (this.clipState == ClipState.PLAYING) {
/* 272 */         if (this.currentState != ClipState.PLAYING) {
/* 273 */           if ((soundClip == null) && (!open())) {
/* 274 */             return;
/*     */           }
/* 276 */           soundClip = this.soundClip;
/* 277 */           soundClip.start();
/* 278 */           this.currentState = ClipState.PLAYING;
/*     */         }
/* 280 */         return;
/*     */       }
/* 282 */       if (this.clipState == ClipState.LOOPING) {
/* 283 */         if (this.currentState != ClipState.LOOPING) {
/* 284 */           if ((soundClip == null) && (!open())) {
/* 285 */             return;
/*     */           }
/* 287 */           soundClip = this.soundClip;
/* 288 */           soundClip.setFramePosition(0);
/* 289 */           soundClip.setLoopPoints(0, -1);
/* 290 */           soundClip.loop(-1);
/* 291 */           this.resumedLoop = false;
/* 292 */           this.currentState = ClipState.LOOPING;
/*     */         }
/* 294 */         return;
/*     */       }
/* 296 */       if (this.clipState == ClipState.CLOSED) {
/* 297 */         return;
/*     */       }
/* 299 */       if ((isPaused()) || (this.clipState == ClipState.STOPPED)) {
/* 300 */         if ((this.currentState == ClipState.PLAYING) || (this.currentState == ClipState.LOOPING)) {
/* 301 */           this.currentState = ClipState.STOPPING;
/* 302 */           this.resumedLoop = false;
/*     */         }
/*     */         else {
/* 305 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 310 */     if ((toState == ClipState.STOPPED) || (toState == ClipState.PAUSED_LOOPING) || (toState == ClipState.PAUSED_PLAYING))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 318 */       soundClip.stop();
/*     */       
/* 320 */       synchronized (this) {
/* 321 */         if (this.resetToStart) {
/* 322 */           this.resetToStart = false;
/* 323 */           soundClip.setFramePosition(0);
/*     */         }
/*     */         
/* 326 */         this.currentState = ClipState.STOPPED;
/*     */         
/*     */ 
/*     */ 
/* 330 */         if (this.clipState == ClipState.PLAYING) {
/* 331 */           soundClip.loop(0);
/* 332 */           soundClip.start();
/* 333 */           this.currentState = ClipState.PLAYING;
/*     */         }
/* 335 */         else if (this.clipState == ClipState.LOOPING) {
/* 336 */           soundClip.setLoopPoints(0, -1);
/* 337 */           soundClip.loop(-1);
/* 338 */           this.currentState = ClipState.LOOPING;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setVolume(int level)
/*     */   {
/* 351 */     this.masterVolume = level;
/* 352 */     if ((this.soundClip != null) && 
/* 353 */       (this.soundClip.isControlSupported(FloatControl.Type.MASTER_GAIN))) {
/* 354 */       FloatControl volume = (FloatControl)this.soundClip.getControl(FloatControl.Type.MASTER_GAIN);
/* 355 */       volume.setValue(SoundUtils.convertMinMax(level, volume.getMinimum(), volume.getMaximum()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized int getVolume()
/*     */   {
/* 367 */     return this.masterVolume;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void stop()
/*     */   {
/* 376 */     if (isStopped()) {
/* 377 */       return;
/*     */     }
/* 379 */     setState(ClipState.STOPPED);
/* 380 */     if (this.soundClip != null) {
/* 381 */       if (this.currentState == ClipState.STOPPED)
/*     */       {
/* 383 */         closerThread.addClip(this.soundClip);
/* 384 */         this.soundClip = null;
/*     */       }
/*     */       else {
/* 387 */         this.resetToStart = true;
/* 388 */         processThread.addToQueue(this);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void close()
/*     */   {
/* 400 */     if (this.clipState != ClipState.CLOSED) {
/* 401 */       if (this.soundClip != null) {
/* 402 */         setVolume(0);
/* 403 */         clipCache.releaseClipData(this.clipData);
/* 404 */         closerThread.addClip(this.soundClip);
/* 405 */         this.soundClip = null;
/*     */       }
/* 407 */       setState(ClipState.CLOSED);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void pause()
/*     */   {
/* 417 */     this.resumedLoop = false;
/* 418 */     if (this.soundClip == null) {
/* 419 */       return;
/*     */     }
/* 421 */     if (this.clipState == ClipState.PLAYING) {
/* 422 */       setState(ClipState.PAUSED_PLAYING);
/* 423 */       processThread.addToQueue(this);
/*     */     }
/* 425 */     if (this.clipState == ClipState.LOOPING) {
/* 426 */       setState(ClipState.PAUSED_LOOPING);
/* 427 */       processThread.addToQueue(this);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setState(ClipState newState)
/*     */   {
/* 433 */     if (this.clipState != newState) {
/* 434 */       this.clipState = newState;
/* 435 */       switch (this.clipState) {
/*     */       case PLAYING: 
/* 437 */         this.playbackListener.playbackStarted(this);
/* 438 */         break;
/*     */       case STOPPED: 
/* 440 */         this.playbackListener.playbackStopped(this);
/* 441 */         break;
/*     */       case PAUSED_LOOPING: 
/* 443 */         this.playbackListener.playbackPaused(this);
/* 444 */         break;
/*     */       case PAUSED_PLAYING: 
/* 446 */         this.playbackListener.playbackPaused(this);
/* 447 */         break;
/*     */       case LOOPING: 
/* 449 */         this.playbackListener.playbackStarted(this);
/* 450 */         break;
/*     */       case CLOSED: 
/* 452 */         this.playbackListener.soundClosed(this);
/*     */       }
/*     */       
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean isPlaying()
/*     */   {
/* 463 */     return (this.clipState == ClipState.PLAYING) || (this.clipState == ClipState.LOOPING);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean isPaused()
/*     */   {
/* 472 */     return (this.clipState == ClipState.PAUSED_PLAYING) || (this.clipState == ClipState.PAUSED_LOOPING);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean isStopped()
/*     */   {
/* 481 */     return (this.clipState == ClipState.STOPPED) || (this.clipState == ClipState.CLOSED);
/*     */   }
/*     */   
/*     */ 
/*     */   public void update(LineEvent event)
/*     */   {
/* 487 */     if (event.getType() == LineEvent.Type.STOP) {
/* 488 */       synchronized (this) {
/* 489 */         if (this.currentState != ClipState.STOPPING)
/*     */         {
/*     */ 
/*     */ 
/* 493 */           this.currentState = ClipState.STOPPED;
/* 494 */           if ((this.resumedLoop) && (this.clipState == ClipState.LOOPING))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 505 */             closerThread.addClip(this.soundClip);
/* 506 */             this.soundClip = null;
/*     */             
/* 508 */             processThread.addToQueue(this);
/*     */           }
/* 510 */           else if (!isPaused()) {
/* 511 */             setState(ClipState.STOPPED);
/*     */             
/*     */ 
/* 514 */             if ((this.clipState == ClipState.STOPPED) && (this.soundClip != null))
/*     */             {
/* 516 */               closerThread.addClip(this.soundClip);
/* 517 */               this.soundClip = null;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 528 */     return this.url + " " + super.toString();
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\SoundClip.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */