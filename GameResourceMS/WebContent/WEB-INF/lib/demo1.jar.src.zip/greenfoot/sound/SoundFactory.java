/*     */ package greenfoot.sound;
/*     */ 
/*     */ import greenfoot.util.GreenfootUtil;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import javax.sound.sampled.UnsupportedAudioFileException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SoundFactory
/*     */ {
/*     */   private static SoundFactory instance;
/*     */   private SoundCollection soundCollection;
/*     */   private static final int maxClipSize = 500000;
/*     */   
/*     */   private SoundFactory()
/*     */   {
/*  57 */     this.soundCollection = new SoundCollection();
/*     */     
/*  59 */     for (String soundFile : GreenfootUtil.getSoundFiles())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */       Sound s = createSound(soundFile, true);
/*     */       
/*  67 */       if ((s instanceof SoundClip)) {
/*  68 */         ((SoundClip)s).preLoad();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static synchronized SoundFactory getInstance()
/*     */   {
/*  77 */     if (instance == null) {
/*  78 */       instance = new SoundFactory();
/*     */     }
/*  80 */     return instance;
/*     */   }
/*     */   
/*     */   public SoundCollection getSoundCollection()
/*     */   {
/*  85 */     return this.soundCollection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Sound createSound(String file, boolean quiet)
/*     */   {
/*     */     try
/*     */     {
/*  99 */       URL url = GreenfootUtil.getURL(file, "sounds");
/* 100 */       int size = url.openConnection().getContentLength();
/* 101 */       if (isMidi(url)) {
/* 102 */         return new MidiFileSound(url, this.soundCollection);
/*     */       }
/* 104 */       if ((!GreenfootUtil.isMp3LibAvailable()) && (isMp3(url)))
/*     */       {
/* 106 */         SoundExceptionHandler.handleMp3LibNotAvailable();
/*     */       } else {
/* 108 */         if (isMp3(url)) {
/* 109 */           return new SoundStream(new Mp3AudioInputStream(url), this.soundCollection);
/*     */         }
/* 111 */         if (isJavaAudioStream(size)) {
/* 112 */           return new SoundStream(new JavaAudioInputStream(url), this.soundCollection);
/*     */         }
/*     */         
/*     */ 
/* 116 */         return new SoundClip(file, url, this.soundCollection);
/*     */       }
/*     */     } catch (IOException e) {
/* 119 */       if (!quiet) {
/* 120 */         SoundExceptionHandler.handleIOException(e, file);
/*     */       }
/*     */     } catch (UnsupportedAudioFileException e) {
/* 123 */       if (!quiet) {
/* 124 */         SoundExceptionHandler.handleUnsupportedAudioFileException(e, file);
/*     */       }
/*     */     }
/* 127 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean isJavaAudioStream(int size)
/*     */   {
/* 134 */     return (size == -1) || (size > 500000);
/*     */   }
/*     */   
/*     */   private boolean isMidi(URL url)
/*     */   {
/* 139 */     String lowerCaseName = url.toString().toLowerCase();
/* 140 */     return (lowerCaseName.endsWith("mid")) || (lowerCaseName.endsWith("midi"));
/*     */   }
/*     */   
/*     */   private boolean isMp3(URL url)
/*     */   {
/* 145 */     String lowerCaseName = url.toString().toLowerCase();
/* 146 */     return lowerCaseName.endsWith("mp3");
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\SoundFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */