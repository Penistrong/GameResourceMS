/*     */ package greenfoot.sound;
/*     */ 
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.FloatControl;
/*     */ import javax.sound.sampled.FloatControl.Type;
/*     */ import javax.sound.sampled.LineUnavailableException;
/*     */ import javax.sound.sampled.SourceDataLine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AudioLine
/*     */ {
/*     */   private static final int EXTRA_SLEEP_DELAY = 50;
/*     */   private volatile SourceDataLine line;
/*     */   private AudioFormat format;
/*     */   private long totalWritten;
/*     */   private boolean open;
/*     */   private boolean started;
/*     */   private int masterVolume;
/*     */   private boolean writing;
/*     */   private boolean reset;
/*     */   private TimeTracker timeTracker;
/*     */   
/*     */   private static void printDebug(String s) {}
/*     */   
/*     */   public AudioLine(SourceDataLine line, AudioFormat format)
/*     */   {
/* 145 */     this.line = line;
/* 146 */     this.format = format;
/* 147 */     this.timeTracker = new TimeTracker();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void open()
/*     */     throws LineUnavailableException, IllegalArgumentException, IllegalStateException, SecurityException
/*     */   {
/* 163 */     if (!this.open) {
/* 164 */       this.line.open(this.format);
/* 165 */       this.open = true;
/* 166 */       this.reset = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void close()
/*     */   {
/* 175 */     if (this.open) {
/* 176 */       this.open = false;
/* 177 */       reset();
/* 178 */       this.line.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void start()
/*     */   {
/* 189 */     if ((!this.started) && (this.open)) {
/* 190 */       this.line.start();
/* 191 */       this.started = true;
/* 192 */       if (getTimeLeft() > 0L)
/*     */       {
/*     */ 
/* 195 */         this.timeTracker.start();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void stop()
/*     */   {
/* 206 */     if (this.open)
/*     */     {
/* 208 */       notifyAll();
/* 209 */       this.started = false;
/* 210 */       this.line.stop();
/* 211 */       this.timeTracker.pause();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void reset()
/*     */   {
/* 222 */     printDebug("reset() start");
/*     */     
/* 224 */     if (this.open) {
/* 225 */       if (this.started) {
/* 226 */         this.line.stop();
/*     */       }
/* 228 */       if (!this.reset) {
/* 229 */         this.line.flush();
/*     */       }
/* 231 */       this.totalWritten = 0L;
/*     */       
/* 233 */       this.started = false;
/* 234 */       this.timeTracker.reset();
/* 235 */       notifyAll();
/*     */     }
/* 237 */     this.reset = true;
/* 238 */     printDebug("reset() end");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int write(byte[] b, int off, int len)
/*     */   {
/* 251 */     synchronized (this) {
/* 252 */       if (!this.open) {
/* 253 */         return 0;
/*     */       }
/*     */       
/* 256 */       this.writing = true;
/* 257 */       this.started = true;
/* 258 */       this.reset = false;
/* 259 */       this.timeTracker.start();
/*     */     }
/* 261 */     this.line.start();
/* 262 */     int written = this.line.write(b, off, len);
/* 263 */     synchronized (this)
/*     */     {
/* 265 */       notifyAll();
/* 266 */       this.writing = false;
/* 267 */       if (!this.reset) {
/* 268 */         this.totalWritten += written;
/*     */       }
/* 270 */       else if ((this.reset) && (this.open))
/*     */       {
/* 272 */         this.line.flush();
/*     */       }
/* 274 */       return written;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean drain()
/*     */   {
/* 288 */     printDebug("Draining start");
/* 289 */     printDebug(" totalWritten: " + this.totalWritten);
/* 290 */     long timeLeft = getTimeLeft();
/* 291 */     while ((timeLeft > 0L) && (this.open)) {
/* 292 */       printDebug(" timeLeft: " + timeLeft);
/* 293 */       if ((this.started) && (timeLeft > 0L)) {
/*     */         try {
/* 295 */           wait(timeLeft);
/*     */ 
/*     */         }
/*     */         catch (InterruptedException e) {}
/*     */       }
/* 300 */       else if ((!this.started) || (this.writing))
/*     */       {
/*     */         try
/*     */         {
/* 304 */           wait();
/*     */         }
/*     */         catch (InterruptedException e) {}
/*     */       }
/*     */       
/* 309 */       timeLeft = getTimeLeft();
/*     */     }
/*     */     
/* 312 */     printDebug("Draining end: " + timeLeft);
/* 313 */     if (timeLeft > 0L) {
/* 314 */       return false;
/*     */     }
/*     */     
/* 317 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized boolean isOpen()
/*     */   {
/* 323 */     return this.open;
/*     */   }
/*     */   
/*     */   private synchronized long getTimeLeft()
/*     */   {
/* 328 */     return SoundUtils.getTimeToPlayBytes(this.totalWritten, this.format) - this.timeTracker.getTimeTracked() + 50L;
/*     */   }
/*     */   
/*     */   public long getLongFramePosition()
/*     */   {
/* 333 */     return this.line.getLongFramePosition();
/*     */   }
/*     */   
/*     */   public synchronized void setVolume(int masterVolume)
/*     */   {
/* 338 */     this.masterVolume = masterVolume;
/*     */     try {
/* 340 */       open();
/* 341 */       if ((this.line != null) && 
/* 342 */         (this.line.isControlSupported(FloatControl.Type.MASTER_GAIN))) {
/* 343 */         FloatControl volume = (FloatControl)this.line.getControl(FloatControl.Type.MASTER_GAIN);
/* 344 */         float val = SoundUtils.convertMinMax(masterVolume, volume.getMinimum(), volume.getMaximum());
/* 345 */         volume.setValue(val);
/*     */       }
/*     */     }
/*     */     catch (LineUnavailableException ex)
/*     */     {
/* 350 */       SoundExceptionHandler.handleLineUnavailableException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized int getVolume()
/*     */   {
/* 356 */     return this.masterVolume;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\AudioLine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */