/*     */ package greenfoot.sound;
/*     */ 
/*     */ import bluej.utility.Debug;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.UnsupportedAudioFileException;
/*     */ import javazoom.jl.decoder.Bitstream;
/*     */ import javazoom.jl.decoder.BitstreamException;
/*     */ import javazoom.jl.decoder.Decoder;
/*     */ import javazoom.jl.decoder.DecoderException;
/*     */ import javazoom.jl.decoder.Header;
/*     */ import javazoom.jl.decoder.SampleBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Mp3AudioInputStream
/*     */   implements GreenfootAudioInputStream
/*     */ {
/*     */   private Bitstream bitstream;
/*     */   private Decoder decoder;
/*     */   private URL url;
/*  53 */   private boolean readingHasStarted = false;
/*     */   private BufferedInputStream inputStream;
/*     */   private AudioFormat format;
/*     */   private SampleBuffer unreadSample;
/*     */   private boolean open;
/*     */   
/*     */   private static void printDebug(String s) {}
/*     */   
/*     */   public Mp3AudioInputStream(URL url)
/*     */     throws IOException, UnsupportedAudioFileException
/*     */   {
/*  64 */     this.url = url;
/*  65 */     open();
/*     */     
/*     */ 
/*  68 */     Header header = null;
/*     */     try {
/*  70 */       header = this.bitstream.readFrame();
/*  71 */       this.bitstream.unreadFrame();
/*     */     } catch (BitstreamException e) {
/*  73 */       throw new IOException(e.toString());
/*     */     }
/*  75 */     if (header == null) {
/*  76 */       this.bitstream.closeFrame();
/*  77 */       this.format = new AudioFormat(this.decoder.getOutputFrequency(), 16, this.decoder.getOutputChannels(), true, false);
/*     */     }
/*     */     else {
/*  80 */       int mode = header.mode();
/*  81 */       int channels = mode == 3 ? 1 : 2;
/*  82 */       this.format = new AudioFormat(header.frequency(), 16, channels, true, false);
/*     */     }
/*     */     
/*  85 */     printDebug(" Created mp3 stream with audioFormat: " + this.format);
/*     */   }
/*     */   
/*     */   public String getSource()
/*     */   {
/*  90 */     return this.url.toString();
/*     */   }
/*     */   
/*     */   public void open()
/*     */     throws IOException, UnsupportedAudioFileException
/*     */   {
/*  96 */     if (!this.open) {
/*  97 */       this.readingHasStarted = false;
/*  98 */       this.unreadSample = null;
/*     */       
/* 100 */       if (this.bitstream != null) {
/*     */         try {
/* 102 */           this.bitstream.close();
/*     */         }
/*     */         catch (BitstreamException e)
/*     */         {
/* 106 */           Debug.reportError("Exception while closing mp3 audio input stream.", e);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 111 */       this.inputStream = new BufferedInputStream(this.url.openStream());
/* 112 */       this.bitstream = new Bitstream(this.inputStream);
/*     */       
/* 114 */       this.decoder = new Decoder();
/* 115 */       this.open = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public void restart() throws IOException, UnsupportedAudioFileException
/*     */   {
/* 121 */     if ((!this.open) || (readingHasStarted()) || (this.bitstream == null)) {
/* 122 */       this.open = false;
/* 123 */       open();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean readingHasStarted()
/*     */   {
/* 135 */     return this.readingHasStarted;
/*     */   }
/*     */   
/*     */   public int available() throws IOException
/*     */   {
/* 140 */     return this.inputStream.available();
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/* 145 */     this.open = false;
/*     */     try {
/* 147 */       this.bitstream.close();
/*     */     } catch (BitstreamException e) {
/* 149 */       throw new IOException(e.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   public AudioFormat getFormat()
/*     */   {
/* 155 */     return this.format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void mark(int readlimit) {}
/*     */   
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 165 */     return false;
/*     */   }
/*     */   
/*     */   public int read() throws IOException
/*     */   {
/* 170 */     byte[] b = new byte[1];
/*     */     
/* 172 */     int bytesRead = read(b, 0, 1);
/* 173 */     if (bytesRead < 0) {
/* 174 */       return -1;
/*     */     }
/* 176 */     if (bytesRead == 0) {
/* 177 */       throw new IOException("cannot read a single byte if frame size > 1");
/*     */     }
/* 179 */     return b[0] & 0xFF;
/*     */   }
/*     */   
/*     */   public int read(byte[] b)
/*     */     throws IOException
/*     */   {
/* 185 */     return read(b, 0, b.length);
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 191 */     if (off < 0) {
/* 192 */       throw new IllegalArgumentException("The offset must be positive. It was: " + off);
/*     */     }
/* 194 */     if (len < 0) {
/* 195 */       throw new IllegalArgumentException("The length must be positive. It was: " + len);
/*     */     }
/* 197 */     if (off + len > b.length) {
/* 198 */       throw new IllegalArgumentException("Lenght + offset must not be bigger than the array length.");
/*     */     }
/* 200 */     this.readingHasStarted = true;
/*     */     
/* 202 */     printDebug("read() called with params: off:" + off + "  len:" + len);
/*     */     
/* 204 */     Header header = null;
/*     */     
/* 206 */     int read = 0;
/* 207 */     if (this.unreadSample != null) {
/* 208 */       int sampleLength = this.unreadSample.getBufferLength();
/* 209 */       int sampleLengthInBytes = sampleLength * 2;
/* 210 */       if (sampleLengthInBytes > len) {
/* 211 */         printDebug("unreadSample too big. ");
/* 212 */         return 0;
/*     */       }
/* 214 */       toByteArray(this.unreadSample.getBuffer(), sampleLength, b, off);
/* 215 */       printDebug("UNREAD SAMPLE just read.");
/* 216 */       read += sampleLengthInBytes;
/* 217 */       this.unreadSample = null;
/* 218 */       this.bitstream.closeFrame();
/*     */     }
/*     */     try {
/* 221 */       header = this.bitstream.readFrame();
/*     */     } catch (BitstreamException e) {
/* 223 */       throw new IOException(e.toString());
/*     */     }
/* 225 */     while (header != null)
/*     */     {
/*     */ 
/* 228 */       SampleBuffer sample = null;
/*     */       try {
/* 230 */         sample = (SampleBuffer)this.decoder.decodeFrame(header, this.bitstream);
/*     */       } catch (DecoderException e) {
/* 232 */         throw new IOException(e.toString());
/*     */       }
/*     */       
/* 235 */       printDebug("Read: " + read);
/* 236 */       int sampleLength = sample.getBufferLength();
/* 237 */       int sampleLengthInBytes = sampleLength * 2;
/* 238 */       printDebug("Buffer length: " + sampleLength);
/* 239 */       if (read + sampleLengthInBytes > len) {
/* 240 */         this.unreadSample = sample;
/* 241 */         printDebug(" saving unreadSample for later.");
/* 242 */         break;
/*     */       }
/* 244 */       toByteArray(sample.getBuffer(), sampleLength, b, off + read);
/* 245 */       printDebug("Just read bytes: " + sampleLengthInBytes);
/* 246 */       read += sampleLengthInBytes;
/* 247 */       this.bitstream.closeFrame();
/*     */       try {
/* 249 */         header = this.bitstream.readFrame();
/*     */       } catch (BitstreamException e) {
/* 251 */         throw new IOException(e.toString());
/*     */       }
/*     */     }
/*     */     
/* 255 */     return read;
/*     */   }
/*     */   
/*     */   private final void toByteArray(short[] samples, int len, byte[] b, int off)
/*     */   {
/* 260 */     int shortIndex = 0;
/*     */     
/* 262 */     while (len-- > 0) {
/* 263 */       short s = samples[(shortIndex++)];
/* 264 */       b[(off++)] = ((byte)s);
/* 265 */       b[(off++)] = ((byte)(s >>> 8));
/*     */     }
/*     */   }
/*     */   
/*     */   public void reset() throws IOException
/*     */   {
/* 271 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public long skip(long n) throws IOException
/*     */   {
/* 276 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\Mp3AudioInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */