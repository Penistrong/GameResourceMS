/*     */ package greenfoot.sound;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import javax.sound.midi.InvalidMidiDataException;
/*     */ import javax.sound.midi.MetaEventListener;
/*     */ import javax.sound.midi.MetaMessage;
/*     */ import javax.sound.midi.MidiSystem;
/*     */ import javax.sound.midi.MidiUnavailableException;
/*     */ import javax.sound.midi.Receiver;
/*     */ import javax.sound.midi.Sequence;
/*     */ import javax.sound.midi.Sequencer;
/*     */ import javax.sound.midi.ShortMessage;
/*     */ import javax.sound.midi.Synthesizer;
/*     */ import javax.sound.midi.Transmitter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MidiFileSound
/*     */   implements Sound
/*     */ {
/*     */   private URL url;
/*     */   private SoundPlaybackListener playbackListener;
/*     */   private Sequencer sequencer;
/*     */   private Synthesizer synthesizer;
/*     */   private Sequence sequence;
/*  59 */   private boolean pause = false;
/*     */   private int level;
/*     */   private Receiver receiver;
/*     */   
/*     */   private void printDebug(String s) {}
/*     */   
/*  65 */   public MidiFileSound(URL url, SoundPlaybackListener listener) { this.url = url;
/*  66 */     this.playbackListener = listener;
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/*  72 */       this.sequence = MidiSystem.getSequence(url);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */       this.sequencer = MidiSystem.getSequencer(false);
/*     */       
/*  81 */       this.synthesizer = MidiSystem.getSynthesizer();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */       this.sequencer.addMetaEventListener(new MetaEventListener()
/*     */       {
/*     */ 
/*     */         public void meta(MetaMessage event)
/*     */         {
/*  98 */           if (event.getType() == 47) {
/*  99 */             MidiFileSound.this.close();
/*     */           }
/*     */         }
/*     */       });
/*     */     }
/*     */     catch (InvalidMidiDataException e)
/*     */     {
/* 106 */       SoundExceptionHandler.handleInvalidMidiDataException(e, url.toString());
/*     */     }
/*     */     catch (IOException e) {
/* 109 */       SoundExceptionHandler.handleIOException(e, url.toString());
/*     */     }
/*     */     catch (MidiUnavailableException e) {
/* 112 */       SoundExceptionHandler.handleLineUnavailableException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void play()
/*     */   {
/* 119 */     this.sequencer.setLoopCount(0);
/*     */     
/* 121 */     if (!isPlaying()) {
/* 122 */       startPlayback();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private synchronized void startPlayback()
/*     */   {
/*     */     try
/*     */     {
/* 132 */       this.pause = false;
/* 133 */       open();
/* 134 */       this.sequencer.setSequence(this.sequence);
/* 135 */       if (this.sequencer.isOpen()) {
/* 136 */         this.sequencer.start();
/* 137 */         this.playbackListener.playbackStarted(this);
/*     */       }
/*     */     }
/*     */     catch (SecurityException e) {
/* 141 */       SoundExceptionHandler.handleSecurityException(e, this.url.toString());
/*     */     }
/*     */     catch (InvalidMidiDataException e) {
/* 144 */       SoundExceptionHandler.handleInvalidMidiDataException(e, this.url.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   private synchronized void open()
/*     */   {
/*     */     try {
/* 151 */       if (!this.sequencer.isOpen()) {
/* 152 */         this.receiver = MidiSystem.getReceiver();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 158 */         this.synthesizer.open();
/* 159 */         this.sequencer.open();
/* 160 */         Transmitter seqTransmitter = this.sequencer.getTransmitter();
/* 161 */         seqTransmitter.setReceiver(this.receiver);
/*     */       }
/*     */     }
/*     */     catch (MidiUnavailableException e) {
/* 165 */       SoundExceptionHandler.handleLineUnavailableException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void loop()
/*     */   {
/* 172 */     this.sequencer.setLoopStartPoint(0L);
/* 173 */     this.sequencer.setLoopEndPoint(-1L);
/* 174 */     this.sequencer.setLoopCount(-1);
/* 175 */     startPlayback();
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void pause()
/*     */   {
/* 181 */     this.pause = true;
/* 182 */     this.sequencer.stop();
/* 183 */     this.playbackListener.playbackPaused(this);
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void stop()
/*     */   {
/* 189 */     this.pause = false;
/* 190 */     close();
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void close()
/*     */   {
/* 196 */     this.playbackListener.playbackStopped(this);
/* 197 */     this.pause = false;
/* 198 */     printDebug(" playback ended: " + this.url);
/* 199 */     if (this.sequencer != null) {
/* 200 */       this.sequencer.close();
/*     */     }
/* 202 */     if (this.synthesizer != null) {
/* 203 */       this.synthesizer.close();
/*     */     }
/* 205 */     this.playbackListener.soundClosed(this);
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized boolean isPaused()
/*     */   {
/* 211 */     return this.pause;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized boolean isPlaying()
/*     */   {
/* 217 */     return this.sequencer.isRunning();
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized boolean isStopped()
/*     */   {
/* 223 */     return (!isPaused()) && (!isPlaying());
/*     */   }
/*     */   
/*     */ 
/*     */   public void setVolume(int level)
/*     */   {
/* 229 */     open();
/* 230 */     this.level = level;
/* 231 */     ShortMessage volMessage = new ShortMessage();
/* 232 */     for (int i = 0; i < 16; i++) {
/*     */       try {
/* 234 */         volMessage.setMessage(176, i, 7, level);
/*     */       }
/*     */       catch (InvalidMidiDataException e) {
/* 237 */         e.printStackTrace();
/*     */       }
/* 239 */       this.receiver.send(volMessage, -1L);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int getVolume()
/*     */   {
/* 246 */     return this.level;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\MidiFileSound.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */