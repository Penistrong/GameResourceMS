package greenfoot.sound;

public abstract interface SoundPlaybackListener
{
  public abstract void playbackStarted(Sound paramSound);
  
  public abstract void playbackPaused(Sound paramSound);
  
  public abstract void playbackStopped(Sound paramSound);
  
  public abstract void soundClosed(Sound paramSound);
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\SoundPlaybackListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */