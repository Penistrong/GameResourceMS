/*     */ package greenfoot.sound;
/*     */ 
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SoundUtils
/*     */ {
/*     */   public static float convertMinMax(int val, float min, float max)
/*     */   {
/*  40 */     float range = max - min;
/*  41 */     float newVal = val / (100.0F / range);
/*  42 */     return newVal + min;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int logToLin(int level)
/*     */   {
/*  52 */     return (int)(Math.log(level) / Math.log(100.0D) * 100.0D);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long getTimeToPlayBytes(long bytes, AudioFormat format)
/*     */   {
/*  64 */     return getTimeToPlayFrames(bytes / format.getFrameSize(), format);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long getTimeToPlayFrames(long frames, AudioFormat format)
/*     */   {
/*  76 */     if (format.getFrameRate() != -1.0F) {
/*  77 */       return ((float)(1000L * frames) / format.getFrameRate());
/*     */     }
/*     */     
/*  80 */     return -1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static int getBufferSizeToHold(AudioFormat format, double seconds)
/*     */   {
/*     */     int bufferSize;
/*     */     
/*     */ 
/*     */     int bufferSize;
/*     */     
/*     */ 
/*  93 */     if (format.getFrameRate() != -1.0F) {
/*  94 */       bufferSize = (int)Math.ceil(format.getFrameSize() * format.getFrameRate() * seconds);
/*     */     } else { int bufferSize;
/*  96 */       if (format.getSampleRate() != -1.0F) {
/*  97 */         bufferSize = (int)Math.ceil(format.getSampleSizeInBits() / 8 * format.getChannels() * format.getSampleRate() * seconds);
/*     */       }
/*     */       else
/*     */       {
/* 101 */         bufferSize = -1; }
/*     */     }
/* 103 */     return bufferSize;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\SoundUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */