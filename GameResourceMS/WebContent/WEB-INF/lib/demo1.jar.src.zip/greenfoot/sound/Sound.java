package greenfoot.sound;

public abstract interface Sound
{
  public abstract void close();
  
  public abstract void stop();
  
  public abstract void pause();
  
  public abstract void play();
  
  public abstract void loop();
  
  public abstract boolean isPlaying();
  
  public abstract boolean isPaused();
  
  public abstract boolean isStopped();
  
  public abstract void setVolume(int paramInt);
  
  public abstract int getVolume();
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\Sound.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */