/*     */ package greenfoot.sound;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioSystem;
/*     */ import javax.sound.sampled.DataLine.Info;
/*     */ import javax.sound.sampled.LineUnavailableException;
/*     */ import javax.sound.sampled.TargetDataLine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MicLevelGrabber
/*     */ {
/*  36 */   private static final MicLevelGrabber INSTANCE = new MicLevelGrabber();
/*     */   
/*     */   private final AudioFormat format;
/*     */   
/*     */   private int level;
/*     */   
/*     */   private final Runnable updator;
/*     */   private volatile boolean running;
/*     */   private boolean reportedFailure;
/*     */   
/*     */   private MicLevelGrabber()
/*     */   {
/*  48 */     this.format = new AudioFormat(22050.0F, 8, 1, true, true);
/*  49 */     this.updator = new Runnable()
/*     */     {
/*     */       public void run() {
/*     */         try {
/*  53 */           TargetDataLine line = (TargetDataLine)AudioSystem.getLine(new DataLine.Info(TargetDataLine.class, MicLevelGrabber.this.format));
/*  54 */           line.open();
/*  55 */           line.start();
/*  56 */           int bufferSize = (int)(MicLevelGrabber.this.format.getSampleRate() / 20.0F) * MicLevelGrabber.this.format.getFrameSize();
/*  57 */           byte[] buffer = new byte[bufferSize];
/*  58 */           int bytesRead = line.read(buffer, 0, bufferSize);
/*  59 */           line.stop();
/*  60 */           MicLevelGrabber.this.level = ((int)(MicLevelGrabber.getRMS(buffer, bytesRead) / 127.0D * 100.0D));
/*  61 */           MicLevelGrabber.this.reportedFailure = false;
/*     */         }
/*     */         catch (LineUnavailableException ex) {
/*  64 */           if (!MicLevelGrabber.this.reportedFailure) {
/*  65 */             System.err.println("Couldn't get mic level: line unavailable");
/*  66 */             MicLevelGrabber.this.reportedFailure = true;
/*     */           }
/*     */         }
/*     */         catch (IllegalArgumentException iae) {
/*  70 */           if (!MicLevelGrabber.this.reportedFailure) {
/*  71 */             System.err.println("Couldn't get mic level: can't match 22050,8,1 audio format");
/*  72 */             MicLevelGrabber.this.reportedFailure = true;
/*     */           }
/*     */         }
/*     */         finally {
/*  76 */           MicLevelGrabber.this.running = false;
/*     */         }
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MicLevelGrabber getInstance()
/*     */   {
/*  88 */     return INSTANCE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLevel()
/*     */   {
/* 101 */     updateLevel();
/* 102 */     return this.level;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void updateLevel()
/*     */   {
/* 111 */     if (!this.running) {
/* 112 */       this.running = true;
/* 113 */       new Thread(this.updator).start();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static double getRMS(byte[] arr, int lim)
/*     */   {
/* 125 */     double average = 0.0D;
/* 126 */     for (int i = 0; (i < arr.length) && (i < lim); i++) {
/* 127 */       average += arr[i] * arr[i];
/*     */     }
/* 129 */     average /= arr.length;
/* 130 */     return Math.sqrt(average);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\MicLevelGrabber.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */