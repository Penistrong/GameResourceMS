package greenfoot.sound;

import java.io.Closeable;
import java.io.IOException;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.UnsupportedAudioFileException;

public abstract interface GreenfootAudioInputStream
  extends Closeable
{
  public abstract void open()
    throws IOException, UnsupportedAudioFileException;
  
  public abstract void restart()
    throws IOException, UnsupportedAudioFileException;
  
  public abstract String getSource();
  
  public abstract AudioFormat getFormat();
  
  public abstract int read()
    throws IOException;
  
  public abstract int read(byte[] paramArrayOfByte)
    throws IOException;
  
  public abstract int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;
  
  public abstract long skip(long paramLong)
    throws IOException;
  
  public abstract int available()
    throws IOException;
  
  public abstract void close()
    throws IOException;
  
  public abstract void mark(int paramInt);
  
  public abstract void reset()
    throws IOException;
  
  public abstract boolean markSupported();
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\GreenfootAudioInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */