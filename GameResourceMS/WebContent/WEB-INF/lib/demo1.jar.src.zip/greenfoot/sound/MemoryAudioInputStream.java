/*     */ package greenfoot.sound;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.UnsupportedAudioFileException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemoryAudioInputStream
/*     */   implements GreenfootAudioInputStream
/*     */ {
/*     */   private byte[] sound;
/*     */   private int startOffset;
/*     */   private int endOffset;
/*     */   private AudioFormat format;
/*     */   private int markIndex;
/*     */   private int curIndex;
/*     */   
/*     */   public MemoryAudioInputStream(byte[] sound, AudioFormat format)
/*     */   {
/*  45 */     this.curIndex = 0;
/*  46 */     this.markIndex = 0;
/*  47 */     this.startOffset = 0;
/*  48 */     this.endOffset = sound.length;
/*  49 */     this.sound = sound;
/*  50 */     this.format = format;
/*     */   }
/*     */   
/*     */   public MemoryAudioInputStream(byte[] sound, int offset, int length, AudioFormat format)
/*     */   {
/*  55 */     this.curIndex = offset;
/*  56 */     this.markIndex = this.curIndex;
/*  57 */     this.startOffset = offset;
/*  58 */     this.endOffset = (offset + length);
/*  59 */     this.sound = sound;
/*  60 */     this.format = format;
/*     */   }
/*     */   
/*     */   private int getFrameSize()
/*     */   {
/*  65 */     return this.format.getFrameSize();
/*     */   }
/*     */   
/*     */   public int available() throws IOException
/*     */   {
/*  70 */     return this.endOffset - this.curIndex;
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */   public AudioFormat getFormat()
/*     */   {
/*  79 */     return this.format;
/*     */   }
/*     */   
/*     */   public String getSource()
/*     */   {
/*  84 */     return "Internal buffer";
/*     */   }
/*     */   
/*     */   public void mark(int readlimit)
/*     */   {
/*  89 */     this.markIndex = this.curIndex;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/*  95 */     return true;
/*     */   }
/*     */   
/*     */   public void open() throws IOException, UnsupportedAudioFileException
/*     */   {
/* 100 */     this.curIndex = this.startOffset;
/*     */   }
/*     */   
/*     */   public int read() throws IOException
/*     */   {
/* 105 */     if (getFrameSize() != 1) {
/* 106 */       throw new IOException("Attempted to read single byte but frame size is not 1");
/*     */     }
/* 108 */     if (this.curIndex < this.endOffset) {
/* 109 */       return this.sound[(this.curIndex++)];
/*     */     }
/* 111 */     return -1;
/*     */   }
/*     */   
/*     */   public int read(byte[] b) throws IOException
/*     */   {
/* 116 */     return read(b, 0, b.length);
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException
/*     */   {
/* 121 */     if (this.curIndex >= this.endOffset) {
/* 122 */       return -1;
/*     */     }
/* 124 */     int maxRead = len - len % getFrameSize();
/*     */     
/* 126 */     if (this.curIndex + maxRead > this.endOffset) {
/* 127 */       int left = this.endOffset - this.curIndex;
/* 128 */       maxRead = left - left % getFrameSize();
/*     */     }
/*     */     
/* 131 */     System.arraycopy(this.sound, this.curIndex, b, off, maxRead);
/* 132 */     this.curIndex += maxRead;
/*     */     
/* 134 */     return maxRead;
/*     */   }
/*     */   
/*     */   public void reset() throws IOException
/*     */   {
/* 139 */     this.curIndex = this.markIndex;
/*     */   }
/*     */   
/*     */   public void restart() throws IOException, UnsupportedAudioFileException
/*     */   {
/* 144 */     this.curIndex = this.startOffset;
/*     */   }
/*     */   
/*     */   public long skip(long n) throws IOException
/*     */   {
/* 149 */     if (this.curIndex + n <= this.endOffset) {
/* 150 */       this.curIndex = ((int)(this.curIndex + n));
/* 151 */       return n;
/*     */     }
/* 153 */     int diff = this.endOffset - this.curIndex;
/* 154 */     this.curIndex = this.endOffset;
/* 155 */     return diff;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\MemoryAudioInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */