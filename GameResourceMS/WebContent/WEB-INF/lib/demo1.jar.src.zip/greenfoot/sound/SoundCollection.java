/*     */ package greenfoot.sound;
/*     */ 
/*     */ import greenfoot.event.SimulationEvent;
/*     */ import greenfoot.event.SimulationListener;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SoundCollection
/*     */   implements SimulationListener, SoundPlaybackListener
/*     */ {
/*  39 */   private Set<Sound> playingSounds = new HashSet();
/*     */   
/*     */ 
/*  42 */   private Set<Sound> pausedSounds = new HashSet();
/*     */   
/*     */ 
/*  45 */   private Set<Sound> stoppedSounds = new HashSet();
/*     */   
/*  47 */   private volatile boolean ignoreEvents = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void simulationChanged(SimulationEvent e)
/*     */   {
/*  54 */     if (e.getType() == 3) {
/*  55 */       close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void close()
/*     */   {
/*  65 */     synchronized (this) {
/*  66 */       this.ignoreEvents = true;
/*     */     }
/*     */     
/*  69 */     Iterator<Sound> iter = this.playingSounds.iterator();
/*  70 */     while (iter.hasNext()) {
/*  71 */       Sound sound = (Sound)iter.next();
/*  72 */       sound.close();
/*     */     }
/*     */     
/*  75 */     iter = this.pausedSounds.iterator();
/*  76 */     while (iter.hasNext()) {
/*  77 */       Sound sound = (Sound)iter.next();
/*  78 */       sound.close();
/*     */     }
/*     */     
/*     */ 
/*  82 */     iter = this.stoppedSounds.iterator();
/*  83 */     while (iter.hasNext()) {
/*  84 */       Sound sound = (Sound)iter.next();
/*  85 */       sound.close();
/*     */     }
/*     */     
/*  88 */     this.playingSounds.clear();
/*  89 */     this.pausedSounds.clear();
/*  90 */     this.stoppedSounds.clear();
/*     */     
/*  92 */     synchronized (this) {
/*  93 */       this.ignoreEvents = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void playbackStarted(Sound sound)
/*     */   {
/* 101 */     if (!this.ignoreEvents) {
/* 102 */       this.playingSounds.add(sound);
/* 103 */       this.pausedSounds.remove(sound);
/* 104 */       this.stoppedSounds.remove(sound);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void playbackStopped(Sound sound)
/*     */   {
/* 110 */     if (!this.ignoreEvents) {
/* 111 */       this.playingSounds.remove(sound);
/* 112 */       this.pausedSounds.remove(sound);
/* 113 */       this.stoppedSounds.add(sound);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void playbackPaused(Sound sound)
/*     */   {
/* 119 */     if (!this.ignoreEvents) {
/* 120 */       this.pausedSounds.add(sound);
/* 121 */       this.playingSounds.remove(sound);
/* 122 */       this.stoppedSounds.remove(sound);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void soundClosed(Sound sound)
/*     */   {
/* 128 */     if (!this.ignoreEvents) {
/* 129 */       this.pausedSounds.remove(sound);
/* 130 */       this.playingSounds.remove(sound);
/* 131 */       this.stoppedSounds.remove(sound);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\SoundCollection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */