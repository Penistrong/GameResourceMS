/*     */ package greenfoot.sound;
/*     */ 
/*     */ import bluej.Config;
/*     */ import greenfoot.core.WorldHandler;
/*     */ import greenfoot.util.GreenfootUtil;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import javax.sound.midi.InvalidMidiDataException;
/*     */ import javax.sound.sampled.UnsupportedAudioFileException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SoundExceptionHandler
/*     */ {
/*     */   private static volatile boolean lineUnavailableHandled;
/*     */   private static volatile boolean illegalArgumentHandled;
/*     */   private static volatile boolean securityHandled;
/*     */   private static boolean mp3LibHandled;
/*     */   
/*     */   public static void handleUnsupportedAudioFileException(UnsupportedAudioFileException e, String filename)
/*     */   {
/*  56 */     throw new IllegalArgumentException("Format of sound file not supported: " + filename, e);
/*     */   }
/*     */   
/*     */   public static void handleFileNotFoundException(FileNotFoundException e, String filename)
/*     */   {
/*  61 */     throw new IllegalArgumentException("Could not find sound file: " + filename, e);
/*     */   }
/*     */   
/*     */   public static void handleIOException(IOException e, String filename)
/*     */   {
/*  66 */     throw new IllegalArgumentException("Could not open sound file: " + filename, e);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void handleLineUnavailableException(Exception e)
/*     */   {
/*  72 */     if (!lineUnavailableHandled) {
/*  73 */       lineUnavailableHandled = true;
/*  74 */       String errMsg = Config.getString("sound-line-unavailable");
/*  75 */       GreenfootUtil.displayMessage(WorldHandler.getInstance().getWorldCanvas(), errMsg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static void handleIllegalArgumentException(IllegalArgumentException e, String filename)
/*     */   {
/*  82 */     if (!illegalArgumentHandled) {
/*  83 */       illegalArgumentHandled = true;
/*  84 */       System.err.println("Could not play sound file: " + filename);
/*  85 */       System.err.println("If you have a sound card installed, check your system settings.");
/*  86 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static void handleSecurityException(SecurityException e, String filename)
/*     */   {
/*  93 */     if (!securityHandled) {
/*  94 */       securityHandled = true;
/*  95 */       System.err.println("Could not play sound file due to security restrictions: " + filename);
/*  96 */       System.err.println("If you have a sound card installed, check your system settings.");
/*  97 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void handleInvalidMidiDataException(InvalidMidiDataException e, String filename)
/*     */   {
/* 103 */     throw new IllegalArgumentException("Invalid data in MIDI file: " + filename, e);
/*     */   }
/*     */   
/*     */   public static void handleMp3LibNotAvailable()
/*     */   {
/* 108 */     if (!mp3LibHandled) {
/* 109 */       mp3LibHandled = true;
/* 110 */       System.err.println("MP3 library not available. You will not be able to play any mp3 audio files. This is most likely happening because you are using a non-standard Greenfoot installation. To get the standard version, go to http://www.greenfoot.org");
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\SoundExceptionHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */