/*    */ package greenfoot.sound;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClipProcessThread
/*    */   implements Runnable
/*    */ {
/*    */   private Thread thread;
/* 36 */   private LinkedList<SoundClip> queue = new LinkedList();
/*    */   
/*    */   public ClipProcessThread()
/*    */   {
/* 40 */     this.thread = new Thread(this);
/* 41 */     this.thread.setDaemon(true);
/* 42 */     this.thread.start();
/*    */   }
/*    */   
/*    */   public void addToQueue(SoundClip clip)
/*    */   {
/* 47 */     synchronized (this.queue) {
/* 48 */       this.queue.add(clip);
/* 49 */       this.queue.notify();
/*    */       
/*    */ 
/*    */ 
/* 53 */       if (!this.thread.isAlive()) {
/* 54 */         this.thread = new Thread(this);
/* 55 */         this.thread.setDaemon(true);
/* 56 */         this.thread.start();
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void run()
/*    */   {
/*    */     try
/*    */     {
/*    */       for (;;) {
/*    */         SoundClip item;
/* 67 */         synchronized (this.queue) {
/* 68 */           if (this.queue.isEmpty()) {
/* 69 */             this.queue.wait(); continue;
/*    */           }
/* 71 */           item = (SoundClip)this.queue.removeFirst();
/*    */         }
/*    */         
/* 74 */         item.processState();
/*    */       }
/*    */     }
/*    */     catch (InterruptedException ie) {}
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\ClipProcessThread.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */