/*    */ package greenfoot.sound;
/*    */ 
/*    */ import javax.sound.sampled.AudioFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClipData
/*    */ {
/*    */   private String url;
/*    */   private byte[] buffer;
/*    */   private AudioFormat format;
/*    */   private int activeUsers;
/*    */   private int length;
/*    */   
/*    */   public ClipData(String url, byte[] buffer, AudioFormat format, int length)
/*    */   {
/* 44 */     this.url = url;
/* 45 */     this.buffer = buffer;
/* 46 */     this.format = format;
/* 47 */     this.length = length;
/* 48 */     this.activeUsers = 1;
/*    */   }
/*    */   
/*    */   public void addUser()
/*    */   {
/* 53 */     this.activeUsers += 1;
/*    */   }
/*    */   
/*    */   public boolean release()
/*    */   {
/* 58 */     return --this.activeUsers == 0;
/*    */   }
/*    */   
/*    */   public String getUrl()
/*    */   {
/* 63 */     return this.url;
/*    */   }
/*    */   
/*    */   public byte[] getBuffer()
/*    */   {
/* 68 */     return this.buffer;
/*    */   }
/*    */   
/*    */   public AudioFormat getFormat()
/*    */   {
/* 73 */     return this.format;
/*    */   }
/*    */   
/*    */   public int getLength()
/*    */   {
/* 78 */     return this.length;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\ClipData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */