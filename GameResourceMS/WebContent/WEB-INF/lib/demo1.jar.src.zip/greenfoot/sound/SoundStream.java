/*     */ package greenfoot.sound;
/*     */ 
/*     */ import bluej.utility.Debug;
/*     */ import java.io.IOException;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioSystem;
/*     */ import javax.sound.sampled.DataLine.Info;
/*     */ import javax.sound.sampled.LineUnavailableException;
/*     */ import javax.sound.sampled.SourceDataLine;
/*     */ import javax.sound.sampled.UnsupportedAudioFileException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SoundStream
/*     */   implements Sound, Runnable
/*     */ {
/*     */   private static final int CLOSE_TIMEOUT = 1000;
/*  62 */   private boolean loop = false;
/*     */   
/*     */ 
/*     */ 
/*  66 */   private boolean stop = true;
/*     */   
/*     */ 
/*     */ 
/*  70 */   private boolean pause = false;
/*     */   
/*  72 */   private boolean restart = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */   private boolean stopped = true;
/*     */   
/*     */   private final GreenfootAudioInputStream inputStream;
/*     */   
/*     */   private final SoundPlaybackListener playbackListener;
/*     */   
/*     */   private volatile AudioLine line;
/*     */   
/*     */   private AudioFormat format;
/*     */   
/*     */   private DataLine.Info info;
/*     */   private Thread playThread;
/*     */   
/*     */   private static void printDebug(String s) {}
/*     */   
/*     */   public SoundStream(GreenfootAudioInputStream inputStream, SoundPlaybackListener playbackListener)
/*     */   {
/*  95 */     this.playbackListener = playbackListener;
/*  96 */     this.inputStream = inputStream;
/*     */     
/*     */     try
/*     */     {
/* 100 */       this.format = inputStream.getFormat();
/* 101 */       this.info = new DataLine.Info(SourceDataLine.class, this.format);
/* 102 */       this.line = initialiseLine(this.info, this.format);
/*     */     }
/*     */     catch (IllegalArgumentException e)
/*     */     {
/* 106 */       SoundExceptionHandler.handleIllegalArgumentException(e, inputStream.getSource());
/*     */     }
/*     */     catch (LineUnavailableException e) {
/* 109 */       SoundExceptionHandler.handleLineUnavailableException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void play()
/*     */   {
/* 116 */     if (isPlaying())
/*     */     {
/* 118 */       this.loop = false;
/*     */     }
/*     */     else
/*     */     {
/* 122 */       startPlayback();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void loop()
/*     */   {
/* 130 */     this.loop = true;
/* 131 */     if (!isPlaying())
/*     */     {
/* 133 */       startPlayback();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void startPlayback()
/*     */   {
/* 143 */     if (!this.pause) {
/* 144 */       this.restart = true;
/* 145 */       if (this.playThread == null) {
/* 146 */         printDebug("Starting new playthread");
/* 147 */         this.playThread = new Thread(this, "SoundStream:" + this.inputStream.getSource());
/* 148 */         this.playThread.start();
/*     */       }
/* 150 */       if (this.line != null) {
/* 151 */         this.line.reset();
/*     */       }
/*     */     }
/* 154 */     this.stopped = false;
/* 155 */     this.pause = false;
/* 156 */     this.stop = false;
/* 157 */     if (this.line != null) {
/* 158 */       this.line.start();
/*     */     }
/* 160 */     notifyAll();
/* 161 */     this.playbackListener.playbackStarted(this);
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void close()
/*     */   {
/* 167 */     if (this.line != null) {
/* 168 */       reset();
/* 169 */       this.line.close();
/* 170 */       notifyAll();
/* 171 */       this.playbackListener.playbackStopped(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void stop()
/*     */   {
/* 178 */     if (!this.stop) {
/* 179 */       this.stop = true;
/* 180 */       this.stopped = true;
/* 181 */       this.pause = false;
/* 182 */       this.line.reset();
/* 183 */       notifyAll();
/* 184 */       this.playbackListener.playbackStopped(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void pause()
/*     */   {
/* 191 */     if ((!this.stopped) && (!this.pause)) {
/* 192 */       this.line.stop();
/* 193 */       this.pause = true;
/* 194 */       notifyAll();
/* 195 */       this.playbackListener.playbackPaused(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized boolean isPlaying()
/*     */   {
/* 202 */     return (!this.stopped) && (!this.pause);
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized boolean isStopped()
/*     */   {
/* 208 */     return (this.stopped) && (!this.pause);
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized boolean isPaused()
/*     */   {
/* 214 */     return this.pause;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 220 */     return this.inputStream.getSource() + " " + super.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/* 227 */     boolean stayAlive = true;
/*     */     try
/*     */     {
/* 230 */       while (stayAlive) {
/* 231 */         this.inputStream.restart();
/* 232 */         synchronized (this) {
/* 233 */           if ((this.line == null) || (!this.format.matches(this.inputStream.getFormat())))
/*     */           {
/*     */ 
/* 236 */             this.format = this.inputStream.getFormat();
/* 237 */             this.info = new DataLine.Info(SourceDataLine.class, this.format);
/* 238 */             this.line = initialiseLine(this.info, this.format);
/*     */           }
/* 240 */           this.line.open();
/* 241 */           this.restart = false;
/*     */         }
/*     */         
/* 244 */         int frameSize = this.format.getFrameSize();
/* 245 */         int bufferSize = SoundUtils.getBufferSizeToHold(this.format, 0.5D);
/* 246 */         if (bufferSize == -1) {
/* 247 */           bufferSize = 65536;
/*     */         }
/*     */         
/* 250 */         byte[] buffer = new byte[bufferSize];
/*     */         
/* 252 */         printDebug("Stream available (in bytes): " + this.inputStream.available() + " in frames: " + this.inputStream.available() / frameSize);
/*     */         
/*     */ 
/* 255 */         int bytesRead = this.inputStream.read(buffer, 0, bufferSize);
/* 256 */         int bytesInBuffer = bytesRead;
/* 257 */         printDebug(" read: " + bytesRead);
/* 258 */         while (bytesInBuffer > 0)
/*     */         {
/* 260 */           int bytesToWrite = bytesInBuffer / frameSize * frameSize;
/*     */           
/* 262 */           synchronized (this)
/*     */           {
/* 264 */             if (this.stop) {
/*     */               break;
/*     */             }
/*     */             
/*     */ 
/* 269 */             if (this.pause) {
/* 270 */               doPause();
/*     */             }
/*     */             
/*     */ 
/* 274 */             if (this.restart) {
/* 275 */               printDebug("restart in thread");
/* 276 */               this.line.reset();
/* 277 */               this.inputStream.restart();
/* 278 */               this.restart = false;
/* 279 */               bytesInBuffer = 0;
/* 280 */               bytesRead = 0;
/* 281 */               bytesToWrite = 0;
/* 282 */               printDebug("inputStream available after restart in thread: " + this.inputStream.available());
/*     */             }
/*     */           }
/*     */           
/* 286 */           int written = this.line.write(buffer, 0, bytesToWrite);
/*     */           
/* 288 */           printDebug(" wrote: " + written);
/*     */           
/*     */ 
/*     */ 
/* 292 */           int remaining = bytesInBuffer - written;
/* 293 */           if (remaining > 0) {
/* 294 */             printDebug("remaining: " + remaining + "  written: " + written + "   bytesInBuffer: " + bytesInBuffer + "   bytesToWrite: " + bytesToWrite);
/*     */             
/* 296 */             System.arraycopy(buffer, written, buffer, 0, remaining);
/*     */           }
/* 298 */           bytesInBuffer = remaining;
/*     */           
/* 300 */           printDebug("remaining: " + remaining + "  written: " + written + "   bytesInBuffer: " + bytesInBuffer + "   bytesToWrite: " + bytesToWrite);
/*     */           
/* 302 */           bytesRead = this.inputStream.read(buffer, bytesInBuffer, buffer.length - bytesInBuffer);
/* 303 */           if (bytesRead != -1) {
/* 304 */             bytesInBuffer += bytesRead;
/*     */           }
/* 306 */           printDebug(" read: " + bytesRead);
/*     */         }
/*     */         
/* 309 */         this.line.drain();
/*     */         
/* 311 */         synchronized (this)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 324 */           if ((!this.loop) || (this.stop)) {
/* 325 */             this.line.reset();
/*     */           }
/*     */           
/* 328 */           if (((!this.restart) && (!this.loop)) || (this.stop)) {
/* 329 */             this.stopped = true;
/* 330 */             this.playbackListener.playbackStopped(this);
/*     */             
/*     */ 
/*     */             try
/*     */             {
/* 335 */               if (this.line.isOpen()) {
/* 336 */                 printDebug("WAIT");
/* 337 */                 wait(1000L);
/*     */               }
/*     */             }
/*     */             catch (InterruptedException e) {}
/*     */             
/*     */ 
/*     */ 
/* 344 */             if (((!this.restart) && (!this.loop)) || (this.stop)) {
/* 345 */               this.line.close();
/* 346 */               stayAlive = false;
/* 347 */               reset();
/* 348 */               printDebug("KILL THREAD");
/*     */             }
/*     */           }
/*     */           
/* 352 */           printDebug(" 2 restart =  " + this.restart + "  stop = " + this.stop);
/*     */           
/*     */ 
/*     */ 
/* 356 */           if (this.restart) {
/* 357 */             this.restart = false;
/*     */           }
/*     */           
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (IllegalArgumentException e)
/*     */     {
/* 365 */       SoundExceptionHandler.handleIllegalArgumentException(e, this.inputStream.getSource());
/*     */     }
/*     */     catch (UnsupportedAudioFileException e) {
/* 368 */       SoundExceptionHandler.handleUnsupportedAudioFileException(e, this.inputStream.getSource());
/*     */     }
/*     */     catch (LineUnavailableException e) {
/* 371 */       SoundExceptionHandler.handleLineUnavailableException(e);
/*     */     }
/*     */     catch (IOException e) {
/* 374 */       SoundExceptionHandler.handleIOException(e, this.inputStream.getSource());
/*     */     }
/*     */     finally {
/* 377 */       if (stayAlive == true)
/*     */       {
/* 379 */         reset();
/*     */       }
/* 381 */       if (this.line != null) {
/* 382 */         this.line.close();
/*     */       }
/* 384 */       if (this.inputStream != null) {
/*     */         try {
/* 386 */           this.inputStream.close();
/*     */         }
/*     */         catch (IOException e) {
/* 389 */           e.printStackTrace();
/*     */         }
/*     */       }
/* 392 */       this.playbackListener.soundClosed(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void doPause()
/*     */   {
/* 401 */     if (this.pause) {
/* 402 */       while (this.pause) {
/*     */         try {
/* 404 */           printDebug("In pause loop");
/* 405 */           this.line.stop();
/* 406 */           printDebug("In pause loop 2");
/* 407 */           wait();
/*     */         }
/*     */         catch (InterruptedException e) {
/* 410 */           Debug.reportError("Interrupted while pausing sound: " + this.inputStream.getSource(), e);
/*     */         }
/*     */       }
/*     */       
/* 414 */       this.line.start();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private AudioLine initialiseLine(DataLine.Info info, AudioFormat format)
/*     */     throws LineUnavailableException, IllegalArgumentException
/*     */   {
/* 436 */     SourceDataLine l = (SourceDataLine)AudioSystem.getLine(info);
/* 437 */     printDebug("buffer size: " + l.getBufferSize());
/* 438 */     return new AudioLine(l, format);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void reset()
/*     */   {
/* 446 */     this.stopped = true;
/* 447 */     this.pause = false;
/* 448 */     this.loop = false;
/* 449 */     this.stop = true;
/* 450 */     this.playThread = null;
/*     */   }
/*     */   
/*     */   public long getLongFramePosition()
/*     */   {
/* 455 */     return this.line.getLongFramePosition();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setVolume(int level)
/*     */   {
/* 461 */     this.line.setVolume(SoundUtils.logToLin(level));
/*     */   }
/*     */   
/*     */ 
/*     */   public int getVolume()
/*     */   {
/* 467 */     return this.line.getVolume();
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\SoundStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */