/*     */ package greenfoot.sound;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ import javax.sound.sampled.AudioSystem;
/*     */ import javax.sound.sampled.UnsupportedAudioFileException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClipCache
/*     */ {
/*  44 */   private LinkedHashMap<String, ClipData> freeClips = new LinkedHashMap();
/*  45 */   private int numberFreeClips = 0;
/*     */   
/*  47 */   private static int MAX_CACHED_CLIPS = 20;
/*     */   
/*     */ 
/*  50 */   private Map<String, ClipData> cachedClips = new HashMap();
/*     */   
/*     */   public synchronized ClipData getCachedClip(URL url)
/*     */     throws IOException, UnsupportedAudioFileException
/*     */   {
/*  55 */     String urlStr = url.toString();
/*  56 */     ClipData data = (ClipData)this.cachedClips.get(urlStr);
/*  57 */     if (data == null)
/*     */     {
/*  59 */       data = (ClipData)this.freeClips.remove(urlStr);
/*  60 */       if (data != null) {
/*  61 */         this.numberFreeClips -= 1;
/*  62 */         this.cachedClips.put(urlStr, data);
/*     */       }
/*     */     }
/*  65 */     if (data == null)
/*     */     {
/*  67 */       AudioInputStream ais = AudioSystem.getAudioInputStream(url);
/*  68 */       AudioFormat af = ais.getFormat();
/*  69 */       long frameLength = ais.getFrameLength();
/*     */       
/*  71 */       int total = (int)(af.getFrameSize() * frameLength);
/*  72 */       byte[] allBytes = new byte[(int)(af.getFrameSize() * frameLength)];
/*  73 */       int pos = 0;
/*     */       try
/*     */       {
/*  76 */         while (pos < total) {
/*  77 */           int r = ais.read(allBytes, pos, total - pos);
/*  78 */           if (r == -1) {
/*     */             break;
/*     */           }
/*  81 */           pos += r;
/*     */         }
/*     */       }
/*     */       finally {
/*  85 */         ais.close();
/*     */       }
/*     */       
/*  88 */       data = new ClipData(urlStr, allBytes, af, (int)frameLength);
/*     */     }
/*     */     else {
/*  91 */       data.addUser();
/*     */     }
/*     */     
/*  94 */     return data;
/*     */   }
/*     */   
/*     */   public synchronized void releaseClipData(ClipData data)
/*     */   {
/*  99 */     if (data.release()) {
/* 100 */       this.cachedClips.remove(data.getUrl());
/* 101 */       this.freeClips.put(data.getUrl(), data);
/* 102 */       this.numberFreeClips += 1;
/* 103 */       if (this.numberFreeClips > MAX_CACHED_CLIPS)
/*     */       {
/* 105 */         Iterator<ClipData> it = this.freeClips.values().iterator();
/* 106 */         it.next();
/* 107 */         it.remove();
/* 108 */         this.numberFreeClips = MAX_CACHED_CLIPS;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\ClipCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */