/*     */ package greenfoot.sound;
/*     */ 
/*     */ import bluej.utility.Debug;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ArrayBlockingQueue;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import javax.sound.sampled.AudioFileFormat.Type;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ import javax.sound.sampled.AudioSystem;
/*     */ import javax.sound.sampled.DataLine.Info;
/*     */ import javax.sound.sampled.LineUnavailableException;
/*     */ import javax.sound.sampled.TargetDataLine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SoundRecorder
/*     */ {
/*     */   private AudioFormat format;
/*  53 */   private AtomicBoolean keepRecording = new AtomicBoolean();
/*     */   private TargetDataLine line;
/*  55 */   private BlockingQueue<byte[]> recordedResultQueue = new ArrayBlockingQueue(1);
/*     */   private byte[] recorded;
/*     */   
/*     */   public SoundRecorder()
/*     */   {
/*  60 */     this.format = new AudioFormat(22050.0F, 8, 1, true, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AtomicReference<List<byte[]>> startRecording()
/*     */   {
/*     */     try
/*     */     {
/*  84 */       this.line = ((TargetDataLine)AudioSystem.getLine(new DataLine.Info(TargetDataLine.class, this.format)));
/*  85 */       this.line.open();
/*  86 */       if (!this.line.getFormat().equals(this.format))
/*  87 */         Debug.message("Format is not as expected" + this.line.getFormat().toString());
/*  88 */       this.line.start();
/*     */       
/*  90 */       this.keepRecording.set(true);
/*     */       
/*  92 */       final AtomicReference<List<byte[]>> partialResult = new AtomicReference(null);
/*     */       
/*  94 */       Runnable rec = new Runnable()
/*     */       {
/*     */ 
/*     */         public void run()
/*     */         {
/*  99 */           int bufferSize = (int)(SoundRecorder.this.format.getSampleRate() / 2.0F) * SoundRecorder.this.format.getFrameSize();
/* 100 */           LinkedList<byte[]> frames = new LinkedList();
/*     */           
/* 102 */           while (SoundRecorder.this.keepRecording.get()) {
/* 103 */             byte[] buffer = new byte[bufferSize];
/*     */             
/* 105 */             int bytesRead = SoundRecorder.this.line.read(buffer, 0, bufferSize);
/*     */             
/* 107 */             if (bytesRead != bufferSize) {
/* 108 */               SoundRecorder.this.keepRecording.set(false);
/*     */             } else {
/* 110 */               frames.addLast(buffer);
/* 111 */               partialResult.set(new LinkedList(frames));
/*     */             }
/*     */           }
/*     */           
/* 115 */           partialResult.set(null);
/*     */           
/* 117 */           SoundRecorder.this.line.stop();
/*     */           
/* 119 */           boolean done = false;
/* 120 */           while (!done) {
/*     */             try {
/* 122 */               SoundRecorder.this.recordedResultQueue.put(SoundRecorder.merge(frames));
/* 123 */               done = true;
/*     */ 
/*     */             }
/*     */             catch (InterruptedException e) {}
/*     */           }
/*     */           
/*     */         }
/* 130 */       };
/* 131 */       new Thread(rec).start();
/*     */       
/* 133 */       return partialResult;
/*     */     }
/*     */     catch (LineUnavailableException e) {
/* 136 */       Debug.reportError("Problem capturing sound", e); }
/* 137 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stopRecording()
/*     */   {
/* 147 */     this.keepRecording.set(false);
/* 148 */     this.recorded = null;
/* 149 */     while (this.recorded == null) {
/*     */       try {
/* 151 */         this.recorded = ((byte[])this.recordedResultQueue.take());
/*     */       }
/*     */       catch (InterruptedException e) {}
/*     */     }
/*     */     
/* 156 */     this.line.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeWAV(File destination)
/*     */   {
/* 164 */     ByteArrayInputStream baiStream = new ByteArrayInputStream(this.recorded);
/* 165 */     AudioInputStream aiStream = new AudioInputStream(baiStream, this.format, this.recorded.length);
/*     */     try {
/* 167 */       AudioSystem.write(aiStream, AudioFileFormat.Type.WAVE, destination);
/* 168 */       aiStream.close();
/* 169 */       baiStream.close();
/*     */     }
/*     */     catch (IOException e) {
/* 172 */       Debug.reportError("Problem writing recorded sound to WAV file", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static byte[] merge(List<byte[]> frames)
/*     */   {
/* 183 */     int totalLength = 0;
/* 184 */     for (byte[] frame : frames) {
/* 185 */       totalLength += frame.length;
/*     */     }
/*     */     
/* 188 */     byte[] result = new byte[totalLength];
/* 189 */     int curOffset = 0;
/* 190 */     for (byte[] frame : frames) {
/* 191 */       System.arraycopy(frame, 0, result, curOffset, frame.length);
/* 192 */       curOffset += frame.length;
/*     */     }
/* 194 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getRawSound()
/*     */   {
/* 204 */     return this.recorded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void trim(float begin, float end)
/*     */   {
/* 214 */     if (this.recorded != null)
/*     */     {
/* 216 */       float length = this.recorded.length;
/* 217 */       int beginIndex = (int)(begin * length);
/* 218 */       int endIndex = (int)(end * length);
/*     */       
/* 220 */       this.recorded = Arrays.copyOfRange(this.recorded, beginIndex, endIndex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AudioFormat getFormat()
/*     */   {
/* 229 */     return this.format;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\SoundRecorder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */