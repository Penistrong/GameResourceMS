/*    */ package greenfoot.sound;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimeTracker
/*    */ {
/*    */   private long startTime;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private boolean tracking;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private long timeElapsed;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void start()
/*    */   {
/* 35 */     if (this.tracking) {
/* 36 */       return;
/*    */     }
/* 38 */     this.startTime = System.currentTimeMillis();
/* 39 */     this.tracking = true;
/*    */   }
/*    */   
/*    */   public void pause()
/*    */   {
/* 44 */     if (!this.tracking) {
/* 45 */       return;
/*    */     }
/* 47 */     long timeSincestart = getTimeSinceStart();
/* 48 */     this.timeElapsed += timeSincestart;
/* 49 */     this.tracking = false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void reset()
/*    */   {
/* 57 */     this.startTime = 0L;
/* 58 */     this.tracking = false;
/* 59 */     this.timeElapsed = 0L;
/*    */   }
/*    */   
/*    */   private long getTimeSinceStart()
/*    */   {
/* 64 */     if (this.tracking) {
/* 65 */       return System.currentTimeMillis() - this.startTime;
/*    */     }
/*    */     
/* 68 */     return 0L;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public long getTimeTracked()
/*    */   {
/* 77 */     return this.timeElapsed + getTimeSinceStart();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setTimeTracked(long newTime)
/*    */   {
/* 86 */     if (this.tracking) {
/* 87 */       this.startTime = (System.currentTimeMillis() - newTime);
/* 88 */       this.timeElapsed = 0L;
/*    */     } else {
/* 90 */       this.timeElapsed = newTime;
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\TimeTracker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */