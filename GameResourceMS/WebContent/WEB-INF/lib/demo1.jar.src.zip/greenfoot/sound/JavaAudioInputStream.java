/*     */ package greenfoot.sound;
/*     */ 
/*     */ import bluej.utility.Debug;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ import javax.sound.sampled.AudioSystem;
/*     */ import javax.sound.sampled.UnsupportedAudioFileException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaAudioInputStream
/*     */   implements GreenfootAudioInputStream
/*     */ {
/*     */   private AudioInputStream stream;
/*     */   private URL url;
/*  44 */   private boolean readingHasStarted = false;
/*     */   private boolean open;
/*     */   
/*     */   public JavaAudioInputStream(URL url)
/*     */     throws UnsupportedAudioFileException, IOException
/*     */   {
/*  50 */     this.url = url;
/*  51 */     open();
/*     */   }
/*     */   
/*     */   public void open() throws UnsupportedAudioFileException, IOException
/*     */   {
/*  56 */     if (!this.open) {
/*  57 */       this.readingHasStarted = false;
/*     */       
/*  59 */       if (this.stream != null) {
/*     */         try {
/*  61 */           this.stream.close();
/*     */         }
/*     */         catch (IOException e) {
/*  64 */           Debug.reportError("Exception while closing java audio input stream.", e);
/*     */         }
/*     */       }
/*  67 */       this.stream = AudioSystem.getAudioInputStream(this.url);
/*  68 */       this.open = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public void restart() throws UnsupportedAudioFileException, IOException
/*     */   {
/*  74 */     if ((!this.open) || (readingHasStarted()) || (this.stream == null)) {
/*  75 */       this.open = false;
/*  76 */       open();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean readingHasStarted()
/*     */   {
/*  88 */     return this.readingHasStarted;
/*     */   }
/*     */   
/*     */   public String getSource()
/*     */   {
/*  93 */     return this.url.toString();
/*     */   }
/*     */   
/*     */   public int available() throws IOException
/*     */   {
/*  98 */     return this.stream.available();
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/* 103 */     this.open = false;
/* 104 */     this.stream.close();
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 109 */     if (obj == null) {
/* 110 */       return false;
/*     */     }
/* 112 */     if (!(obj instanceof JavaAudioInputStream)) {
/* 113 */       return false;
/*     */     }
/* 115 */     return this.stream.equals(((JavaAudioInputStream)obj).stream);
/*     */   }
/*     */   
/*     */   public AudioFormat getFormat()
/*     */   {
/* 120 */     return this.stream.getFormat();
/*     */   }
/*     */   
/*     */   public long getFrameLength()
/*     */   {
/* 125 */     return this.stream.getFrameLength();
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 130 */     return this.stream.hashCode();
/*     */   }
/*     */   
/*     */   public void mark(int readlimit)
/*     */   {
/* 135 */     this.stream.mark(readlimit);
/*     */   }
/*     */   
/*     */   public boolean markSupported()
/*     */   {
/* 140 */     return this.stream.markSupported();
/*     */   }
/*     */   
/*     */   public int read() throws IOException
/*     */   {
/* 145 */     this.readingHasStarted = true;
/* 146 */     return this.stream.read();
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException
/*     */   {
/* 151 */     this.readingHasStarted = true;
/* 152 */     return this.stream.read(b, off, len);
/*     */   }
/*     */   
/*     */   public int read(byte[] b) throws IOException
/*     */   {
/* 157 */     this.readingHasStarted = true;
/* 158 */     return this.stream.read(b);
/*     */   }
/*     */   
/*     */   public void reset() throws IOException
/*     */   {
/* 163 */     this.stream.reset();
/*     */   }
/*     */   
/*     */   public long skip(long n) throws IOException
/*     */   {
/* 168 */     this.readingHasStarted = true;
/* 169 */     return this.stream.skip(n);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 174 */     return this.stream.toString();
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\sound\JavaAudioInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */