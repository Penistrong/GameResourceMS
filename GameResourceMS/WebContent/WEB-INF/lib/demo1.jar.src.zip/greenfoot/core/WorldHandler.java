/*      */ package greenfoot.core;
/*      */ 
/*      */ import bluej.debugmgr.objectbench.ObjectBenchInterface;
/*      */ import greenfoot.Actor;
/*      */ import greenfoot.ActorVisitor;
/*      */ import greenfoot.World;
/*      */ import greenfoot.WorldVisitor;
/*      */ import greenfoot.event.SimulationEvent;
/*      */ import greenfoot.event.SimulationListener;
/*      */ import greenfoot.event.TriggeredKeyListener;
/*      */ import greenfoot.event.TriggeredMouseListener;
/*      */ import greenfoot.event.TriggeredMouseMotionListener;
/*      */ import greenfoot.event.WorldEvent;
/*      */ import greenfoot.event.WorldListener;
/*      */ import greenfoot.gui.DragListener;
/*      */ import greenfoot.gui.DropTarget;
/*      */ import greenfoot.gui.WorldCanvas;
/*      */ import greenfoot.gui.input.InputManager;
/*      */ import greenfoot.gui.input.KeyboardManager;
/*      */ import greenfoot.gui.input.mouse.LocationTracker;
/*      */ import greenfoot.gui.input.mouse.MousePollingManager;
/*      */ import greenfoot.gui.input.mouse.WorldLocator;
/*      */ import greenfoot.platforms.WorldHandlerDelegate;
/*      */ import greenfoot.util.GraphicsUtilities;
/*      */ import java.awt.Component;
/*      */ import java.awt.Cursor;
/*      */ import java.awt.EventQueue;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Point;
/*      */ import java.awt.Window;
/*      */ import java.awt.event.KeyEvent;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.event.EventListenerList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WorldHandler
/*      */   implements TriggeredMouseListener, TriggeredMouseMotionListener, TriggeredKeyListener, DropTarget, DragListener, SimulationListener
/*      */ {
/*      */   private boolean worldIsSet;
/*      */   private World initialisingWorld;
/*      */   private volatile World world;
/*      */   private WorldCanvas worldCanvas;
/*      */   private int dragBeginX;
/*      */   private int dragBeginY;
/*   89 */   private boolean objectDropped = true;
/*      */   
/*      */   private KeyboardManager keyboardManager;
/*      */   private static WorldHandler instance;
/*   93 */   private EventListenerList listenerList = new EventListenerList();
/*      */   
/*      */   private WorldHandlerDelegate handlerDelegate;
/*      */   
/*      */   private MousePollingManager mousePollingManager;
/*      */   
/*      */   private InputManager inputManager;
/*      */   
/*      */   private int dragOffsetX;
/*      */   
/*      */   private int dragOffsetY;
/*      */   private Actor dragActor;
/*      */   private boolean dragActorMoved;
/*      */   private Cursor defaultCursor;
/*  107 */   private static ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
/*      */   
/*      */ 
/*      */   public static final int READ_LOCK_TIMEOUT = 500;
/*      */   
/*  112 */   private Object repaintLock = new Object();
/*  113 */   private boolean isRepaintPending = false;
/*      */   
/*      */   public static synchronized void initialise(WorldCanvas worldCanvas, WorldHandlerDelegate helper)
/*      */   {
/*  117 */     instance = new WorldHandler(worldCanvas, helper);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static synchronized void initialise()
/*      */   {
/*  125 */     instance = new WorldHandler();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static synchronized WorldHandler getInstance()
/*      */   {
/*  133 */     return instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private WorldHandler()
/*      */   {
/*  141 */     instance = this;
/*  142 */     this.mousePollingManager = new MousePollingManager(null);
/*  143 */     this.handlerDelegate = new WorldHandlerDelegate()
/*      */     {
/*      */       public void discardWorld(World world) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public InputManager getInputManager()
/*      */       {
/*  153 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void instantiateNewWorld() {}
/*      */       
/*      */ 
/*      */ 
/*      */       public boolean maybeShowPopup(MouseEvent e)
/*      */       {
/*  164 */         return false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public void mouseClicked(MouseEvent e) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public void mouseMoved(MouseEvent e) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public void setWorld(World oldWorld, World newWorld) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public void setWorldHandler(WorldHandler handler) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public void addActor(Actor actor, int x, int y) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public void actorDragged(Actor actor, int xCell, int yCell) {}
/*      */       
/*      */ 
/*      */ 
/*      */       public void objectAddedToWorld(Actor actor) {}
/*      */       
/*      */ 
/*      */ 
/*      */       public String ask(String prompt)
/*      */       {
/*  205 */         return "";
/*      */       }
/*      */     };
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private WorldHandler(WorldCanvas worldCanvas, WorldHandlerDelegate handlerDelegate)
/*      */   {
/*  218 */     instance = this;
/*  219 */     this.handlerDelegate = handlerDelegate;
/*  220 */     this.handlerDelegate.setWorldHandler(this);
/*      */     
/*  222 */     this.worldCanvas = worldCanvas;
/*      */     
/*  224 */     this.mousePollingManager = new MousePollingManager(null);
/*      */     
/*  226 */     worldCanvas.setDropTargetListener(this);
/*      */     
/*  228 */     LocationTracker.instance().setSourceComponent(worldCanvas);
/*  229 */     this.keyboardManager = new KeyboardManager();
/*  230 */     worldCanvas.addFocusListener(this.keyboardManager);
/*      */     
/*  232 */     this.inputManager = handlerDelegate.getInputManager();
/*  233 */     addWorldListener(this.inputManager);
/*  234 */     this.inputManager.setRunningListeners(getKeyboardManager(), this.mousePollingManager, this.mousePollingManager);
/*  235 */     worldCanvas.addMouseListener(this.inputManager);
/*  236 */     worldCanvas.addMouseMotionListener(this.inputManager);
/*  237 */     worldCanvas.addKeyListener(this.inputManager);
/*  238 */     this.inputManager.init();
/*      */     
/*  240 */     this.defaultCursor = worldCanvas.getCursor();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public KeyboardManager getKeyboardManager()
/*      */   {
/*  248 */     return this.keyboardManager;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public MousePollingManager getMouseManager()
/*      */   {
/*  256 */     return this.mousePollingManager;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void mouseClicked(MouseEvent e)
/*      */   {
/*  264 */     this.handlerDelegate.mouseClicked(e);
/*      */   }
/*      */   
/*      */ 
/*      */   public void mousePressed(MouseEvent e)
/*      */   {
/*  270 */     World world = this.world;
/*  271 */     boolean isPopUp = this.handlerDelegate.maybeShowPopup(e);
/*  272 */     if ((world != null) && (SwingUtilities.isLeftMouseButton(e)) && (!isPopUp)) {
/*  273 */       Actor actor = getObject(e.getX(), e.getY());
/*  274 */       if (actor != null) {
/*  275 */         Point p = e.getPoint();
/*  276 */         startDrag(actor, p, world);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void startDrag(Actor actor, Point p, World world)
/*      */   {
/*  286 */     this.dragActor = actor;
/*  287 */     this.dragActorMoved = false;
/*  288 */     this.dragBeginX = (ActorVisitor.getX(actor) * world.getCellSize() + world.getCellSize() / 2);
/*  289 */     this.dragBeginY = (ActorVisitor.getY(actor) * world.getCellSize() + world.getCellSize() / 2);
/*  290 */     this.dragOffsetX = (this.dragBeginX - p.x);
/*  291 */     this.dragOffsetY = (this.dragBeginY - p.y);
/*  292 */     this.objectDropped = false;
/*  293 */     SwingUtilities.getWindowAncestor(this.worldCanvas).toFront();
/*  294 */     this.worldCanvas.setCursor(Cursor.getPredefinedCursor(12));
/*  295 */     drag(actor, p);
/*      */   }
/*      */   
/*      */   public boolean isDragging()
/*      */   {
/*  300 */     return this.dragActor != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void mouseReleased(MouseEvent e)
/*      */   {
/*  308 */     this.handlerDelegate.maybeShowPopup(e);
/*  309 */     if (SwingUtilities.isLeftMouseButton(e)) {
/*  310 */       if ((this.dragActor != null) && (this.dragActorMoved))
/*      */       {
/*      */ 
/*      */ 
/*  314 */         Simulation.getInstance().runLater(new Runnable() {
/*  315 */           private Actor dragActor = WorldHandler.this.dragActor;
/*      */           
/*      */           public void run()
/*      */           {
/*  319 */             int ax = ActorVisitor.getX(this.dragActor);
/*  320 */             int ay = ActorVisitor.getY(this.dragActor);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  325 */             ActorVisitor.setLocationInPixels(this.dragActor, WorldHandler.this.dragBeginX, WorldHandler.this.dragBeginY);
/*  326 */             this.dragActor.setLocation(ax, ay);
/*  327 */             WorldHandler.this.handlerDelegate.actorDragged(this.dragActor, ax, ay);
/*      */           }
/*      */         });
/*      */       }
/*  331 */       this.dragActor = null;
/*  332 */       this.worldCanvas.setCursor(this.defaultCursor);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Actor getObject(int x, int y)
/*      */   {
/*  348 */     return getObject(this.world, x, y);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Actor getObject(World world, int x, int y)
/*      */   {
/*  363 */     if (world == null) {
/*  364 */       return null;
/*      */     }
/*      */     
/*  367 */     int timeout = 500;
/*      */     try {
/*  369 */       if (lock.readLock().tryLock(timeout, TimeUnit.MILLISECONDS))
/*      */       {
/*  371 */         Collection<?> objectsThere = WorldVisitor.getObjectsAtPixel(world, x, y);
/*  372 */         if (objectsThere.isEmpty()) {
/*  373 */           lock.readLock().unlock();
/*  374 */           return null;
/*      */         }
/*      */         
/*  377 */         Iterator<?> iter = objectsThere.iterator();
/*  378 */         Actor topmostActor = (Actor)iter.next();
/*  379 */         int seq = ActorVisitor.getLastPaintSeqNum(topmostActor);
/*      */         
/*  381 */         while (iter.hasNext()) {
/*  382 */           Actor actor = (Actor)iter.next();
/*  383 */           int actorSeq = ActorVisitor.getLastPaintSeqNum(actor);
/*  384 */           if (actorSeq > seq) {
/*  385 */             topmostActor = actor;
/*  386 */             seq = actorSeq;
/*      */           }
/*      */         }
/*      */         
/*  390 */         lock.readLock().unlock();
/*  391 */         return topmostActor;
/*      */       }
/*      */     }
/*      */     catch (InterruptedException ie) {}
/*      */     
/*  396 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void mouseEntered(MouseEvent e)
/*      */   {
/*  404 */     this.worldCanvas.requestFocusInWindow();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void mouseExited(MouseEvent e)
/*      */   {
/*  412 */     if (this.dragActor != null) {
/*  413 */       this.dragActorMoved = false;
/*  414 */       Simulation.getInstance().runLater(new Runnable() {
/*  415 */         private Actor dragActor = WorldHandler.this.dragActor;
/*  416 */         private int dragBeginX = WorldHandler.this.dragBeginX;
/*  417 */         private int dragBeginY = WorldHandler.this.dragBeginY;
/*      */         
/*      */         public void run()
/*      */         {
/*  421 */           ActorVisitor.setLocationInPixels(this.dragActor, this.dragBeginX, this.dragBeginY);
/*  422 */           WorldHandler.this.repaint();
/*      */         }
/*      */       });
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void repaint()
/*      */   {
/*  433 */     this.worldCanvas.repaint();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void repaintAndWait()
/*      */   {
/*  441 */     this.worldCanvas.repaint();
/*      */     
/*  443 */     boolean isWorldLocked = lock.isWriteLockedByCurrentThread();
/*      */     
/*  445 */     synchronized (this.repaintLock)
/*      */     {
/*      */ 
/*  448 */       if (isWorldLocked) {
/*  449 */         lock.writeLock().unlock();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  454 */       this.isRepaintPending = true;
/*      */       try {
/*      */         do {
/*  457 */           this.repaintLock.wait(100L);
/*  458 */         } while (this.isRepaintPending);
/*      */       }
/*      */       catch (InterruptedException ie) {
/*  461 */         throw new ActInterruptedException();
/*      */       }
/*      */       finally {
/*  464 */         this.isRepaintPending = false;
/*  465 */         if (isWorldLocked) {
/*  466 */           lock.writeLock().lock();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void repainted()
/*      */   {
/*  477 */     synchronized (this.repaintLock) {
/*  478 */       if (this.isRepaintPending) {
/*  479 */         this.isRepaintPending = false;
/*  480 */         this.repaintLock.notify();
/*      */       }
/*      */     }
/*  483 */     Simulation.getInstance().worldRepainted();
/*      */   }
/*      */   
/*      */ 
/*      */   public void keyTyped(KeyEvent e) {}
/*      */   
/*      */   public void keyPressed(KeyEvent e)
/*      */   {
/*  491 */     if ((e.getKeyCode() == 27) && 
/*  492 */       (this.dragActor != null)) {
/*  493 */       this.dragActorMoved = false;
/*  494 */       Simulation.getInstance().runLater(new Runnable() {
/*  495 */         private Actor dragActor = WorldHandler.this.dragActor;
/*  496 */         private int dragBeginX = WorldHandler.this.dragBeginX;
/*  497 */         private int dragBeginY = WorldHandler.this.dragBeginY;
/*      */         
/*      */         public void run()
/*      */         {
/*  501 */           ActorVisitor.setLocationInPixels(this.dragActor, this.dragBeginX, this.dragBeginY);
/*  502 */           WorldHandler.this.repaint();
/*      */         }
/*  504 */       });
/*  505 */       this.dragActor = null;
/*  506 */       this.worldCanvas.setCursor(this.defaultCursor);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void keyReleased(KeyEvent e)
/*      */   {
/*  515 */     this.worldCanvas.requestFocus();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ReentrantReadWriteLock getWorldLock()
/*      */   {
/*  523 */     return lock;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void instantiateNewWorld()
/*      */   {
/*  534 */     this.handlerDelegate.instantiateNewWorld();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInitialisingWorld(World world)
/*      */   {
/*  543 */     this.initialisingWorld = world;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void discardWorld()
/*      */   {
/*  551 */     if (this.world == null) return;
/*  552 */     this.handlerDelegate.discardWorld(this.world);
/*  553 */     final World discardedWorld = this.world;
/*  554 */     this.world = null;
/*      */     
/*  556 */     EventQueue.invokeLater(new Runnable() {
/*      */       public void run() {
/*  558 */         WorldHandler.this.worldCanvas.setWorld(null);
/*  559 */         WorldHandler.this.fireWorldRemovedEvent(discardedWorld);
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean checkWorldSet()
/*      */   {
/*  569 */     return this.worldIsSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void clearWorldSet()
/*      */   {
/*  577 */     this.worldIsSet = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setWorld(final World world)
/*      */   {
/*  587 */     this.worldIsSet = true;
/*      */     
/*  589 */     this.handlerDelegate.setWorld(this.world, world);
/*  590 */     this.mousePollingManager.setWorldLocator(new WorldLocator()
/*      */     {
/*      */       public Actor getTopMostActorAt(MouseEvent e)
/*      */       {
/*  594 */         Point p = SwingUtilities.convertPoint(e.getComponent(), e.getX(), e.getY(), WorldHandler.this.worldCanvas);
/*  595 */         return WorldHandler.getObject(world, p.x, p.y);
/*      */       }
/*      */       
/*      */ 
/*      */       public int getTranslatedX(MouseEvent e)
/*      */       {
/*  601 */         Point p = SwingUtilities.convertPoint(e.getComponent(), e.getX(), e.getY(), WorldHandler.this.worldCanvas);
/*  602 */         return WorldVisitor.toCellFloor(world, p.x);
/*      */       }
/*      */       
/*      */ 
/*      */       public int getTranslatedY(MouseEvent e)
/*      */       {
/*  608 */         Point p = SwingUtilities.convertPoint(e.getComponent(), e.getX(), e.getY(), WorldHandler.this.worldCanvas);
/*  609 */         return WorldVisitor.toCellFloor(world, p.y);
/*      */       }
/*  611 */     });
/*  612 */     this.world = world;
/*      */     
/*  614 */     EventQueue.invokeLater(new Runnable()
/*      */     {
/*      */       public void run() {
/*  617 */         if (WorldHandler.this.worldCanvas != null) {
/*  618 */           WorldHandler.this.worldCanvas.setWorld(world);
/*      */         }
/*  620 */         WorldHandler.this.fireWorldCreatedEvent(world);
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized World getWorld()
/*      */   {
/*  630 */     if (this.world == null) {
/*  631 */       return this.initialisingWorld;
/*      */     }
/*      */     
/*  634 */     return this.world;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean hasWorld()
/*      */   {
/*  647 */     return this.world != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean drop(Object o, Point p)
/*      */   {
/*  657 */     final World world = this.world;
/*      */     
/*  659 */     int maxHeight = WorldVisitor.getHeightInPixels(world);
/*  660 */     int maxWidth = WorldVisitor.getWidthInPixels(world);
/*  661 */     final int x = (int)p.getX();
/*  662 */     final int y = (int)p.getY();
/*      */     
/*  664 */     if ((x >= maxWidth) || (y >= maxHeight) || (x < 0) || (y < 0)) {
/*  665 */       return false;
/*      */     }
/*  667 */     if ((o instanceof ObjectDragProxy))
/*      */     {
/*  669 */       final ObjectDragProxy to = (ObjectDragProxy)o;
/*  670 */       to.createRealObject();
/*  671 */       Simulation.getInstance().runLater(new Runnable()
/*      */       {
/*      */         public void run()
/*      */         {
/*  675 */           world.removeObject(to);
/*      */         }
/*  677 */       });
/*  678 */       this.objectDropped = true;
/*  679 */       return true;
/*      */     }
/*  681 */     if (((o instanceof Actor)) && (ActorVisitor.getWorld((Actor)o) == null))
/*      */     {
/*  683 */       Actor actor = (Actor)o;
/*  684 */       addActorAtPixel(actor, x, y);
/*  685 */       this.objectDropped = true;
/*  686 */       return true;
/*      */     }
/*  688 */     if ((o instanceof Actor)) {
/*  689 */       final Actor actor = (Actor)o;
/*  690 */       if (ActorVisitor.getWorld(actor) == null)
/*      */       {
/*      */ 
/*      */ 
/*  694 */         return false;
/*      */       }
/*  696 */       Simulation.getInstance().runLater(new Runnable()
/*      */       {
/*      */         public void run()
/*      */         {
/*  700 */           ActorVisitor.setLocationInPixels(actor, x, y);
/*      */         }
/*  702 */       });
/*  703 */       this.dragActorMoved = true;
/*  704 */       this.objectDropped = true;
/*  705 */       return true;
/*      */     }
/*      */     
/*  708 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean drag(Object o, Point p)
/*      */   {
/*  719 */     World world = this.world;
/*  720 */     if (((o instanceof Actor)) && (world != null)) {
/*  721 */       int x = WorldVisitor.toCellFloor(world, (int)p.getX() + this.dragOffsetX);
/*  722 */       int y = WorldVisitor.toCellFloor(world, (int)p.getY() + this.dragOffsetY);
/*  723 */       Actor actor = (Actor)o;
/*      */       try {
/*  725 */         int oldX = ActorVisitor.getX(actor);
/*  726 */         int oldY = ActorVisitor.getY(actor);
/*      */         
/*  728 */         if ((oldX != x) || (oldY != y)) {
/*  729 */           if ((x < WorldVisitor.getWidthInCells(world)) && (y < WorldVisitor.getHeightInCells(world)) && (x >= 0) && (y >= 0))
/*      */           {
/*  731 */             ReentrantReadWriteLock.WriteLock writeLock = lock.writeLock();
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  736 */             if (writeLock.tryLock()) {
/*  737 */               ActorVisitor.setLocationInPixels(actor, (int)p.getX() + this.dragOffsetX, (int)p.getY() + this.dragOffsetY);
/*      */               
/*      */ 
/*  740 */               writeLock.unlock();
/*  741 */               this.dragActorMoved = true;
/*  742 */               repaint();
/*      */             }
/*      */           }
/*      */           else {
/*  746 */             ReentrantReadWriteLock.WriteLock writeLock = lock.writeLock();
/*  747 */             if (writeLock.tryLock()) {
/*  748 */               ActorVisitor.setLocationInPixels(actor, this.dragBeginX, this.dragBeginY);
/*  749 */               x = WorldVisitor.toCellFloor(getWorld(), this.dragBeginX);
/*  750 */               y = WorldVisitor.toCellFloor(getWorld(), this.dragBeginY);
/*  751 */               this.handlerDelegate.actorDragged(actor, x, y);
/*  752 */               writeLock.unlock();
/*      */               
/*  754 */               this.dragActorMoved = false;
/*      */               
/*  756 */               repaint();
/*      */             }
/*  758 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (IndexOutOfBoundsException e) {}catch (IllegalStateException e) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  767 */       return true;
/*      */     }
/*      */     
/*  770 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean addObjectAtEvent(Actor actor, MouseEvent e)
/*      */   {
/*  781 */     Component source = (Component)e.getSource();
/*  782 */     if (source != this.worldCanvas) {
/*  783 */       e = SwingUtilities.convertMouseEvent(source, e, this.worldCanvas);
/*      */     }
/*  785 */     int xPixel = e.getX();
/*  786 */     int yPixel = e.getY();
/*  787 */     return addActorAtPixel(actor, xPixel, yPixel);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean addActorAtPixel(final Actor actor, int xPixel, int yPixel)
/*      */   {
/*  800 */     final World world = this.world;
/*  801 */     final int x = WorldVisitor.toCellFloor(world, xPixel);
/*  802 */     final int y = WorldVisitor.toCellFloor(world, yPixel);
/*  803 */     if ((x < WorldVisitor.getWidthInCells(world)) && (y < WorldVisitor.getHeightInCells(world)) && (x >= 0) && (y >= 0))
/*      */     {
/*  805 */       Simulation.getInstance().runLater(new Runnable()
/*      */       {
/*      */         public void run()
/*      */         {
/*  809 */           world.addObject(actor, x, y);
/*      */         }
/*  811 */       });
/*  812 */       this.handlerDelegate.addActor(actor, x, y);
/*  813 */       return true;
/*      */     }
/*      */     
/*  816 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public void dragEnded(Object o)
/*      */   {
/*  822 */     if (((o instanceof Actor)) && (this.world != null)) {
/*  823 */       final Actor actor = (Actor)o;
/*  824 */       Simulation.getInstance().runLater(new Runnable()
/*      */       {
/*      */         public void run()
/*      */         {
/*  828 */           WorldHandler.this.world.removeObject(actor);
/*      */         }
/*      */       });
/*      */     }
/*      */   }
/*      */   
/*      */   public void dragFinished(Object o)
/*      */   {
/*  836 */     finishDrag(o);
/*      */   }
/*      */   
/*      */ 
/*      */   protected void fireWorldCreatedEvent(World newWorld)
/*      */   {
/*  842 */     Object[] listeners = this.listenerList.getListenerList();
/*      */     
/*      */ 
/*  845 */     WorldEvent worldEvent = new WorldEvent(newWorld);
/*  846 */     for (int i = listeners.length - 2; i >= 0; i -= 2) {
/*  847 */       if (listeners[i] == WorldListener.class) {
/*  848 */         ((WorldListener)listeners[(i + 1)]).worldCreated(worldEvent);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void fireWorldRemovedEvent(World discardedWorld)
/*      */   {
/*  856 */     Object[] listeners = this.listenerList.getListenerList();
/*      */     
/*      */ 
/*  859 */     WorldEvent worldEvent = new WorldEvent(discardedWorld);
/*  860 */     for (int i = listeners.length - 2; i >= 0; i -= 2) {
/*  861 */       if (listeners[i] == WorldListener.class) {
/*  862 */         ((WorldListener)listeners[(i + 1)]).worldRemoved(worldEvent);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addWorldListener(WorldListener l)
/*      */   {
/*  876 */     this.listenerList.add(WorldListener.class, l);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeWorldListener(WorldListener l)
/*      */   {
/*  887 */     this.listenerList.remove(WorldListener.class, l);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void startSequence()
/*      */   {
/*  899 */     World world = this.world;
/*  900 */     if (world != null) {
/*  901 */       WorldVisitor.startSequence(world);
/*  902 */       this.mousePollingManager.newActStarted();
/*      */     }
/*      */   }
/*      */   
/*      */   public WorldCanvas getWorldCanvas()
/*      */   {
/*  908 */     return this.worldCanvas;
/*      */   }
/*      */   
/*      */   public EventListenerList getListenerList()
/*      */   {
/*  913 */     return this.listenerList;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void finishDrag(Object o)
/*      */   {
/*  925 */     if ((!this.objectDropped) && ((o instanceof Actor))) {
/*  926 */       final Actor actor = (Actor)o;
/*  927 */       this.objectDropped = true;
/*  928 */       this.dragActorMoved = false;
/*  929 */       Simulation.getInstance().runLater(new Runnable()
/*      */       {
/*      */         public void run()
/*      */         {
/*  933 */           ActorVisitor.setLocationInPixels(actor, WorldHandler.this.dragBeginX, WorldHandler.this.dragBeginY);
/*      */         }
/*      */       });
/*      */     }
/*      */   }
/*      */   
/*      */   public void simulationChanged(SimulationEvent e)
/*      */   {
/*  941 */     this.inputManager.simulationChanged(e);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectBenchInterface getObjectBench()
/*      */   {
/*  949 */     if ((this.handlerDelegate instanceof ObjectBenchInterface)) {
/*  950 */       return (ObjectBenchInterface)this.handlerDelegate;
/*      */     }
/*      */     
/*  953 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public InputManager getInputManager()
/*      */   {
/*  959 */     return this.inputManager;
/*      */   }
/*      */   
/*      */ 
/*      */   public void mouseDragged(MouseEvent e)
/*      */   {
/*  965 */     if (SwingUtilities.isLeftMouseButton(e)) {
/*  966 */       this.objectDropped = false;
/*  967 */       drag(this.dragActor, e.getPoint());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void mouseMoved(MouseEvent e)
/*      */   {
/*  974 */     this.objectDropped = false;
/*  975 */     if (this.dragActor != null) {
/*  976 */       drag(this.dragActor, e.getPoint());
/*      */     }
/*  978 */     this.handlerDelegate.mouseMoved(e);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BufferedImage getSnapShot()
/*      */   {
/*  989 */     if (this.world == null) {
/*  990 */       return null;
/*      */     }
/*      */     
/*  993 */     WorldCanvas canvas = getWorldCanvas();
/*  994 */     BufferedImage img = GraphicsUtilities.createCompatibleImage(WorldVisitor.getWidthInPixels(this.world), WorldVisitor.getHeightInPixels(this.world));
/*      */     
/*  996 */     Graphics2D g = img.createGraphics();
/*  997 */     g.setColor(canvas.getBackground());
/*  998 */     g.fillRect(0, 0, img.getWidth(), img.getHeight());
/*  999 */     canvas.paintBackground(g);
/*      */     
/* 1001 */     int timeout = 500;
/*      */     try
/*      */     {
/* 1004 */       if (lock.readLock().tryLock(timeout, TimeUnit.MILLISECONDS)) {
/*      */         try {
/* 1006 */           canvas.paintObjects(g);
/*      */         }
/*      */         finally {
/* 1009 */           lock.readLock().unlock();
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (InterruptedException e) {}
/*      */     
/* 1015 */     return img;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void listeningEnded() {}
/*      */   
/*      */ 
/*      */ 
/*      */   public void listeningStarted(Object obj)
/*      */   {
/* 1026 */     World world = this.world;
/*      */     
/*      */ 
/* 1029 */     if ((world != null) && (obj != null) && (obj != this.dragActor) && ((obj instanceof Actor))) {
/* 1030 */       Actor actor = (Actor)obj;
/* 1031 */       int ax = ActorVisitor.getX(actor);
/* 1032 */       int ay = ActorVisitor.getY(actor);
/* 1033 */       int x = (int)Math.floor(WorldVisitor.getCellCenter(world, ax));
/* 1034 */       int y = (int)Math.floor(WorldVisitor.getCellCenter(world, ay));
/* 1035 */       Point p = new Point(x, y);
/* 1036 */       startDrag(actor, p, world);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void objectAddedToWorld(Actor object)
/*      */   {
/* 1046 */     this.handlerDelegate.objectAddedToWorld(object);
/*      */   }
/*      */   
/*      */   public String ask(String prompt)
/*      */   {
/* 1051 */     boolean held = lock.isWriteLockedByCurrentThread();
/* 1052 */     if (held)
/* 1053 */       lock.writeLock().unlock();
/* 1054 */     String answer = this.handlerDelegate.ask(prompt);
/*      */     
/* 1056 */     EventQueue.invokeLater(new Runnable() {
/* 1057 */       public void run() { WorldHandler.this.worldCanvas.requestFocusInWindow(); }
/*      */     });
/* 1059 */     if (held)
/* 1060 */       lock.writeLock().lock();
/* 1061 */     return answer;
/*      */   }
/*      */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\core\WorldHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */