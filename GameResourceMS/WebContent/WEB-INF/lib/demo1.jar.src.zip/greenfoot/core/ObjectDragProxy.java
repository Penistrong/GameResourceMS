/*    */ package greenfoot.core;
/*    */ 
/*    */ import greenfoot.Actor;
/*    */ import greenfoot.GreenfootImage;
/*    */ import javax.swing.Action;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectDragProxy
/*    */   extends Actor
/*    */ {
/*    */   private Action realAction;
/*    */   
/*    */   public ObjectDragProxy(GreenfootImage dragImage, Action realAction)
/*    */   {
/* 44 */     setImage(dragImage);
/* 45 */     this.realAction = realAction;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void createRealObject()
/*    */   {
/* 54 */     this.realAction.actionPerformed(null);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\core\ObjectDragProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */