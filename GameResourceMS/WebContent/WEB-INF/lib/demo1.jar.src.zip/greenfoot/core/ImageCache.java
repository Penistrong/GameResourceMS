/*     */ package greenfoot.core;
/*     */ 
/*     */ import greenfoot.GreenfootImage;
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageCache
/*     */ {
/*  39 */   private static ImageCache instance = new ImageCache();
/*     */   
/*     */   private class CachedImageRef
/*     */     extends SoftReference<GreenfootImage>
/*     */   {
/*     */     String imgName;
/*     */     
/*     */     public CachedImageRef(GreenfootImage imgName, ReferenceQueue<GreenfootImage> image)
/*     */     {
/*  48 */       super(queue);
/*  49 */       this.imgName = imgName;
/*     */     }
/*     */   }
/*     */   
/*  53 */   private Map<String, CachedImageRef> imageCache = new HashMap();
/*  54 */   private ReferenceQueue<GreenfootImage> imgCacheRefQueue = new ReferenceQueue();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ImageCache getInstance()
/*     */   {
/*  61 */     return instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean addCachedImage(String fileName, GreenfootImage image)
/*     */   {
/*  72 */     synchronized (this.imageCache) {
/*  73 */       if (image != null) {
/*  74 */         CachedImageRef cr = new CachedImageRef(fileName, image, this.imgCacheRefQueue);
/*  75 */         this.imageCache.put(fileName, cr);
/*     */       }
/*     */       else {
/*  78 */         this.imageCache.put(fileName, null);
/*     */       }
/*     */     }
/*  81 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GreenfootImage getCachedImage(String fileName)
/*     */   {
/*  93 */     synchronized (this.imageCache) {
/*  94 */       flushImgCacheRefQueue();
/*  95 */       CachedImageRef sr = (CachedImageRef)this.imageCache.get(fileName);
/*  96 */       if (sr != null) {
/*  97 */         return (GreenfootImage)sr.get();
/*     */       }
/*  99 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeCachedImage(String fileName)
/*     */   {
/* 109 */     synchronized (this.imageCache) {
/* 110 */       CachedImageRef cr = (CachedImageRef)this.imageCache.remove(fileName);
/* 111 */       if (cr != null) {
/* 112 */         cr.clear();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNullCachedImage(String fileName)
/*     */   {
/* 123 */     synchronized (this.imageCache) {
/* 124 */       return (this.imageCache.containsKey(fileName)) && (this.imageCache.get(fileName) == null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearImageCache()
/*     */   {
/* 133 */     synchronized (this.imageCache) {
/* 134 */       this.imageCache.clear();
/* 135 */       this.imgCacheRefQueue = new ReferenceQueue();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void flushImgCacheRefQueue()
/*     */   {
/* 148 */     Reference<? extends GreenfootImage> ref = this.imgCacheRefQueue.poll();
/* 149 */     while (ref != null) {
/* 150 */       if ((ref instanceof CachedImageRef)) {
/* 151 */         CachedImageRef cr = (CachedImageRef)ref;
/* 152 */         this.imageCache.remove(cr.imgName);
/*     */       }
/* 154 */       ref = this.imgCacheRefQueue.poll();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\core\ImageCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */