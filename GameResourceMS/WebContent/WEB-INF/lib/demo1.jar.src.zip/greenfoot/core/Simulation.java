/*      */ package greenfoot.core;
/*      */ 
/*      */ import greenfoot.Actor;
/*      */ import greenfoot.ActorVisitor;
/*      */ import greenfoot.World;
/*      */ import greenfoot.WorldVisitor;
/*      */ import greenfoot.event.SimulationEvent;
/*      */ import greenfoot.event.SimulationListener;
/*      */ import greenfoot.event.WorldEvent;
/*      */ import greenfoot.event.WorldListener;
/*      */ import greenfoot.gui.input.KeyboardManager;
/*      */ import greenfoot.platforms.SimulationDelegate;
/*      */ import greenfoot.util.HDTimer;
/*      */ import java.awt.EventQueue;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Queue;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.event.EventListenerList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Simulation
/*      */   extends Thread
/*      */   implements WorldListener
/*      */ {
/*   71 */   private static int MAX_FRAME_RATE = 65;
/*      */   
/*   73 */   private static int MIN_FRAME_RATE = 35;
/*      */   
/*      */ 
/*      */   private WorldHandler worldHandler;
/*      */   
/*      */ 
/*      */   private boolean paused;
/*      */   
/*      */ 
/*      */   private volatile boolean enabled;
/*      */   
/*      */ 
/*      */   private boolean runOnce;
/*      */   
/*   87 */   private Queue<Runnable> queuedTasks = new LinkedList();
/*      */   
/*   89 */   private EventListenerList listenerList = new EventListenerList();
/*      */   
/*      */   private SimulationEvent startedEvent;
/*      */   
/*      */   private SimulationEvent stoppedEvent;
/*      */   
/*      */   private SimulationEvent disabledEvent;
/*      */   
/*      */   private SimulationEvent speedChangeEvent;
/*      */   
/*      */   private SimulationEvent debuggerPausedEvent;
/*      */   
/*      */   private SimulationEvent debuggerResumedEvent;
/*      */   
/*      */   private static Simulation instance;
/*      */   
/*      */   public static final int MAX_SIMULATION_SPEED = 100;
/*      */   
/*      */   private int speed;
/*      */   
/*      */   private long lastDelayTime;
/*      */   
/*      */   private long delay;
/*  112 */   private Object repaintLock = new Object();
/*      */   
/*      */ 
/*      */   private long lastRepaintTime;
/*      */   
/*      */ 
/*      */   private boolean paintPending;
/*      */   
/*      */ 
/*      */   private SimulationDelegate delegate;
/*      */   
/*  123 */   private Object interruptLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean delaying;
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean interruptDelay;
/*      */   
/*      */ 
/*  134 */   private boolean isRunning = false;
/*      */   
/*      */   private volatile boolean abort;
/*      */   
/*      */   public static final String PAUSED = "simulationWait";
/*      */   
/*      */   public static final String WORLD_STARTED = "worldStarted";
/*      */   
/*      */   public static final String WORLD_STOPPED = "worldStopped";
/*      */   
/*      */ 
/*      */   private Simulation(SimulationDelegate simulationDelegate)
/*      */   {
/*  147 */     setName("SimulationThread");
/*  148 */     this.delegate = simulationDelegate;
/*  149 */     this.startedEvent = new SimulationEvent(this, 0);
/*  150 */     this.stoppedEvent = new SimulationEvent(this, 1);
/*  151 */     this.speedChangeEvent = new SimulationEvent(this, 2);
/*  152 */     this.disabledEvent = new SimulationEvent(this, 3);
/*  153 */     this.debuggerPausedEvent = new SimulationEvent(this, 5);
/*  154 */     this.debuggerResumedEvent = new SimulationEvent(this, 6);
/*  155 */     setPriority(1);
/*  156 */     this.paused = true;
/*  157 */     this.speed = 50;
/*  158 */     this.delay = calculateDelay(this.speed);
/*  159 */     HDTimer.init();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void initialize(SimulationDelegate simulationDelegate)
/*      */   {
/*  169 */     instance = new Simulation(simulationDelegate);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Simulation getInstance()
/*      */   {
/*  177 */     return instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void attachWorldHandler(WorldHandler worldHandler)
/*      */   {
/*  185 */     this.worldHandler = worldHandler;
/*  186 */     worldHandler.addWorldListener(this);
/*  187 */     addSimulationListener(worldHandler);
/*  188 */     start();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void run()
/*      */   {
/*  205 */     runContent();
/*      */   }
/*      */   
/*      */   private void runContent()
/*      */   {
/*  210 */     while (!this.abort) {
/*      */       try {
/*  212 */         maybePause();
/*      */         
/*  214 */         if (this.worldHandler.hasWorld()) {
/*  215 */           runOneLoop(this.worldHandler.getWorld());
/*      */         }
/*      */         
/*  218 */         delay();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       catch (ActInterruptedException e) {}catch (InterruptedException e) {}catch (Throwable t)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  229 */         synchronized (this) {
/*  230 */           this.paused = true;
/*      */         }
/*  232 */         t.printStackTrace();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  237 */     synchronized (this) {
/*  238 */       if (this.isRunning) {
/*  239 */         World world = this.worldHandler.getWorld();
/*  240 */         if (world != null) {
/*  241 */           worldStopped(world);
/*      */         }
/*  243 */         this.isRunning = false;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void runLater(Runnable r)
/*      */   {
/*  254 */     this.queuedTasks.add(r);
/*      */     
/*      */ 
/*      */ 
/*  258 */     if ((this.paused) || (!this.enabled)) {
/*  259 */       notify();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void simulationWait()
/*      */     throws InterruptedException
/*      */   {
/*  270 */     wait();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static void worldStarted(World world)
/*      */   {
/*  277 */     world.started();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static void worldStopped(World world)
/*      */   {
/*  284 */     world.stopped();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void maybePause()
/*      */     throws InterruptedException
/*      */   {
/*  298 */     while (!this.abort) {
/*  299 */       runQueuedTasks();
/*      */       
/*      */ 
/*      */       boolean checkStop;
/*      */       
/*      */ 
/*      */       World world;
/*      */       
/*  307 */       synchronized (this) {
/*  308 */         checkStop = ((this.paused) || (!this.enabled)) && (this.isRunning);
/*  309 */         world = this.worldHandler.getWorld();
/*      */         
/*  311 */         if (checkStop) {
/*  312 */           this.isRunning = false;
/*  313 */           synchronized (this.interruptLock) {
/*  314 */             this.interruptDelay = false;
/*      */           }
/*      */         }
/*  317 */         else if (this.isRunning) {
/*  318 */           return;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  324 */       if (checkStop) {
/*      */         try {
/*  326 */           signalStopping(world);
/*      */         }
/*      */         catch (InterruptedException ie) {}
/*  329 */         continue;
/*      */         
/*      */ 
/*  332 */         synchronized (this) {
/*  333 */           this.runOnce = false;
/*      */           
/*  335 */           if (!this.paused) {
/*  336 */             this.isRunning = this.enabled;
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*      */         boolean doResumeRunning;
/*      */         
/*      */ 
/*  345 */         synchronized (this) {
/*  346 */           doResumeRunning = (!this.paused) && (this.enabled) && (!this.abort) && (!this.isRunning);
/*  347 */           if ((!this.isRunning) && (!doResumeRunning) && (!this.runOnce))
/*      */           {
/*  349 */             if (this.enabled) {
/*  350 */               fireSimulationEvent(this.stoppedEvent);
/*      */             }
/*  352 */             if (this.worldHandler != null) {
/*  353 */               this.worldHandler.repaint();
/*      */             }
/*      */             
/*  356 */             if (!this.queuedTasks.isEmpty()) {
/*      */               continue;
/*      */             }
/*      */             
/*  360 */             System.gc();
/*      */             try {
/*  362 */               simulationWait();
/*  363 */               this.lastDelayTime = System.nanoTime();
/*      */             }
/*      */             catch (InterruptedException e1) {}
/*      */             
/*      */ 
/*      */ 
/*  369 */             continue;
/*      */           }
/*      */         }
/*      */         
/*  373 */         if (doResumeRunning) {
/*  374 */           resumeRunning();
/*      */         }
/*      */         
/*  377 */         synchronized (this) {
/*  378 */           if ((this.runOnce) || (this.isRunning))
/*      */           {
/*  380 */             this.runOnce = false;
/*  381 */             return;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  386 */     runQueuedTasks();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void resumeRunning()
/*      */     throws InterruptedException
/*      */   {
/*  396 */     this.isRunning = true;
/*  397 */     this.lastDelayTime = System.nanoTime();
/*  398 */     fireSimulationEvent(this.startedEvent);
/*  399 */     World world = this.worldHandler.getWorld();
/*  400 */     if (world != null)
/*      */     {
/*  402 */       ReentrantReadWriteLock lock = this.worldHandler.getWorldLock();
/*      */       try {
/*  404 */         lock.writeLock().lockInterruptibly();
/*      */       }
/*      */       catch (InterruptedException ie) {
/*  407 */         this.isRunning = false;
/*  408 */         throw ie;
/*      */       }
/*      */       try
/*      */       {
/*  412 */         worldStarted(world);
/*      */       }
/*      */       catch (Throwable t) {
/*  415 */         this.isRunning = false;
/*  416 */         synchronized (this.interruptLock)
/*      */         {
/*  418 */           Thread.interrupted();
/*  419 */           this.interruptDelay = false;
/*      */         }
/*  421 */         setPaused(true);
/*  422 */         t.printStackTrace();
/*      */       }
/*      */       finally
/*      */       {
/*  426 */         lock.writeLock().unlock();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void signalStopping(World world)
/*      */     throws InterruptedException
/*      */   {
/*  442 */     if (world != null)
/*      */     {
/*  444 */       ReentrantReadWriteLock lock = this.worldHandler.getWorldLock();
/*  445 */       lock.writeLock().lockInterruptibly();
/*      */       try {
/*  447 */         worldStopped(world);
/*      */       }
/*      */       catch (ActInterruptedException aie) {
/*  450 */         synchronized (this) {
/*  451 */           this.paused = true;
/*      */         }
/*  453 */         throw aie;
/*      */       }
/*      */       catch (Throwable t)
/*      */       {
/*  457 */         synchronized (this) {
/*  458 */           this.paused = true;
/*      */         }
/*  460 */         t.printStackTrace();
/*      */       }
/*      */       finally {
/*  463 */         lock.writeLock().unlock();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*  469 */   public static String RUN_QUEUED_TASKS = "runQueuedTasks";
/*      */   
/*      */   public static final String ACT_ACTOR = "actActor";
/*      */   
/*      */   public static final String ACT_WORLD = "actWorld";
/*      */   public static final String NEW_INSTANCE = "newInstance";
/*      */   
/*      */   private void runQueuedTasks()
/*      */   {
/*      */     Runnable r;
/*  479 */     synchronized (this) {
/*  480 */       r = (Runnable)this.queuedTasks.poll();
/*      */     }
/*      */     
/*  483 */     while (r != null) {
/*  484 */       World world = WorldHandler.getInstance().getWorld();
/*      */       try {
/*  486 */         ReentrantReadWriteLock lock = null;
/*  487 */         if (world != null) {
/*  488 */           lock = this.worldHandler.getWorldLock();
/*  489 */           lock.writeLock().lock();
/*      */         }
/*      */         
/*      */         try
/*      */         {
/*  494 */           r.run();
/*      */         }
/*      */         catch (Throwable t) {
/*  497 */           t.printStackTrace();
/*      */         }
/*      */         
/*  500 */         if (world != null) {
/*  501 */           lock.writeLock().unlock();
/*      */         }
/*      */       }
/*      */       finally {}
/*      */       
/*      */ 
/*  507 */       synchronized (this) {
/*  508 */         r = (Runnable)this.queuedTasks.poll();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void runOneLoop(World world)
/*      */   {
/*  520 */     this.worldHandler.startSequence();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  525 */     ActInterruptedException interruptedException = null;
/*      */     
/*  527 */     List<? extends Actor> objects = null;
/*      */     
/*      */     try
/*      */     {
/*  531 */       ReentrantReadWriteLock lock = this.worldHandler.getWorldLock();
/*  532 */       lock.writeLock().lockInterruptibly();
/*      */       try {
/*      */         try {
/*  535 */           actWorld(world);
/*  536 */           if (world != this.worldHandler.getWorld()) {
/*      */             return;
/*      */           }
/*      */         }
/*      */         catch (ActInterruptedException e) {
/*  541 */           interruptedException = e;
/*      */         }
/*      */         
/*      */ 
/*  545 */         objects = new ArrayList(WorldVisitor.getObjectsListInActOrder(world));
/*  546 */         for (Actor actor : objects) {
/*  547 */           if (!this.enabled) {
/*      */             return;
/*      */           }
/*  550 */           if (ActorVisitor.getWorld(actor) != null) {
/*      */             try {
/*  552 */               actActor(actor);
/*  553 */               if (world != this.worldHandler.getWorld()) {
/*      */                 return;
/*      */               }
/*      */             }
/*      */             catch (ActInterruptedException e) {
/*  558 */               if (interruptedException == null) {
/*  559 */                 interruptedException = e;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*  566 */         this.worldHandler.getKeyboardManager().clearLatchedKeys();
/*      */       }
/*      */       finally {
/*  569 */         lock.writeLock().unlock();
/*      */       }
/*      */     }
/*      */     catch (InterruptedException e)
/*      */     {
/*  574 */       throw new ActInterruptedException(e);
/*      */     }
/*      */     
/*      */ 
/*  578 */     if (interruptedException != null) {
/*  579 */       throw interruptedException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  584 */     repaintIfNeeded();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void actActor(Actor actor)
/*      */   {
/*  594 */     actor.act();
/*      */   }
/*      */   
/*      */ 
/*      */   private static void actWorld(World world)
/*      */   {
/*  600 */     world.act();
/*      */   }
/*      */   
/*      */ 
/*      */   public static Object newInstance(Constructor<?> constructor)
/*      */     throws InvocationTargetException, IllegalArgumentException, InstantiationException, IllegalAccessException
/*      */   {
/*  607 */     return constructor.newInstance((Object[])null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void repaintIfNeeded()
/*      */   {
/*  615 */     long currentTime = System.currentTimeMillis();
/*  616 */     long timeSinceLast = Math.max(1L, currentTime - this.lastRepaintTime);
/*      */     
/*  618 */     if (1000L / timeSinceLast <= MAX_FRAME_RATE) {
/*      */       try {
/*  620 */         synchronized (this.repaintLock)
/*      */         {
/*      */ 
/*      */ 
/*  624 */           if (!this.paintPending) {
/*  625 */             this.lastRepaintTime = currentTime;
/*  626 */             this.worldHandler.repaint();
/*  627 */             this.paintPending = true;
/*      */           }
/*      */           
/*  630 */           if (1000L / timeSinceLast <= MIN_FRAME_RATE)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  639 */             EventQueue.invokeLater(new Runnable()
/*      */             {
/*      */               public void run()
/*      */               {
/*  643 */                 Simulation.this.forcedRepaint();
/*      */               }
/*      */             });
/*      */             
/*  647 */             while (this.paintPending) {
/*  648 */               this.repaintLock.wait();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (InterruptedException ie) {}
/*      */     }
/*      */   }
/*      */   
/*      */   private void forcedRepaint()
/*      */   {
/*  659 */     JComponent wcanvas = WorldHandler.getInstance().getWorldCanvas();
/*  660 */     synchronized (this.repaintLock) {
/*  661 */       if (WorldHandler.getInstance().hasWorld()) {
/*  662 */         wcanvas.paintImmediately(wcanvas.getBounds());
/*      */       }
/*      */       
/*  665 */       if (this.paintPending) {
/*  666 */         this.paintPending = false;
/*  667 */         this.repaintLock.notify();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void worldRepainted()
/*      */   {
/*  677 */     synchronized (this.repaintLock) {
/*  678 */       this.paintPending = false;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  683 */       this.repaintLock.notify();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void runOnce()
/*      */   {
/*  713 */     if (this.enabled) {
/*  714 */       synchronized (this.interruptLock) {
/*  715 */         this.interruptDelay = false;
/*      */       }
/*      */     }
/*  718 */     this.runOnce = true;
/*  719 */     notifyAll();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setPaused(boolean b)
/*      */   {
/*  727 */     if (this.paused == b)
/*      */     {
/*  729 */       return;
/*      */     }
/*  731 */     this.paused = b;
/*  732 */     if (this.enabled) {
/*  733 */       if (!this.paused)
/*      */       {
/*  735 */         synchronized (this.interruptLock) {
/*  736 */           this.interruptDelay = false;
/*      */         }
/*      */       }
/*      */       
/*  740 */       notifyAll();
/*      */       
/*      */ 
/*      */ 
/*  744 */       if (this.paused) {
/*  745 */         interruptDelay();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void interruptDelay()
/*      */   {
/*  759 */     synchronized (this.interruptLock) {
/*  760 */       if (this.delaying) {
/*  761 */         interrupt();
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  766 */         this.interruptDelay = true;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setEnabled(boolean b)
/*      */   {
/*  776 */     if (b == this.enabled) {
/*  777 */       return;
/*      */     }
/*      */     
/*  780 */     this.enabled = b;
/*      */     
/*  782 */     if (b) {
/*  783 */       notifyAll();
/*      */       
/*      */ 
/*  786 */       if (this.paused) {
/*  787 */         fireSimulationEvent(this.stoppedEvent);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  795 */       interruptDelay();
/*  796 */       if (!this.paused) {
/*  797 */         this.paused = true;
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*  806 */         synchronized (this.interruptLock) {
/*  807 */           this.interruptDelay = false;
/*      */         }
/*      */       }
/*  810 */       fireSimulationEvent(this.disabledEvent);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void fireSimulationEvent(SimulationEvent event)
/*      */   {
/*  818 */     synchronized (this.listenerList) {
/*  819 */       Object[] listeners = this.listenerList.getListenerList();
/*      */       
/*      */ 
/*      */ 
/*  823 */       for (int i = listeners.length - 2; i >= 0; i -= 2) {
/*  824 */         if (listeners[i] == SimulationListener.class) {
/*  825 */           ((SimulationListener)listeners[(i + 1)]).simulationChanged(event);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notifyThreadStatus(boolean halted)
/*      */   {
/*  836 */     if (halted) {
/*  837 */       fireSimulationEvent(this.debuggerPausedEvent);
/*      */     }
/*      */     else
/*      */     {
/*  841 */       fireSimulationEvent(this.debuggerResumedEvent);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSimulationListener(SimulationListener l)
/*      */   {
/*  853 */     synchronized (this.listenerList) {
/*  854 */       this.listenerList.add(SimulationListener.class, l);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSimulationListener(SimulationListener l)
/*      */   {
/*  866 */     synchronized (this.listenerList) {
/*  867 */       this.listenerList.remove(SimulationListener.class, l);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSpeed(int speed)
/*      */   {
/*  879 */     if (speed < 0) {
/*  880 */       speed = 0;
/*      */     }
/*  882 */     else if (speed > 100) {
/*  883 */       speed = 100;
/*      */     }
/*      */     
/*      */     boolean speedChanged;
/*  887 */     synchronized (this) {
/*  888 */       speedChanged = this.speed != speed;
/*  889 */       if (speedChanged) {
/*  890 */         this.speed = speed;
/*      */         
/*  892 */         this.delegate.setSpeed(speed);
/*      */         
/*  894 */         this.delay = calculateDelay(speed);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  899 */         if (!this.paused) {
/*  900 */           synchronized (this.interruptLock) {
/*  901 */             if (this.delaying) {
/*  902 */               interrupt();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  909 */     if (speedChanged) {
/*  910 */       fireSimulationEvent(this.speedChangeEvent);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private long calculateDelay(int speed)
/*      */   {
/*  922 */     long rawDelay = 100 - speed;
/*      */     
/*  924 */     long min = 30000L;
/*  925 */     long max = 10000000000L;
/*      */     
/*  927 */     double a = Math.pow(max / min, 0.010101010101010102D);
/*  928 */     long delay = 0L;
/*  929 */     if (rawDelay > 0L) {
/*  930 */       delay = (Math.pow(a, rawDelay - 1L) * min);
/*      */     }
/*  932 */     return delay;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getSpeed()
/*      */   {
/*  942 */     return this.speed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sleep(int numCycles)
/*      */   {
/*  953 */     World world = this.worldHandler.getWorld();
/*      */     
/*  955 */     synchronized (this) {
/*  956 */       if ((this.paused) && (this.isRunning) && (!this.runOnce))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  964 */         return;
/*      */       }
/*  966 */       if (!this.enabled)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  971 */         return;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  977 */       synchronized (this.interruptLock) {
/*  978 */         if (this.interruptDelay)
/*      */         {
/*      */ 
/*      */ 
/*  982 */           return;
/*      */         }
/*  984 */         this.delaying = true;
/*      */       }
/*      */     }
/*      */     try
/*      */     {
/*  989 */       this.worldHandler.repaint();
/*  990 */       for (int i = 0; i < numCycles; i++) {
/*  991 */         if (world != null)
/*      */         {
/*      */ 
/*      */ 
/*  995 */           HDTimer.wait(this.delay, this.worldHandler.getWorldLock());
/*      */         }
/*      */         else
/*      */         {
/*  999 */           HDTimer.sleep(this.delay);
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     catch (InterruptedException e) {}finally
/*      */     {
/*      */ 
/* 1009 */       synchronized (this.interruptLock) {
/* 1010 */         Thread.interrupted();
/* 1011 */         this.interruptDelay = false;
/* 1012 */         this.delaying = false;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void delay()
/*      */   {
/* 1029 */     long currentTime = System.nanoTime();
/* 1030 */     long timeElapsed = currentTime - this.lastDelayTime;
/* 1031 */     long actualDelay = Math.max(this.delay - timeElapsed, 0L);
/*      */     
/* 1033 */     synchronized (this) {
/* 1034 */       synchronized (this.interruptLock) {
/* 1035 */         if (this.interruptDelay)
/*      */         {
/* 1037 */           this.interruptDelay = false;
/* 1038 */           if ((this.paused) || (this.abort)) {
/* 1039 */             this.lastDelayTime = currentTime;
/* 1040 */             return;
/*      */           }
/*      */         }
/* 1043 */         this.delaying = true;
/*      */       }
/*      */     }
/*      */     
/* 1047 */     while (actualDelay > 0L)
/*      */     {
/*      */       try {
/* 1050 */         HDTimer.sleep(actualDelay);
/*      */ 
/*      */       }
/*      */       catch (InterruptedException ie)
/*      */       {
/*      */ 
/* 1056 */         synchronized (this) {
/* 1057 */           if ((!this.enabled) || (this.paused) || (this.abort)) {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1063 */       currentTime = System.nanoTime();
/* 1064 */       timeElapsed = currentTime - this.lastDelayTime;
/* 1065 */       actualDelay = this.delay - timeElapsed;
/*      */     }
/*      */     
/* 1068 */     this.lastDelayTime = currentTime;
/* 1069 */     synchronized (this.interruptLock) {
/* 1070 */       Thread.interrupted();
/* 1071 */       this.interruptDelay = false;
/* 1072 */       this.delaying = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void abort()
/*      */   {
/* 1082 */     this.abort = true;
/* 1083 */     setEnabled(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void worldCreated(WorldEvent e)
/*      */   {
/* 1096 */     setEnabled(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void worldRemoved(WorldEvent e)
/*      */   {
/* 1105 */     setEnabled(false);
/*      */   }
/*      */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\core\Simulation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */