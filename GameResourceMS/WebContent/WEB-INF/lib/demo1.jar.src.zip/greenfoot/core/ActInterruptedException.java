/*    */ package greenfoot.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActInterruptedException
/*    */   extends RuntimeException
/*    */ {
/*    */   public ActInterruptedException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ActInterruptedException(String message)
/*    */   {
/* 38 */     super(message);
/*    */   }
/*    */   
/*    */   public ActInterruptedException(String message, Throwable cause)
/*    */   {
/* 43 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public ActInterruptedException(Throwable cause)
/*    */   {
/* 48 */     super(cause);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\core\ActInterruptedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */