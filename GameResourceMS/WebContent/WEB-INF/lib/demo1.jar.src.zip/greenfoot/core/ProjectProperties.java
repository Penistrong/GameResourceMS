/*     */ package greenfoot.core;
/*     */ 
/*     */ import greenfoot.GreenfootImage;
/*     */ import greenfoot.util.GreenfootUtil;
/*     */ import greenfoot.util.Version;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProjectProperties
/*     */ {
/*     */   private static final String FILE_HEADER = "Greenfoot properties";
/*     */   public static final String GREENFOOT_PKG_NAME = "project.greenfoot";
/*     */   private Properties properties;
/*     */   private File propsFile;
/*     */   
/*     */   public ProjectProperties(File projectDir)
/*     */   {
/*  70 */     this.properties = new Properties();
/*  71 */     load(projectDir);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ProjectProperties()
/*     */   {
/*  81 */     this.properties = new Properties();
/*  82 */     load();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void load()
/*     */   {
/*  90 */     URL probsFile = getClass().getResource("/project.greenfoot");
/*  91 */     InputStream is = null;
/*     */     try {
/*  93 */       is = probsFile.openStream();
/*  94 */       this.properties.load(is); return;
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (IOException ioe) {}finally
/*     */     {
/*     */ 
/*     */ 
/* 103 */       if (is != null) {
/*     */         try {
/* 105 */           is.close();
/*     */         }
/*     */         catch (IOException e) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void load(File projectDir)
/*     */   {
/* 121 */     this.propsFile = new File(projectDir, "project.greenfoot");
/*     */     
/* 123 */     InputStream is = null;
/*     */     try {
/* 125 */       is = new FileInputStream(this.propsFile);
/* 126 */       this.properties.load(is); return;
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (IOException ioe) {}finally
/*     */     {
/*     */ 
/*     */ 
/* 135 */       if (is != null) {
/*     */         try {
/* 137 */           is.close();
/*     */         }
/*     */         catch (IOException e) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void save()
/*     */   {
/* 153 */     OutputStream os = null;
/*     */     try {
/* 155 */       os = new FileOutputStream(this.propsFile);
/* 156 */       this.properties.store(os, "Greenfoot properties"); return;
/*     */ 
/*     */     }
/*     */     catch (FileNotFoundException e) {}catch (IOException e) {}finally
/*     */     {
/* 161 */       if (os != null) {
/*     */         try {
/* 163 */           os.close();
/*     */         }
/*     */         catch (IOException e) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setString(String key, String value)
/*     */   {
/* 176 */     this.properties.setProperty(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized String getString(String key)
/*     */   {
/* 185 */     return this.properties.getProperty(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setInt(String key, int value)
/*     */   {
/* 194 */     this.properties.setProperty(key, Integer.toString(value));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized int getInt(String key)
/*     */     throws NumberFormatException
/*     */   {
/* 203 */     String number = this.properties.getProperty(key);
/* 204 */     return Integer.parseInt(number);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setBoolean(String key, boolean value)
/*     */   {
/* 212 */     this.properties.setProperty(key, Boolean.toString(value));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean getBoolean(String key, String defaultValue)
/*     */   {
/* 221 */     String bool = this.properties.getProperty(key, defaultValue);
/* 222 */     return Boolean.parseBoolean(bool);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized String removeProperty(String key)
/*     */   {
/* 231 */     return (String)this.properties.remove(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setApiVersion(String version)
/*     */   {
/* 240 */     this.properties.setProperty("version", version);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Version getAPIVersion()
/*     */   {
/* 253 */     String versionString = this.properties.getProperty("version");
/* 254 */     Version version = new Version(versionString);
/* 255 */     return version;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GreenfootImage getImage(String className)
/*     */   {
/* 269 */     return GreenfootUtil.getGreenfootImage(className, getString("class." + className + ".image"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeCachedImage(String className)
/*     */   {
/* 278 */     GreenfootUtil.removeCachedImage(className);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\core\ProjectProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */