/*    */ package greenfoot.core;
/*    */ 
/*    */ import greenfoot.util.GraphicsUtilities;
/*    */ import greenfoot.util.GraphicsUtilities.MultiLineStringDimensions;
/*    */ import java.awt.Color;
/*    */ import java.awt.Graphics2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextLabel
/*    */ {
/*    */   private final int xpos;
/*    */   private final int ypos;
/*    */   private final String text;
/*    */   private final String[] lines;
/*    */   private GraphicsUtilities.MultiLineStringDimensions dimensions;
/*    */   
/*    */   public TextLabel(String s, int xpos, int ypos)
/*    */   {
/* 48 */     this.text = s;
/* 49 */     this.lines = GraphicsUtilities.splitLines(this.text);
/* 50 */     this.xpos = xpos;
/* 51 */     this.ypos = ypos;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void draw(Graphics2D g, int cellsize)
/*    */   {
/* 61 */     if (this.dimensions == null) {
/* 62 */       this.dimensions = GraphicsUtilities.getMultiLineStringDimensions(this.lines, 1, 25.0D);
/*    */     }
/*    */     
/*    */ 
/* 66 */     int ydraw = this.ypos * cellsize - this.dimensions.getHeight() / 2 + cellsize / 2;
/*    */     
/* 68 */     int xdraw = this.xpos * cellsize - this.dimensions.getWidth() / 2 + cellsize / 2;
/*    */     
/* 70 */     g.translate(xdraw, ydraw);
/*    */     
/* 72 */     GraphicsUtilities.drawOutlinedText(g, this.dimensions, Color.WHITE, Color.BLACK);
/*    */     
/* 74 */     g.translate(-xdraw, -ydraw);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getX()
/*    */   {
/* 82 */     return this.xpos;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getY()
/*    */   {
/* 90 */     return this.ypos;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getText()
/*    */   {
/* 98 */     return this.text;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\core\TextLabel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */