/*     */ package greenfoot;
/*     */ 
/*     */ import greenfoot.collision.ibsp.Rect;
/*     */ import greenfoot.platforms.ActorDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActorVisitor
/*     */ {
/*     */   public static void setLocationInPixels(Actor actor, int dragBeginX, int dragBeginY)
/*     */   {
/*  39 */     actor.setLocationInPixels(dragBeginX, dragBeginY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getX(Actor actor)
/*     */   {
/*  47 */     return actor.x;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getY(Actor actor)
/*     */   {
/*  55 */     return actor.y;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getRotation(Actor actor)
/*     */   {
/*  63 */     return actor.rotation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static World getWorld(Actor actor)
/*     */   {
/*  71 */     return actor.world;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean containsPoint(Actor actor, int px, int py)
/*     */   {
/*  85 */     return actor.containsPoint(px, py);
/*     */   }
/*     */   
/*     */   public static boolean intersects(Actor actor, Actor other)
/*     */   {
/*  90 */     return actor.intersects(other);
/*     */   }
/*     */   
/*     */   public static int toPixel(Actor actor, int x)
/*     */   {
/*  95 */     return actor.toPixel(x);
/*     */   }
/*     */   
/*     */   public static Rect getBoundingRect(Actor actor)
/*     */   {
/* 100 */     return actor.getBoundingRect();
/*     */   }
/*     */   
/*     */   public static void setData(Actor actor, Object n)
/*     */   {
/* 105 */     actor.setData(n);
/*     */   }
/*     */   
/*     */   public static Object getData(Actor actor)
/*     */   {
/* 110 */     return actor.getData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static GreenfootImage getDisplayImage(Actor actor)
/*     */   {
/* 121 */     return actor.getImage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static GreenfootImage getDragImage(Actor actor)
/*     */   {
/* 131 */     GreenfootImage image = actor.getImage();
/* 132 */     if (image == null) {
/* 133 */       image = Actor.greenfootImage;
/*     */     }
/* 135 */     return image;
/*     */   }
/*     */   
/*     */   public static void setDelegate(ActorDelegate instance)
/*     */   {
/* 140 */     Actor.setDelegate(instance);
/*     */   }
/*     */   
/*     */   public static int getSequenceNumber(Actor actor)
/*     */   {
/* 145 */     return actor.getSequenceNumber();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getLastPaintSeqNum(Actor actor)
/*     */   {
/* 155 */     return actor.getLastPaintSeqNum();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setLastPaintSeqNum(Actor actor, int num)
/*     */   {
/* 164 */     actor.setLastPaintSeqNum(num);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\ActorVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */