package greenfoot.collision;

import greenfoot.Actor;

public abstract interface CollisionQuery
{
  public abstract boolean checkCollision(Actor paramActor);
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\collision\CollisionQuery.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */