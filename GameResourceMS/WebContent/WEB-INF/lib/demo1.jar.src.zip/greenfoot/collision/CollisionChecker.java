package greenfoot.collision;

import greenfoot.Actor;
import java.awt.Graphics;
import java.util.List;

public abstract interface CollisionChecker
{
  public abstract void initialize(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean);
  
  public abstract void addObject(Actor paramActor);
  
  public abstract void removeObject(Actor paramActor);
  
  public abstract void updateObjectLocation(Actor paramActor, int paramInt1, int paramInt2);
  
  public abstract void updateObjectSize(Actor paramActor);
  
  public abstract <T extends Actor> List<T> getObjectsAt(int paramInt1, int paramInt2, Class<T> paramClass);
  
  public abstract <T extends Actor> List<T> getIntersectingObjects(Actor paramActor, Class<T> paramClass);
  
  public abstract <T extends Actor> List<T> getObjectsInRange(int paramInt1, int paramInt2, int paramInt3, Class<T> paramClass);
  
  public abstract <T extends Actor> List<T> getNeighbours(Actor paramActor, int paramInt, boolean paramBoolean, Class<T> paramClass);
  
  public abstract <T extends Actor> List<T> getObjectsInDirection(int paramInt1, int paramInt2, int paramInt3, int paramInt4, Class<T> paramClass);
  
  public abstract <T extends Actor> List<T> getObjects(Class<T> paramClass);
  
  public abstract List<Actor> getObjectsList();
  
  public abstract void startSequence();
  
  public abstract <T extends Actor> T getOneObjectAt(Actor paramActor, int paramInt1, int paramInt2, Class<T> paramClass);
  
  public abstract <T extends Actor> T getOneIntersectingObject(Actor paramActor, Class<T> paramClass);
  
  public abstract void paintDebug(Graphics paramGraphics);
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\collision\CollisionChecker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */