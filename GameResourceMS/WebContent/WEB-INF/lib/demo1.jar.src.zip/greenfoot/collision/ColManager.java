/*     */ package greenfoot.collision;
/*     */ 
/*     */ import greenfoot.Actor;
/*     */ import greenfoot.collision.ibsp.IBSPColChecker;
/*     */ import java.awt.Graphics;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColManager
/*     */   implements CollisionChecker
/*     */ {
/*  49 */   private Map<Class<? extends Actor>, LinkedList<Actor>> freeObjects = new HashMap();
/*     */   
/*     */ 
/*  52 */   private Set<Class<? extends Actor>> collisionClasses = new HashSet();
/*     */   
/*     */ 
/*  55 */   private CollisionChecker collisionChecker = new IBSPColChecker();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void makeCollisionObjects(Class<? extends Actor> cls, boolean includeSubclasses)
/*     */   {
/*  63 */     if (cls == null)
/*     */     {
/*  65 */       Set<Map.Entry<Class<? extends Actor>, LinkedList<Actor>>> entries = this.freeObjects.entrySet();
/*  66 */       for (Map.Entry<Class<? extends Actor>, LinkedList<Actor>> entry : entries)
/*     */       {
/*  68 */         for (Actor actor : (LinkedList)entry.getValue()) {
/*  69 */           this.collisionChecker.addObject(actor);
/*     */         }
/*  71 */         this.collisionClasses.add(entry.getKey());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*  76 */       this.freeObjects.clear();
/*     */     }
/*  78 */     else if (!this.collisionClasses.contains(cls))
/*     */     {
/*     */ 
/*  81 */       List<? extends Actor> classSet = (List)this.freeObjects.remove(cls);
/*     */       
/*  83 */       if (classSet != null) {
/*  84 */         this.collisionClasses.add(cls);
/*     */         
/*     */ 
/*     */ 
/*  88 */         for (Actor actor : classSet) {
/*  89 */           this.collisionChecker.addObject(actor);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  94 */     if (includeSubclasses)
/*     */     {
/*  96 */       Set<Map.Entry<Class<? extends Actor>, LinkedList<Actor>>> entries = new HashSet(this.freeObjects.entrySet());
/*     */       
/*     */ 
/*  99 */       for (Map.Entry<Class<? extends Actor>, LinkedList<Actor>> entry : entries) {
/* 100 */         if (cls.isAssignableFrom((Class)entry.getKey())) {
/* 101 */           makeCollisionObjects((Class)entry.getKey(), false);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T extends Actor> void prepareForCollision(Actor actor, Class<T> cls)
/*     */   {
/* 114 */     makeCollisionObjects(actor.getClass(), false);
/* 115 */     makeCollisionObjects(cls, true);
/*     */   }
/*     */   
/*     */   public void addObject(Actor actor)
/*     */   {
/* 120 */     Class<? extends Actor> cls = actor.getClass();
/*     */     
/* 122 */     if (this.collisionClasses.contains(cls)) {
/* 123 */       this.collisionChecker.addObject(actor);
/*     */     }
/*     */     else {
/* 126 */       LinkedList<Actor> classSet = (LinkedList)this.freeObjects.get(cls);
/* 127 */       if (classSet == null) {
/* 128 */         classSet = new LinkedList();
/* 129 */         this.freeObjects.put(cls, classSet);
/*     */       }
/* 131 */       classSet.add(actor);
/*     */     }
/*     */   }
/*     */   
/*     */   public <T extends Actor> List<T> getIntersectingObjects(Actor actor, Class<T> cls)
/*     */   {
/* 137 */     prepareForCollision(actor, cls);
/* 138 */     return this.collisionChecker.getIntersectingObjects(actor, cls);
/*     */   }
/*     */   
/*     */   public <T extends Actor> List<T> getNeighbours(Actor actor, int distance, boolean diag, Class<T> cls)
/*     */   {
/* 143 */     prepareForCollision(actor, cls);
/* 144 */     return this.collisionChecker.getNeighbours(actor, distance, diag, cls);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends Actor> List<T> getObjects(Class<T> cls)
/*     */   {
/* 150 */     List<T> result = this.collisionChecker.getObjects(cls);
/*     */     
/* 152 */     Set<Map.Entry<Class<? extends Actor>, LinkedList<Actor>>> entries = this.freeObjects.entrySet();
/* 153 */     for (Map.Entry<Class<? extends Actor>, LinkedList<Actor>> entry : entries) {
/* 154 */       if ((cls == null) || (cls.isAssignableFrom((Class)entry.getKey()))) {
/* 155 */         result.addAll((Collection)entry.getValue());
/*     */       }
/*     */     }
/* 158 */     return result;
/*     */   }
/*     */   
/*     */   public <T extends Actor> List<T> getObjectsAt(int x, int y, Class<T> cls)
/*     */   {
/* 163 */     makeCollisionObjects(cls, true);
/* 164 */     return this.collisionChecker.getObjectsAt(x, y, cls);
/*     */   }
/*     */   
/*     */   public <T extends Actor> List<T> getObjectsInDirection(int x, int y, int angle, int length, Class<T> cls)
/*     */   {
/* 169 */     makeCollisionObjects(cls, true);
/* 170 */     return this.collisionChecker.getObjectsInDirection(x, y, angle, length, cls);
/*     */   }
/*     */   
/*     */   public <T extends Actor> List<T> getObjectsInRange(int x, int y, int r, Class<T> cls)
/*     */   {
/* 175 */     makeCollisionObjects(cls, true);
/* 176 */     return this.collisionChecker.getObjectsInRange(x, y, r, cls);
/*     */   }
/*     */   
/*     */   public List<Actor> getObjectsList()
/*     */   {
/* 181 */     return getObjects(null);
/*     */   }
/*     */   
/*     */   public <T extends Actor> T getOneIntersectingObject(Actor object, Class<T> cls)
/*     */   {
/* 186 */     prepareForCollision(object, cls);
/* 187 */     return this.collisionChecker.getOneIntersectingObject(object, cls);
/*     */   }
/*     */   
/*     */   public <T extends Actor> T getOneObjectAt(Actor object, int dx, int dy, Class<T> cls)
/*     */   {
/* 192 */     prepareForCollision(object, cls);
/* 193 */     return this.collisionChecker.getOneObjectAt(object, dx, dy, cls);
/*     */   }
/*     */   
/*     */   public void initialize(int width, int height, int cellSize, boolean wrap)
/*     */   {
/* 198 */     this.collisionChecker.initialize(width, height, cellSize, wrap);
/*     */   }
/*     */   
/*     */   public void paintDebug(Graphics g)
/*     */   {
/* 203 */     this.collisionChecker.paintDebug(g);
/*     */   }
/*     */   
/*     */   public void removeObject(Actor object)
/*     */   {
/* 208 */     LinkedList<Actor> classSet = (LinkedList)this.freeObjects.get(object.getClass());
/* 209 */     if (classSet != null) {
/* 210 */       classSet.remove(object);
/*     */     }
/*     */     else {
/* 213 */       this.collisionChecker.removeObject(object);
/*     */     }
/*     */   }
/*     */   
/*     */   public void startSequence()
/*     */   {
/* 219 */     this.collisionChecker.startSequence();
/*     */   }
/*     */   
/*     */   public void updateObjectLocation(Actor object, int oldX, int oldY)
/*     */   {
/* 224 */     if (!this.freeObjects.containsKey(object.getClass())) {
/* 225 */       this.collisionChecker.updateObjectLocation(object, oldX, oldY);
/*     */     }
/*     */   }
/*     */   
/*     */   public void updateObjectSize(Actor object)
/*     */   {
/* 231 */     if (!this.freeObjects.containsKey(object.getClass())) {
/* 232 */       this.collisionChecker.updateObjectSize(object);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\collision\ColManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */