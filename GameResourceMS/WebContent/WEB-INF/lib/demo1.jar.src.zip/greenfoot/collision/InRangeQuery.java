/*    */ package greenfoot.collision;
/*    */ 
/*    */ import greenfoot.Actor;
/*    */ import greenfoot.ActorVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InRangeQuery
/*    */   implements CollisionQuery
/*    */ {
/*    */   private int x;
/*    */   private int y;
/*    */   private int r;
/*    */   
/*    */   public void init(int x, int y, int r)
/*    */   {
/* 48 */     this.x = x;
/* 49 */     this.y = y;
/* 50 */     this.r = r;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean checkCollision(Actor actor)
/*    */   {
/* 59 */     int actorX = ActorVisitor.toPixel(actor, ActorVisitor.getX(actor));
/* 60 */     int actorY = ActorVisitor.toPixel(actor, ActorVisitor.getY(actor));
/*    */     
/* 62 */     int dx = actorX - this.x;
/* 63 */     int dy = actorY - this.y;
/* 64 */     int dist = (int)Math.sqrt(dx * dx + dy * dy);
/*    */     
/* 66 */     return dist <= this.r;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\collision\InRangeQuery.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */