/*     */ package greenfoot.collision;
/*     */ 
/*     */ import greenfoot.Actor;
/*     */ import greenfoot.ActorVisitor;
/*     */ import java.awt.Graphics;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GridCollisionChecker
/*     */   implements CollisionChecker
/*     */ {
/*     */   private Set<Actor> objects;
/*     */   private boolean wrap;
/*     */   private GridWorld world;
/*     */   private int cellSize;
/*     */   
/*     */   class Cell
/*     */   {
/*  53 */     private HashMap<Class<?>, List<Actor>> classMap = new HashMap();
/*  54 */     private List<Actor> objects = new ArrayList();
/*     */     
/*     */     Cell() {}
/*     */     
/*  58 */     public void add(Actor thing) { Class<?> clazz = thing.getClass();
/*  59 */       List<Actor> list = (List)this.classMap.get(clazz);
/*  60 */       if (list == null) {
/*  61 */         list = new ArrayList();
/*  62 */         this.classMap.put(clazz, list);
/*     */       }
/*  64 */       if (!list.contains(thing)) {
/*  65 */         list.add(thing);
/*     */       }
/*  67 */       if (!this.objects.contains(thing)) {
/*  68 */         this.objects.add(thing);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public <T> List<T> get(Class<T> cls)
/*     */     {
/*  75 */       return (List)this.classMap.get(cls);
/*     */     }
/*     */     
/*     */     public void remove(Actor object)
/*     */     {
/*  80 */       this.objects.remove(object);
/*  81 */       List<Actor> classes = (List)this.classMap.get(object.getClass());
/*  82 */       if (classes != null) {
/*  83 */         classes.remove(object);
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean isEmpty()
/*     */     {
/*  89 */       return this.objects.isEmpty();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public List<Actor> getAll()
/*     */     {
/* 102 */       return this.objects;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private class GridWorld
/*     */   {
/*     */     protected GridCollisionChecker.Cell[][] world;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public GridWorld(int width, int height)
/*     */     {
/* 118 */       this.world = new GridCollisionChecker.Cell[width][height];
/*     */     }
/*     */     
/*     */     public GridCollisionChecker.Cell get(int x, int y)
/*     */     {
/* 123 */       return this.world[x][y];
/*     */     }
/*     */     
/*     */     public void set(int x, int y, GridCollisionChecker.Cell cell)
/*     */     {
/* 128 */       this.world[x][y] = cell;
/*     */     }
/*     */     
/*     */     public int getWidth()
/*     */     {
/* 133 */       return this.world.length;
/*     */     }
/*     */     
/*     */     public int getHeight()
/*     */     {
/* 138 */       return this.world[0].length;
/*     */     }
/*     */   }
/*     */   
/*     */   private class WrappingGridWorld extends GridCollisionChecker.GridWorld
/*     */   {
/*     */     public WrappingGridWorld(int width, int height)
/*     */     {
/* 146 */       super(width, height);
/*     */     }
/*     */     
/*     */     public GridCollisionChecker.Cell get(int x, int y)
/*     */     {
/* 151 */       x = GridCollisionChecker.this.wrap(x, getWidth());
/* 152 */       y = GridCollisionChecker.this.wrap(y, getHeight());
/* 153 */       return this.world[x][y];
/*     */     }
/*     */     
/*     */     public void set(int x, int y, GridCollisionChecker.Cell cell)
/*     */     {
/* 158 */       x = GridCollisionChecker.this.wrap(x, getWidth());
/* 159 */       y = GridCollisionChecker.this.wrap(y, getHeight());
/* 160 */       this.world[x][y] = cell;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Statistics
/*     */   {
/*     */     private static final String format = "%15s%15s%15s%15s%15s%15s";
/*     */     private long objectsAt;
/*     */     private long intersectionObjects;
/*     */     private long objectsInRange;
/*     */     private long neighbours;
/*     */     private long objectsInDirection;
/* 172 */     private long startTime = -1L;
/*     */     
/*     */     public void incGetObjectsAt() {
/* 175 */       initStartTime();
/* 176 */       this.objectsAt += 1L;
/*     */     }
/*     */     
/*     */     public void incGetIntersectingObjects() {
/* 180 */       initStartTime();
/* 181 */       this.intersectionObjects += 1L;
/*     */     }
/*     */     
/*     */     public void incGetObjectsInRange() {
/* 185 */       initStartTime();
/* 186 */       this.objectsInRange += 1L;
/*     */     }
/*     */     
/*     */     public void incGetNeighbours() {
/* 190 */       initStartTime();
/* 191 */       this.neighbours += 1L;
/*     */     }
/*     */     
/*     */     public void incGetObjectsInDirection() {
/* 195 */       initStartTime();
/* 196 */       this.objectsInDirection += 1L;
/*     */     }
/*     */     
/*     */     private void initStartTime()
/*     */     {
/* 201 */       if (this.startTime == -1L) {
/* 202 */         this.startTime = System.currentTimeMillis();
/*     */       }
/*     */     }
/*     */     
/*     */     public String toString() {
/* 207 */       return String.format("%15s%15s%15s%15s%15s%15s", new Object[] { Long.valueOf(this.startTime), Long.valueOf(this.objectsAt), Long.valueOf(this.intersectionObjects), Long.valueOf(this.objectsInRange), Long.valueOf(this.neighbours), Long.valueOf(this.objectsInDirection) });
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static String headerString()
/*     */     {
/* 218 */       return String.format("%15s%15s%15s%15s%15s%15s", new Object[] { "startTime", "objectsAt", "intersection", "oinRange", "neighbours", "inDirection" });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 237 */   private Statistics currentStats = new Statistics();
/* 238 */   private List<Statistics> allStats = new ArrayList();
/* 239 */   private static boolean PRINT_STATS = false;
/*     */   
/*     */ 
/*     */   public void initialize(int width, int height, int cellSize, boolean wrap)
/*     */   {
/* 244 */     this.wrap = wrap;
/* 245 */     this.cellSize = cellSize;
/* 246 */     this.objects = null;
/* 247 */     if (PRINT_STATS) {
/* 248 */       System.out.println(Statistics.headerString());
/* 249 */       this.objects = new TreeSet(new Comparator()
/*     */       {
/*     */         public int compare(Actor arg0, Actor arg1) {
/* 252 */           return arg0.hashCode() - arg1.hashCode();
/*     */         }
/*     */       });
/*     */     }
/*     */     else {
/* 257 */       this.objects = new HashSet();
/*     */     }
/*     */     
/* 260 */     if (wrap) {
/* 261 */       this.world = new WrappingGridWorld(width, height);
/*     */     }
/*     */     else {
/* 264 */       this.world = new GridWorld(width, height);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void addObject(Actor thing)
/*     */     throws ArrayIndexOutOfBoundsException
/*     */   {
/* 279 */     testBounds(thing);
/*     */     
/* 281 */     if (!this.objects.contains(thing)) {
/* 282 */       int xpos = ActorVisitor.getX(thing);
/* 283 */       int ypos = ActorVisitor.getY(thing);
/* 284 */       Cell cell = this.world.get(xpos, ypos);
/* 285 */       if (cell == null) {
/* 286 */         cell = new Cell();
/* 287 */         this.world.set(xpos, ypos, cell);
/*     */       }
/* 289 */       cell.add(thing);
/* 290 */       this.objects.add(thing);
/*     */     }
/*     */   }
/*     */   
/*     */   private void testBounds(Actor thing)
/*     */   {
/* 296 */     int ax = ActorVisitor.getX(thing);
/* 297 */     int ay = ActorVisitor.getY(thing);
/*     */     
/* 299 */     if (ax >= getWidth()) {
/* 300 */       throw new ArrayIndexOutOfBoundsException(ax);
/*     */     }
/* 302 */     if (ay >= getHeight()) {
/* 303 */       throw new ArrayIndexOutOfBoundsException(ay);
/*     */     }
/* 305 */     if (ax < 0) {
/* 306 */       throw new ArrayIndexOutOfBoundsException(ax);
/*     */     }
/* 308 */     if (ay < 0) {
/* 309 */       throw new ArrayIndexOutOfBoundsException(ay);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends Actor> List<T> getObjectsAt(int x, int y, Class<T> cls)
/*     */   {
/* 322 */     if (this.wrap) {
/* 323 */       x = wrap(x, this.world.getWidth());
/* 324 */       y = wrap(y, this.world.getWidth());
/*     */     }
/* 326 */     List<T> objectsThere = new ArrayList();
/* 327 */     for (Iterator<Actor> iter = this.objects.iterator(); iter.hasNext();) {
/* 328 */       this.currentStats.incGetObjectsAt();
/* 329 */       Actor actor = (Actor)iter.next();
/* 330 */       int ax = x * this.cellSize + this.cellSize / 2;
/* 331 */       int ay = y * this.cellSize + this.cellSize / 2;
/* 332 */       if (((cls == null) || (cls.isInstance(actor))) && (ActorVisitor.containsPoint(actor, ax, y - ay))) {
/* 333 */         objectsThere.add(actor);
/*     */       }
/*     */     }
/* 336 */     return objectsThere;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends Actor> List<T> getObjectsInRange(int x, int y, int r, Class<T> cls)
/*     */   {
/* 364 */     Iterator<Actor> iter = this.objects.iterator();
/* 365 */     List<T> neighbours = new ArrayList();
/* 366 */     while (iter.hasNext()) {
/* 367 */       Object o = iter.next();
/* 368 */       this.currentStats.incGetObjectsInRange();
/* 369 */       if ((cls == null) || (cls.isInstance(o))) {
/* 370 */         Actor g = (Actor)o;
/* 371 */         if (distance(x, y, g) <= r) {
/* 372 */           neighbours.add(g);
/*     */         }
/*     */       }
/*     */     }
/* 376 */     return neighbours;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private double distance(int x, int y, Actor actor)
/*     */   {
/* 393 */     double gx = ActorVisitor.getX(actor);
/* 394 */     double gy = ActorVisitor.getY(actor);
/* 395 */     double dx = Math.abs(gx - x);
/* 396 */     double dy = Math.abs(gy - y);
/*     */     
/* 398 */     if (this.wrap) {
/* 399 */       double dxWrap = getWidth() - dx;
/* 400 */       double dyWrap = getWidth() - dy;
/* 401 */       if (dx >= dxWrap) {
/* 402 */         dx = dxWrap;
/*     */       }
/* 404 */       if (dy >= dyWrap) {
/* 405 */         dy = dyWrap;
/*     */       }
/*     */     }
/*     */     
/* 409 */     return Math.sqrt(dx * dx + dy * dy);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void removeObject(Actor object)
/*     */   {
/* 420 */     int ax = ActorVisitor.getX(object);
/* 421 */     int ay = ActorVisitor.getY(object);
/* 422 */     Cell cell = this.world.get(ax, ay);
/* 423 */     if (cell != null) {
/* 424 */       cell.remove(object);
/* 425 */       if (cell.isEmpty()) {
/* 426 */         this.world.set(ax, ay, null);
/*     */       }
/*     */     }
/* 429 */     this.objects.remove(object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWidth()
/*     */   {
/* 437 */     return this.world.getWidth();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHeight()
/*     */   {
/* 445 */     return this.world.getHeight();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateObjectLocation(Actor object, int oldX, int oldY)
/*     */   {
/* 461 */     Cell cell = this.world.get(oldX, oldY);
/* 462 */     if (cell != null) {
/* 463 */       cell.remove(object);
/* 464 */       if (cell.isEmpty())
/*     */       {
/* 466 */         this.world.set(oldX, oldY, null);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 471 */     int ax = ActorVisitor.getX(object);
/* 472 */     int ay = ActorVisitor.getY(object);
/* 473 */     cell = this.world.get(ax, ay);
/* 474 */     if (cell == null) {
/* 475 */       cell = new Cell();
/* 476 */       this.world.set(ax, ay, cell);
/*     */     }
/* 478 */     cell.add(object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateObjectSize(Actor object) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends Actor> List<T> getIntersectingObjects(Actor actor, Class<T> cls)
/*     */   {
/* 494 */     List<T> intersecting = new ArrayList();
/* 495 */     for (Iterator<Actor> iter = this.objects.iterator(); iter.hasNext();) {
/* 496 */       Actor element = (Actor)iter.next();
/* 497 */       this.currentStats.incGetIntersectingObjects();
/* 498 */       if ((element != actor) && (ActorVisitor.intersects(actor, element)) && ((cls == null) || (cls.isInstance(element)))) {
/* 499 */         intersecting.add(element);
/*     */       }
/*     */     }
/* 502 */     return intersecting;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends Actor> List<T> getNeighbours(Actor actor, int distance, boolean diag, Class<T> cls)
/*     */   {
/* 511 */     int x = ActorVisitor.getX(actor);
/* 512 */     int y = ActorVisitor.getY(actor);
/* 513 */     List<T> c = new ArrayList();
/* 514 */     if (diag) {
/* 515 */       for (int dx = x - distance; dx <= x + distance; dx++) {
/* 516 */         if (!this.wrap) {
/* 517 */           if (dx >= 0)
/*     */           {
/* 519 */             if (dx >= this.world.getWidth())
/*     */               break; }
/*     */         } else {
/* 522 */           for (int dy = y - distance; dy <= y + distance; dy++) {
/* 523 */             if (!this.wrap) {
/* 524 */               if (dy >= 0)
/*     */               {
/* 526 */                 if (dy >= this.world.getHeight())
/*     */                   break;
/*     */               }
/* 529 */             } else if ((dx != x) || (dy != y))
/*     */             {
/* 531 */               Cell cell = this.world.get(dx, dy);
/* 532 */               this.currentStats.incGetNeighbours();
/* 533 */               if (cell != null) {
/* 534 */                 Collection<T> found = cell.get(cls);
/* 535 */                 if (found != null)
/* 536 */                   c.addAll(found);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     } else {
/* 543 */       int d = distance;
/* 544 */       int xStart = x;
/* 545 */       int yStart = y;
/*     */       
/* 547 */       int dyEnd = d;
/* 548 */       for (int dx = 0; dx <= d; dx++) {
/* 549 */         for (int dy = dx - d; dy <= dyEnd; dy++) {
/* 550 */           int xPos = xStart + dx;
/* 551 */           int xNeg = xStart - dx;
/* 552 */           int yPos = yStart + dy;
/* 553 */           if (!this.wrap) {
/* 554 */             if (yPos >= this.world.getHeight()) {
/*     */               break;
/*     */             }
/* 557 */             if (yPos < 0) {}
/*     */ 
/*     */ 
/*     */           }
/* 561 */           else if ((dx != 0) || (dy != 0))
/*     */           {
/*     */ 
/* 564 */             this.currentStats.incGetNeighbours();
/* 565 */             if (withinBounds(xPos, getWidth())) {
/* 566 */               Cell cell = this.world.get(xPos, yPos);
/* 567 */               if (cell != null) {
/* 568 */                 Collection<T> found = cell.get(cls);
/* 569 */                 if (found != null) {
/* 570 */                   c.addAll(found);
/*     */                 }
/*     */               }
/*     */             }
/* 574 */             if ((dx != 0) && (withinBounds(xNeg, getWidth()))) {
/* 575 */               Cell cell = this.world.get(xNeg, yPos);
/* 576 */               if (cell != null) {
/* 577 */                 Collection<T> found = cell.get(cls);
/* 578 */                 if (found != null)
/* 579 */                   c.addAll(found);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/* 584 */         dyEnd--;
/*     */       }
/*     */     }
/* 587 */     return c;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends Actor> List<T> getObjectsInDirection(int x, int y, int angle, int length, Class<T> cls)
/*     */   {
/* 612 */     List<T> result = new ArrayList();
/* 613 */     double dy = 2.0D * Math.sin(Math.toRadians(angle));
/* 614 */     double dx = 2.0D * Math.cos(Math.toRadians(angle));
/* 615 */     int lxMax = (int)Math.abs(Math.round(length * Math.cos(Math.toRadians(angle))));
/* 616 */     int lyMax = (int)Math.abs(Math.round(length * Math.sin(Math.toRadians(angle))));
/*     */     
/*     */     int stepy;
/*     */     int stepy;
/* 620 */     if (dy < 0.0D) {
/* 621 */       dy = -dy;
/* 622 */       stepy = -1;
/*     */     }
/*     */     else {
/* 625 */       stepy = 1; }
/*     */     int stepx;
/* 627 */     int stepx; if (dx < 0.0D) {
/* 628 */       dx = -dx;
/* 629 */       stepx = -1;
/*     */     }
/*     */     else {
/* 632 */       stepx = 1;
/*     */     }
/*     */     
/* 635 */     result.addAll(getObjectsAt(x, y, cls));
/* 636 */     if (dx > dy) {
/* 637 */       double fraction = dy - dx / 2.0D;
/* 638 */       for (int l = 0; l < lxMax; l++) {
/* 639 */         this.currentStats.incGetObjectsInDirection();
/* 640 */         if (fraction >= 0.0D) {
/* 641 */           y += stepy;
/* 642 */           fraction -= dx;
/*     */         }
/* 644 */         x += stepx;
/* 645 */         fraction += dy;
/*     */         
/* 647 */         result.addAll(getObjectsAt(x, y, cls));
/*     */       }
/*     */     }
/*     */     else {
/* 651 */       double fraction = dx - dy / 2.0D;
/* 652 */       for (int l = 0; l < lyMax; l++) {
/* 653 */         this.currentStats.incGetObjectsInDirection();
/* 654 */         if (fraction >= 0.0D) {
/* 655 */           x += stepx;
/* 656 */           fraction -= dy;
/*     */         }
/* 658 */         y += stepy;
/* 659 */         fraction += dx;
/* 660 */         result.addAll(getObjectsAt(x, y, cls));
/*     */       }
/*     */     }
/*     */     
/* 664 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean withinBounds(int x, int width)
/*     */   {
/* 677 */     return (this.wrap) || ((!this.wrap) && (x >= 0) && (x < width));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int wrap(int x, int width)
/*     */   {
/* 685 */     int remainder = x % width;
/* 686 */     if (remainder < 0) {
/* 687 */       return width + remainder;
/*     */     }
/*     */     
/* 690 */     return remainder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void startSequence()
/*     */   {
/* 697 */     if (PRINT_STATS) {
/* 698 */       System.out.println(this.currentStats);
/*     */     }
/* 700 */     this.allStats.add(this.currentStats);
/* 701 */     this.currentStats = new Statistics();
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends Actor> List<T> getObjects(Class<T> cls)
/*     */   {
/* 707 */     List<T> objectsThere = new ArrayList();
/* 708 */     for (Iterator<Actor> iter = this.objects.iterator(); iter.hasNext();) {
/* 709 */       this.currentStats.incGetObjectsAt();
/* 710 */       Actor actor = (Actor)iter.next();
/* 711 */       if ((cls == null) || (cls.isInstance(actor))) {
/* 712 */         objectsThere.add(actor);
/*     */       }
/*     */     }
/* 715 */     return objectsThere;
/*     */   }
/*     */   
/*     */   public List<Actor> getObjectsList()
/*     */   {
/* 720 */     List<Actor> l = new ArrayList(this.objects);
/* 721 */     return l;
/*     */   }
/*     */   
/*     */   public <T extends Actor> T getOneObjectAt(Actor actor, int dx, int dy, Class<T> cls)
/*     */   {
/* 726 */     List<T> neighbours = getObjectsAt(dx, dy, cls);
/* 727 */     neighbours.remove(actor);
/* 728 */     if (!neighbours.isEmpty()) {
/* 729 */       return (Actor)neighbours.get(0);
/*     */     }
/* 731 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends Actor> T getOneIntersectingObject(Actor object, Class<T> cls)
/*     */   {
/* 737 */     List<T> intersecting = getIntersectingObjects(object, cls);
/* 738 */     if (!intersecting.isEmpty()) {
/* 739 */       return (Actor)intersecting.get(0);
/*     */     }
/* 741 */     return null;
/*     */   }
/*     */   
/*     */   public void paintDebug(Graphics g) {}
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\collision\GridCollisionChecker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */