/*    */ package greenfoot.collision;
/*    */ 
/*    */ import greenfoot.Actor;
/*    */ import greenfoot.ActorVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PointCollisionQuery
/*    */   implements CollisionQuery
/*    */ {
/*    */   private int x;
/*    */   private int y;
/*    */   private Class<?> cls;
/*    */   
/*    */   public void init(int x, int y, Class<?> cls)
/*    */   {
/* 46 */     this.x = x;
/* 47 */     this.y = y;
/* 48 */     this.cls = cls;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean checkCollision(Actor actor)
/*    */   {
/* 56 */     if ((this.cls != null) && (!this.cls.isInstance(actor))) {
/* 57 */       return false;
/*    */     }
/* 59 */     return ActorVisitor.containsPoint(actor, this.x, this.y);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\collision\PointCollisionQuery.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */