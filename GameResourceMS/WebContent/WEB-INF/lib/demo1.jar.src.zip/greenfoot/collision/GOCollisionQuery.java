/*    */ package greenfoot.collision;
/*    */ 
/*    */ import greenfoot.Actor;
/*    */ import greenfoot.ActorVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GOCollisionQuery
/*    */   implements CollisionQuery
/*    */ {
/*    */   private Class<?> cls;
/*    */   private Actor compareObject;
/*    */   
/*    */   public void init(Class<?> cls, Actor actor)
/*    */   {
/* 47 */     this.cls = cls;
/* 48 */     this.compareObject = actor;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean checkCollision(Actor other)
/*    */   {
/* 56 */     if ((this.cls != null) && (!this.cls.isInstance(other))) {
/* 57 */       return false;
/*    */     }
/*    */     
/* 60 */     if (this.compareObject == null) {
/* 61 */       return true;
/*    */     }
/* 63 */     if (ActorVisitor.intersects(this.compareObject, other)) {
/* 64 */       return true;
/*    */     }
/* 66 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\collision\GOCollisionQuery.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */