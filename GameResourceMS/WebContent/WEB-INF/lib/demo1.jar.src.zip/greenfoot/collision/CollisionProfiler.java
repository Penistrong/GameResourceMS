/*     */ package greenfoot.collision;
/*     */ 
/*     */ import greenfoot.Actor;
/*     */ import java.awt.Graphics;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CollisionProfiler
/*     */   implements CollisionChecker
/*     */ {
/*  36 */   private static boolean to_console = true;
/*     */   
/*     */ 
/*  39 */   private static boolean verbose = true;
/*     */   
/*     */   private static final int MAX_SEQ_COUNT = 100;
/*     */   
/*     */   private CollisionChecker checker;
/*     */   
/*     */   private long addObjectTime;
/*     */   
/*     */   private long removeObjectTime;
/*     */   
/*     */   private long updateObjectLocationTime;
/*     */   
/*     */   private long updateObjectSizeTime;
/*     */   
/*     */   private long getObjectsAtTime;
/*     */   
/*     */   private long getIntersectingObjectsTime;
/*     */   private long getObjectsInRangeTime;
/*     */   private long getNeighboursTime;
/*     */   private long getObjectsInDirectionTime;
/*     */   private long getObjectsTime;
/*     */   private long getOneObjectAtTime;
/*     */   private long getOneIntersectingObjectTime;
/*     */   private int sequenceCount;
/*     */   private int sequences;
/*     */   private PrintStream fileStream;
/*     */   private int objectCount;
/*     */   
/*     */   public CollisionProfiler(CollisionChecker checker)
/*     */   {
/*  69 */     this.checker = checker;
/*     */   }
/*     */   
/*     */   public void initialize(int width, int height, int cellSize, boolean wrap)
/*     */   {
/*  74 */     this.checker.initialize(width, height, cellSize, wrap);
/*  75 */     if (to_console) {
/*  76 */       this.fileStream = System.out;
/*     */     }
/*     */     else {
/*  79 */       File f = new File(System.getProperty("user.home"));
/*  80 */       f = new File(f, "profile.txt");
/*     */       try {
/*  82 */         f.createNewFile();
/*     */       }
/*     */       catch (IOException e1)
/*     */       {
/*  86 */         e1.printStackTrace();
/*     */       }
/*     */       try {
/*  89 */         this.fileStream = new PrintStream(f);
/*     */       }
/*     */       catch (FileNotFoundException e)
/*     */       {
/*  93 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void addObject(Actor actor)
/*     */   {
/* 100 */     long t1 = System.nanoTime();
/* 101 */     this.checker.addObject(actor);
/* 102 */     long t2 = System.nanoTime();
/* 103 */     this.addObjectTime += t2 - t1;
/*     */   }
/*     */   
/*     */   public synchronized void removeObject(Actor object)
/*     */   {
/* 108 */     long t1 = System.nanoTime();
/* 109 */     this.checker.removeObject(object);
/* 110 */     long t2 = System.nanoTime();
/* 111 */     this.removeObjectTime += t2 - t1;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void updateObjectLocation(Actor object, int oldX, int oldY)
/*     */   {
/* 117 */     long t1 = System.nanoTime();
/* 118 */     this.checker.updateObjectLocation(object, oldX, oldY);
/* 119 */     long t2 = System.nanoTime();
/* 120 */     this.updateObjectLocationTime += t2 - t1;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void updateObjectSize(Actor object)
/*     */   {
/* 126 */     long t1 = System.nanoTime();
/* 127 */     this.checker.updateObjectSize(object);
/* 128 */     long t2 = System.nanoTime();
/* 129 */     this.updateObjectSizeTime += t2 - t1;
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends Actor> List<T> getObjectsAt(int x, int y, Class<T> cls)
/*     */   {
/* 135 */     long t1 = System.nanoTime();
/* 136 */     List<T> l = this.checker.getObjectsAt(x, y, cls);
/* 137 */     long t2 = System.nanoTime();
/* 138 */     this.getObjectsAtTime += t2 - t1;
/* 139 */     return l;
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends Actor> List<T> getIntersectingObjects(Actor actor, Class<T> cls)
/*     */   {
/* 145 */     long t1 = System.nanoTime();
/* 146 */     List<T> l = this.checker.getIntersectingObjects(actor, cls);
/* 147 */     long t2 = System.nanoTime();
/* 148 */     this.getIntersectingObjectsTime += t2 - t1;
/* 149 */     return l;
/*     */   }
/*     */   
/*     */   public <T extends Actor> List<T> getObjectsInRange(int x, int y, int r, Class<T> cls)
/*     */   {
/* 154 */     long t1 = System.nanoTime();
/* 155 */     List<T> l = this.checker.getObjectsInRange(x, y, r, cls);
/* 156 */     long t2 = System.nanoTime();
/* 157 */     this.getObjectsInRangeTime += t2 - t1;
/* 158 */     return l;
/*     */   }
/*     */   
/*     */   public <T extends Actor> List<T> getNeighbours(Actor actor, int distance, boolean diag, Class<T> cls)
/*     */   {
/* 163 */     long t1 = System.nanoTime();
/* 164 */     List<T> l = this.checker.getNeighbours(actor, distance, diag, cls);
/* 165 */     long t2 = System.nanoTime();
/* 166 */     this.getNeighboursTime += t2 - t1;
/* 167 */     return l;
/*     */   }
/*     */   
/*     */   public <T extends Actor> List<T> getObjectsInDirection(int x, int y, int angle, int length, Class<T> cls)
/*     */   {
/* 172 */     long t1 = System.nanoTime();
/* 173 */     List<T> l = this.checker.getObjectsInDirection(x, y, angle, length, cls);
/* 174 */     long t2 = System.nanoTime();
/* 175 */     this.getObjectsInDirectionTime += t2 - t1;
/* 176 */     return l;
/*     */   }
/*     */   
/*     */   public synchronized <T extends Actor> List<T> getObjects(Class<T> cls)
/*     */   {
/* 181 */     long t1 = System.nanoTime();
/* 182 */     List<T> l = this.checker.getObjects(cls);
/* 183 */     long t2 = System.nanoTime();
/* 184 */     this.getObjectsTime += t2 - t1;
/* 185 */     return l;
/*     */   }
/*     */   
/*     */   public List<Actor> getObjectsList()
/*     */   {
/* 190 */     return this.checker.getObjectsList();
/*     */   }
/*     */   
/*     */   public void startSequence()
/*     */   {
/* 195 */     this.checker.startSequence();
/* 196 */     this.sequenceCount += 1;
/* 197 */     this.objectCount += this.checker.getObjects(null).size();
/* 198 */     if (this.sequenceCount > 100)
/*     */     {
/* 200 */       printTimes();
/*     */       
/* 202 */       this.addObjectTime = 0L;
/* 203 */       this.removeObjectTime = 0L;
/* 204 */       this.updateObjectLocationTime = 0L;
/* 205 */       this.updateObjectSizeTime = 0L;
/* 206 */       this.getObjectsAtTime = 0L;
/* 207 */       this.getIntersectingObjectsTime = 0L;
/* 208 */       this.getObjectsInRangeTime = 0L;
/* 209 */       this.getNeighboursTime = 0L;
/* 210 */       this.getObjectsInDirectionTime = 0L;
/* 211 */       this.getObjectsTime = 0L;
/* 212 */       this.getOneObjectAtTime = 0L;
/* 213 */       this.getOneIntersectingObjectTime = 0L;
/*     */       
/* 215 */       this.objectCount = 0;
/*     */       
/* 217 */       this.sequenceCount = 0;
/*     */     }
/*     */     
/*     */ 
/* 221 */     this.fileStream.flush();
/*     */   }
/*     */   
/*     */   private void printTimes()
/*     */   {
/* 226 */     this.sequences += 1;
/* 227 */     if (verbose) {
/* 228 */       this.fileStream.println("Sequence # " + this.sequences);
/*     */     }
/*     */     
/* 231 */     long totalTime = 0L;
/* 232 */     totalTime += this.addObjectTime;
/* 233 */     totalTime += this.removeObjectTime;
/* 234 */     totalTime += this.updateObjectLocationTime;
/* 235 */     totalTime += this.updateObjectSizeTime;
/* 236 */     totalTime += this.getObjectsAtTime;
/* 237 */     totalTime += this.getIntersectingObjectsTime;
/* 238 */     totalTime += this.getObjectsInRangeTime;
/* 239 */     totalTime += this.getNeighboursTime;
/* 240 */     totalTime += this.getObjectsInDirectionTime;
/* 241 */     totalTime += this.getObjectsTime;
/* 242 */     totalTime += this.getOneObjectAtTime;
/* 243 */     totalTime += this.getOneIntersectingObjectTime;
/*     */     
/*     */ 
/* 246 */     if (verbose) {
/* 247 */       this.fileStream.println("addObjectTime                : " + this.addObjectTime);
/* 248 */       this.fileStream.println("removeObjectTime             : " + this.removeObjectTime);
/* 249 */       this.fileStream.println("updateObjectLocationTime     : " + this.updateObjectLocationTime);
/* 250 */       this.fileStream.println("updateObjectSizeTime         : " + this.updateObjectSizeTime);
/* 251 */       this.fileStream.println("getObjectsAtTime             : " + this.getObjectsAtTime);
/* 252 */       this.fileStream.println("getIntersectingObjectsTime   : " + this.getIntersectingObjectsTime);
/* 253 */       this.fileStream.println("getObjectsInRanageTime       : " + this.getObjectsInRangeTime);
/* 254 */       this.fileStream.println("getNeighboursTime            : " + this.getNeighboursTime);
/* 255 */       this.fileStream.println("getObjectsInDirectionTime    : " + this.getObjectsInDirectionTime);
/* 256 */       this.fileStream.println("getObjectsTime               : " + this.getObjectsTime);
/* 257 */       this.fileStream.println("getOneObjectAtTime           : " + this.getOneObjectAtTime);
/* 258 */       this.fileStream.println("getOneIntersectingObjectTime : " + this.getOneIntersectingObjectTime);
/*     */     }
/*     */     
/*     */ 
/* 262 */     this.fileStream.println(totalTime + "," + this.objectCount / this.sequenceCount);
/* 263 */     this.fileStream.println("========================");
/*     */   }
/*     */   
/*     */   public <T extends Actor> T getOneObjectAt(Actor actor, int dx, int dy, Class<T> cls)
/*     */   {
/* 268 */     long t1 = System.nanoTime();
/* 269 */     T o = this.checker.getOneObjectAt(actor, dx, dy, cls);
/* 270 */     long t2 = System.nanoTime();
/* 271 */     this.getOneObjectAtTime += t2 - t1;
/* 272 */     return o;
/*     */   }
/*     */   
/*     */   public <T extends Actor> T getOneIntersectingObject(Actor object, Class<T> cls)
/*     */   {
/* 277 */     long t1 = System.nanoTime();
/* 278 */     T o = this.checker.getOneIntersectingObject(object, cls);
/* 279 */     long t2 = System.nanoTime();
/* 280 */     this.getOneIntersectingObjectTime += t2 - t1;
/* 281 */     return o;
/*     */   }
/*     */   
/*     */   public void paintDebug(Graphics g) {}
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\collision\CollisionProfiler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */