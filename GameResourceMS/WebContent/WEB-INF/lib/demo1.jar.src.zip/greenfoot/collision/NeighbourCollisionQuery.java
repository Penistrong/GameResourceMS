/*    */ package greenfoot.collision;
/*    */ 
/*    */ import greenfoot.Actor;
/*    */ import greenfoot.ActorVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NeighbourCollisionQuery
/*    */   implements CollisionQuery
/*    */ {
/*    */   private int x;
/*    */   private int y;
/*    */   private int distance;
/*    */   private boolean diag;
/*    */   private Class<?> cls;
/*    */   
/*    */   public void init(int x, int y, int distance, boolean diag, Class<?> cls)
/*    */   {
/* 54 */     this.x = x;
/* 55 */     this.y = y;
/* 56 */     this.distance = distance;
/* 57 */     this.diag = diag;
/* 58 */     this.cls = cls;
/*    */   }
/*    */   
/*    */   public boolean checkCollision(Actor actor)
/*    */   {
/* 63 */     if ((this.cls != null) && (!this.cls.isInstance(actor))) {
/* 64 */       return false;
/*    */     }
/*    */     
/* 67 */     int actorX = ActorVisitor.getX(actor);
/* 68 */     int actorY = ActorVisitor.getY(actor);
/*    */     
/* 70 */     if ((actorX == this.x) && (actorY == this.y)) {
/* 71 */       return false;
/*    */     }
/* 73 */     int ax = ActorVisitor.getX(actor);
/* 74 */     int ay = ActorVisitor.getY(actor);
/* 75 */     if (this.diag) {
/* 76 */       int x1 = this.x - this.distance;
/* 77 */       int y1 = this.y - this.distance;
/* 78 */       int x2 = this.x + this.distance;
/* 79 */       int y2 = this.y + this.distance;
/* 80 */       return (ax >= x1) && (ay >= y1) && (ax <= x2) && (ay <= y2);
/*    */     }
/* 82 */     int dx = Math.abs(ax - this.x);
/* 83 */     int dy = Math.abs(ay - this.y);
/* 84 */     return dx + dy <= this.distance;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\collision\NeighbourCollisionQuery.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */