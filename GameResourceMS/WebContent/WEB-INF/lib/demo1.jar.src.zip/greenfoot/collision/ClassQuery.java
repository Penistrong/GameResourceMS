/*    */ package greenfoot.collision;
/*    */ 
/*    */ import greenfoot.Actor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassQuery
/*    */   implements CollisionQuery
/*    */ {
/*    */   private Class<?> cls;
/*    */   private CollisionQuery subQuery;
/*    */   
/*    */   public ClassQuery(Class<?> cls, CollisionQuery subQuery)
/*    */   {
/* 33 */     this.cls = cls;
/* 34 */     this.subQuery = subQuery;
/*    */   }
/*    */   
/*    */   public boolean checkCollision(Actor actor)
/*    */   {
/* 39 */     if (this.cls.isInstance(actor)) {
/* 40 */       return this.subQuery.checkCollision(actor);
/*    */     }
/*    */     
/* 43 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\collision\ClassQuery.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */