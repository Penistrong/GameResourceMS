/*     */ package greenfoot.collision.ibsp;
/*     */ 
/*     */ import greenfoot.Actor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BSPNode
/*     */ {
/*     */   private Map<Actor, ActorNode> actors;
/*     */   private BSPNode parent;
/*     */   private Rect area;
/*     */   private int splitAxis;
/*     */   private int splitPos;
/*     */   private BSPNode left;
/*     */   private BSPNode right;
/*     */   private boolean areaRipple;
/*     */   
/*     */   public BSPNode(Rect area, int splitAxis, int splitPos)
/*     */   {
/*  52 */     this.area = area;
/*  53 */     this.splitAxis = splitAxis;
/*  54 */     this.splitPos = splitPos;
/*     */     
/*     */ 
/*  57 */     this.actors = new HashMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setChild(int side, BSPNode child)
/*     */   {
/*  66 */     if (side == 0) {
/*  67 */       this.left = child;
/*  68 */       if (child != null) {
/*  69 */         child.parent = this;
/*     */       }
/*     */     }
/*     */     else {
/*  73 */       this.right = child;
/*  74 */       if (child != null) {
/*  75 */         child.parent = this;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setArea(Rect area)
/*     */   {
/*  82 */     this.area = area;
/*  83 */     this.areaRipple = true;
/*     */   }
/*     */   
/*     */   public void setSplitAxis(int axis)
/*     */   {
/*  88 */     if (axis != this.splitAxis) {
/*  89 */       this.splitAxis = axis;
/*  90 */       this.areaRipple = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public void setSplitPos(int pos)
/*     */   {
/*  96 */     if (pos != this.splitPos) {
/*  97 */       this.splitPos = pos;
/*  98 */       this.areaRipple = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public int getSplitAxis()
/*     */   {
/* 104 */     return this.splitAxis;
/*     */   }
/*     */   
/*     */   public int getSplitPos()
/*     */   {
/* 109 */     return this.splitPos;
/*     */   }
/*     */   
/*     */   public Rect getLeftArea()
/*     */   {
/* 114 */     if (this.splitAxis == 0) {
/* 115 */       return new Rect(this.area.getX(), this.area.getY(), this.splitPos - this.area.getX(), this.area.getHeight());
/*     */     }
/*     */     
/* 118 */     return new Rect(this.area.getX(), this.area.getY(), this.area.getWidth(), this.splitPos - this.area.getY());
/*     */   }
/*     */   
/*     */ 
/*     */   public Rect getRightArea()
/*     */   {
/* 124 */     if (this.splitAxis == 0) {
/* 125 */       return new Rect(this.splitPos, this.area.getY(), this.area.getRight() - this.splitPos, this.area.getHeight());
/*     */     }
/*     */     
/* 128 */     return new Rect(this.area.getX(), this.splitPos, this.area.getWidth(), this.area.getTop() - this.splitPos);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rect getArea()
/*     */   {
/* 138 */     return this.area;
/*     */   }
/*     */   
/*     */   private void resizeChildren()
/*     */   {
/* 143 */     if (this.left != null) {
/* 144 */       this.left.setArea(getLeftArea());
/*     */     }
/* 146 */     if (this.right != null) {
/* 147 */       this.right.setArea(getRightArea());
/*     */     }
/*     */   }
/*     */   
/*     */   public BSPNode getLeft()
/*     */   {
/* 153 */     if (this.areaRipple) {
/* 154 */       resizeChildren();
/* 155 */       this.areaRipple = false;
/*     */     }
/* 157 */     return this.left;
/*     */   }
/*     */   
/*     */   public BSPNode getRight()
/*     */   {
/* 162 */     if (this.areaRipple) {
/* 163 */       resizeChildren();
/* 164 */       this.areaRipple = false;
/*     */     }
/* 166 */     return this.right;
/*     */   }
/*     */   
/*     */   public BSPNode getParent()
/*     */   {
/* 171 */     return this.parent;
/*     */   }
/*     */   
/*     */   public void setParent(BSPNode parent)
/*     */   {
/* 176 */     this.parent = parent;
/*     */   }
/*     */   
/*     */   public int getChildSide(BSPNode child)
/*     */   {
/* 181 */     if (this.left == child) {
/* 182 */       return 0;
/*     */     }
/*     */     
/* 185 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 191 */     return "bsp" + hashCode();
/*     */   }
/*     */   
/*     */   public void addActor(Actor actor)
/*     */   {
/* 196 */     this.actors.put(actor, new ActorNode(actor, this));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsActor(Actor actor)
/*     */   {
/* 205 */     ActorNode anode = (ActorNode)this.actors.get(actor);
/* 206 */     if (anode != null) {
/* 207 */       anode.mark();
/* 208 */       return true;
/*     */     }
/* 210 */     return false;
/*     */   }
/*     */   
/*     */   public void actorRemoved(Actor actor)
/*     */   {
/* 215 */     this.actors.remove(actor);
/*     */   }
/*     */   
/*     */   public int numberActors()
/*     */   {
/* 220 */     return this.actors.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 228 */     return this.actors.isEmpty();
/*     */   }
/*     */   
/*     */   public Iterator<Map.Entry<Actor, ActorNode>> getEntriesIterator()
/*     */   {
/* 233 */     return this.actors.entrySet().iterator();
/*     */   }
/*     */   
/*     */   public Iterator<Actor> getActorsIterator()
/*     */   {
/* 238 */     return this.actors.keySet().iterator();
/*     */   }
/*     */   
/*     */   public List<Actor> getActorsList()
/*     */   {
/* 243 */     return new ArrayList(this.actors.keySet());
/*     */   }
/*     */   
/*     */ 
/*     */   void blankNode()
/*     */   {
/* 249 */     this.actors.clear();
/*     */   }
/*     */   
/*     */   public void areaChanged()
/*     */   {
/* 254 */     this.areaRipple = true;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\collision\ibsp\BSPNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */