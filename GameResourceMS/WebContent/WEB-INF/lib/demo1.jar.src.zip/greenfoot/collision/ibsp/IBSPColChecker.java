/*     */ package greenfoot.collision.ibsp;
/*     */ 
/*     */ import greenfoot.Actor;
/*     */ import greenfoot.ActorVisitor;
/*     */ import greenfoot.collision.ClassQuery;
/*     */ import greenfoot.collision.CollisionChecker;
/*     */ import greenfoot.collision.CollisionQuery;
/*     */ import greenfoot.collision.GOCollisionQuery;
/*     */ import greenfoot.collision.InRangeQuery;
/*     */ import greenfoot.collision.NeighbourCollisionQuery;
/*     */ import greenfoot.collision.PointCollisionQuery;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IBSPColChecker
/*     */   implements CollisionChecker
/*     */ {
/*     */   public static final int X_AXIS = 0;
/*     */   public static final int Y_AXIS = 1;
/*     */   public static final int PARENT_LEFT = 0;
/*     */   public static final int PARENT_RIGHT = 1;
/*     */   public static final int PARENT_NONE = 3;
/*     */   public static final int REBALANCE_THRESHOLD = 20;
/*  52 */   private GOCollisionQuery actorQuery = new GOCollisionQuery();
/*  53 */   private NeighbourCollisionQuery neighbourQuery = new NeighbourCollisionQuery();
/*  54 */   private PointCollisionQuery pointQuery = new PointCollisionQuery();
/*  55 */   private InRangeQuery inRangeQuery = new InRangeQuery();
/*     */   
/*     */   private int cellSize;
/*     */   
/*     */   private BSPNode bspTree;
/*     */   
/*  61 */   public static boolean debugging = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initialize(int width, int height, int cellSize, boolean wrap)
/*     */   {
/*  68 */     this.cellSize = cellSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addObject(Actor actor)
/*     */   {
/*  77 */     Rect bounds = getActorBounds(actor);
/*  78 */     if (this.bspTree == null) {
/*     */       int splitPos;
/*     */       int splitAxis;
/*     */       int splitPos;
/*  82 */       if (bounds.getWidth() > bounds.getHeight()) {
/*  83 */         int splitAxis = 0;
/*  84 */         splitPos = bounds.getMiddleX();
/*     */       }
/*     */       else {
/*  87 */         splitAxis = 1;
/*  88 */         splitPos = bounds.getMiddleY();
/*     */       }
/*  90 */       this.bspTree = BSPNodeCache.getBSPNode();
/*  91 */       this.bspTree.getArea().copyFrom(bounds);
/*  92 */       this.bspTree.setSplitAxis(splitAxis);
/*  93 */       this.bspTree.setSplitPos(splitPos);
/*  94 */       this.bspTree.addActor(actor);
/*     */     }
/*     */     else {
/*  97 */       Rect treeArea = this.bspTree.getArea();
/*  98 */       while (!treeArea.contains(bounds))
/*     */       {
/* 100 */         if (bounds.getX() < treeArea.getX())
/*     */         {
/* 102 */           int bx = treeArea.getX() - treeArea.getWidth();
/* 103 */           Rect newArea = new Rect(bx, treeArea.getY(), treeArea.getRight() - bx, treeArea.getHeight());
/*     */           
/* 105 */           BSPNode newTop = BSPNodeCache.getBSPNode();
/* 106 */           newTop.getArea().copyFrom(newArea);
/* 107 */           newTop.setSplitAxis(0);
/* 108 */           newTop.setSplitPos(treeArea.getX());
/* 109 */           newTop.setChild(1, this.bspTree);
/* 110 */           this.bspTree = newTop;
/* 111 */           treeArea = newArea;
/*     */         }
/* 113 */         if (bounds.getRight() > treeArea.getRight())
/*     */         {
/* 115 */           int bx = treeArea.getRight() + treeArea.getWidth();
/* 116 */           Rect newArea = new Rect(treeArea.getX(), treeArea.getY(), bx - treeArea.getX(), treeArea.getHeight());
/*     */           
/* 118 */           BSPNode newTop = BSPNodeCache.getBSPNode();
/* 119 */           newTop.getArea().copyFrom(newArea);
/* 120 */           newTop.setSplitAxis(0);
/* 121 */           newTop.setSplitPos(treeArea.getRight());
/* 122 */           newTop.setChild(0, this.bspTree);
/* 123 */           this.bspTree = newTop;
/* 124 */           treeArea = newArea;
/*     */         }
/* 126 */         if (bounds.getY() < treeArea.getY())
/*     */         {
/* 128 */           int by = treeArea.getY() - treeArea.getHeight();
/* 129 */           Rect newArea = new Rect(treeArea.getX(), by, treeArea.getWidth(), treeArea.getTop() - by);
/*     */           
/* 131 */           BSPNode newTop = BSPNodeCache.getBSPNode();
/* 132 */           newTop.getArea().copyFrom(newArea);
/* 133 */           newTop.setSplitAxis(1);
/* 134 */           newTop.setSplitPos(treeArea.getY());
/* 135 */           newTop.setChild(1, this.bspTree);
/* 136 */           this.bspTree = newTop;
/* 137 */           treeArea = newArea;
/*     */         }
/* 139 */         if (bounds.getTop() > treeArea.getTop())
/*     */         {
/* 141 */           int by = treeArea.getTop() + treeArea.getHeight();
/* 142 */           Rect newArea = new Rect(treeArea.getX(), treeArea.getY(), treeArea.getWidth(), by - treeArea.getY());
/*     */           
/* 144 */           BSPNode newTop = BSPNodeCache.getBSPNode();
/* 145 */           newTop.getArea().copyFrom(newArea);
/* 146 */           newTop.setSplitAxis(1);
/* 147 */           newTop.setSplitPos(treeArea.getTop());
/* 148 */           newTop.setChild(0, this.bspTree);
/* 149 */           this.bspTree = newTop;
/* 150 */           treeArea = newArea;
/*     */         }
/*     */       }
/*     */       
/* 154 */       insertObject(actor, bounds, bounds, treeArea, this.bspTree);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void checkConsistency(boolean checkActorBounds)
/*     */   {
/* 164 */     if (!debugging) {
/* 165 */       return;
/*     */     }
/*     */     
/* 168 */     LinkedList<BSPNode> stack = new LinkedList();
/*     */     
/* 170 */     stack.add(this.bspTree);
/* 171 */     while (!stack.isEmpty()) {
/* 172 */       BSPNode node = (BSPNode)stack.removeLast();
/* 173 */       if (node != null) {
/* 174 */         Rect nodeArea = node.getArea();
/* 175 */         List<Actor> actors = node.getActorsList();
/*     */         
/* 177 */         for (Actor actor : actors)
/*     */         {
/* 179 */           Rect actorBounds = getActorBounds(actor);
/* 180 */           if ((checkActorBounds) && (!nodeArea.intersects(actorBounds))) {
/* 181 */             throw new IllegalStateException("Actor not contained within region bounds?");
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 187 */         if (node.getLeft() != null) {
/* 188 */           Rect leftArea = node.getLeft().getArea();
/* 189 */           if (!Rect.equals(leftArea, node.getLeftArea())) {
/* 190 */             throw new IllegalStateException("Areas wrong!");
/*     */           }
/*     */         }
/*     */         
/* 194 */         if (node.getRight() != null) {
/* 195 */           Rect rightArea = node.getRight().getArea();
/* 196 */           if (!Rect.equals(rightArea, node.getRightArea())) {
/* 197 */             throw new IllegalStateException("Areas wrong!");
/*     */           }
/*     */         }
/*     */         
/* 201 */         stack.add(node.getLeft());
/* 202 */         stack.add(node.getRight());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void insertObject(Actor actor, Rect actorBounds, Rect bounds, Rect area, BSPNode node)
/*     */   {
/* 220 */     if (node.containsActor(actor)) {
/* 221 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 226 */     if ((node.isEmpty()) || ((area.getWidth() <= actorBounds.getWidth()) && (area.getHeight() <= actorBounds.getHeight())))
/*     */     {
/* 228 */       node.addActor(actor);
/* 229 */       return;
/*     */     }
/*     */     
/*     */ 
/* 233 */     Rect leftArea = node.getLeftArea();
/* 234 */     Rect rightArea = node.getRightArea();
/*     */     
/* 236 */     Rect leftIntersects = Rect.getIntersection(leftArea, bounds);
/* 237 */     Rect rightIntersects = Rect.getIntersection(rightArea, bounds);
/*     */     
/* 239 */     if (leftIntersects != null) {
/* 240 */       if (node.getLeft() == null) {
/* 241 */         BSPNode newLeft = createNewNode(leftArea);
/* 242 */         newLeft.addActor(actor);
/* 243 */         node.setChild(0, newLeft);
/*     */       }
/*     */       else {
/* 246 */         insertObject(actor, actorBounds, leftIntersects, leftArea, node.getLeft());
/*     */       }
/*     */     }
/*     */     
/* 250 */     if (rightIntersects != null) {
/* 251 */       if (node.getRight() == null) {
/* 252 */         BSPNode newRight = createNewNode(rightArea);
/* 253 */         newRight.addActor(actor);
/* 254 */         node.setChild(1, newRight);
/*     */       }
/*     */       else {
/* 257 */         insertObject(actor, actorBounds, rightIntersects, rightArea, node.getRight());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private BSPNode createNewNode(Rect area)
/*     */   {
/*     */     int splitPos;
/*     */     int splitAxis;
/*     */     int splitPos;
/* 268 */     if (area.getWidth() > area.getHeight()) {
/* 269 */       int splitAxis = 0;
/* 270 */       splitPos = area.getMiddleX();
/*     */     }
/*     */     else {
/* 273 */       splitAxis = 1;
/* 274 */       splitPos = area.getMiddleY();
/*     */     }
/* 276 */     BSPNode newNode = BSPNodeCache.getBSPNode();
/* 277 */     newNode.setArea(area);
/* 278 */     newNode.setSplitAxis(splitAxis);
/* 279 */     newNode.setSplitPos(splitPos);
/* 280 */     return newNode;
/*     */   }
/*     */   
/*     */   public final Rect getActorBounds(Actor actor)
/*     */   {
/* 285 */     Rect r = ActorVisitor.getBoundingRect(actor);
/* 286 */     return r;
/*     */   }
/*     */   
/*     */   public static void printTree(BSPNode node, String indent, String lead)
/*     */   {
/* 291 */     if (node == null) {
/* 292 */       return;
/*     */     }
/*     */     
/* 295 */     String xx = lead;
/* 296 */     xx = xx + node + ": ";
/* 297 */     xx = xx + node.getArea();
/* 298 */     println(xx);
/*     */     
/* 300 */     BSPNode left = node.getLeft();
/* 301 */     BSPNode right = node.getRight();
/*     */     
/* 303 */     if (left != null) { String newIndent;
/*     */       String newIndent;
/* 305 */       if (right != null) {
/* 306 */         newIndent = indent + " |";
/*     */       }
/*     */       else {
/* 309 */         newIndent = indent + "  ";
/*     */       }
/* 311 */       printTree(left, newIndent, indent + " \\L-");
/*     */     }
/*     */     
/* 314 */     if (right != null) {
/* 315 */       printTree(node.getRight(), indent + "  ", indent + " \\R-");
/*     */     }
/*     */   }
/*     */   
/*     */   public void printTree()
/*     */   {
/* 321 */     printTree(this.bspTree, "", "");
/*     */   }
/*     */   
/*     */ 
/*     */   public void removeObject(Actor object)
/*     */   {
/* 327 */     ActorNode node = getNodeForActor(object);
/*     */     
/* 329 */     while (node != null) {
/* 330 */       BSPNode bspNode = node.getBSPNode();
/* 331 */       node.remove();
/* 332 */       checkRemoveNode(bspNode);
/* 333 */       node = getNodeForActor(object);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private BSPNode checkRemoveNode(BSPNode node)
/*     */   {
/* 345 */     while ((node != null) && (node.isEmpty())) {
/* 346 */       BSPNode parent = node.getParent();
/* 347 */       int side = parent != null ? parent.getChildSide(node) : 3;
/* 348 */       BSPNode left = node.getLeft();
/* 349 */       BSPNode right = node.getRight();
/* 350 */       if (left == null) {
/* 351 */         if (parent != null) {
/* 352 */           if (right != null) {
/* 353 */             right.getArea().copyFrom(node.getArea());
/* 354 */             right.areaChanged();
/*     */           }
/* 356 */           parent.setChild(side, right);
/*     */         }
/*     */         else {
/* 359 */           this.bspTree = right;
/* 360 */           if (right != null) {
/* 361 */             right.setParent(null);
/*     */           }
/*     */         }
/* 364 */         node.setChild(1, null);
/* 365 */         BSPNodeCache.returnNode(node);
/* 366 */         node = parent;
/*     */       } else {
/* 368 */         if (right != null) break;
/* 369 */         if (parent != null) {
/* 370 */           if (left != null) {
/* 371 */             left.getArea().copyFrom(node.getArea());
/* 372 */             left.areaChanged();
/*     */           }
/* 374 */           parent.setChild(side, left);
/*     */         }
/*     */         else {
/* 377 */           this.bspTree = left;
/* 378 */           if (left != null) {
/* 379 */             left.setParent(null);
/*     */           }
/*     */         }
/* 382 */         node.setChild(0, null);
/* 383 */         BSPNodeCache.returnNode(node);
/* 384 */         node = parent;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 392 */     return node;
/*     */   }
/*     */   
/* 395 */   private static int dbgCounter = 0;
/*     */   
/*     */   private static void println(String s)
/*     */   {
/* 399 */     if (dbgCounter < 3000) {
/* 400 */       System.out.println(s);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static ActorNode getNodeForActor(Actor object)
/*     */   {
/* 407 */     return (ActorNode)ActorVisitor.getData(object);
/*     */   }
/*     */   
/*     */   public static void setNodeForActor(Actor object, ActorNode node)
/*     */   {
/* 412 */     ActorVisitor.setData(object, node);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void updateObject(Actor object)
/*     */   {
/* 421 */     ActorNode node = getNodeForActor(object);
/* 422 */     if (node == null)
/*     */     {
/*     */ 
/* 425 */       return;
/*     */     }
/*     */     
/* 428 */     Rect newBounds = getActorBounds(object);
/* 429 */     if (!this.bspTree.getArea().contains(newBounds))
/*     */     {
/* 431 */       while (node != null) {
/* 432 */         BSPNode rNode = node.getBSPNode();
/* 433 */         node.remove();
/* 434 */         checkRemoveNode(rNode);
/* 435 */         node = node.getNext();
/*     */       }
/* 437 */       addObject(object);
/* 438 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 445 */     while (node != null)
/*     */     {
/* 447 */       BSPNode bspNode = node.getBSPNode();
/* 448 */       Rect bspArea = bspNode.getArea();
/* 449 */       if (bspArea.contains(newBounds))
/*     */       {
/*     */ 
/* 452 */         ActorNode iter = getNodeForActor(object);
/* 453 */         while (iter != null) {
/* 454 */           if (iter != node) {
/* 455 */             BSPNode rNode = iter.getBSPNode();
/* 456 */             iter.remove();
/* 457 */             checkRemoveNode(rNode);
/*     */           }
/* 459 */           iter = iter.getNext();
/*     */         }
/* 461 */         return;
/*     */       }
/* 463 */       if (!bspArea.intersects(newBounds))
/*     */       {
/* 465 */         BSPNode rNode = node.getBSPNode();
/* 466 */         node.remove();
/* 467 */         checkRemoveNode(rNode);
/*     */         
/*     */ 
/* 470 */         if (this.bspTree == null) {
/* 471 */           addObject(object);
/* 472 */           return;
/*     */         }
/*     */       }
/* 475 */       node.clearMark();
/* 476 */       node = node.getNext();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 483 */     node = getNodeForActor(object);
/*     */     
/*     */     BSPNode bspNode;
/* 486 */     if (node != null) {
/* 487 */       BSPNode bspNode = node.getBSPNode();
/* 488 */       while ((bspNode != null) && (!bspNode.getArea().contains(newBounds))) {
/* 489 */         bspNode = bspNode.getParent();
/*     */       }
/* 491 */       if (bspNode == null)
/*     */       {
/*     */ 
/* 494 */         while (node != null) {
/* 495 */           bspNode = node.getBSPNode();
/* 496 */           node.remove();
/* 497 */           checkRemoveNode(bspNode);
/* 498 */           node = node.getNext();
/*     */         }
/*     */         
/* 501 */         addObject(object);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 506 */       bspNode = this.bspTree;
/*     */     }
/*     */     
/*     */ 
/* 510 */     Rect bspArea = bspNode.getArea();
/* 511 */     insertObject(object, newBounds, newBounds, bspArea, bspNode);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 517 */     node = getNodeForActor(object);
/* 518 */     while (node != null) {
/* 519 */       if (!node.checkMark()) {
/* 520 */         bspNode = node.getBSPNode();
/* 521 */         node.remove();
/* 522 */         checkRemoveNode(bspNode);
/*     */       }
/* 524 */       node = node.getNext();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void updateObjectLocation(Actor object, int oldX, int oldY)
/*     */   {
/* 532 */     updateObject(object);
/*     */   }
/*     */   
/*     */   public void updateObjectSize(Actor object)
/*     */   {
/* 537 */     updateObject(object);
/*     */   }
/*     */   
/*     */   private List<Actor> getIntersectingObjects(Rect r, CollisionQuery query)
/*     */   {
/* 542 */     Set<Actor> set = new HashSet();
/* 543 */     getIntersectingObjects(r, query, set, this.bspTree);
/* 544 */     List<Actor> l = new ArrayList(set);
/* 545 */     return l;
/*     */   }
/*     */   
/*     */   private void getIntersectingObjects(Rect r, CollisionQuery query, Set<Actor> resultSet, BSPNode startNode)
/*     */   {
/* 550 */     LinkedList<BSPNode> nodeStack = new LinkedList();
/*     */     
/* 552 */     if (startNode != null) {
/* 553 */       nodeStack.add(startNode);
/*     */     }
/*     */     
/* 556 */     while (!nodeStack.isEmpty()) {
/* 557 */       BSPNode node = (BSPNode)nodeStack.removeLast();
/* 558 */       if (node.getArea().intersects(r)) {
/* 559 */         Iterator<Actor> i = node.getActorsIterator();
/* 560 */         while (i.hasNext()) {
/* 561 */           Actor actor = (Actor)i.next();
/* 562 */           if ((query.checkCollision(actor)) && 
/* 563 */             (!resultSet.contains(actor))) {
/* 564 */             resultSet.add(actor);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 569 */         BSPNode left = node.getLeft();
/* 570 */         BSPNode right = node.getRight();
/* 571 */         if (left != null) {
/* 572 */           nodeStack.add(left);
/*     */         }
/* 574 */         if (right != null) {
/* 575 */           nodeStack.add(right);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Actor checkForOneCollision(Actor ignore, BSPNode node, CollisionQuery query)
/*     */   {
/* 587 */     Iterator<Actor> i = node.getActorsIterator();
/*     */     
/* 589 */     while (i.hasNext()) {
/* 590 */       Actor candidate = (Actor)i.next();
/* 591 */       if ((ignore != candidate) && (query.checkCollision(candidate))) {
/* 592 */         return candidate;
/*     */       }
/*     */     }
/*     */     
/* 596 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Actor getOneObjectDownTree(Actor ignore, Rect r, CollisionQuery query, BSPNode startNode)
/*     */   {
/* 612 */     if (startNode == null) {
/* 613 */       return null;
/*     */     }
/*     */     
/* 616 */     LinkedList<BSPNode> nodeStack = new LinkedList();
/* 617 */     nodeStack.add(startNode);
/*     */     
/* 619 */     while (!nodeStack.isEmpty()) {
/* 620 */       BSPNode node = (BSPNode)nodeStack.removeLast();
/* 621 */       if (node.getArea().intersects(r)) {
/* 622 */         Actor res = checkForOneCollision(ignore, node, query);
/* 623 */         if (res != null) {
/* 624 */           return res;
/*     */         }
/*     */         
/* 627 */         BSPNode left = node.getLeft();
/* 628 */         BSPNode right = node.getRight();
/* 629 */         if (left != null) {
/* 630 */           nodeStack.add(left);
/*     */         }
/* 632 */         if (right != null) {
/* 633 */           nodeStack.add(right);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 638 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Actor getOneIntersectingDown(Rect r, CollisionQuery query, Actor actor)
/*     */   {
/* 650 */     if (this.bspTree == null) {
/* 651 */       return null;
/*     */     }
/*     */     
/* 654 */     LinkedList<BSPNode> nodeStack = new LinkedList();
/* 655 */     nodeStack.add(this.bspTree);
/*     */     
/* 657 */     while (!nodeStack.isEmpty()) {
/* 658 */       BSPNode node = (BSPNode)nodeStack.removeLast();
/* 659 */       if (node.getArea().contains(r)) {
/* 660 */         Actor res = checkForOneCollision(actor, node, query);
/* 661 */         if (res != null) {
/* 662 */           return res;
/*     */         }
/*     */         
/* 665 */         BSPNode left = node.getLeft();
/* 666 */         BSPNode right = node.getRight();
/* 667 */         if (left != null) {
/* 668 */           nodeStack.add(left);
/*     */         }
/* 670 */         if (right != null) {
/* 671 */           nodeStack.add(right);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 676 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Actor getOneIntersectingUp(Rect r, CollisionQuery query, Actor actor, BSPNode start)
/*     */   {
/* 688 */     while ((start != null) && (!start.getArea().contains(r))) {
/* 689 */       Actor res = checkForOneCollision(actor, start, query);
/* 690 */       if (res != null) {
/* 691 */         return res;
/*     */       }
/* 693 */       start = start.getParent();
/*     */     }
/* 695 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends Actor> List<T> getObjectsAt(int x, int y, Class<T> cls)
/*     */   {
/* 701 */     synchronized (this.pointQuery) {
/* 702 */       int px = x * this.cellSize + this.cellSize / 2;
/* 703 */       int py = y * this.cellSize + this.cellSize / 2;
/* 704 */       this.pointQuery.init(px, py, cls);
/* 705 */       return getIntersectingObjects(new Rect(px, py, 1, 1), this.pointQuery);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public <T extends Actor> List<T> getIntersectingObjects(Actor actor, Class<T> cls)
/*     */   {
/* 713 */     Rect r = getActorBounds(actor);
/*     */     
/* 715 */     synchronized (this.actorQuery) {
/* 716 */       this.actorQuery.init(cls, actor);
/* 717 */       return getIntersectingObjects(r, this.actorQuery);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public <T extends Actor> List<T> getObjectsInRange(int x, int y, int r, Class<T> cls)
/*     */   {
/* 725 */     int halfCell = this.cellSize / 2;
/* 726 */     int size = 2 * r * this.cellSize;
/*     */     
/* 728 */     Rect rect = new Rect((x - r) * this.cellSize + halfCell, (y - r) * this.cellSize + halfCell, size, size);
/*     */     
/*     */ 
/*     */     List<T> result;
/*     */     
/*     */ 
/* 734 */     synchronized (this.actorQuery) {
/* 735 */       this.actorQuery.init(cls, null);
/* 736 */       result = getIntersectingObjects(rect, this.actorQuery);
/*     */     }
/*     */     
/* 739 */     Iterator<T> i = result.iterator();
/* 740 */     synchronized (this.inRangeQuery) {
/* 741 */       this.inRangeQuery.init(x * this.cellSize + halfCell, y * this.cellSize + halfCell, r * this.cellSize);
/* 742 */       while (i.hasNext()) {
/* 743 */         if (!this.inRangeQuery.checkCollision((Actor)i.next())) {
/* 744 */           i.remove();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 749 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public <T extends Actor> List<T> getNeighbours(Actor actor, int distance, boolean diag, Class<T> cls)
/*     */   {
/* 756 */     int x = ActorVisitor.getX(actor);
/* 757 */     int y = ActorVisitor.getY(actor);
/* 758 */     int xPixel = x * this.cellSize;
/* 759 */     int yPixel = y * this.cellSize;
/* 760 */     int dPixel = distance * this.cellSize;
/*     */     
/* 762 */     Rect r = new Rect(xPixel - dPixel, yPixel - dPixel, dPixel * 2 + 1, dPixel * 2 + 1);
/*     */     
/* 764 */     synchronized (this.neighbourQuery) {
/* 765 */       this.neighbourQuery.init(x, y, distance, diag, cls);
/* 766 */       List<T> res = getIntersectingObjects(r, this.neighbourQuery);
/* 767 */       return res;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public <T extends Actor> List<T> getObjectsInDirection(int x, int y, int angle, int length, Class<T> cls)
/*     */   {
/* 775 */     return new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends Actor> List<T> getObjects(Class<T> cls)
/*     */   {
/* 781 */     Set<T> set = new HashSet();
/* 782 */     LinkedList<BSPNode> nodeStack = new LinkedList();
/*     */     
/* 784 */     if (this.bspTree != null) {
/* 785 */       nodeStack.add(this.bspTree);
/*     */     }
/*     */     
/* 788 */     while (!nodeStack.isEmpty()) {
/* 789 */       BSPNode node = (BSPNode)nodeStack.removeLast();
/* 790 */       Iterator<Actor> i = node.getActorsIterator();
/* 791 */       while (i.hasNext()) {
/* 792 */         Actor actor = (Actor)i.next();
/* 793 */         if ((cls == null) || (cls.isInstance(actor))) {
/* 794 */           set.add(actor);
/*     */         }
/*     */       }
/* 797 */       BSPNode left = node.getLeft();
/* 798 */       BSPNode right = node.getRight();
/* 799 */       if (left != null) {
/* 800 */         nodeStack.add(left);
/*     */       }
/* 802 */       if (right != null) {
/* 803 */         nodeStack.add(right);
/*     */       }
/*     */     }
/*     */     
/* 807 */     List<T> list = new ArrayList(set);
/* 808 */     return list;
/*     */   }
/*     */   
/*     */   public List<Actor> getObjectsList()
/*     */   {
/* 813 */     return getObjects(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void startSequence() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public <T extends Actor> T getOneObjectAt(Actor object, int dx, int dy, Class<T> cls)
/*     */   {
/* 825 */     synchronized (this.pointQuery) {
/* 826 */       int px = dx * this.cellSize + this.cellSize / 2;
/* 827 */       int py = dy * this.cellSize + this.cellSize / 2;
/* 828 */       this.pointQuery.init(px, py, cls);
/* 829 */       CollisionQuery query = this.pointQuery;
/* 830 */       if (cls != null) {
/* 831 */         query = new ClassQuery(cls, this.pointQuery);
/*     */       }
/*     */       
/*     */ 
/* 835 */       return getOneIntersectingDown(new Rect(px, py, 1, 1), query, object);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends Actor> T getOneIntersectingObject(Actor actor, Class<T> cls)
/*     */   {
/* 842 */     Rect r = getActorBounds(actor);
/* 843 */     synchronized (this.actorQuery) {
/* 844 */       this.actorQuery.init(cls, actor);
/*     */       
/* 846 */       ActorNode node = getNodeForActor(actor);
/*     */       do {
/* 848 */         BSPNode bspNode = node.getBSPNode();
/* 849 */         T ret = getOneObjectDownTree(actor, r, this.actorQuery, bspNode);
/* 850 */         if (ret != null) {
/* 851 */           return ret;
/*     */         }
/* 853 */         ret = getOneIntersectingUp(r, this.actorQuery, actor, bspNode.getParent());
/* 854 */         if (ret != null) {
/* 855 */           return ret;
/*     */         }
/* 857 */         node = node.getNext();
/*     */       }
/* 859 */       while (node != null);
/* 860 */       return getOneIntersectingDown(r, this.actorQuery, actor);
/*     */     }
/*     */   }
/*     */   
/*     */   public void paintDebug(Graphics g)
/*     */   {
/* 866 */     LinkedList<BSPNode> nodeStack = new LinkedList();
/* 867 */     nodeStack.add(this.bspTree);
/*     */     
/* 869 */     Color oldColor = g.getColor();
/*     */     
/*     */ 
/* 872 */     g.setColor(Color.RED);
/*     */     
/* 874 */     while (!nodeStack.isEmpty()) {
/* 875 */       BSPNode node = (BSPNode)nodeStack.removeLast();
/* 876 */       if (node != null) {
/* 877 */         Rect area = node.getArea();
/* 878 */         g.drawRect(area.getX(), area.getY(), area.getWidth(), area.getHeight());
/* 879 */         nodeStack.add(node.getLeft());
/* 880 */         nodeStack.add(node.getRight());
/*     */       }
/*     */     }
/*     */     
/* 884 */     g.setColor(oldColor);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\collision\ibsp\IBSPColChecker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */