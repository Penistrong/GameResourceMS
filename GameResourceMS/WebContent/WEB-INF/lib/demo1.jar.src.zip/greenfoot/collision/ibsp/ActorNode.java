/*     */ package greenfoot.collision.ibsp;
/*     */ 
/*     */ import greenfoot.Actor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ActorNode
/*     */ {
/*     */   private Actor actor;
/*     */   private BSPNode node;
/*     */   private ActorNode next;
/*     */   private ActorNode prev;
/*     */   private boolean mark;
/*     */   
/*     */   public ActorNode(Actor actor, BSPNode node)
/*     */   {
/*  43 */     this.actor = actor;
/*  44 */     this.node = node;
/*     */     
/*     */ 
/*  47 */     ActorNode first = IBSPColChecker.getNodeForActor(actor);
/*  48 */     this.next = first;
/*  49 */     IBSPColChecker.setNodeForActor(actor, this);
/*  50 */     if (this.next != null) {
/*  51 */       this.next.prev = this;
/*     */     }
/*     */     
/*  54 */     this.mark = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearMark()
/*     */   {
/*  63 */     this.mark = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mark()
/*     */   {
/*  72 */     this.mark = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean checkMark()
/*     */   {
/*  82 */     boolean markVal = this.mark;
/*  83 */     this.mark = false;
/*  84 */     return markVal;
/*     */   }
/*     */   
/*     */   public Actor getActor()
/*     */   {
/*  89 */     return this.actor;
/*     */   }
/*     */   
/*     */   public BSPNode getBSPNode()
/*     */   {
/*  94 */     return this.node;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ActorNode getNext()
/*     */   {
/* 103 */     return this.next;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void remove()
/*     */   {
/* 114 */     removed();
/* 115 */     this.node.actorRemoved(this.actor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removed()
/*     */   {
/* 125 */     if (this.prev == null) {
/* 126 */       IBSPColChecker.setNodeForActor(this.actor, this.next);
/*     */     }
/*     */     else {
/* 129 */       this.prev.next = this.next;
/*     */     }
/*     */     
/* 132 */     if (this.next != null) {
/* 133 */       this.next.prev = this.prev;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\collision\ibsp\ActorNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */