/*     */ package greenfoot.collision.ibsp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Rect
/*     */ {
/*     */   private int x;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int y;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int width;
/*     */   
/*     */ 
/*     */ 
/*     */   private int height;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rect(int x, int y, int width, int height)
/*     */   {
/*  30 */     this.x = x;
/*  31 */     this.y = y;
/*  32 */     this.width = width;
/*  33 */     this.height = height;
/*     */   }
/*     */   
/*     */   public void copyFrom(Rect other)
/*     */   {
/*  38 */     this.x = other.x;
/*  39 */     this.y = other.y;
/*  40 */     this.width = other.width;
/*  41 */     this.height = other.height;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  46 */     return "rect (" + this.x + "," + this.y + ")-(" + (this.x + this.width) + "," + (this.y + this.height) + ")";
/*     */   }
/*     */   
/*     */   public int getX()
/*     */   {
/*  51 */     return this.x;
/*     */   }
/*     */   
/*     */   public int getMiddleX()
/*     */   {
/*  56 */     return this.x + this.width / 2;
/*     */   }
/*     */   
/*     */   public int getRight()
/*     */   {
/*  61 */     return this.x + this.width;
/*     */   }
/*     */   
/*     */   public int getY()
/*     */   {
/*  66 */     return this.y;
/*     */   }
/*     */   
/*     */   public int getMiddleY()
/*     */   {
/*  71 */     return this.y + this.height / 2;
/*     */   }
/*     */   
/*     */   public int getTop()
/*     */   {
/*  76 */     return this.y + this.height;
/*     */   }
/*     */   
/*     */   public int getWidth()
/*     */   {
/*  81 */     return this.width;
/*     */   }
/*     */   
/*     */   public int getHeight()
/*     */   {
/*  86 */     return this.height;
/*     */   }
/*     */   
/*     */   public boolean contains(Rect other)
/*     */   {
/*  91 */     return (this.x <= other.x) && (this.y <= other.y) && (getTop() >= other.getTop()) && (getRight() >= other.getRight());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rect getIntersection(Rect a, Rect b)
/*     */   {
/*  99 */     int a_x = a.getX();
/* 100 */     int a_r = a.getRight();
/* 101 */     int a_y = a.getY();
/* 102 */     int a_t = a.getTop();
/*     */     
/* 104 */     int b_x = b.getX();
/* 105 */     int b_r = b.getRight();
/* 106 */     int b_y = b.getY();
/* 107 */     int b_t = b.getTop();
/*     */     
/*     */ 
/* 110 */     int i_x = Math.max(a_x, b_x);
/* 111 */     int i_r = Math.min(a_r, b_r);
/* 112 */     int i_y = Math.max(a_y, b_y);
/* 113 */     int i_t = Math.min(a_t, b_t);
/* 114 */     if ((i_x >= i_r) || (i_y >= i_t)) {
/* 115 */       return null;
/*     */     }
/*     */     
/* 118 */     return new Rect(i_x, i_y, i_r - i_x, i_t - i_y);
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean equals(Rect a, Rect b)
/*     */   {
/* 124 */     return (a.x == b.x) && (a.y == b.y) && (a.width == b.width) && (a.height == b.height);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setX(int x)
/*     */   {
/* 130 */     this.x = x;
/*     */   }
/*     */   
/*     */   public void setY(int y)
/*     */   {
/* 135 */     this.y = y;
/*     */   }
/*     */   
/*     */   public void setWidth(int width)
/*     */   {
/* 140 */     this.width = width;
/*     */   }
/*     */   
/*     */   public void setHeight(int height)
/*     */   {
/* 145 */     this.height = height;
/*     */   }
/*     */   
/*     */   public boolean intersects(Rect otherBounds)
/*     */   {
/* 150 */     if (otherBounds.x >= getRight())
/* 151 */       return false;
/* 152 */     if (this.x >= otherBounds.getRight()) {
/* 153 */       return false;
/*     */     }
/* 155 */     if (otherBounds.y >= getTop())
/* 156 */       return false;
/* 157 */     if (this.y >= otherBounds.getTop()) {
/* 158 */       return false;
/*     */     }
/* 160 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\collision\ibsp\Rect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */