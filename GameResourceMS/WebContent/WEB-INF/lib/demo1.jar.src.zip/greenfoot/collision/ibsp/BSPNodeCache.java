/*    */ package greenfoot.collision.ibsp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BSPNodeCache
/*    */ {
/*    */   private static final int CACHE_SIZE = 1000;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 34 */   private static BSPNode[] cache = new BSPNode['Ϩ'];
/* 35 */   private static int tail = 0;
/* 36 */   private static int size = 0;
/*    */   
/*    */   public static BSPNode getBSPNode()
/*    */   {
/* 40 */     if (size == 0) {
/* 41 */       return new BSPNode(new Rect(0, 0, 0, 0), 0, 0);
/*    */     }
/*    */     
/* 44 */     int ppos = tail - size;
/* 45 */     if (ppos < 0) {
/* 46 */       ppos += 1000;
/*    */     }
/*    */     
/* 49 */     BSPNode node = cache[ppos];
/* 50 */     node.setParent(null);
/* 51 */     size -= 1;
/* 52 */     return node;
/*    */   }
/*    */   
/*    */ 
/*    */   public static void returnNode(BSPNode node)
/*    */   {
/* 58 */     node.blankNode();
/* 59 */     cache[(tail++)] = node;
/* 60 */     if (tail == 1000) {
/* 61 */       tail = 0;
/*    */     }
/* 63 */     size = Math.min(size + 1, 1000);
/*    */     
/* 65 */     if ((node.getLeft() != null) || (node.getRight() != null)) {
/* 66 */       throw new RuntimeException("HHHHH!");
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\collision\ibsp\BSPNodeCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */