/*     */ package greenfoot.collision;
/*     */ 
/*     */ import greenfoot.Actor;
/*     */ import greenfoot.ActorVisitor;
/*     */ import greenfoot.util.Circle;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.PriorityQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BVHInsChecker
/*     */   implements CollisionChecker
/*     */ {
/*     */   public CircleTree tree;
/*     */   
/*     */   class Node
/*     */   {
/*     */     public Node parent;
/*     */     public Node left;
/*     */     public Node right;
/*     */     public Circle circle;
/*     */     private Actor actor;
/*     */     
/*     */     public Node(Circle circle)
/*     */     {
/*  77 */       this.circle = circle;
/*     */     }
/*     */     
/*     */     public Node()
/*     */     {
/*  82 */       this.circle = new Circle();
/*     */     }
/*     */     
/*     */     public Node(Circle circle, Actor actor)
/*     */     {
/*  87 */       if (actor == null) {
/*  88 */         throw new NullPointerException("Actor may not be null.");
/*     */       }
/*  90 */       this.circle = circle;
/*  91 */       this.actor = actor;
/*     */     }
/*     */     
/*     */     public Actor getActor()
/*     */     {
/*  96 */       return this.actor;
/*     */     }
/*     */     
/*     */     public boolean isLeaf()
/*     */     {
/* 101 */       return (this.left == null) && (this.right == null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void getIntersections(Circle c, CollisionQuery checker, List<Actor> result)
/*     */     {
/* 118 */       if (!c.intersects(this.circle)) {
/* 119 */         return;
/*     */       }
/* 121 */       if ((isLeaf()) && (checker != null) && (checker.checkCollision(getActor()))) {
/* 122 */         result.add(getActor());
/*     */       }
/* 124 */       else if (!isLeaf()) {
/* 125 */         this.left.getIntersections(c, checker, result);
/* 126 */         this.right.getIntersections(c, checker, result);
/*     */       }
/*     */     }
/*     */     
/*     */     private Actor getOneIntersectingObject(Circle c, CollisionQuery checker)
/*     */     {
/* 132 */       return getOneIntersectingObjectUpwards(c, checker);
/*     */     }
/*     */     
/*     */ 
/*     */     private Actor getOneIntersectingObjectDownwards(Circle c, CollisionQuery checker)
/*     */     {
/* 138 */       if (!c.intersects(this.circle)) {
/* 139 */         return null;
/*     */       }
/* 141 */       if ((isLeaf()) && (checker != null) && (checker.checkCollision(getActor()))) {
/* 142 */         return getActor();
/*     */       }
/* 144 */       if (!isLeaf())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 153 */         Actor res = this.left.getOneIntersectingObjectDownwards(c, checker);
/* 154 */         if (res != null) {
/* 155 */           return res;
/*     */         }
/*     */         
/* 158 */         return this.right.getOneIntersectingObjectDownwards(c, checker);
/*     */       }
/*     */       
/* 161 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private Actor getOneIntersectingObjectUpwards(Circle c, CollisionQuery checker)
/*     */     {
/* 172 */       Node sibling = getSibling();
/* 173 */       Actor result = null;
/* 174 */       if (sibling != null) {
/* 175 */         result = sibling.getOneIntersectingObjectDownwards(sibling.circle, checker);
/*     */       }
/*     */       
/* 178 */       if ((result == null) && (this.parent != null)) {
/* 179 */         return this.parent.getOneIntersectingObjectUpwards(c, checker);
/*     */       }
/* 181 */       if (result != null) {
/* 182 */         return result;
/*     */       }
/* 184 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void reset()
/*     */     {
/* 195 */       if ((this.left != null) && (this.left.parent == this)) {
/* 196 */         this.left.parent = null;
/*     */       }
/* 198 */       if ((this.right != null) && (this.right.parent == this)) {
/* 199 */         this.right.parent = null;
/*     */       }
/* 201 */       if (this.parent != null) {
/* 202 */         if (this.parent.left == this) {
/* 203 */           this.parent.left = null;
/*     */         }
/* 205 */         else if (this.parent.right == this) {
/* 206 */           this.parent.right = null;
/*     */         }
/*     */       }
/* 209 */       this.parent = null;
/* 210 */       this.left = null;
/* 211 */       this.right = null;
/*     */     }
/*     */     
/*     */     private Node getSibling()
/*     */     {
/* 216 */       if (this.parent != null) {
/* 217 */         if (this.parent.left == this) {
/* 218 */           return this.parent.right;
/*     */         }
/*     */         
/* 221 */         return this.parent.left;
/*     */       }
/*     */       
/* 224 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static class CircleFringe
/*     */     implements Comparable<CircleFringe>
/*     */   {
/*     */     private BVHInsChecker.Node node;
/*     */     
/*     */ 
/*     */ 
/*     */     private double ancestorExpansion;
/*     */     
/*     */ 
/*     */ 
/*     */     private double volume;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public CircleFringe(BVHInsChecker.Node n, double ancestorExpansion, double volume)
/*     */     {
/* 250 */       this.ancestorExpansion = ancestorExpansion;
/* 251 */       this.volume = volume;
/* 252 */       this.node = n;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public CircleFringe(CircleFringe other)
/*     */     {
/* 262 */       copyValuesFrom(other);
/*     */     }
/*     */     
/*     */     public void copyValuesFrom(CircleFringe other) {
/* 266 */       this.node = other.getNode();
/* 267 */       this.ancestorExpansion = other.getAncestorExpansion();
/* 268 */       this.volume = other.getVolume();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public double getAncestorExpansion()
/*     */     {
/* 277 */       return this.ancestorExpansion;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setAncestorExpansion(double ancestorExpansion)
/*     */     {
/* 286 */       this.ancestorExpansion = ancestorExpansion;
/*     */     }
/*     */     
/*     */     public int compareTo(CircleFringe other)
/*     */     {
/* 291 */       return (int)(this.ancestorExpansion - other.getAncestorExpansion());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public BVHInsChecker.Node getNode()
/*     */     {
/* 299 */       return this.node;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setNode(BVHInsChecker.Node node)
/*     */     {
/* 307 */       this.node = node;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setVolume(double volume)
/*     */     {
/* 317 */       this.volume = volume;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public double getVolume()
/*     */     {
/* 327 */       return this.volume;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public double getCost()
/*     */     {
/* 335 */       return this.ancestorExpansion + this.volume;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   class CircleTree
/*     */   {
/*     */     private BVHInsChecker.Node root;
/*     */     
/*     */ 
/*     */     private int size;
/*     */     
/*     */ 
/*     */     private BVHInsChecker.Node lastInsertionPoint;
/*     */     
/*     */ 
/*     */ 
/*     */     CircleTree() {}
/*     */     
/*     */ 
/*     */ 
/*     */     public void addNode(BVHInsChecker.Node n, BVHInsChecker.Node bestGuess)
/*     */     {
/* 360 */       BVHInsChecker.Node sibling = bestSibling(n, bestGuess);
/* 361 */       insertAtNode(n, sibling);
/*     */     }
/*     */     
/*     */ 
/*     */     public void addNode(BVHInsChecker.Node n)
/*     */     {
/* 367 */       if (!contains(this.lastInsertionPoint)) {
/* 368 */         this.lastInsertionPoint = null;
/*     */       }
/*     */       
/* 371 */       BVHInsChecker.Node sibling = bestSibling(n, this.lastInsertionPoint);
/* 372 */       insertAtNode(n, sibling);
/* 373 */       this.lastInsertionPoint = BVHInsChecker.Node.access$000(n);
/*     */     }
/*     */     
/*     */     private boolean contains(BVHInsChecker.Node n)
/*     */     {
/* 378 */       if (n == null) {
/* 379 */         return false;
/*     */       }
/* 381 */       if ((this.root == n) || (n.parent != null)) {
/* 382 */         return true;
/*     */       }
/* 384 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public BVHInsChecker.Node bestSibling(BVHInsChecker.Node newNode, BVHInsChecker.Node bestGuess)
/*     */     {
/* 392 */       if (getRoot() == null) {
/* 393 */         return null;
/*     */       }
/*     */       
/* 396 */       if (this.root.isLeaf()) {
/* 397 */         return this.root;
/*     */       }
/*     */       
/* 400 */       BVHInsChecker.CircleFringe rootFringe = createFringe(newNode, this.root);
/*     */       
/*     */ 
/* 403 */       BVHInsChecker.CircleFringe best = new BVHInsChecker.CircleFringe(rootFringe);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 409 */       if (bestGuess != null) {
/* 410 */         BVHInsChecker.CircleFringe newFringe = createFringe(newNode, bestGuess);
/* 411 */         if (newFringe.getCost() < best.getCost()) {
/* 412 */           best.copyValuesFrom(newFringe);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 418 */       PriorityQueue<BVHInsChecker.CircleFringe> fringeQueue = new PriorityQueue();
/*     */       
/*     */ 
/* 421 */       fringeQueue.add(rootFringe);
/*     */       
/* 423 */       bestSiblingSearch(newNode, best, fringeQueue);
/*     */       
/* 425 */       return best.getNode();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void bestSiblingSearch(BVHInsChecker.Node newNode, BVHInsChecker.CircleFringe best, PriorityQueue<BVHInsChecker.CircleFringe> fringeQueue)
/*     */     {
/* 435 */       while (!fringeQueue.isEmpty())
/*     */       {
/* 437 */         BVHInsChecker.CircleFringe tf = (BVHInsChecker.CircleFringe)fringeQueue.poll();
/* 438 */         if (tf.getAncestorExpansion() >= best.getCost()) {
/*     */           break;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 445 */         double newAExp = tf.getCost() - tf.getNode().circle.getVolume();
/* 446 */         processNode(newNode, tf.getNode().left, newAExp, best, fringeQueue);
/* 447 */         processNode(newNode, tf.getNode().right, newAExp, best, fringeQueue);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private BVHInsChecker.CircleFringe createFringe(BVHInsChecker.Node newNode, BVHInsChecker.Node currentNode)
/*     */     {
/* 464 */       Circle bestCircle = new Circle();
/* 465 */       bestCircle.merge(currentNode.circle, newNode.circle);
/*     */       
/* 467 */       double bestCost = bestCircle.getVolume();
/* 468 */       double ae = 0.0D;
/* 469 */       BVHInsChecker.Node n = currentNode;
/* 470 */       while (n.parent != null) {
/* 471 */         Circle enclosingCircle = new Circle();
/* 472 */         enclosingCircle.merge(n.circle, newNode.circle);
/* 473 */         double delta = enclosingCircle.getVolume() - n.parent.circle.getVolume();
/* 474 */         if (delta == 0.0D) {
/*     */           break;
/*     */         }
/* 477 */         ae += delta;
/* 478 */         n = n.parent;
/*     */       }
/* 480 */       BVHInsChecker.CircleFringe newFringe = new BVHInsChecker.CircleFringe(currentNode, ae, bestCost);
/*     */       
/* 482 */       return newFringe;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void processNode(BVHInsChecker.Node newNode, BVHInsChecker.Node childNode, double newAExp, BVHInsChecker.CircleFringe best, PriorityQueue<BVHInsChecker.CircleFringe> fringeQueue)
/*     */     {
/* 492 */       Circle enclosingCircle = new Circle();
/* 493 */       enclosingCircle.merge(childNode.circle, newNode.circle);
/* 494 */       double enclosingVolume = enclosingCircle.getVolume();
/*     */       
/*     */ 
/* 497 */       if (newAExp + enclosingVolume < best.getCost()) {
/* 498 */         best.setVolume(enclosingVolume);
/* 499 */         best.setAncestorExpansion(enclosingVolume);
/* 500 */         best.setNode(childNode);
/*     */       }
/* 502 */       if (!childNode.isLeaf()) {
/* 503 */         BVHInsChecker.CircleFringe newFringe = new BVHInsChecker.CircleFringe(childNode, newAExp, enclosingVolume);
/* 504 */         fringeQueue.add(newFringe);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void insertAtNode(BVHInsChecker.Node newNode, BVHInsChecker.Node sibling)
/*     */     {
/* 519 */       if (getRoot() == null) {
/* 520 */         setRoot(newNode);
/*     */       }
/*     */       else {
/* 523 */         BVHInsChecker.Node newParent = new BVHInsChecker.Node(BVHInsChecker.this);
/* 524 */         newParent.parent = sibling.parent;
/* 525 */         if (sibling.parent == null) {
/* 526 */           setRoot(newParent);
/*     */         }
/* 528 */         else if (sibling.parent.left == sibling)
/*     */         {
/* 530 */           sibling.parent.left = newParent;
/*     */         }
/*     */         else
/*     */         {
/* 534 */           sibling.parent.right = newParent;
/*     */         }
/*     */         
/* 537 */         newParent.left = sibling;
/* 538 */         newParent.right = newNode;
/*     */         
/* 540 */         newNode.parent = newParent;
/* 541 */         sibling.parent = newParent;
/* 542 */         newParent.circle.merge(newNode.circle, sibling.circle);
/* 543 */         repairParents(newParent);
/*     */       }
/*     */       
/* 546 */       this.size += 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void repairParents(BVHInsChecker.Node newParent)
/*     */     {
/* 556 */       BVHInsChecker.Node p = newParent.parent;
/* 557 */       while (p != null) {
/* 558 */         int radius = p.circle.getRadius();
/* 559 */         p.circle.merge(p.left.circle, p.right.circle);
/*     */         
/* 561 */         if (p.circle.getRadius() == radius) {
/*     */           break;
/*     */         }
/* 564 */         p = p.parent;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void repairNode(BVHInsChecker.Node n)
/*     */     {
/* 574 */       if (n == null)
/* 575 */         return;
/* 576 */       BVHInsChecker.Node sibling = removeNode(n);
/* 577 */       addNode(n, sibling);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public BVHInsChecker.Node removeNode(BVHInsChecker.Node n)
/*     */     {
/* 585 */       BVHInsChecker.Node sibling = null;
/* 586 */       if (n == null) {
/* 587 */         return null;
/*     */       }
/* 589 */       if (n == this.root)
/*     */       {
/* 591 */         setRoot(null);
/*     */       }
/*     */       else {
/* 594 */         sibling = BVHInsChecker.Node.access$000(n);
/* 595 */         BVHInsChecker.Node parent = n.parent;
/*     */         
/* 597 */         sibling.parent = parent.parent;
/* 598 */         if (parent.parent == null) {
/* 599 */           setRoot(sibling);
/*     */         }
/* 601 */         else if (parent.parent.left == parent) {
/* 602 */           parent.parent.left = sibling;
/*     */         }
/*     */         else {
/* 605 */           parent.parent.right = sibling;
/*     */         }
/* 607 */         parent.reset();
/* 608 */         repairParents(sibling);
/*     */       }
/* 610 */       n.reset();
/* 611 */       this.size -= 1;
/* 612 */       return sibling;
/*     */     }
/*     */     
/*     */     public List<Actor> getIntersections(Circle b, CollisionQuery c)
/*     */     {
/* 617 */       List<Actor> result = new ArrayList();
/* 618 */       if (getRoot() == null) {
/* 619 */         return result;
/*     */       }
/*     */       
/* 622 */       getRoot().getIntersections(b, c, result);
/*     */       
/* 624 */       return result;
/*     */     }
/*     */     
/*     */     public Actor getOneIntersectingObject(BVHInsChecker.Node node, Circle circle, CollisionQuery checker)
/*     */     {
/* 629 */       if (node != null) {
/* 630 */         return BVHInsChecker.Node.access$100(node, circle, checker);
/*     */       }
/* 632 */       if (this.root != null) {
/* 633 */         return BVHInsChecker.Node.access$100(this.root, circle, checker);
/*     */       }
/*     */       
/* 636 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */     public Actor getOneIntersectingObject(BVHInsChecker.Node node, CollisionQuery checker)
/*     */     {
/* 642 */       return BVHInsChecker.Node.access$100(node, node.circle, checker);
/*     */     }
/*     */     
/*     */     public void paintDebug(Graphics g)
/*     */     {
/* 647 */       if (getRoot() != null) {
/* 648 */         paintNode(getRoot(), g);
/*     */       }
/*     */     }
/*     */     
/*     */     private void paintNode(BVHInsChecker.Node n, Graphics g)
/*     */     {
/* 654 */       paintCircle(n.circle, g);
/* 655 */       if (n.left != null) {
/* 656 */         g.setColor(Color.BLUE);
/* 657 */         paintLine(n, n.left, g);
/* 658 */         paintNode(n.left, g);
/*     */       }
/* 660 */       if (n.right != null) {
/* 661 */         g.setColor(Color.GREEN);
/* 662 */         paintLine(n, n.right, g);
/* 663 */         paintNode(n.right, g);
/*     */       }
/*     */     }
/*     */     
/*     */     private void paintLine(BVHInsChecker.Node from, BVHInsChecker.Node to, Graphics g)
/*     */     {
/* 669 */       if ((from == null) || (to == null)) {
/* 670 */         return;
/*     */       }
/* 672 */       g.drawLine(from.circle.getX(), from.circle.getY(), to.circle.getX(), to.circle.getY());
/*     */     }
/*     */     
/*     */     private void paintCircle(Circle b, Graphics g)
/*     */     {
/* 677 */       if (b != null) {
/* 678 */         g.setColor(Color.RED);
/* 679 */         g.drawOval(b.getX() - b.getRadius(), b.getY() - b.getRadius(), b.getRadius() * 2, b.getRadius() * 2);
/*     */       }
/*     */     }
/*     */     
/*     */     public int size()
/*     */     {
/* 685 */       return this.size;
/*     */     }
/*     */     
/*     */     public void setRoot(BVHInsChecker.Node root)
/*     */     {
/* 690 */       this.root = root;
/*     */     }
/*     */     
/*     */     public BVHInsChecker.Node getRoot()
/*     */     {
/* 695 */       return this.root;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 701 */   private GOCollisionQuery actorQuery = new GOCollisionQuery();
/* 702 */   private NeighbourCollisionQuery neighbourQuery = new NeighbourCollisionQuery();
/* 703 */   private PointCollisionQuery pointQuery = new PointCollisionQuery();
/*     */   private int cellSize;
/*     */   private List<Actor> objects;
/*     */   
/*     */   public void initialize(int width, int height, int cellSize, boolean wrap)
/*     */   {
/* 709 */     this.tree = new CircleTree();
/* 710 */     this.cellSize = cellSize;
/* 711 */     this.objects = new ArrayList();
/*     */   }
/*     */   
/*     */   public synchronized void addObject(Actor actor)
/*     */   {
/* 716 */     if (this.objects.contains(actor)) {
/* 717 */       return;
/*     */     }
/*     */     
/* 720 */     Node n = createNode(actor);
/* 721 */     ActorVisitor.setData(actor, n);
/* 722 */     this.tree.addNode(n);
/* 723 */     this.objects.add(actor);
/*     */   }
/*     */   
/*     */   private Node createNode(Actor actor)
/*     */   {
/* 728 */     Circle c = getCircle(actor);
/* 729 */     Node n = new Node(c, actor);
/* 730 */     return n;
/*     */   }
/*     */   
/*     */   public synchronized void removeObject(Actor object)
/*     */   {
/* 735 */     this.tree.removeNode((Node)ActorVisitor.getData(object));
/*     */     
/* 737 */     ActorVisitor.setData(object, null);
/* 738 */     this.objects.remove(object);
/*     */   }
/*     */   
/*     */   public synchronized void updateObjectLocation(Actor object, int oldX, int oldY)
/*     */   {
/* 743 */     int ax = ActorVisitor.getX(object);
/* 744 */     int ay = ActorVisitor.getY(object);
/* 745 */     if ((ax == oldX) && (ay == oldY)) {
/* 746 */       return;
/*     */     }
/* 748 */     Node n = (Node)ActorVisitor.getData(object);
/* 749 */     Circle c = getCircle(object);
/* 750 */     if ((c != null) && (n != null)) {
/* 751 */       n.circle.setX(c.getX());
/* 752 */       n.circle.setY(c.getY());
/* 753 */       this.tree.repairNode(n);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void updateObjectSize(Actor object)
/*     */   {
/* 760 */     throw new RuntimeException("No longer working because of missing bounding circle");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends Actor> List<T> getObjectsAt(int x, int y, Class<T> cls)
/*     */   {
/* 771 */     int halfCell = this.cellSize / 2;
/* 772 */     Circle b = new Circle(x * this.cellSize + halfCell, y * this.cellSize + halfCell, 0);
/* 773 */     synchronized (this.pointQuery) {
/* 774 */       this.pointQuery.init(x, y, cls);
/* 775 */       return this.tree.getIntersections(b, this.pointQuery);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends Actor> List<T> getIntersectingObjects(Actor actor, Class<T> cls)
/*     */   {
/* 782 */     Circle b = getCircle(actor);
/* 783 */     synchronized (this.actorQuery) {
/* 784 */       this.actorQuery.init(cls, actor);
/* 785 */       return this.tree.getIntersections(b, this.actorQuery);
/*     */     }
/*     */   }
/*     */   
/*     */   private Circle getCircle(Actor actor)
/*     */   {
/* 791 */     throw new RuntimeException("No longer working because of missing bounding circle");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends Actor> List<T> getObjectsInRange(int x, int y, int r, Class<T> cls)
/*     */   {
/* 803 */     Circle b = new Circle(x * this.cellSize, y * this.cellSize, r * this.cellSize);
/* 804 */     synchronized (this.actorQuery) {
/* 805 */       this.actorQuery.init(cls, null);
/* 806 */       return this.tree.getIntersections(b, this.actorQuery);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends Actor> List<T> getNeighbours(Actor a, int distance, boolean diag, Class<T> cls)
/*     */   {
/* 813 */     int x = ActorVisitor.getX(a);
/* 814 */     int y = ActorVisitor.getY(a);
/* 815 */     int xPixel = x * this.cellSize;
/* 816 */     int yPixel = y * this.cellSize;
/* 817 */     int dPixel = distance * this.cellSize;
/* 818 */     int r = 0;
/* 819 */     if (diag) {
/* 820 */       r = (int)Math.ceil(Math.sqrt(dPixel * dPixel + dPixel * dPixel));
/*     */     }
/*     */     else {
/* 823 */       double dy = 0.5D * this.cellSize;
/* 824 */       double dx = dPixel + dy;
/* 825 */       r = (int)Math.sqrt(dy * dy + dx * dx);
/*     */     }
/* 827 */     Circle c = new Circle(xPixel, yPixel, r);
/*     */     
/* 829 */     synchronized (this.neighbourQuery) {
/* 830 */       this.neighbourQuery.init(x, y, distance, diag, cls);
/* 831 */       return this.tree.getIntersections(c, this.neighbourQuery);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public <T extends Actor> List<T> getObjectsInDirection(int x, int y, int angle, int length, Class<T> cls)
/*     */   {
/* 839 */     throw new RuntimeException("NOT IMPLEMENTED YET");
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends Actor> List<T> getObjects(Class<T> cls)
/*     */   {
/* 845 */     if (cls == null) {
/* 846 */       return new ArrayList(this.objects);
/*     */     }
/* 848 */     List<T> l = new ArrayList();
/* 849 */     for (Iterator<Actor> iter = this.objects.iterator(); iter.hasNext();) {
/* 850 */       Actor actor = (Actor)iter.next();
/* 851 */       if (cls.isInstance(actor)) {
/* 852 */         l.add(actor);
/*     */       }
/*     */     }
/* 855 */     return l;
/*     */   }
/*     */   
/*     */   public List<Actor> getObjectsList()
/*     */   {
/* 860 */     return this.objects;
/*     */   }
/*     */   
/*     */ 
/*     */   public void startSequence() {}
/*     */   
/*     */ 
/*     */   public <T extends Actor> T getOneObjectAt(Actor actor, int x, int y, Class<T> cls)
/*     */   {
/* 869 */     int halfCell = this.cellSize / 2;
/* 870 */     Circle b = new Circle(x * this.cellSize + halfCell, y * this.cellSize + halfCell, 0);
/* 871 */     synchronized (this.pointQuery) {
/* 872 */       this.pointQuery.init(x, y, cls);
/* 873 */       Node node = (Node)ActorVisitor.getData(actor);
/* 874 */       return this.tree.getOneIntersectingObject(node, b, this.pointQuery);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends Actor> T getOneIntersectingObject(Actor object, Class<T> cls)
/*     */   {
/* 881 */     synchronized (this.actorQuery) {
/* 882 */       this.actorQuery.init(cls, object);
/*     */       
/* 884 */       Node node = (Node)ActorVisitor.getData(object);
/* 885 */       if (node == null) {
/* 886 */         return null;
/*     */       }
/* 888 */       return this.tree.getOneIntersectingObject(node, this.actorQuery);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void paintDebug(Graphics g)
/*     */   {
/* 898 */     int missing = 0;
/* 899 */     synchronized (this) {
/* 900 */       missing = this.objects.size() - this.tree.size();
/* 901 */       this.tree.paintDebug(g);
/*     */     }
/* 903 */     if (missing > 0) {
/* 904 */       System.out.println("Objects missing: " + missing);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\collision\BVHInsChecker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */