/*    */ package greenfoot;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MouseInfoVisitor
/*    */ {
/*    */   public static void setActor(MouseInfo info, Actor actor)
/*    */   {
/* 36 */     info.setActor(actor);
/*    */   }
/*    */   
/*    */   public static void setLoc(MouseInfo info, int x, int y) {
/* 40 */     info.setLoc(x, y);
/*    */   }
/*    */   
/*    */   public static void setButton(MouseInfo info, int button)
/*    */   {
/* 45 */     info.setButton(button);
/*    */   }
/*    */   
/*    */   public static MouseInfo newMouseInfo()
/*    */   {
/* 50 */     return new MouseInfo();
/*    */   }
/*    */   
/*    */   public static void setClickCount(MouseInfo mouseInfo, int clickCount)
/*    */   {
/* 55 */     mouseInfo.setClickCount(clickCount);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\MouseInfoVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */