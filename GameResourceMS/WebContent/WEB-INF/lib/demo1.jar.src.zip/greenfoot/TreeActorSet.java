/*     */ package greenfoot;
/*     */ 
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeActorSet
/*     */   extends AbstractSet<Actor>
/*     */ {
/*     */   private List<ActorSet> subSets;
/*     */   private ActorSet generalSet;
/*     */   private HashMap<Class<?>, ActorSet> classSets;
/*     */   
/*     */   public TreeActorSet()
/*     */   {
/*  50 */     this.subSets = new LinkedList();
/*  51 */     this.generalSet = new ActorSet();
/*  52 */     this.subSets.add(this.generalSet);
/*     */     
/*  54 */     this.classSets = new HashMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setClassOrder(boolean reverse, Class<?>... classes)
/*     */   {
/*  72 */     HashMap<Class<?>, ActorSet> oldClassSets = this.classSets;
/*  73 */     this.classSets = new HashMap();
/*     */     
/*     */ 
/*  76 */     LinkedList<Class<?>> sweepClasses = new LinkedList();
/*     */     
/*     */ 
/*     */ 
/*  80 */     for (int i = 0; i < classes.length; i++) {
/*  81 */       ActorSet oldSet = (ActorSet)oldClassSets.remove(classes[i]);
/*  82 */       if (oldSet == null)
/*     */       {
/*     */ 
/*     */ 
/*  86 */         sweepClasses.add(classes[i]);
/*  87 */         oldSet = new ActorSet();
/*     */       }
/*  89 */       this.classSets.put(classes[i], oldSet);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */     Set<Class<?>> sweptClasses = new HashSet();
/*     */     
/*  98 */     while (!sweepClasses.isEmpty()) {
/*  99 */       Class<?> sweepClass = ((Class)sweepClasses.removeFirst()).getSuperclass();
/* 100 */       ActorSet sweepSet = (ActorSet)this.classSets.get(sweepClass);
/* 101 */       while (sweepSet == null) {
/* 102 */         sweepClass = sweepClass.getSuperclass();
/* 103 */         if (sweepClass == null) {
/* 104 */           sweepSet = this.generalSet;
/*     */         }
/*     */         else {
/* 107 */           sweepSet = (ActorSet)this.classSets.get(sweepClass);
/*     */         }
/*     */       }
/*     */       
/* 111 */       if (!sweptClasses.contains(sweepClass)) {
/* 112 */         sweptClasses.add(sweepClass);
/*     */         
/* 114 */         Iterator<Actor> i = sweepSet.iterator();
/* 115 */         while (i.hasNext()) {
/* 116 */           Actor actor = (Actor)i.next();
/* 117 */           ActorSet set = setForActor(actor);
/* 118 */           if (set != sweepSet) {
/* 119 */             set.add(actor);
/* 120 */             i.remove();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 129 */     Iterator<Map.Entry<Class<?>, ActorSet>> ei = oldClassSets.entrySet().iterator();
/* 130 */     while (ei.hasNext()) {
/* 131 */       Map.Entry<Class<?>, ActorSet> entry = (Map.Entry)ei.next();
/* 132 */       ActorSet destinationSet = setForClass((Class)entry.getKey());
/* 133 */       destinationSet.addAll((Collection)entry.getValue());
/*     */     }
/*     */     
/*     */ 
/* 137 */     this.subSets.clear();
/* 138 */     int i; if (reverse) {
/* 139 */       this.subSets.add(this.generalSet);
/* 140 */       for (i = classes.length; i > 0;) {
/* 141 */         this.subSets.add(this.classSets.get(classes[(--i)]));
/*     */       }
/*     */     }
/*     */     else {
/* 145 */       for (int i = 0; i < classes.length; i++) {
/* 146 */         this.subSets.add(this.classSets.get(classes[i]));
/*     */       }
/* 148 */       this.subSets.add(this.generalSet);
/*     */     }
/*     */   }
/*     */   
/*     */   public Iterator<Actor> iterator()
/*     */   {
/* 154 */     return new TasIterator();
/*     */   }
/*     */   
/*     */   public int size()
/*     */   {
/* 159 */     int size = 0;
/* 160 */     for (Iterator<ActorSet> i = this.subSets.iterator(); i.hasNext();) {
/* 161 */       size += ((ActorSet)i.next()).size();
/*     */     }
/* 163 */     return size;
/*     */   }
/*     */   
/*     */   public boolean add(Actor o)
/*     */   {
/* 168 */     if (o == null) {
/* 169 */       throw new UnsupportedOperationException("Cannot add null actor.");
/*     */     }
/*     */     
/* 172 */     return setForActor(o).add(o);
/*     */   }
/*     */   
/*     */   public boolean remove(Actor o)
/*     */   {
/* 177 */     return setForActor(o).remove(o);
/*     */   }
/*     */   
/*     */   public boolean contains(Actor o)
/*     */   {
/* 182 */     return setForActor(o).contains(o);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ActorSet setForActor(Actor o)
/*     */   {
/* 190 */     Class<?> oClass = o.getClass();
/* 191 */     return setForClass(oClass);
/*     */   }
/*     */   
/*     */   private ActorSet setForClass(Class<?> oClass)
/*     */   {
/* 196 */     ActorSet set = (ActorSet)this.classSets.get(oClass);
/*     */     
/*     */ 
/* 199 */     while ((set == null) && (oClass != Object.class)) {
/* 200 */       oClass = oClass.getSuperclass();
/* 201 */       set = (ActorSet)this.classSets.get(oClass);
/*     */     }
/*     */     
/* 204 */     if (set == null) {
/* 205 */       set = this.generalSet;
/*     */     }
/* 207 */     return set;
/*     */   }
/*     */   
/*     */ 
/*     */   class TasIterator
/*     */     implements Iterator<Actor>
/*     */   {
/*     */     private Iterator<ActorSet> setIterator;
/*     */     
/*     */     private ActorSet currentSet;
/*     */     
/*     */     private Iterator<Actor> actorIterator;
/*     */     
/*     */ 
/*     */     public TasIterator()
/*     */     {
/* 223 */       this.setIterator = TreeActorSet.this.subSets.iterator();
/* 224 */       this.currentSet = ((ActorSet)this.setIterator.next());
/* 225 */       while ((this.currentSet.isEmpty()) && (this.setIterator.hasNext())) {
/* 226 */         this.currentSet = ((ActorSet)this.setIterator.next());
/*     */       }
/* 228 */       this.actorIterator = this.currentSet.iterator();
/*     */     }
/*     */     
/*     */     public void remove()
/*     */     {
/* 233 */       this.actorIterator.remove();
/*     */     }
/*     */     
/*     */     public Actor next()
/*     */     {
/* 238 */       hasNext();
/* 239 */       return (Actor)this.actorIterator.next();
/*     */     }
/*     */     
/*     */     public boolean hasNext()
/*     */     {
/* 244 */       if (this.actorIterator.hasNext()) {
/* 245 */         return true;
/*     */       }
/*     */       
/* 248 */       if (!this.setIterator.hasNext()) {
/* 249 */         return false;
/*     */       }
/*     */       
/* 252 */       while (this.setIterator.hasNext()) {
/* 253 */         this.currentSet = ((ActorSet)this.setIterator.next());
/* 254 */         if (!this.currentSet.isEmpty()) {
/*     */           break;
/*     */         }
/*     */       }
/*     */       
/* 259 */       this.actorIterator = this.currentSet.iterator();
/* 260 */       return this.actorIterator.hasNext();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\greenfoot\TreeActorSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */