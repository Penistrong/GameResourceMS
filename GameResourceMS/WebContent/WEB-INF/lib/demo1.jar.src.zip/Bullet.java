/*    */ import greenfoot.Actor;
/*    */ import greenfoot.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Bullet
/*    */   extends Actor
/*    */ {
/* 13 */   protected int speed = 4;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void setSpeed(int bulletSpeed)
/*    */   {
/* 20 */     this.speed = bulletSpeed;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void checkBoundaries()
/*    */   {
/* 28 */     if (getX() > getWorld().getWidth() - 10) {
/* 29 */       getWorld().removeObject(this);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\Bullet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */