/*    */ import greenfoot.Actor;
/*    */ import greenfoot.GreenfootSound;
/*    */ import greenfoot.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Lawnmower
/*    */   extends Actor
/*    */ {
/* 14 */   private GifImage gif = new GifImage("lawn_mower.gif");
/* 15 */   private int speed = 0;
/* 16 */   GreenfootSound sound = new GreenfootSound("lamborghini.wav");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Lawnmower()
/*    */   {
/* 23 */     setImage(this.gif.getCurrentImage());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void act()
/*    */   {
/* 32 */     move(this.speed);
/* 33 */     if (isTouching(Zombie.class))
/*    */     {
/* 35 */       removeTouching(Zombie.class);
/* 36 */       this.speed = 12;
/* 37 */       this.sound.play();
/*    */     }
/* 39 */     if (this.speed > 0)
/*    */     {
/* 41 */       setImage(this.gif.getCurrentImage());
/*    */     }
/* 43 */     checkBoundaries();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void checkBoundaries()
/*    */   {
/* 51 */     if (getX() > getWorld().getWidth() - 10) {
/* 52 */       getWorld().removeObject(this);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\Lawnmower.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */