/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Beet
/*    */   extends Bullet
/*    */ {
/*    */   public Beet()
/*    */   {
/* 15 */     setSpeed(6);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void act()
/*    */   {
/* 24 */     move(this.speed);
/* 25 */     checkBoundaries();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\Beet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */