/*     */ import greenfoot.Greenfoot;
/*     */ import greenfoot.GreenfootSound;
/*     */ import greenfoot.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Backyard
/*     */   extends World
/*     */ {
/*     */   private int[] rows;
/*     */   private int[] columns;
/*  16 */   private Counter counter_sun = new Counter();
/*  17 */   private Counter counter_score = new Counter();
/*  18 */   private GreenfootSound backgroundMusic = new GreenfootSound("background.wav");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Backyard()
/*     */   {
/*  27 */     super(1111, 602, 1);
/*     */     
/*  29 */     setRowsCoordinates();
/*  30 */     setColumnsCoordinates();
/*  31 */     prepare();
/*  32 */     this.backgroundMusic.playLoop();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setRowsCoordinates()
/*     */   {
/*  40 */     this.rows = new int[5];
/*  41 */     this.rows[0] = 78;
/*  42 */     this.rows[1] = 184;
/*  43 */     this.rows[2] = 306;
/*  44 */     this.rows[3] = 418;
/*  45 */     this.rows[4] = 523;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setColumnsCoordinates()
/*     */   {
/*  53 */     this.columns = new int[9];
/*  54 */     this.columns[0] = 326;
/*  55 */     this.columns[1] = 413;
/*  56 */     this.columns[2] = 500;
/*  57 */     this.columns[3] = 588;
/*  58 */     this.columns[4] = 679;
/*  59 */     this.columns[5] = 765;
/*  60 */     this.columns[6] = 857;
/*  61 */     this.columns[7] = 943;
/*  62 */     this.columns[8] = 1042;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int returnGridRowPosition(int y)
/*     */   {
/*  72 */     int[] rowGrid = { 0, 137, 246, 357, 462, 569 };
/*  73 */     for (int row = 0; row < 5; row++)
/*     */     {
/*  75 */       if ((y > rowGrid[row]) && (y < rowGrid[(row + 1)]))
/*     */       {
/*  77 */         return this.rows[row];
/*     */       }
/*     */     }
/*  80 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int returnGridColumnPosition(int x)
/*     */   {
/*  90 */     int[] columnGrid = { 280, 364, 449, 543, 632, 721, 812, 897, 985, 1089 };
/*  91 */     for (int column = 0; column < 9; column++)
/*     */     {
/*  93 */       if ((x > columnGrid[column]) && (x < columnGrid[(column + 1)]))
/*     */       {
/*  95 */         return this.columns[column];
/*     */       }
/*     */     }
/*  98 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prepareLawnmowers()
/*     */   {
/* 106 */     int[] rows = { 77, 183, 309, 422, 522 };
/* 107 */     int[] columns = { 242, 240, 226, 219, 214 };
/* 108 */     for (int i = 0; i < 5; i++)
/*     */     {
/* 110 */       addObject(new Lawnmower(), columns[i], rows[i]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prepareSidebar()
/*     */   {
/* 119 */     addObject(new WalnutIcon(49, 140), 49, 140);
/* 120 */     addObject(new PeaShootIcon(49, 236), 49, 236);
/* 121 */     addObject(new SunFlowerIcon(49, 332), 49, 332);
/* 122 */     addObject(new BeetRootIcon(49, 428), 49, 428);
/*     */     
/* 124 */     addObject(this.counter_score, 49, 78);
/* 125 */     addObject(this.counter_sun, 49, 567);
/* 126 */     this.counter_sun.setValue(400);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prepare()
/*     */   {
/* 136 */     prepareSidebar();
/* 137 */     prepareLawnmowers();
/* 138 */     addObject(new Shovel(1035, 40), 1035, 40);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addZombie(Zombie zombie, int row)
/*     */   {
/* 146 */     addObject(zombie, this.columns[8] + 70, this.rows[row]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void randomZombie(int row)
/*     */   {
/* 154 */     if (Greenfoot.getRandomNumber(2) == 0)
/*     */     {
/* 156 */       addZombie(new NormalZombie(), row);
/*     */     }
/*     */     else
/*     */     {
/* 160 */       addZombie(new FootballZombie(), row);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void createWave()
/*     */   {
/* 169 */     for (int i = 0; i < 5; i++)
/*     */     {
/* 171 */       randomZombie(i);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 176 */   private long lastAdded = System.currentTimeMillis();
/* 177 */   private int timeUnit = 1;
/* 178 */   private int numberOfWaves = 0;
/* 179 */   private int waveNumber = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void act()
/*     */   {
/* 188 */     long curTime = System.currentTimeMillis();
/*     */     
/* 190 */     if (curTime >= this.lastAdded + 10000L)
/*     */     {
/* 192 */       this.lastAdded = curTime;
/* 193 */       this.timeUnit += 1;
/* 194 */       produceSunFromSky();
/* 195 */       randomZombie(Greenfoot.getRandomNumber(5));
/*     */     }
/*     */     
/* 198 */     if ((this.timeUnit % 3 == 0) && (this.timeUnit != 3))
/*     */     {
/* 200 */       if (curTime <= this.lastAdded + 25L)
/*     */       {
/* 202 */         addObject(new ZombiesAreComing(), 639, 273);
/* 203 */         this.numberOfWaves = ((this.timeUnit - 3) / 3);
/* 204 */         createWave();
/* 205 */         this.waveNumber = 1;
/*     */       }
/*     */       
/* 208 */       if ((curTime > this.lastAdded + this.waveNumber * 1000) && (curTime < this.lastAdded + this.numberOfWaves * 1000))
/*     */       {
/* 210 */         this.waveNumber += 1;
/* 211 */         createWave();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void produceSunFromSky()
/*     */   {
/* 222 */     Sun sun = new Sun();
/* 223 */     addObject(sun, this.columns[Greenfoot.getRandomNumber(8)], 0);
/* 224 */     sun.letTheSunFall();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Counter getSunCounter()
/*     */   {
/* 232 */     return this.counter_sun;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Counter getScoreCounter()
/*     */   {
/* 240 */     return this.counter_score;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void stopBackgroundMusic()
/*     */   {
/* 247 */     this.backgroundMusic.stop();
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\Backyard.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */