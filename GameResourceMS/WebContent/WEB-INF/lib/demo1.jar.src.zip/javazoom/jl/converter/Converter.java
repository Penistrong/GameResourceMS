/*     */ package javazoom.jl.converter;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import javazoom.jl.decoder.Decoder.Params;
/*     */ import javazoom.jl.decoder.Header;
/*     */ import javazoom.jl.decoder.JavaLayerException;
/*     */ import javazoom.jl.decoder.Obuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Converter
/*     */ {
/*     */   public synchronized void convert(String sourceName, String destName)
/*     */     throws JavaLayerException
/*     */   {
/*  59 */     convert(sourceName, destName, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void convert(String sourceName, String destName, ProgressListener progressListener)
/*     */     throws JavaLayerException
/*     */   {
/*  66 */     convert(sourceName, destName, progressListener, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void convert(String sourceName, String destName, ProgressListener progressListener, Decoder.Params decoderParams)
/*     */     throws JavaLayerException
/*     */   {
/*  74 */     if (destName.length() == 0)
/*  75 */       destName = null;
/*     */     try {
/*  77 */       InputStream in = openInput(sourceName);
/*  78 */       convert(in, destName, progressListener, decoderParams);
/*  79 */       in.close();
/*     */     } catch (IOException ioe) {
/*  81 */       throw new JavaLayerException(ioe.getLocalizedMessage(), ioe);
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public synchronized void convert(InputStream sourceStream, String destName, ProgressListener progressListener, Decoder.Params decoderParams)
/*     */     throws JavaLayerException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_3
/*     */     //   1: ifnonnull +8 -> 9
/*     */     //   4: iconst_0
/*     */     //   5: invokestatic 61	javazoom/jl/converter/Converter$PrintWriterProgressListener:newStdOut	(I)Ljavazoom/jl/converter/Converter$PrintWriterProgressListener;
/*     */     //   8: astore_3
/*     */     //   9: aload_1
/*     */     //   10: instanceof 67
/*     */     //   13: ifne +12 -> 25
/*     */     //   16: new 67	java/io/BufferedInputStream
/*     */     //   19: dup
/*     */     //   20: aload_1
/*     */     //   21: invokespecial 69	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
/*     */     //   24: astore_1
/*     */     //   25: iconst_m1
/*     */     //   26: istore 5
/*     */     //   28: aload_1
/*     */     //   29: invokevirtual 72	java/io/InputStream:markSupported	()Z
/*     */     //   32: ifeq +19 -> 51
/*     */     //   35: aload_1
/*     */     //   36: iconst_m1
/*     */     //   37: invokevirtual 76	java/io/InputStream:mark	(I)V
/*     */     //   40: aload_0
/*     */     //   41: aload_1
/*     */     //   42: invokevirtual 80	javazoom/jl/converter/Converter:countFrames	(Ljava/io/InputStream;)I
/*     */     //   45: istore 5
/*     */     //   47: aload_1
/*     */     //   48: invokevirtual 84	java/io/InputStream:reset	()V
/*     */     //   51: aload_3
/*     */     //   52: iconst_1
/*     */     //   53: iload 5
/*     */     //   55: iconst_0
/*     */     //   56: invokeinterface 87 4 0
/*     */     //   61: aconst_null
/*     */     //   62: astore 6
/*     */     //   64: new 93	javazoom/jl/decoder/Decoder
/*     */     //   67: dup
/*     */     //   68: aload 4
/*     */     //   70: invokespecial 95	javazoom/jl/decoder/Decoder:<init>	(Ljavazoom/jl/decoder/Decoder$Params;)V
/*     */     //   73: astore 7
/*     */     //   75: new 98	javazoom/jl/decoder/Bitstream
/*     */     //   78: dup
/*     */     //   79: aload_1
/*     */     //   80: invokespecial 100	javazoom/jl/decoder/Bitstream:<init>	(Ljava/io/InputStream;)V
/*     */     //   83: astore 8
/*     */     //   85: iload 5
/*     */     //   87: iconst_m1
/*     */     //   88: if_icmpne +7 -> 95
/*     */     //   91: ldc 101
/*     */     //   93: istore 5
/*     */     //   95: iconst_0
/*     */     //   96: istore 9
/*     */     //   98: invokestatic 102	java/lang/System:currentTimeMillis	()J
/*     */     //   101: lstore 10
/*     */     //   103: goto +168 -> 271
/*     */     //   106: aload 8
/*     */     //   108: invokevirtual 108	javazoom/jl/decoder/Bitstream:readFrame	()Ljavazoom/jl/decoder/Header;
/*     */     //   111: astore 12
/*     */     //   113: aload 12
/*     */     //   115: ifnonnull +6 -> 121
/*     */     //   118: goto +178 -> 296
/*     */     //   121: aload_3
/*     */     //   122: iload 9
/*     */     //   124: aload 12
/*     */     //   126: invokeinterface 112 3 0
/*     */     //   131: aload 6
/*     */     //   133: ifnonnull +47 -> 180
/*     */     //   136: aload 12
/*     */     //   138: invokevirtual 115	javazoom/jl/decoder/Header:mode	()I
/*     */     //   141: iconst_3
/*     */     //   142: if_icmpne +7 -> 149
/*     */     //   145: iconst_1
/*     */     //   146: goto +4 -> 150
/*     */     //   149: iconst_2
/*     */     //   150: istore 13
/*     */     //   152: aload 12
/*     */     //   154: invokevirtual 120	javazoom/jl/decoder/Header:frequency	()I
/*     */     //   157: istore 14
/*     */     //   159: new 123	javazoom/jl/converter/WaveFileObuffer
/*     */     //   162: dup
/*     */     //   163: iload 13
/*     */     //   165: iload 14
/*     */     //   167: aload_2
/*     */     //   168: invokespecial 125	javazoom/jl/converter/WaveFileObuffer:<init>	(IILjava/lang/String;)V
/*     */     //   171: astore 6
/*     */     //   173: aload 7
/*     */     //   175: aload 6
/*     */     //   177: invokevirtual 128	javazoom/jl/decoder/Decoder:setOutputBuffer	(Ljavazoom/jl/decoder/Obuffer;)V
/*     */     //   180: aload 7
/*     */     //   182: aload 12
/*     */     //   184: aload 8
/*     */     //   186: invokevirtual 132	javazoom/jl/decoder/Decoder:decodeFrame	(Ljavazoom/jl/decoder/Header;Ljavazoom/jl/decoder/Bitstream;)Ljavazoom/jl/decoder/Obuffer;
/*     */     //   189: astore 13
/*     */     //   191: aload 13
/*     */     //   193: aload 6
/*     */     //   195: if_acmpeq +13 -> 208
/*     */     //   198: new 136	java/lang/InternalError
/*     */     //   201: dup
/*     */     //   202: ldc -118
/*     */     //   204: invokespecial 140	java/lang/InternalError:<init>	(Ljava/lang/String;)V
/*     */     //   207: athrow
/*     */     //   208: aload_3
/*     */     //   209: iload 9
/*     */     //   211: aload 12
/*     */     //   213: aload 6
/*     */     //   215: invokeinterface 143 4 0
/*     */     //   220: aload 8
/*     */     //   222: invokevirtual 147	javazoom/jl/decoder/Bitstream:closeFrame	()V
/*     */     //   225: goto +43 -> 268
/*     */     //   228: astore 12
/*     */     //   230: aload_3
/*     */     //   231: aload 12
/*     */     //   233: invokeinterface 150 2 0
/*     */     //   238: ifeq +7 -> 245
/*     */     //   241: iconst_0
/*     */     //   242: goto +4 -> 246
/*     */     //   245: iconst_1
/*     */     //   246: istore 13
/*     */     //   248: iload 13
/*     */     //   250: ifeq +18 -> 268
/*     */     //   253: new 17	javazoom/jl/decoder/JavaLayerException
/*     */     //   256: dup
/*     */     //   257: aload 12
/*     */     //   259: invokevirtual 154	java/lang/Exception:getLocalizedMessage	()Ljava/lang/String;
/*     */     //   262: aload 12
/*     */     //   264: invokespecial 52	javazoom/jl/decoder/JavaLayerException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   267: athrow
/*     */     //   268: iinc 9 1
/*     */     //   271: iload 9
/*     */     //   273: iload 5
/*     */     //   275: if_icmplt -169 -> 106
/*     */     //   278: goto +18 -> 296
/*     */     //   281: astore 15
/*     */     //   283: aload 6
/*     */     //   285: ifnull +8 -> 293
/*     */     //   288: aload 6
/*     */     //   290: invokevirtual 157	javazoom/jl/decoder/Obuffer:close	()V
/*     */     //   293: aload 15
/*     */     //   295: athrow
/*     */     //   296: aload 6
/*     */     //   298: ifnull +8 -> 306
/*     */     //   301: aload 6
/*     */     //   303: invokevirtual 157	javazoom/jl/decoder/Obuffer:close	()V
/*     */     //   306: invokestatic 102	java/lang/System:currentTimeMillis	()J
/*     */     //   309: lload 10
/*     */     //   311: lsub
/*     */     //   312: l2i
/*     */     //   313: istore 12
/*     */     //   315: aload_3
/*     */     //   316: iconst_2
/*     */     //   317: iload 12
/*     */     //   319: iload 9
/*     */     //   321: invokeinterface 87 4 0
/*     */     //   326: goto +20 -> 346
/*     */     //   329: astore 5
/*     */     //   331: new 17	javazoom/jl/decoder/JavaLayerException
/*     */     //   334: dup
/*     */     //   335: aload 5
/*     */     //   337: invokevirtual 46	java/io/IOException:getLocalizedMessage	()Ljava/lang/String;
/*     */     //   340: aload 5
/*     */     //   342: invokespecial 52	javazoom/jl/decoder/JavaLayerException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   345: athrow
/*     */     //   346: return
/*     */     // Line number table:
/*     */     //   Java source line #89	-> byte code offset #0
/*     */     //   Java source line #91	-> byte code offset #4
/*     */     //   Java source line #90	-> byte code offset #5
/*     */     //   Java source line #93	-> byte code offset #9
/*     */     //   Java source line #94	-> byte code offset #16
/*     */     //   Java source line #95	-> byte code offset #25
/*     */     //   Java source line #96	-> byte code offset #28
/*     */     //   Java source line #97	-> byte code offset #35
/*     */     //   Java source line #98	-> byte code offset #40
/*     */     //   Java source line #99	-> byte code offset #47
/*     */     //   Java source line #101	-> byte code offset #51
/*     */     //   Java source line #104	-> byte code offset #61
/*     */     //   Java source line #105	-> byte code offset #64
/*     */     //   Java source line #106	-> byte code offset #75
/*     */     //   Java source line #108	-> byte code offset #85
/*     */     //   Java source line #109	-> byte code offset #91
/*     */     //   Java source line #111	-> byte code offset #95
/*     */     //   Java source line #112	-> byte code offset #98
/*     */     //   Java source line #116	-> byte code offset #103
/*     */     //   Java source line #120	-> byte code offset #106
/*     */     //   Java source line #121	-> byte code offset #113
/*     */     //   Java source line #122	-> byte code offset #118
/*     */     //   Java source line #124	-> byte code offset #121
/*     */     //   Java source line #126	-> byte code offset #131
/*     */     //   Java source line #132	-> byte code offset #136
/*     */     //   Java source line #133	-> byte code offset #152
/*     */     //   Java source line #134	-> byte code offset #159
/*     */     //   Java source line #135	-> byte code offset #173
/*     */     //   Java source line #138	-> byte code offset #180
/*     */     //   Java source line #143	-> byte code offset #191
/*     */     //   Java source line #144	-> byte code offset #198
/*     */     //   Java source line #147	-> byte code offset #208
/*     */     //   Java source line #149	-> byte code offset #220
/*     */     //   Java source line #152	-> byte code offset #228
/*     */     //   Java source line #154	-> byte code offset #230
/*     */     //   Java source line #156	-> byte code offset #248
/*     */     //   Java source line #158	-> byte code offset #253
/*     */     //   Java source line #116	-> byte code offset #268
/*     */     //   Java source line #165	-> byte code offset #281
/*     */     //   Java source line #167	-> byte code offset #283
/*     */     //   Java source line #168	-> byte code offset #288
/*     */     //   Java source line #169	-> byte code offset #293
/*     */     //   Java source line #167	-> byte code offset #296
/*     */     //   Java source line #168	-> byte code offset #301
/*     */     //   Java source line #171	-> byte code offset #306
/*     */     //   Java source line #172	-> byte code offset #315
/*     */     //   Java source line #173	-> byte code offset #317
/*     */     //   Java source line #172	-> byte code offset #321
/*     */     //   Java source line #175	-> byte code offset #329
/*     */     //   Java source line #177	-> byte code offset #331
/*     */     //   Java source line #179	-> byte code offset #346
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	347	0	this	Converter
/*     */     //   0	347	1	sourceStream	InputStream
/*     */     //   0	347	2	destName	String
/*     */     //   0	347	3	progressListener	ProgressListener
/*     */     //   0	347	4	decoderParams	Decoder.Params
/*     */     //   26	248	5	frameCount	int
/*     */     //   329	12	5	ex	IOException
/*     */     //   62	240	6	output	Obuffer
/*     */     //   73	108	7	decoder	javazoom.jl.decoder.Decoder
/*     */     //   83	138	8	stream	javazoom.jl.decoder.Bitstream
/*     */     //   96	224	9	frame	int
/*     */     //   101	209	10	startTime	long
/*     */     //   111	101	12	header	Header
/*     */     //   228	35	12	ex	Exception
/*     */     //   313	5	12	time	int
/*     */     //   150	14	13	channels	int
/*     */     //   189	3	13	decoderOutput	Obuffer
/*     */     //   246	3	13	stop	boolean
/*     */     //   157	9	14	freq	int
/*     */     //   281	13	15	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   106	118	228	java/lang/Exception
/*     */     //   121	225	228	java/lang/Exception
/*     */     //   103	281	281	finally
/*     */     //   9	326	329	java/io/IOException
/*     */   }
/*     */   
/*     */   protected int countFrames(InputStream in)
/*     */   {
/* 184 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected InputStream openInput(String fileName)
/*     */     throws IOException
/*     */   {
/* 192 */     File file = new File(fileName);
/* 193 */     InputStream fileIn = new FileInputStream(file);
/* 194 */     BufferedInputStream bufIn = new BufferedInputStream(fileIn);
/*     */     
/* 196 */     return bufIn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class PrintWriterProgressListener
/*     */     implements Converter.ProgressListener
/*     */   {
/*     */     public static final int NO_DETAIL = 0;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static final int EXPERT_DETAIL = 1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static final int VERBOSE_DETAIL = 2;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static final int DEBUG_DETAIL = 7;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static final int MAX_DETAIL = 10;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private PrintWriter pw;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private int detailLevel;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static PrintWriterProgressListener newStdOut(int detail)
/*     */     {
/* 312 */       return new PrintWriterProgressListener(
/* 313 */         new PrintWriter(System.out, true), detail);
/*     */     }
/*     */     
/*     */     public PrintWriterProgressListener(PrintWriter writer, int detailLevel)
/*     */     {
/* 318 */       this.pw = writer;
/* 319 */       this.detailLevel = detailLevel;
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean isDetail(int detail)
/*     */     {
/* 325 */       return this.detailLevel >= detail;
/*     */     }
/*     */     
/*     */     public void converterUpdate(int updateID, int param1, int param2)
/*     */     {
/* 330 */       if (isDetail(2))
/*     */       {
/* 332 */         switch (updateID)
/*     */         {
/*     */ 
/*     */         case 2: 
/* 336 */           if (param2 == 0) {
/* 337 */             param2 = 1;
/*     */           }
/* 339 */           this.pw.println();
/* 340 */           this.pw.println("Converted " + param2 + " frames in " + param1 + " ms (" + 
/* 341 */             param1 / param2 + " ms per frame.)");
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     
/*     */     public void parsedFrame(int frameNo, Header header) {
/* 348 */       if ((frameNo == 0) && (isDetail(2)))
/*     */       {
/* 350 */         String headerString = header.toString();
/* 351 */         this.pw.println("File is a " + headerString);
/*     */       }
/* 353 */       else if (isDetail(10))
/*     */       {
/* 355 */         String headerString = header.toString();
/* 356 */         this.pw.println("Prased frame " + frameNo + ": " + headerString);
/*     */       }
/*     */     }
/*     */     
/*     */     public void readFrame(int frameNo, Header header)
/*     */     {
/* 362 */       if ((frameNo == 0) && (isDetail(2)))
/*     */       {
/* 364 */         String headerString = header.toString();
/* 365 */         this.pw.println("File is a " + headerString);
/*     */       }
/* 367 */       else if (isDetail(10))
/*     */       {
/* 369 */         String headerString = header.toString();
/* 370 */         this.pw.println("Read frame " + frameNo + ": " + headerString);
/*     */       }
/*     */     }
/*     */     
/*     */     public void decodedFrame(int frameNo, Header header, Obuffer o)
/*     */     {
/* 376 */       if (isDetail(10))
/*     */       {
/* 378 */         String headerString = header.toString();
/* 379 */         this.pw.println("Decoded frame " + frameNo + ": " + headerString);
/* 380 */         this.pw.println("Output: " + o);
/*     */       }
/* 382 */       else if (isDetail(2))
/*     */       {
/* 384 */         if (frameNo == 0)
/*     */         {
/* 386 */           this.pw.print("Converting.");
/* 387 */           this.pw.flush();
/*     */         }
/*     */         
/* 390 */         if (frameNo % 10 == 0)
/*     */         {
/* 392 */           this.pw.print('.');
/* 393 */           this.pw.flush();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean converterException(Throwable t)
/*     */     {
/* 400 */       if (this.detailLevel > 0)
/*     */       {
/* 402 */         t.printStackTrace(this.pw);
/* 403 */         this.pw.flush();
/*     */       }
/* 405 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract interface ProgressListener
/*     */   {
/*     */     public static final int UPDATE_FRAME_COUNT = 1;
/*     */     public static final int UPDATE_CONVERT_COMPLETE = 2;
/*     */     
/*     */     public abstract void converterUpdate(int paramInt1, int paramInt2, int paramInt3);
/*     */     
/*     */     public abstract void parsedFrame(int paramInt, Header paramHeader);
/*     */     
/*     */     public abstract void readFrame(int paramInt, Header paramHeader);
/*     */     
/*     */     public abstract void decodedFrame(int paramInt, Header paramHeader, Obuffer paramObuffer);
/*     */     
/*     */     public abstract boolean converterException(Throwable paramThrowable);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\javazoom\jl\converter\Converter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */