package javazoom.jl.decoder;

public abstract interface FrameDecoder
{
  public abstract void decodeFrame()
    throws DecoderException;
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\javazoom\jl\decoder\FrameDecoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */