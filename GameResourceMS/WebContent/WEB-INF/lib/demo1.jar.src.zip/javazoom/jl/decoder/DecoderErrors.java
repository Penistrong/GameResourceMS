package javazoom.jl.decoder;

public abstract interface DecoderErrors
  extends JavaLayerErrors
{
  public static final int UNKNOWN_ERROR = 512;
  public static final int UNSUPPORTED_LAYER = 513;
  public static final int ILLEGAL_SUBBAND_ALLOCATION = 514;
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\javazoom\jl\decoder\DecoderErrors.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */