package javazoom.jl.decoder;

public class Manager
{
  public void addControl(Control c) {}
  
  public void removeControl(Control c) {}
  
  public void removeAll() {}
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\javazoom\jl\decoder\Manager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */