/*    */ package javazoom.jl.decoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DecoderException
/*    */   extends JavaLayerException
/*    */   implements DecoderErrors
/*    */ {
/* 32 */   private int errorcode = 512;
/*    */   
/*    */   public DecoderException(String msg, Throwable t)
/*    */   {
/* 36 */     super(msg, t);
/*    */   }
/*    */   
/*    */   public DecoderException(int errorcode, Throwable t)
/*    */   {
/* 41 */     this(getErrorString(errorcode), t);
/*    */   }
/*    */   
/*    */ 
/*    */   public int getErrorCode()
/*    */   {
/* 47 */     return this.errorcode;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String getErrorString(int errorcode)
/*    */   {
/* 56 */     return "Decoder errorcode " + Integer.toHexString(errorcode);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\javazoom\jl\decoder\DecoderException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */