package javazoom.jl.decoder;

public class JavaLayerError
  extends Error
{}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\javazoom\jl\decoder\JavaLayerError.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */