/*    */ package javazoom.jl.player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullAudioDevice
/*    */   extends AudioDeviceBase
/*    */ {
/*    */   public int getPosition()
/*    */   {
/* 35 */     return 0;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\javazoom\jl\player\NullAudioDevice.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */