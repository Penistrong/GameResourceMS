/*    */ package javazoom.jl.player;
/*    */ 
/*    */ import javazoom.jl.decoder.JavaLayerException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaSoundAudioDeviceFactory
/*    */   extends AudioDeviceFactory
/*    */ {
/* 33 */   private boolean tested = false;
/*    */   
/*    */   private static final String DEVICE_CLASS_NAME = "javazoom.jl.player.JavaSoundAudioDevice";
/*    */   
/*    */   public synchronized AudioDevice createAudioDevice()
/*    */     throws JavaLayerException
/*    */   {
/* 40 */     if (!this.tested)
/*    */     {
/* 42 */       testAudioDevice();
/* 43 */       this.tested = true;
/*    */     }
/*    */     
/*    */     try
/*    */     {
/* 48 */       return createAudioDeviceImpl();
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 52 */       throw new JavaLayerException("unable to create JavaSound device: " + ex);
/*    */     }
/*    */     catch (LinkageError ex)
/*    */     {
/* 56 */       throw new JavaLayerException("unable to create JavaSound device: " + ex);
/*    */     }
/*    */   }
/*    */   
/*    */   protected JavaSoundAudioDevice createAudioDeviceImpl()
/*    */     throws JavaLayerException
/*    */   {
/* 63 */     ClassLoader loader = getClass().getClassLoader();
/*    */     try
/*    */     {
/* 66 */       return (JavaSoundAudioDevice)instantiate(loader, "javazoom.jl.player.JavaSoundAudioDevice");
/*    */ 
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 71 */       throw new JavaLayerException("Cannot create JavaSound device", ex);
/*    */     }
/*    */     catch (LinkageError ex)
/*    */     {
/* 75 */       throw new JavaLayerException("Cannot create JavaSound device", ex);
/*    */     }
/*    */   }
/*    */   
/*    */   public void testAudioDevice()
/*    */     throws JavaLayerException
/*    */   {
/* 82 */     JavaSoundAudioDevice dev = createAudioDeviceImpl();
/* 83 */     dev.test();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\javazoom\jl\player\JavaSoundAudioDeviceFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */