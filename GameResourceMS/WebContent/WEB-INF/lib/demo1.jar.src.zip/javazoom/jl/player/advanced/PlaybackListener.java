package javazoom.jl.player.advanced;

public abstract class PlaybackListener
{
  public void playbackStarted(PlaybackEvent evt) {}
  
  public void playbackFinished(PlaybackEvent evt) {}
}


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\javazoom\jl\player\advanced\PlaybackListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */