/*    */ import greenfoot.GreenfootSound;
/*    */ import greenfoot.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StartScreen
/*    */   extends World
/*    */ {
/* 14 */   private GreenfootSound background = new GreenfootSound("menu.wav");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public StartScreen()
/*    */   {
/* 22 */     super(1111, 602, 1);
/* 23 */     prepare();
/* 24 */     this.background.playLoop();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void stopBackgroundMusic()
/*    */   {
/* 32 */     this.background.stop();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private void prepare()
/*    */   {
/* 40 */     ClickToStart start = new ClickToStart();
/* 41 */     addObject(start, 641, 534);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\StartScreen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */