/*    */ import greenfoot.Actor;
/*    */ import greenfoot.GreenfootSound;
/*    */ import greenfoot.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Plants
/*    */   extends Actor
/*    */ {
/* 15 */   GreenfootSound plantEaten = new GreenfootSound("chomp.wav");
/* 16 */   protected int timeToLive = 2000;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void setTimeToLive(int time)
/*    */   {
/* 23 */     this.timeToLive = time;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void plantHit(String filename, int timeLoop)
/*    */   {
/* 31 */     if (isTouching(Zombie.class))
/*    */     {
/* 33 */       this.timeToLive -= 20;
/* 34 */       this.plantEaten.play();
/*    */     }
/*    */     
/* 37 */     if (this.timeToLive < 0)
/*    */     {
/* 39 */       World world = getWorld();
/* 40 */       dyingPlantAnimation(filename, timeLoop);
/* 41 */       world.removeObject(this);
/* 42 */       this.plantEaten.stop();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void dyingPlantAnimation(String filename, int timeLoop)
/*    */   {
/* 51 */     DeadActor dead = new DeadActor(filename, timeLoop);
/* 52 */     World world = getWorld();
/* 53 */     world.addObject(dead, getX(), getY());
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\Plants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */