/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NormalZombie
/*    */   extends Zombie
/*    */ {
/* 13 */   private GifImage gif = new GifImage("zombie_normal.gif");
/*    */   
/*    */ 
/*    */ 
/*    */   public NormalZombie()
/*    */   {
/* 19 */     setImage(this.gif.getCurrentImage());
/* 20 */     setHealth(100);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void act()
/*    */   {
/* 28 */     setImage(this.gif.getCurrentImage());
/* 29 */     move(this.zombieSpeed);
/* 30 */     checkGameOver();
/* 31 */     setSpeed(-1);
/* 32 */     zombieHit(25, "zombie_normal_dying.gif", 800, 10);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\NormalZombie.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */