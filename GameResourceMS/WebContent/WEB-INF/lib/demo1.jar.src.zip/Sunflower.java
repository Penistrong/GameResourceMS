/*    */ import greenfoot.World;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Sunflower
/*    */   extends Plants
/*    */ {
/* 14 */   private GifImage gif = new GifImage("sun_flower.gif");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Sunflower()
/*    */   {
/* 21 */     setImage(this.gif.getCurrentImage());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void act()
/*    */   {
/* 30 */     setImage(this.gif.getCurrentImage());
/* 31 */     produceSun(4000);
/* 32 */     plantHit("sun_flower_dying.gif", 1000);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 38 */   private long lastAdded = System.currentTimeMillis();
/*    */   
/*    */   public void produceSun(int timeInterval)
/*    */   {
/* 42 */     long curTime = System.currentTimeMillis();
/* 43 */     if (curTime >= this.lastAdded + timeInterval)
/*    */     {
/* 45 */       this.lastAdded = curTime;
/* 46 */       Sun sun = new Sun();
/* 47 */       World world = getWorld();
/* 48 */       if (world.getObjectsAt(getX() + 30, getY() + 30, Sun.class).isEmpty())
/*    */       {
/* 50 */         world.addObject(sun, getX() + 30, getY() + 30);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\Sunflower.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */