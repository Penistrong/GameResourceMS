/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FootballZombie
/*    */   extends Zombie
/*    */ {
/* 14 */   private GifImage gif = new GifImage("zombie_football.gif");
/*    */   
/*    */ 
/*    */ 
/*    */   public FootballZombie()
/*    */   {
/* 20 */     setImage(this.gif.getCurrentImage());
/* 21 */     setHealth(100);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void act()
/*    */   {
/* 29 */     setImage(this.gif.getCurrentImage());
/* 30 */     move(this.zombieSpeed);
/* 31 */     checkGameOver();
/* 32 */     setSpeed(-1);
/* 33 */     zombieHit(20, "zombie_football_dying.gif", 600, 20);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\FootballZombie.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */