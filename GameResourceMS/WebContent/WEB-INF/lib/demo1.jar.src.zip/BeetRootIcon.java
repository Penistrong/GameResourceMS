/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeetRootIcon
/*    */   extends Sidebar
/*    */ {
/*    */   public BeetRootIcon(int positionX, int positionY)
/*    */   {
/* 19 */     setCostOfPlant(125);
/* 20 */     setIconCoordinates(positionX, positionY);
/* 21 */     setActiveImage("active_beetroot.png");
/* 22 */     setInactiveImage("inactive_beetroot.png");
/*    */   }
/*    */   
/*    */   public void act()
/*    */   {
/* 27 */     createPlant(new Beetroot());
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\BeetRootIcon.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */