/*    */ import greenfoot.Actor;
/*    */ import greenfoot.Greenfoot;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Replay
/*    */   extends Actor
/*    */ {
/* 12 */   private GifImage gif = new GifImage("gameOver.gif");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void act()
/*    */   {
/* 20 */     setImage(this.gif.getCurrentImage());
/*    */     
/* 22 */     if (Greenfoot.mouseClicked(this))
/*    */     {
/* 24 */       Greenfoot.setWorld(new StartScreen());
/* 25 */       GameOver world = (GameOver)getWorld();
/* 26 */       world.stopBackgroundMusic();
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\demo1\PlantsVsZombies-Game\Plants Vs Zombies.jar!\Replay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */