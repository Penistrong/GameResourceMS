/*    */ package org.apache.ibatis.scripting.xmltags;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.apache.ibatis.session.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetSqlNode
/*    */   extends TrimSqlNode
/*    */ {
/* 28 */   private static List<String> suffixList = Arrays.asList(new String[] { "," });
/*    */   
/*    */   public SetSqlNode(Configuration configuration, SqlNode contents) {
/* 31 */     super(configuration, contents, "SET", null, null, suffixList);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\xmltags\SetSqlNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */