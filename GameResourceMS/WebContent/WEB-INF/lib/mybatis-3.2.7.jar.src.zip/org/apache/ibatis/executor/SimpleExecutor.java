/*    */ package org.apache.ibatis.executor;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.apache.ibatis.executor.statement.StatementHandler;
/*    */ import org.apache.ibatis.logging.Log;
/*    */ import org.apache.ibatis.mapping.BoundSql;
/*    */ import org.apache.ibatis.mapping.MappedStatement;
/*    */ import org.apache.ibatis.session.Configuration;
/*    */ import org.apache.ibatis.session.ResultHandler;
/*    */ import org.apache.ibatis.session.RowBounds;
/*    */ import org.apache.ibatis.transaction.Transaction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleExecutor
/*    */   extends BaseExecutor
/*    */ {
/*    */   public SimpleExecutor(Configuration configuration, Transaction transaction)
/*    */   {
/* 39 */     super(configuration, transaction);
/*    */   }
/*    */   
/*    */   public int doUpdate(MappedStatement ms, Object parameter) throws SQLException {
/* 43 */     Statement stmt = null;
/*    */     try {
/* 45 */       Configuration configuration = ms.getConfiguration();
/* 46 */       StatementHandler handler = configuration.newStatementHandler(this, ms, parameter, RowBounds.DEFAULT, null, null);
/* 47 */       stmt = prepareStatement(handler, ms.getStatementLog());
/* 48 */       return handler.update(stmt);
/*    */     } finally {
/* 50 */       closeStatement(stmt);
/*    */     }
/*    */   }
/*    */   
/*    */   public <E> List<E> doQuery(MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler, BoundSql boundSql) throws SQLException {
/* 55 */     Statement stmt = null;
/*    */     try {
/* 57 */       Configuration configuration = ms.getConfiguration();
/* 58 */       StatementHandler handler = configuration.newStatementHandler(this.wrapper, ms, parameter, rowBounds, resultHandler, boundSql);
/* 59 */       stmt = prepareStatement(handler, ms.getStatementLog());
/* 60 */       return handler.query(stmt, resultHandler);
/*    */     } finally {
/* 62 */       closeStatement(stmt);
/*    */     }
/*    */   }
/*    */   
/*    */   public List<BatchResult> doFlushStatements(boolean isRollback) throws SQLException {
/* 67 */     return Collections.emptyList();
/*    */   }
/*    */   
/*    */   private Statement prepareStatement(StatementHandler handler, Log statementLog) throws SQLException
/*    */   {
/* 72 */     Connection connection = getConnection(statementLog);
/* 73 */     Statement stmt = handler.prepare(connection);
/* 74 */     handler.parameterize(stmt);
/* 75 */     return stmt;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\SimpleExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */