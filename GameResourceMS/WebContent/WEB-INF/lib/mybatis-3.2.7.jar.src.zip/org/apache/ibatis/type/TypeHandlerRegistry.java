/*     */ package org.apache.ibatis.type;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Type;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumMap;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.ibatis.io.ResolverUtil;
/*     */ import org.apache.ibatis.io.ResolverUtil.IsA;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TypeHandlerRegistry
/*     */ {
/*  38 */   private static final Map<Class<?>, Class<?>> reversePrimitiveMap = new HashMap()
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  52 */   private final Map<JdbcType, TypeHandler<?>> JDBC_TYPE_HANDLER_MAP = new EnumMap(JdbcType.class);
/*  53 */   private final Map<Type, Map<JdbcType, TypeHandler<?>>> TYPE_HANDLER_MAP = new HashMap();
/*  54 */   private final TypeHandler<Object> UNKNOWN_TYPE_HANDLER = new UnknownTypeHandler(this);
/*  55 */   private final Map<Class<?>, TypeHandler<?>> ALL_TYPE_HANDLERS_MAP = new HashMap();
/*     */   
/*     */   public TypeHandlerRegistry() {
/*  58 */     register(Boolean.class, new BooleanTypeHandler());
/*  59 */     register(Boolean.TYPE, new BooleanTypeHandler());
/*  60 */     register(JdbcType.BOOLEAN, new BooleanTypeHandler());
/*  61 */     register(JdbcType.BIT, new BooleanTypeHandler());
/*     */     
/*  63 */     register(Byte.class, new ByteTypeHandler());
/*  64 */     register(Byte.TYPE, new ByteTypeHandler());
/*  65 */     register(JdbcType.TINYINT, new ByteTypeHandler());
/*     */     
/*  67 */     register(Short.class, new ShortTypeHandler());
/*  68 */     register(Short.TYPE, new ShortTypeHandler());
/*  69 */     register(JdbcType.SMALLINT, new ShortTypeHandler());
/*     */     
/*  71 */     register(Integer.class, new IntegerTypeHandler());
/*  72 */     register(Integer.TYPE, new IntegerTypeHandler());
/*  73 */     register(JdbcType.INTEGER, new IntegerTypeHandler());
/*     */     
/*  75 */     register(Long.class, new LongTypeHandler());
/*  76 */     register(Long.TYPE, new LongTypeHandler());
/*     */     
/*  78 */     register(Float.class, new FloatTypeHandler());
/*  79 */     register(Float.TYPE, new FloatTypeHandler());
/*  80 */     register(JdbcType.FLOAT, new FloatTypeHandler());
/*     */     
/*  82 */     register(Double.class, new DoubleTypeHandler());
/*  83 */     register(Double.TYPE, new DoubleTypeHandler());
/*  84 */     register(JdbcType.DOUBLE, new DoubleTypeHandler());
/*     */     
/*  86 */     register(String.class, new StringTypeHandler());
/*  87 */     register(String.class, JdbcType.CHAR, new StringTypeHandler());
/*  88 */     register(String.class, JdbcType.CLOB, new ClobTypeHandler());
/*  89 */     register(String.class, JdbcType.VARCHAR, new StringTypeHandler());
/*  90 */     register(String.class, JdbcType.LONGVARCHAR, new ClobTypeHandler());
/*  91 */     register(String.class, JdbcType.NVARCHAR, new NStringTypeHandler());
/*  92 */     register(String.class, JdbcType.NCHAR, new NStringTypeHandler());
/*  93 */     register(String.class, JdbcType.NCLOB, new NClobTypeHandler());
/*  94 */     register(JdbcType.CHAR, new StringTypeHandler());
/*  95 */     register(JdbcType.VARCHAR, new StringTypeHandler());
/*  96 */     register(JdbcType.CLOB, new ClobTypeHandler());
/*  97 */     register(JdbcType.LONGVARCHAR, new ClobTypeHandler());
/*  98 */     register(JdbcType.NVARCHAR, new NStringTypeHandler());
/*  99 */     register(JdbcType.NCHAR, new NStringTypeHandler());
/* 100 */     register(JdbcType.NCLOB, new NClobTypeHandler());
/*     */     
/* 102 */     register(Object.class, JdbcType.ARRAY, new ArrayTypeHandler());
/* 103 */     register(JdbcType.ARRAY, new ArrayTypeHandler());
/*     */     
/* 105 */     register(BigInteger.class, new BigIntegerTypeHandler());
/* 106 */     register(JdbcType.BIGINT, new LongTypeHandler());
/*     */     
/* 108 */     register(BigDecimal.class, new BigDecimalTypeHandler());
/* 109 */     register(JdbcType.REAL, new BigDecimalTypeHandler());
/* 110 */     register(JdbcType.DECIMAL, new BigDecimalTypeHandler());
/* 111 */     register(JdbcType.NUMERIC, new BigDecimalTypeHandler());
/*     */     
/* 113 */     register(Byte[].class, new ByteObjectArrayTypeHandler());
/* 114 */     register(Byte[].class, JdbcType.BLOB, new BlobByteObjectArrayTypeHandler());
/* 115 */     register(Byte[].class, JdbcType.LONGVARBINARY, new BlobByteObjectArrayTypeHandler());
/* 116 */     register(byte[].class, new ByteArrayTypeHandler());
/* 117 */     register(byte[].class, JdbcType.BLOB, new BlobTypeHandler());
/* 118 */     register(byte[].class, JdbcType.LONGVARBINARY, new BlobTypeHandler());
/* 119 */     register(JdbcType.LONGVARBINARY, new BlobTypeHandler());
/* 120 */     register(JdbcType.BLOB, new BlobTypeHandler());
/*     */     
/* 122 */     register(Object.class, this.UNKNOWN_TYPE_HANDLER);
/* 123 */     register(Object.class, JdbcType.OTHER, this.UNKNOWN_TYPE_HANDLER);
/* 124 */     register(JdbcType.OTHER, this.UNKNOWN_TYPE_HANDLER);
/*     */     
/* 126 */     register(java.util.Date.class, new DateTypeHandler());
/* 127 */     register(java.util.Date.class, JdbcType.DATE, new DateOnlyTypeHandler());
/* 128 */     register(java.util.Date.class, JdbcType.TIME, new TimeOnlyTypeHandler());
/* 129 */     register(JdbcType.TIMESTAMP, new DateTypeHandler());
/* 130 */     register(JdbcType.DATE, new DateOnlyTypeHandler());
/* 131 */     register(JdbcType.TIME, new TimeOnlyTypeHandler());
/*     */     
/* 133 */     register(java.sql.Date.class, new SqlDateTypeHandler());
/* 134 */     register(Time.class, new SqlTimeTypeHandler());
/* 135 */     register(Timestamp.class, new SqlTimestampTypeHandler());
/*     */     
/*     */ 
/* 138 */     register(Character.class, new CharacterTypeHandler());
/* 139 */     register(Character.TYPE, new CharacterTypeHandler());
/*     */   }
/*     */   
/*     */   public boolean hasTypeHandler(Class<?> javaType) {
/* 143 */     return hasTypeHandler(javaType, null);
/*     */   }
/*     */   
/*     */   public boolean hasTypeHandler(TypeReference<?> javaTypeReference) {
/* 147 */     return hasTypeHandler(javaTypeReference, null);
/*     */   }
/*     */   
/*     */   public boolean hasTypeHandler(Class<?> javaType, JdbcType jdbcType) {
/* 151 */     return (javaType != null) && (getTypeHandler(javaType, jdbcType) != null);
/*     */   }
/*     */   
/*     */   public boolean hasTypeHandler(TypeReference<?> javaTypeReference, JdbcType jdbcType) {
/* 155 */     return (javaTypeReference != null) && (getTypeHandler(javaTypeReference, jdbcType) != null);
/*     */   }
/*     */   
/*     */   public TypeHandler<?> getMappingTypeHandler(Class<? extends TypeHandler<?>> handlerType) {
/* 159 */     return (TypeHandler)this.ALL_TYPE_HANDLERS_MAP.get(handlerType);
/*     */   }
/*     */   
/*     */   public <T> TypeHandler<T> getTypeHandler(Class<T> type) {
/* 163 */     return getTypeHandler(type, null);
/*     */   }
/*     */   
/*     */   public <T> TypeHandler<T> getTypeHandler(TypeReference<T> javaTypeReference) {
/* 167 */     return getTypeHandler(javaTypeReference, null);
/*     */   }
/*     */   
/*     */   public TypeHandler<?> getTypeHandler(JdbcType jdbcType) {
/* 171 */     return (TypeHandler)this.JDBC_TYPE_HANDLER_MAP.get(jdbcType);
/*     */   }
/*     */   
/*     */   public <T> TypeHandler<T> getTypeHandler(Class<T> type, JdbcType jdbcType) {
/* 175 */     return getTypeHandler(type, jdbcType);
/*     */   }
/*     */   
/*     */   public <T> TypeHandler<T> getTypeHandler(TypeReference<T> javaTypeReference, JdbcType jdbcType) {
/* 179 */     return getTypeHandler(javaTypeReference.getRawType(), jdbcType);
/*     */   }
/*     */   
/*     */   private <T> TypeHandler<T> getTypeHandler(Type type, JdbcType jdbcType) {
/* 183 */     Map<JdbcType, TypeHandler<?>> jdbcHandlerMap = (Map)this.TYPE_HANDLER_MAP.get(type);
/* 184 */     TypeHandler<?> handler = null;
/* 185 */     if (jdbcHandlerMap != null) {
/* 186 */       handler = (TypeHandler)jdbcHandlerMap.get(jdbcType);
/* 187 */       if (handler == null) {
/* 188 */         handler = (TypeHandler)jdbcHandlerMap.get(null);
/*     */       }
/*     */     }
/* 191 */     if ((handler == null) && (type != null) && ((type instanceof Class)) && (Enum.class.isAssignableFrom((Class)type))) {
/* 192 */       handler = new EnumTypeHandler((Class)type);
/*     */     }
/*     */     
/*     */ 
/* 196 */     TypeHandler<T> returned = handler;
/* 197 */     return returned;
/*     */   }
/*     */   
/*     */   public TypeHandler<Object> getUnknownTypeHandler() {
/* 201 */     return this.UNKNOWN_TYPE_HANDLER;
/*     */   }
/*     */   
/*     */   public void register(JdbcType jdbcType, TypeHandler<?> handler) {
/* 205 */     this.JDBC_TYPE_HANDLER_MAP.put(jdbcType, handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> void register(TypeHandler<T> typeHandler)
/*     */   {
/* 216 */     boolean mappedTypeFound = false;
/* 217 */     MappedTypes mappedTypes = (MappedTypes)typeHandler.getClass().getAnnotation(MappedTypes.class);
/* 218 */     if (mappedTypes != null) {
/* 219 */       for (Class<?> handledType : mappedTypes.value()) {
/* 220 */         register(handledType, typeHandler);
/* 221 */         mappedTypeFound = true;
/*     */       }
/*     */     }
/*     */     
/* 225 */     if ((!mappedTypeFound) && ((typeHandler instanceof TypeReference))) {
/*     */       try {
/* 227 */         TypeReference<T> typeReference = (TypeReference)typeHandler;
/* 228 */         register(typeReference.getRawType(), typeHandler);
/* 229 */         mappedTypeFound = true;
/*     */       }
/*     */       catch (Throwable t) {}
/*     */     }
/*     */     
/* 234 */     if (!mappedTypeFound) {
/* 235 */       register((Class)null, typeHandler);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> void register(Class<T> javaType, TypeHandler<? extends T> typeHandler)
/*     */   {
/* 242 */     register(javaType, typeHandler);
/*     */   }
/*     */   
/*     */   private <T> void register(Type javaType, TypeHandler<? extends T> typeHandler) {
/* 246 */     MappedJdbcTypes mappedJdbcTypes = (MappedJdbcTypes)typeHandler.getClass().getAnnotation(MappedJdbcTypes.class);
/* 247 */     if (mappedJdbcTypes != null) {
/* 248 */       for (JdbcType handledJdbcType : mappedJdbcTypes.value()) {
/* 249 */         register(javaType, handledJdbcType, typeHandler);
/*     */       }
/* 251 */       if (mappedJdbcTypes.includeNullJdbcType()) {
/* 252 */         register(javaType, null, typeHandler);
/*     */       }
/*     */     } else {
/* 255 */       register(javaType, null, typeHandler);
/*     */     }
/*     */   }
/*     */   
/*     */   public <T> void register(TypeReference<T> javaTypeReference, TypeHandler<? extends T> handler) {
/* 260 */     register(javaTypeReference.getRawType(), handler);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> void register(Class<T> type, JdbcType jdbcType, TypeHandler<? extends T> handler)
/*     */   {
/* 266 */     register(type, jdbcType, handler);
/*     */   }
/*     */   
/*     */   private void register(Type javaType, JdbcType jdbcType, TypeHandler<?> handler) {
/* 270 */     if (javaType != null) {
/* 271 */       Map<JdbcType, TypeHandler<?>> map = (Map)this.TYPE_HANDLER_MAP.get(javaType);
/* 272 */       if (map == null) {
/* 273 */         map = new HashMap();
/* 274 */         this.TYPE_HANDLER_MAP.put(javaType, map);
/*     */       }
/* 276 */       map.put(jdbcType, handler);
/* 277 */       if (reversePrimitiveMap.containsKey(javaType)) {
/* 278 */         register((Type)reversePrimitiveMap.get(javaType), jdbcType, handler);
/*     */       }
/*     */     }
/* 281 */     this.ALL_TYPE_HANDLERS_MAP.put(handler.getClass(), handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void register(Class<?> typeHandlerClass)
/*     */   {
/* 291 */     boolean mappedTypeFound = false;
/* 292 */     MappedTypes mappedTypes = (MappedTypes)typeHandlerClass.getAnnotation(MappedTypes.class);
/* 293 */     if (mappedTypes != null) {
/* 294 */       for (Class<?> javaTypeClass : mappedTypes.value()) {
/* 295 */         register(javaTypeClass, typeHandlerClass);
/* 296 */         mappedTypeFound = true;
/*     */       }
/*     */     }
/* 299 */     if (!mappedTypeFound) {
/* 300 */       register(getInstance(null, typeHandlerClass));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void register(Class<?> javaTypeClass, Class<?> typeHandlerClass)
/*     */   {
/* 307 */     register(javaTypeClass, getInstance(javaTypeClass, typeHandlerClass));
/*     */   }
/*     */   
/*     */ 
/*     */   public void register(Class<?> javaTypeClass, JdbcType jdbcType, Class<?> typeHandlerClass)
/*     */   {
/* 313 */     register(javaTypeClass, jdbcType, getInstance(javaTypeClass, typeHandlerClass));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public <T> TypeHandler<T> getInstance(Class<?> javaTypeClass, Class<?> typeHandlerClass)
/*     */   {
/* 320 */     if (javaTypeClass != null) {
/*     */       try {
/* 322 */         Constructor<?> c = typeHandlerClass.getConstructor(new Class[] { Class.class });
/* 323 */         return (TypeHandler)c.newInstance(new Object[] { javaTypeClass });
/*     */       }
/*     */       catch (NoSuchMethodException ignored) {}catch (Exception e)
/*     */       {
/* 327 */         throw new TypeException("Failed invoking constructor for handler " + typeHandlerClass, e);
/*     */       }
/*     */     }
/*     */     try {
/* 331 */       Constructor<?> c = typeHandlerClass.getConstructor(new Class[0]);
/* 332 */       return (TypeHandler)c.newInstance(new Object[0]);
/*     */     } catch (Exception e) {
/* 334 */       throw new TypeException("Unable to find a usable constructor for " + typeHandlerClass, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void register(String packageName)
/*     */   {
/* 341 */     ResolverUtil<Class<?>> resolverUtil = new ResolverUtil();
/* 342 */     resolverUtil.find(new ResolverUtil.IsA(TypeHandler.class), packageName);
/* 343 */     Set<Class<? extends Class<?>>> handlerSet = resolverUtil.getClasses();
/* 344 */     for (Class<?> type : handlerSet)
/*     */     {
/* 346 */       if ((!type.isAnonymousClass()) && (!type.isInterface()) && (!Modifier.isAbstract(type.getModifiers()))) {
/* 347 */         register(type);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<TypeHandler<?>> getTypeHandlers()
/*     */   {
/* 358 */     return Collections.unmodifiableCollection(this.ALL_TYPE_HANDLERS_MAP.values());
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\TypeHandlerRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */