package org.apache.ibatis.plugin;

import java.util.Properties;

public abstract interface Interceptor
{
  public abstract Object intercept(Invocation paramInvocation)
    throws Throwable;
  
  public abstract Object plugin(Object paramObject);
  
  public abstract void setProperties(Properties paramProperties);
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\plugin\Interceptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */