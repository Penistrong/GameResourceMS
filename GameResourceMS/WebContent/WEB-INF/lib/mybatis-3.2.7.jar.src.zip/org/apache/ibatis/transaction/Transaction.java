package org.apache.ibatis.transaction;

import java.sql.Connection;
import java.sql.SQLException;

public abstract interface Transaction
{
  public abstract Connection getConnection()
    throws SQLException;
  
  public abstract void commit()
    throws SQLException;
  
  public abstract void rollback()
    throws SQLException;
  
  public abstract void close()
    throws SQLException;
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\transaction\Transaction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */