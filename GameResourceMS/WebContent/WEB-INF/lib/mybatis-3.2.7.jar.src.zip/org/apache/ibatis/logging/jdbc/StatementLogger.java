/*     */ package org.apache.ibatis.logging.jdbc;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.Statement;
/*     */ import java.util.Set;
/*     */ import org.apache.ibatis.logging.Log;
/*     */ import org.apache.ibatis.reflection.ExceptionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StatementLogger
/*     */   extends BaseJdbcLogger
/*     */   implements InvocationHandler
/*     */ {
/*     */   private Statement statement;
/*     */   
/*     */   private StatementLogger(Statement stmt, Log statementLog, int queryStack)
/*     */   {
/*  39 */     super(statementLog, queryStack);
/*  40 */     this.statement = stmt;
/*     */   }
/*     */   
/*     */   public Object invoke(Object proxy, Method method, Object[] params) throws Throwable {
/*     */     try {
/*  45 */       if (Object.class.equals(method.getDeclaringClass())) {
/*  46 */         return method.invoke(this, params);
/*     */       }
/*  48 */       if (EXECUTE_METHODS.contains(method.getName())) {
/*  49 */         if (isDebugEnabled()) {
/*  50 */           debug(" Executing: " + removeBreakingWhitespace((String)params[0]), true);
/*     */         }
/*  52 */         if ("executeQuery".equals(method.getName())) {
/*  53 */           ResultSet rs = (ResultSet)method.invoke(this.statement, params);
/*  54 */           if (rs != null) {
/*  55 */             return ResultSetLogger.newInstance(rs, this.statementLog, this.queryStack);
/*     */           }
/*  57 */           return null;
/*     */         }
/*     */         
/*  60 */         return method.invoke(this.statement, params);
/*     */       }
/*  62 */       if ("getResultSet".equals(method.getName())) {
/*  63 */         ResultSet rs = (ResultSet)method.invoke(this.statement, params);
/*  64 */         if (rs != null) {
/*  65 */           return ResultSetLogger.newInstance(rs, this.statementLog, this.queryStack);
/*     */         }
/*  67 */         return null;
/*     */       }
/*  69 */       if ("equals".equals(method.getName())) {
/*  70 */         Object ps = params[0];
/*  71 */         return Boolean.valueOf(((ps instanceof Proxy)) && (proxy == ps)); }
/*  72 */       if ("hashCode".equals(method.getName())) {
/*  73 */         return Integer.valueOf(proxy.hashCode());
/*     */       }
/*  75 */       return method.invoke(this.statement, params);
/*     */     }
/*     */     catch (Throwable t) {
/*  78 */       throw ExceptionUtil.unwrapThrowable(t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Statement newInstance(Statement stmt, Log statementLog, int queryStack)
/*     */   {
/*  89 */     InvocationHandler handler = new StatementLogger(stmt, statementLog, queryStack);
/*  90 */     ClassLoader cl = Statement.class.getClassLoader();
/*  91 */     return (Statement)Proxy.newProxyInstance(cl, new Class[] { Statement.class }, handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Statement getStatement()
/*     */   {
/* 100 */     return this.statement;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\logging\jdbc\StatementLogger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */