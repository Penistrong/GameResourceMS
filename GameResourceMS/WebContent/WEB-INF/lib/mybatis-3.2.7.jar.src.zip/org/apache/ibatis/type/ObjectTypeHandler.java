/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectTypeHandler
/*    */   extends BaseTypeHandler<Object>
/*    */ {
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, Object parameter, JdbcType jdbcType)
/*    */     throws SQLException
/*    */   {
/* 31 */     ps.setObject(i, parameter);
/*    */   }
/*    */   
/*    */   public Object getNullableResult(ResultSet rs, String columnName)
/*    */     throws SQLException
/*    */   {
/* 37 */     return rs.getObject(columnName);
/*    */   }
/*    */   
/*    */   public Object getNullableResult(ResultSet rs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 43 */     return rs.getObject(columnIndex);
/*    */   }
/*    */   
/*    */   public Object getNullableResult(CallableStatement cs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 49 */     return cs.getObject(columnIndex);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\ObjectTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */