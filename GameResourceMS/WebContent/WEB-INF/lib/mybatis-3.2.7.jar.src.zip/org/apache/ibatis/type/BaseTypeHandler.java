/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.apache.ibatis.session.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BaseTypeHandler<T>
/*    */   extends TypeReference<T>
/*    */   implements TypeHandler<T>
/*    */ {
/*    */   protected Configuration configuration;
/*    */   
/*    */   public void setConfiguration(Configuration c)
/*    */   {
/* 34 */     this.configuration = c;
/*    */   }
/*    */   
/*    */   public void setParameter(PreparedStatement ps, int i, T parameter, JdbcType jdbcType) throws SQLException {
/* 38 */     if (parameter == null) {
/* 39 */       if (jdbcType == null) {
/* 40 */         throw new TypeException("JDBC requires that the JdbcType must be specified for all nullable parameters.");
/*    */       }
/*    */       try {
/* 43 */         ps.setNull(i, jdbcType.TYPE_CODE);
/*    */       } catch (SQLException e) {
/* 45 */         throw new TypeException("Error setting null for parameter #" + i + " with JdbcType " + jdbcType + " . " + "Try setting a different JdbcType for this parameter or a different jdbcTypeForNull configuration property. " + "Cause: " + e, e);
/*    */       }
/*    */     }
/*    */     else
/*    */     {
/* 50 */       setNonNullParameter(ps, i, parameter, jdbcType);
/*    */     }
/*    */   }
/*    */   
/*    */   public T getResult(ResultSet rs, String columnName) throws SQLException {
/* 55 */     T result = getNullableResult(rs, columnName);
/* 56 */     if (rs.wasNull()) {
/* 57 */       return null;
/*    */     }
/* 59 */     return result;
/*    */   }
/*    */   
/*    */   public T getResult(ResultSet rs, int columnIndex) throws SQLException
/*    */   {
/* 64 */     T result = getNullableResult(rs, columnIndex);
/* 65 */     if (rs.wasNull()) {
/* 66 */       return null;
/*    */     }
/* 68 */     return result;
/*    */   }
/*    */   
/*    */   public T getResult(CallableStatement cs, int columnIndex) throws SQLException
/*    */   {
/* 73 */     T result = getNullableResult(cs, columnIndex);
/* 74 */     if (cs.wasNull()) {
/* 75 */       return null;
/*    */     }
/* 77 */     return result;
/*    */   }
/*    */   
/*    */   public abstract void setNonNullParameter(PreparedStatement paramPreparedStatement, int paramInt, T paramT, JdbcType paramJdbcType)
/*    */     throws SQLException;
/*    */   
/*    */   public abstract T getNullableResult(ResultSet paramResultSet, String paramString)
/*    */     throws SQLException;
/*    */   
/*    */   public abstract T getNullableResult(ResultSet paramResultSet, int paramInt)
/*    */     throws SQLException;
/*    */   
/*    */   public abstract T getNullableResult(CallableStatement paramCallableStatement, int paramInt)
/*    */     throws SQLException;
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\BaseTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */