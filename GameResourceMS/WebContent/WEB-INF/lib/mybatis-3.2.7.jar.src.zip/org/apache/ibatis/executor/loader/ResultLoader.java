/*     */ package org.apache.ibatis.executor.loader;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.ibatis.cache.CacheKey;
/*     */ import org.apache.ibatis.executor.Executor;
/*     */ import org.apache.ibatis.executor.ExecutorException;
/*     */ import org.apache.ibatis.executor.ResultExtractor;
/*     */ import org.apache.ibatis.mapping.BoundSql;
/*     */ import org.apache.ibatis.mapping.Environment;
/*     */ import org.apache.ibatis.mapping.MappedStatement;
/*     */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.session.ExecutorType;
/*     */ import org.apache.ibatis.session.RowBounds;
/*     */ import org.apache.ibatis.transaction.Transaction;
/*     */ import org.apache.ibatis.transaction.TransactionFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResultLoader
/*     */ {
/*     */   protected final Configuration configuration;
/*     */   protected final Executor executor;
/*     */   protected final MappedStatement mappedStatement;
/*     */   protected final Object parameterObject;
/*     */   protected final Class<?> targetType;
/*     */   protected final ObjectFactory objectFactory;
/*     */   protected final CacheKey cacheKey;
/*     */   protected final BoundSql boundSql;
/*     */   protected final ResultExtractor resultExtractor;
/*     */   protected final long creatorThreadId;
/*     */   protected boolean loaded;
/*     */   protected Object resultObject;
/*     */   
/*     */   public ResultLoader(Configuration config, Executor executor, MappedStatement mappedStatement, Object parameterObject, Class<?> targetType, CacheKey cacheKey, BoundSql boundSql)
/*     */   {
/*  57 */     this.configuration = config;
/*  58 */     this.executor = executor;
/*  59 */     this.mappedStatement = mappedStatement;
/*  60 */     this.parameterObject = parameterObject;
/*  61 */     this.targetType = targetType;
/*  62 */     this.objectFactory = this.configuration.getObjectFactory();
/*  63 */     this.cacheKey = cacheKey;
/*  64 */     this.boundSql = boundSql;
/*  65 */     this.resultExtractor = new ResultExtractor(this.configuration, this.objectFactory);
/*  66 */     this.creatorThreadId = Thread.currentThread().getId();
/*     */   }
/*     */   
/*     */   public Object loadResult() throws SQLException {
/*  70 */     List<Object> list = selectList();
/*  71 */     this.resultObject = this.resultExtractor.extractObjectFromList(list, this.targetType);
/*  72 */     return this.resultObject;
/*     */   }
/*     */   
/*     */   private <E> List<E> selectList() throws SQLException {
/*  76 */     Executor localExecutor = this.executor;
/*  77 */     if ((Thread.currentThread().getId() != this.creatorThreadId) || (localExecutor.isClosed())) {
/*  78 */       localExecutor = newExecutor();
/*     */     }
/*     */     try {
/*  81 */       return localExecutor.query(this.mappedStatement, this.parameterObject, RowBounds.DEFAULT, Executor.NO_RESULT_HANDLER, this.cacheKey, this.boundSql);
/*     */     } finally {
/*  83 */       if (localExecutor != this.executor) {
/*  84 */         localExecutor.close(false);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Executor newExecutor() throws SQLException {
/*  90 */     Environment environment = this.configuration.getEnvironment();
/*  91 */     if (environment == null) throw new ExecutorException("ResultLoader could not load lazily.  Environment was not configured.");
/*  92 */     DataSource ds = environment.getDataSource();
/*  93 */     if (ds == null) throw new ExecutorException("ResultLoader could not load lazily.  DataSource was not configured.");
/*  94 */     TransactionFactory transactionFactory = environment.getTransactionFactory();
/*  95 */     Transaction tx = transactionFactory.newTransaction(ds, null, false);
/*  96 */     return this.configuration.newExecutor(tx, ExecutorType.SIMPLE);
/*     */   }
/*     */   
/*     */   public boolean wasNull() {
/* 100 */     return this.resultObject == null;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\loader\ResultLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */