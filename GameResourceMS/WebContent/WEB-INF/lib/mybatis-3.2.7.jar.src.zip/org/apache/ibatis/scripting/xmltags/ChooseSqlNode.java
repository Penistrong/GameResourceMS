/*    */ package org.apache.ibatis.scripting.xmltags;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChooseSqlNode
/*    */   implements SqlNode
/*    */ {
/*    */   private SqlNode defaultSqlNode;
/*    */   private List<SqlNode> ifSqlNodes;
/*    */   
/*    */   public ChooseSqlNode(List<SqlNode> ifSqlNodes, SqlNode defaultSqlNode)
/*    */   {
/* 28 */     this.ifSqlNodes = ifSqlNodes;
/* 29 */     this.defaultSqlNode = defaultSqlNode;
/*    */   }
/*    */   
/*    */   public boolean apply(DynamicContext context) {
/* 33 */     for (SqlNode sqlNode : this.ifSqlNodes) {
/* 34 */       if (sqlNode.apply(context)) {
/* 35 */         return true;
/*    */       }
/*    */     }
/* 38 */     if (this.defaultSqlNode != null) {
/* 39 */       this.defaultSqlNode.apply(context);
/* 40 */       return true;
/*    */     }
/* 42 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\xmltags\ChooseSqlNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */