/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IteratorEnumeration
/*    */   implements Enumeration
/*    */ {
/*    */   private Iterator it;
/*    */   
/*    */   public IteratorEnumeration(Iterator it)
/*    */   {
/* 47 */     this.it = it;
/*    */   }
/*    */   
/*    */   public boolean hasMoreElements() {
/* 51 */     return this.it.hasNext();
/*    */   }
/*    */   
/*    */   public Object nextElement() {
/* 55 */     return this.it.next();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\IteratorEnumeration.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */