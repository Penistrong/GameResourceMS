/*    */ package org.apache.ibatis.logging.log4j;
/*    */ 
/*    */ import org.apache.ibatis.logging.Log;
/*    */ import org.apache.log4j.Level;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Log4jImpl
/*    */   implements Log
/*    */ {
/* 27 */   private static final String FQCN = Log4jImpl.class.getName();
/*    */   private Logger log;
/*    */   
/*    */   public Log4jImpl(String clazz)
/*    */   {
/* 32 */     this.log = Logger.getLogger(clazz);
/*    */   }
/*    */   
/*    */   public boolean isDebugEnabled() {
/* 36 */     return this.log.isDebugEnabled();
/*    */   }
/*    */   
/*    */   public boolean isTraceEnabled() {
/* 40 */     return this.log.isTraceEnabled();
/*    */   }
/*    */   
/*    */   public void error(String s, Throwable e) {
/* 44 */     this.log.log(FQCN, Level.ERROR, s, e);
/*    */   }
/*    */   
/*    */   public void error(String s) {
/* 48 */     this.log.log(FQCN, Level.ERROR, s, null);
/*    */   }
/*    */   
/*    */   public void debug(String s) {
/* 52 */     this.log.log(FQCN, Level.DEBUG, s, null);
/*    */   }
/*    */   
/*    */   public void trace(String s) {
/* 56 */     this.log.log(FQCN, Level.TRACE, s, null);
/*    */   }
/*    */   
/*    */   public void warn(String s) {
/* 60 */     this.log.log(FQCN, Level.WARN, s, null);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\logging\log4j\Log4jImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */