package org.apache.ibatis.reflection.wrapper;

import java.util.List;
import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.reflection.factory.ObjectFactory;
import org.apache.ibatis.reflection.property.PropertyTokenizer;

public abstract interface ObjectWrapper
{
  public abstract Object get(PropertyTokenizer paramPropertyTokenizer);
  
  public abstract void set(PropertyTokenizer paramPropertyTokenizer, Object paramObject);
  
  public abstract String findProperty(String paramString, boolean paramBoolean);
  
  public abstract String[] getGetterNames();
  
  public abstract String[] getSetterNames();
  
  public abstract Class<?> getSetterType(String paramString);
  
  public abstract Class<?> getGetterType(String paramString);
  
  public abstract boolean hasSetter(String paramString);
  
  public abstract boolean hasGetter(String paramString);
  
  public abstract MetaObject instantiatePropertyValue(String paramString, PropertyTokenizer paramPropertyTokenizer, ObjectFactory paramObjectFactory);
  
  public abstract boolean isCollection();
  
  public abstract void add(Object paramObject);
  
  public abstract <E> void addAll(List<E> paramList);
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\wrapper\ObjectWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */