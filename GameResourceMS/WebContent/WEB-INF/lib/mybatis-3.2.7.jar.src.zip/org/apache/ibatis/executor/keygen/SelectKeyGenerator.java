/*     */ package org.apache.ibatis.executor.keygen;
/*     */ 
/*     */ import java.sql.Statement;
/*     */ import java.util.List;
/*     */ import org.apache.ibatis.executor.Executor;
/*     */ import org.apache.ibatis.executor.ExecutorException;
/*     */ import org.apache.ibatis.mapping.MappedStatement;
/*     */ import org.apache.ibatis.reflection.MetaObject;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.session.ExecutorType;
/*     */ import org.apache.ibatis.session.RowBounds;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectKeyGenerator
/*     */   implements KeyGenerator
/*     */ {
/*     */   public static final String SELECT_KEY_SUFFIX = "!selectKey";
/*     */   private boolean executeBefore;
/*     */   private MappedStatement keyStatement;
/*     */   
/*     */   public SelectKeyGenerator(MappedStatement keyStatement, boolean executeBefore)
/*     */   {
/*  40 */     this.executeBefore = executeBefore;
/*  41 */     this.keyStatement = keyStatement;
/*     */   }
/*     */   
/*     */   public void processBefore(Executor executor, MappedStatement ms, Statement stmt, Object parameter) {
/*  45 */     if (this.executeBefore) {
/*  46 */       processGeneratedKeys(executor, ms, parameter);
/*     */     }
/*     */   }
/*     */   
/*     */   public void processAfter(Executor executor, MappedStatement ms, Statement stmt, Object parameter) {
/*  51 */     if (!this.executeBefore) {
/*  52 */       processGeneratedKeys(executor, ms, parameter);
/*     */     }
/*     */   }
/*     */   
/*     */   private void processGeneratedKeys(Executor executor, MappedStatement ms, Object parameter) {
/*     */     try {
/*  58 */       if ((parameter != null) && (this.keyStatement != null) && (this.keyStatement.getKeyProperties() != null)) {
/*  59 */         String[] keyProperties = this.keyStatement.getKeyProperties();
/*  60 */         Configuration configuration = ms.getConfiguration();
/*  61 */         MetaObject metaParam = configuration.newMetaObject(parameter);
/*  62 */         if (keyProperties != null)
/*     */         {
/*     */ 
/*  65 */           Executor keyExecutor = configuration.newExecutor(executor.getTransaction(), ExecutorType.SIMPLE);
/*  66 */           List<Object> values = keyExecutor.query(this.keyStatement, parameter, RowBounds.DEFAULT, Executor.NO_RESULT_HANDLER);
/*  67 */           if (values.size() == 0)
/*  68 */             throw new ExecutorException("SelectKey returned no data.");
/*  69 */           if (values.size() > 1) {
/*  70 */             throw new ExecutorException("SelectKey returned more than one value.");
/*     */           }
/*  72 */           MetaObject metaResult = configuration.newMetaObject(values.get(0));
/*  73 */           if (keyProperties.length == 1) {
/*  74 */             if (metaResult.hasGetter(keyProperties[0])) {
/*  75 */               setValue(metaParam, keyProperties[0], metaResult.getValue(keyProperties[0]));
/*     */             }
/*     */             else
/*     */             {
/*  79 */               setValue(metaParam, keyProperties[0], values.get(0));
/*     */             }
/*     */           } else {
/*  82 */             handleMultipleProperties(keyProperties, metaParam, metaResult);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (ExecutorException e) {
/*  88 */       throw e;
/*     */     } catch (Exception e) {
/*  90 */       throw new ExecutorException("Error selecting key or setting result to parameter object. Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   private void handleMultipleProperties(String[] keyProperties, MetaObject metaParam, MetaObject metaResult)
/*     */   {
/*  96 */     String[] keyColumns = this.keyStatement.getKeyColumns();
/*     */     
/*  98 */     if ((keyColumns == null) || (keyColumns.length == 0))
/*     */     {
/* 100 */       for (int i = 0; i < keyProperties.length; i++) {
/* 101 */         setValue(metaParam, keyProperties[i], metaResult.getValue(keyProperties[i]));
/*     */       }
/*     */     } else {
/* 104 */       if (keyColumns.length != keyProperties.length) {
/* 105 */         throw new ExecutorException("If SelectKey has key columns, the number must match the number of key properties.");
/*     */       }
/* 107 */       for (int i = 0; i < keyProperties.length; i++) {
/* 108 */         setValue(metaParam, keyProperties[i], metaResult.getValue(keyColumns[i]));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void setValue(MetaObject metaParam, String property, Object value) {
/* 114 */     if (metaParam.hasSetter(property)) {
/* 115 */       metaParam.setValue(property, value);
/*     */     } else {
/* 117 */       throw new ExecutorException("No setter found for the keyProperty '" + property + "' in " + metaParam.getOriginalObject().getClass().getName() + ".");
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\keygen\SelectKeyGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */