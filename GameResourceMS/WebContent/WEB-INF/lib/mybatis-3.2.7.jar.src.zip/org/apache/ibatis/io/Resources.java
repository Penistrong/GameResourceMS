/*     */ package org.apache.ibatis.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Resources
/*     */ {
/*  35 */   private static ClassLoaderWrapper classLoaderWrapper = new ClassLoaderWrapper();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Charset charset;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ClassLoader getDefaultClassLoader()
/*     */   {
/*  52 */     return classLoaderWrapper.defaultClassLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setDefaultClassLoader(ClassLoader defaultClassLoader)
/*     */   {
/*  61 */     classLoaderWrapper.defaultClassLoader = defaultClassLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static URL getResourceURL(String resource)
/*     */     throws IOException
/*     */   {
/*  72 */     return getResourceURL(null, resource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static URL getResourceURL(ClassLoader loader, String resource)
/*     */     throws IOException
/*     */   {
/*  84 */     URL url = classLoaderWrapper.getResourceAsURL(resource, loader);
/*  85 */     if (url == null) throw new IOException("Could not find resource " + resource);
/*  86 */     return url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static InputStream getResourceAsStream(String resource)
/*     */     throws IOException
/*     */   {
/*  97 */     return getResourceAsStream(null, resource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static InputStream getResourceAsStream(ClassLoader loader, String resource)
/*     */     throws IOException
/*     */   {
/* 109 */     InputStream in = classLoaderWrapper.getResourceAsStream(resource, loader);
/* 110 */     if (in == null) throw new IOException("Could not find resource " + resource);
/* 111 */     return in;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Properties getResourceAsProperties(String resource)
/*     */     throws IOException
/*     */   {
/* 122 */     Properties props = new Properties();
/* 123 */     InputStream in = getResourceAsStream(resource);
/* 124 */     props.load(in);
/* 125 */     in.close();
/* 126 */     return props;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Properties getResourceAsProperties(ClassLoader loader, String resource)
/*     */     throws IOException
/*     */   {
/* 138 */     Properties props = new Properties();
/* 139 */     InputStream in = getResourceAsStream(loader, resource);
/* 140 */     props.load(in);
/* 141 */     in.close();
/* 142 */     return props;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Reader getResourceAsReader(String resource)
/*     */     throws IOException
/*     */   {
/*     */     Reader reader;
/*     */     
/*     */     Reader reader;
/*     */     
/* 154 */     if (charset == null) {
/* 155 */       reader = new InputStreamReader(getResourceAsStream(resource));
/*     */     } else {
/* 157 */       reader = new InputStreamReader(getResourceAsStream(resource), charset);
/*     */     }
/* 159 */     return reader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Reader getResourceAsReader(ClassLoader loader, String resource)
/*     */     throws IOException
/*     */   {
/*     */     Reader reader;
/*     */     
/*     */ 
/*     */     Reader reader;
/*     */     
/* 172 */     if (charset == null) {
/* 173 */       reader = new InputStreamReader(getResourceAsStream(loader, resource));
/*     */     } else {
/* 175 */       reader = new InputStreamReader(getResourceAsStream(loader, resource), charset);
/*     */     }
/* 177 */     return reader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static File getResourceAsFile(String resource)
/*     */     throws IOException
/*     */   {
/* 188 */     return new File(getResourceURL(resource).getFile());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static File getResourceAsFile(ClassLoader loader, String resource)
/*     */     throws IOException
/*     */   {
/* 200 */     return new File(getResourceURL(loader, resource).getFile());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static InputStream getUrlAsStream(String urlString)
/*     */     throws IOException
/*     */   {
/* 211 */     URL url = new URL(urlString);
/* 212 */     URLConnection conn = url.openConnection();
/* 213 */     return conn.getInputStream();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Reader getUrlAsReader(String urlString)
/*     */     throws IOException
/*     */   {
/*     */     Reader reader;
/*     */     
/*     */     Reader reader;
/*     */     
/* 225 */     if (charset == null) {
/* 226 */       reader = new InputStreamReader(getUrlAsStream(urlString));
/*     */     } else {
/* 228 */       reader = new InputStreamReader(getUrlAsStream(urlString), charset);
/*     */     }
/* 230 */     return reader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Properties getUrlAsProperties(String urlString)
/*     */     throws IOException
/*     */   {
/* 241 */     Properties props = new Properties();
/* 242 */     InputStream in = getUrlAsStream(urlString);
/* 243 */     props.load(in);
/* 244 */     in.close();
/* 245 */     return props;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> classForName(String className)
/*     */     throws ClassNotFoundException
/*     */   {
/* 256 */     return classLoaderWrapper.classForName(className);
/*     */   }
/*     */   
/*     */   public static Charset getCharset() {
/* 260 */     return charset;
/*     */   }
/*     */   
/*     */   public static void setCharset(Charset charset) {
/* 264 */     charset = charset;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\io\Resources.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */