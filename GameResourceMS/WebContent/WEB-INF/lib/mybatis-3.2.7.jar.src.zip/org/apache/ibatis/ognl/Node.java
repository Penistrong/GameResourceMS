package org.apache.ibatis.ognl;

public abstract interface Node
{
  public abstract void jjtOpen();
  
  public abstract void jjtClose();
  
  public abstract void jjtSetParent(Node paramNode);
  
  public abstract Node jjtGetParent();
  
  public abstract void jjtAddChild(Node paramNode, int paramInt);
  
  public abstract Node jjtGetChild(int paramInt);
  
  public abstract int jjtGetNumChildren();
  
  public abstract Object getValue(OgnlContext paramOgnlContext, Object paramObject)
    throws OgnlException;
  
  public abstract void setValue(OgnlContext paramOgnlContext, Object paramObject1, Object paramObject2)
    throws OgnlException;
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\Node.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */