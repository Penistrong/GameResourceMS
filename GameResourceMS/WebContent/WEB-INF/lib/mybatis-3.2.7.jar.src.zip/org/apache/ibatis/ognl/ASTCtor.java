/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ASTCtor
/*     */   extends SimpleNode
/*     */ {
/*     */   private String className;
/*     */   private boolean isArray;
/*     */   
/*     */   public ASTCtor(int id)
/*     */   {
/*  46 */     super(id);
/*     */   }
/*     */   
/*     */   public ASTCtor(OgnlParser p, int id) {
/*  50 */     super(p, id);
/*     */   }
/*     */   
/*     */   void setClassName(String className)
/*     */   {
/*  55 */     this.className = className;
/*     */   }
/*     */   
/*     */   void setArray(boolean value) {
/*  59 */     this.isArray = value;
/*     */   }
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source)
/*     */     throws OgnlException
/*     */   {
/*  65 */     Object root = context.getRoot();
/*  66 */     int count = jjtGetNumChildren();
/*  67 */     Object[] args = OgnlRuntime.getObjectArrayPool().create(count);
/*     */     try
/*     */     {
/*  70 */       for (int i = 0; i < count; i++)
/*  71 */         args[i] = this.children[i].getValue(context, root);
/*     */       Object result;
/*  73 */       if (this.isArray) { Object result;
/*  74 */         if (args.length == 1) {
/*     */           try {
/*  76 */             Class componentClass = OgnlRuntime.classForName(context, this.className);
/*  77 */             List sourceList = null;
/*     */             int size;
/*     */             int size;
/*  80 */             if ((args[0] instanceof List)) {
/*  81 */               sourceList = (List)args[0];
/*  82 */               size = sourceList.size();
/*     */             } else {
/*  84 */               size = (int)OgnlOps.longValue(args[0]);
/*     */             }
/*  86 */             Object result = Array.newInstance(componentClass, size);
/*  87 */             if (sourceList == null) break label296;
/*  88 */             TypeConverter converter = context.getTypeConverter();
/*     */             
/*  90 */             int i = 0; for (int icount = sourceList.size(); i < icount; i++) {
/*  91 */               Object o = sourceList.get(i);
/*     */               
/*  93 */               if ((o == null) || (componentClass.isInstance(o))) {
/*  94 */                 Array.set(result, i, o);
/*     */               } else {
/*  96 */                 Array.set(result, i, converter.convertValue(context, null, null, null, o, componentClass));
/*     */               }
/*     */             }
/*     */           }
/*     */           catch (ClassNotFoundException ex) {
/* 101 */             throw new OgnlException("array component class '" + this.className + "' not found", ex);
/*     */           }
/*     */         } else {
/* 104 */           throw new OgnlException("only expect array size or fixed initializer list");
/*     */         }
/*     */       } else {
/* 107 */         result = OgnlRuntime.callConstructor(context, this.className, args);
/*     */       }
/*     */       label296:
/* 110 */       return result;
/*     */     } finally {
/* 112 */       OgnlRuntime.getObjectArrayPool().recycle(args);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 118 */     String result = "new " + this.className;
/*     */     
/* 120 */     if (this.isArray) {
/* 121 */       if ((this.children[0] instanceof ASTConst)) {
/* 122 */         result = result + "[" + this.children[0] + "]";
/*     */       } else {
/* 124 */         result = result + "[] " + this.children[0];
/*     */       }
/*     */     } else {
/* 127 */       result = result + "(";
/* 128 */       if ((this.children != null) && (this.children.length > 0)) {
/* 129 */         for (int i = 0; i < this.children.length; i++) {
/* 130 */           if (i > 0) {
/* 131 */             result = result + ", ";
/*     */           }
/* 133 */           result = result + this.children[i];
/*     */         }
/*     */       }
/* 136 */       result = result + ")";
/*     */     }
/* 138 */     return result;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTCtor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */