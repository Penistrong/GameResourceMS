/*     */ package org.apache.ibatis.reflection;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Collection;
/*     */ import org.apache.ibatis.reflection.invoker.GetFieldInvoker;
/*     */ import org.apache.ibatis.reflection.invoker.Invoker;
/*     */ import org.apache.ibatis.reflection.invoker.MethodInvoker;
/*     */ import org.apache.ibatis.reflection.property.PropertyTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MetaClass
/*     */ {
/*     */   private Reflector reflector;
/*     */   
/*     */   private MetaClass(Class<?> type)
/*     */   {
/*  37 */     this.reflector = Reflector.forClass(type);
/*     */   }
/*     */   
/*     */   public static MetaClass forClass(Class<?> type) {
/*  41 */     return new MetaClass(type);
/*     */   }
/*     */   
/*     */   public static boolean isClassCacheEnabled() {
/*  45 */     return Reflector.isClassCacheEnabled();
/*     */   }
/*     */   
/*     */   public static void setClassCacheEnabled(boolean classCacheEnabled) {
/*  49 */     Reflector.setClassCacheEnabled(classCacheEnabled);
/*     */   }
/*     */   
/*     */   public MetaClass metaClassForProperty(String name) {
/*  53 */     Class<?> propType = this.reflector.getGetterType(name);
/*  54 */     return forClass(propType);
/*     */   }
/*     */   
/*     */   public String findProperty(String name) {
/*  58 */     StringBuilder prop = buildProperty(name, new StringBuilder());
/*  59 */     return prop.length() > 0 ? prop.toString() : null;
/*     */   }
/*     */   
/*     */   public String findProperty(String name, boolean useCamelCaseMapping) {
/*  63 */     if (useCamelCaseMapping) {
/*  64 */       name = name.replace("_", "");
/*     */     }
/*  66 */     return findProperty(name);
/*     */   }
/*     */   
/*     */   public String[] getGetterNames() {
/*  70 */     return this.reflector.getGetablePropertyNames();
/*     */   }
/*     */   
/*     */   public String[] getSetterNames() {
/*  74 */     return this.reflector.getSetablePropertyNames();
/*     */   }
/*     */   
/*     */   public Class<?> getSetterType(String name) {
/*  78 */     PropertyTokenizer prop = new PropertyTokenizer(name);
/*  79 */     if (prop.hasNext()) {
/*  80 */       MetaClass metaProp = metaClassForProperty(prop.getName());
/*  81 */       return metaProp.getSetterType(prop.getChildren());
/*     */     }
/*  83 */     return this.reflector.getSetterType(prop.getName());
/*     */   }
/*     */   
/*     */   public Class<?> getGetterType(String name)
/*     */   {
/*  88 */     PropertyTokenizer prop = new PropertyTokenizer(name);
/*  89 */     if (prop.hasNext()) {
/*  90 */       MetaClass metaProp = metaClassForProperty(prop);
/*  91 */       return metaProp.getGetterType(prop.getChildren());
/*     */     }
/*  93 */     return getGetterType(prop);
/*     */   }
/*     */   
/*     */   private MetaClass metaClassForProperty(PropertyTokenizer prop)
/*     */   {
/*  98 */     Class<?> propType = getGetterType(prop);
/*  99 */     return forClass(propType);
/*     */   }
/*     */   
/*     */   private Class<?> getGetterType(PropertyTokenizer prop) {
/* 103 */     Class<?> type = this.reflector.getGetterType(prop.getName());
/* 104 */     if ((prop.getIndex() != null) && (Collection.class.isAssignableFrom(type))) {
/* 105 */       Type returnType = getGenericGetterType(prop.getName());
/* 106 */       if ((returnType instanceof ParameterizedType)) {
/* 107 */         Type[] actualTypeArguments = ((ParameterizedType)returnType).getActualTypeArguments();
/* 108 */         if ((actualTypeArguments != null) && (actualTypeArguments.length == 1)) {
/* 109 */           returnType = actualTypeArguments[0];
/* 110 */           if ((returnType instanceof Class)) {
/* 111 */             type = (Class)returnType;
/* 112 */           } else if ((returnType instanceof ParameterizedType)) {
/* 113 */             type = (Class)((ParameterizedType)returnType).getRawType();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 118 */     return type;
/*     */   }
/*     */   
/*     */   private Type getGenericGetterType(String propertyName) {
/*     */     try {
/* 123 */       Invoker invoker = this.reflector.getGetInvoker(propertyName);
/* 124 */       if ((invoker instanceof MethodInvoker)) {
/* 125 */         Field _method = MethodInvoker.class.getDeclaredField("method");
/* 126 */         _method.setAccessible(true);
/* 127 */         Method method = (Method)_method.get(invoker);
/* 128 */         return method.getGenericReturnType(); }
/* 129 */       if ((invoker instanceof GetFieldInvoker)) {
/* 130 */         Field _field = GetFieldInvoker.class.getDeclaredField("field");
/* 131 */         _field.setAccessible(true);
/* 132 */         Field field = (Field)_field.get(invoker);
/* 133 */         return field.getGenericType();
/*     */       }
/*     */     }
/*     */     catch (NoSuchFieldException e) {}catch (IllegalAccessException e) {}
/*     */     
/* 138 */     return null;
/*     */   }
/*     */   
/*     */   public boolean hasSetter(String name) {
/* 142 */     PropertyTokenizer prop = new PropertyTokenizer(name);
/* 143 */     if (prop.hasNext()) {
/* 144 */       if (this.reflector.hasSetter(prop.getName())) {
/* 145 */         MetaClass metaProp = metaClassForProperty(prop.getName());
/* 146 */         return metaProp.hasSetter(prop.getChildren());
/*     */       }
/* 148 */       return false;
/*     */     }
/*     */     
/* 151 */     return this.reflector.hasSetter(prop.getName());
/*     */   }
/*     */   
/*     */   public boolean hasGetter(String name)
/*     */   {
/* 156 */     PropertyTokenizer prop = new PropertyTokenizer(name);
/* 157 */     if (prop.hasNext()) {
/* 158 */       if (this.reflector.hasGetter(prop.getName())) {
/* 159 */         MetaClass metaProp = metaClassForProperty(prop);
/* 160 */         return metaProp.hasGetter(prop.getChildren());
/*     */       }
/* 162 */       return false;
/*     */     }
/*     */     
/* 165 */     return this.reflector.hasGetter(prop.getName());
/*     */   }
/*     */   
/*     */   public Invoker getGetInvoker(String name)
/*     */   {
/* 170 */     return this.reflector.getGetInvoker(name);
/*     */   }
/*     */   
/*     */   public Invoker getSetInvoker(String name) {
/* 174 */     return this.reflector.getSetInvoker(name);
/*     */   }
/*     */   
/*     */   private StringBuilder buildProperty(String name, StringBuilder builder) {
/* 178 */     PropertyTokenizer prop = new PropertyTokenizer(name);
/* 179 */     if (prop.hasNext()) {
/* 180 */       String propertyName = this.reflector.findPropertyName(prop.getName());
/* 181 */       if (propertyName != null) {
/* 182 */         builder.append(propertyName);
/* 183 */         builder.append(".");
/* 184 */         MetaClass metaProp = metaClassForProperty(propertyName);
/* 185 */         metaProp.buildProperty(prop.getChildren(), builder);
/*     */       }
/*     */     } else {
/* 188 */       String propertyName = this.reflector.findPropertyName(name);
/* 189 */       if (propertyName != null) {
/* 190 */         builder.append(propertyName);
/*     */       }
/*     */     }
/* 193 */     return builder;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\MetaClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */