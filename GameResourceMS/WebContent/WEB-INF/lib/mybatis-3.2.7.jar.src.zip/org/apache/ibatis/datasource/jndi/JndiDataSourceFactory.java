/*    */ package org.apache.ibatis.datasource.jndi;
/*    */ 
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Properties;
/*    */ import javax.naming.Context;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.ibatis.datasource.DataSourceException;
/*    */ import org.apache.ibatis.datasource.DataSourceFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JndiDataSourceFactory
/*    */   implements DataSourceFactory
/*    */ {
/*    */   public static final String INITIAL_CONTEXT = "initial_context";
/*    */   public static final String DATA_SOURCE = "data_source";
/*    */   public static final String ENV_PREFIX = "env.";
/*    */   private DataSource dataSource;
/*    */   
/*    */   public void setProperties(Properties properties)
/*    */   {
/*    */     try
/*    */     {
/* 42 */       InitialContext initCtx = null;
/* 43 */       Properties env = getEnvProperties(properties);
/* 44 */       if (env == null) {
/* 45 */         initCtx = new InitialContext();
/*    */       } else {
/* 47 */         initCtx = new InitialContext(env);
/*    */       }
/*    */       
/* 50 */       if ((properties.containsKey("initial_context")) && (properties.containsKey("data_source")))
/*    */       {
/* 52 */         Context ctx = (Context)initCtx.lookup(properties.getProperty("initial_context"));
/* 53 */         this.dataSource = ((DataSource)ctx.lookup(properties.getProperty("data_source")));
/* 54 */       } else if (properties.containsKey("data_source")) {
/* 55 */         this.dataSource = ((DataSource)initCtx.lookup(properties.getProperty("data_source")));
/*    */       }
/*    */     }
/*    */     catch (NamingException e) {
/* 59 */       throw new DataSourceException("There was an error configuring JndiDataSourceTransactionPool. Cause: " + e, e);
/*    */     }
/*    */   }
/*    */   
/*    */   public DataSource getDataSource() {
/* 64 */     return this.dataSource;
/*    */   }
/*    */   
/*    */   private static Properties getEnvProperties(Properties allProps) {
/* 68 */     String PREFIX = "env.";
/* 69 */     Properties contextProperties = null;
/* 70 */     for (Map.Entry<Object, Object> entry : allProps.entrySet()) {
/* 71 */       String key = (String)entry.getKey();
/* 72 */       String value = (String)entry.getValue();
/* 73 */       if (key.startsWith("env.")) {
/* 74 */         if (contextProperties == null) {
/* 75 */           contextProperties = new Properties();
/*    */         }
/* 77 */         contextProperties.put(key.substring("env.".length()), value);
/*    */       }
/*    */     }
/* 80 */     return contextProperties;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\datasource\jndi\JndiDataSourceFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */