/*    */ package org.apache.ibatis.reflection.invoker;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GetFieldInvoker
/*    */   implements Invoker
/*    */ {
/*    */   private Field field;
/*    */   
/*    */   public GetFieldInvoker(Field field)
/*    */   {
/* 28 */     this.field = field;
/*    */   }
/*    */   
/*    */   public Object invoke(Object target, Object[] args) throws IllegalAccessException, InvocationTargetException {
/* 32 */     return this.field.get(target);
/*    */   }
/*    */   
/*    */   public Class<?> getType() {
/* 36 */     return this.field.getType();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\invoker\GetFieldInvoker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */