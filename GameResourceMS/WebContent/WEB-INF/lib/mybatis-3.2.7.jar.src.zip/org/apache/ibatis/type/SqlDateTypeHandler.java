/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.Date;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SqlDateTypeHandler
/*    */   extends BaseTypeHandler<Date>
/*    */ {
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, Date parameter, JdbcType jdbcType)
/*    */     throws SQLException
/*    */   {
/* 32 */     ps.setDate(i, parameter);
/*    */   }
/*    */   
/*    */   public Date getNullableResult(ResultSet rs, String columnName)
/*    */     throws SQLException
/*    */   {
/* 38 */     return rs.getDate(columnName);
/*    */   }
/*    */   
/*    */   public Date getNullableResult(ResultSet rs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 44 */     return rs.getDate(columnIndex);
/*    */   }
/*    */   
/*    */   public Date getNullableResult(CallableStatement cs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 50 */     return cs.getDate(columnIndex);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\SqlDateTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */