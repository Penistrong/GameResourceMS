/*    */ package org.apache.ibatis.jdbc;
/*    */ 
/*    */ import org.apache.ibatis.type.BigDecimalTypeHandler;
/*    */ import org.apache.ibatis.type.BlobTypeHandler;
/*    */ import org.apache.ibatis.type.BooleanTypeHandler;
/*    */ import org.apache.ibatis.type.ByteArrayTypeHandler;
/*    */ import org.apache.ibatis.type.ByteTypeHandler;
/*    */ import org.apache.ibatis.type.ClobTypeHandler;
/*    */ import org.apache.ibatis.type.DateOnlyTypeHandler;
/*    */ import org.apache.ibatis.type.DateTypeHandler;
/*    */ import org.apache.ibatis.type.DoubleTypeHandler;
/*    */ import org.apache.ibatis.type.FloatTypeHandler;
/*    */ import org.apache.ibatis.type.IntegerTypeHandler;
/*    */ import org.apache.ibatis.type.JdbcType;
/*    */ import org.apache.ibatis.type.LongTypeHandler;
/*    */ import org.apache.ibatis.type.ObjectTypeHandler;
/*    */ import org.apache.ibatis.type.ShortTypeHandler;
/*    */ import org.apache.ibatis.type.SqlDateTypeHandler;
/*    */ import org.apache.ibatis.type.SqlTimeTypeHandler;
/*    */ import org.apache.ibatis.type.SqlTimestampTypeHandler;
/*    */ import org.apache.ibatis.type.StringTypeHandler;
/*    */ import org.apache.ibatis.type.TimeOnlyTypeHandler;
/*    */ import org.apache.ibatis.type.TypeHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Null
/*    */ {
/* 45 */   BOOLEAN(new BooleanTypeHandler(), JdbcType.BOOLEAN), 
/*    */   
/* 47 */   BYTE(new ByteTypeHandler(), JdbcType.TINYINT), 
/* 48 */   SHORT(new ShortTypeHandler(), JdbcType.SMALLINT), 
/* 49 */   INTEGER(new IntegerTypeHandler(), JdbcType.INTEGER), 
/* 50 */   LONG(new LongTypeHandler(), JdbcType.BIGINT), 
/* 51 */   FLOAT(new FloatTypeHandler(), JdbcType.FLOAT), 
/* 52 */   DOUBLE(new DoubleTypeHandler(), JdbcType.DOUBLE), 
/* 53 */   BIGDECIMAL(new BigDecimalTypeHandler(), JdbcType.DECIMAL), 
/*    */   
/* 55 */   STRING(new StringTypeHandler(), JdbcType.VARCHAR), 
/* 56 */   CLOB(new ClobTypeHandler(), JdbcType.CLOB), 
/* 57 */   LONGVARCHAR(new ClobTypeHandler(), JdbcType.LONGVARCHAR), 
/*    */   
/* 59 */   BYTEARRAY(new ByteArrayTypeHandler(), JdbcType.LONGVARBINARY), 
/* 60 */   BLOB(new BlobTypeHandler(), JdbcType.BLOB), 
/* 61 */   LONGVARBINARY(new BlobTypeHandler(), JdbcType.LONGVARBINARY), 
/*    */   
/* 63 */   OBJECT(new ObjectTypeHandler(), JdbcType.OTHER), 
/* 64 */   OTHER(new ObjectTypeHandler(), JdbcType.OTHER), 
/* 65 */   TIMESTAMP(new DateTypeHandler(), JdbcType.TIMESTAMP), 
/* 66 */   DATE(new DateOnlyTypeHandler(), JdbcType.DATE), 
/* 67 */   TIME(new TimeOnlyTypeHandler(), JdbcType.TIME), 
/* 68 */   SQLTIMESTAMP(new SqlTimestampTypeHandler(), JdbcType.TIMESTAMP), 
/* 69 */   SQLDATE(new SqlDateTypeHandler(), JdbcType.DATE), 
/* 70 */   SQLTIME(new SqlTimeTypeHandler(), JdbcType.TIME);
/*    */   
/*    */   private TypeHandler typeHandler;
/*    */   private JdbcType jdbcType;
/*    */   
/*    */   private Null(TypeHandler typeHandler, JdbcType jdbcType) {
/* 76 */     this.typeHandler = typeHandler;
/* 77 */     this.jdbcType = jdbcType;
/*    */   }
/*    */   
/*    */   public TypeHandler getTypeHandler() {
/* 81 */     return this.typeHandler;
/*    */   }
/*    */   
/*    */   public JdbcType getJdbcType() {
/* 85 */     return this.jdbcType;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\jdbc\Null.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */