/*    */ package org.apache.ibatis.executor.statement;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import java.util.List;
/*    */ import org.apache.ibatis.executor.Executor;
/*    */ import org.apache.ibatis.executor.ExecutorException;
/*    */ import org.apache.ibatis.executor.parameter.ParameterHandler;
/*    */ import org.apache.ibatis.mapping.BoundSql;
/*    */ import org.apache.ibatis.mapping.MappedStatement;
/*    */ import org.apache.ibatis.session.ResultHandler;
/*    */ import org.apache.ibatis.session.RowBounds;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoutingStatementHandler
/*    */   implements StatementHandler
/*    */ {
/*    */   private final StatementHandler delegate;
/*    */   
/*    */   public RoutingStatementHandler(Executor executor, MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler, BoundSql boundSql)
/*    */   {
/* 40 */     switch (ms.getStatementType()) {
/*    */     case STATEMENT: 
/* 42 */       this.delegate = new SimpleStatementHandler(executor, ms, parameter, rowBounds, resultHandler, boundSql);
/* 43 */       break;
/*    */     case PREPARED: 
/* 45 */       this.delegate = new PreparedStatementHandler(executor, ms, parameter, rowBounds, resultHandler, boundSql);
/* 46 */       break;
/*    */     case CALLABLE: 
/* 48 */       this.delegate = new CallableStatementHandler(executor, ms, parameter, rowBounds, resultHandler, boundSql);
/* 49 */       break;
/*    */     default: 
/* 51 */       throw new ExecutorException("Unknown statement type: " + ms.getStatementType());
/*    */     }
/*    */   }
/*    */   
/*    */   public Statement prepare(Connection connection) throws SQLException
/*    */   {
/* 57 */     return this.delegate.prepare(connection);
/*    */   }
/*    */   
/*    */   public void parameterize(Statement statement) throws SQLException {
/* 61 */     this.delegate.parameterize(statement);
/*    */   }
/*    */   
/*    */   public void batch(Statement statement) throws SQLException {
/* 65 */     this.delegate.batch(statement);
/*    */   }
/*    */   
/*    */   public int update(Statement statement) throws SQLException {
/* 69 */     return this.delegate.update(statement);
/*    */   }
/*    */   
/*    */   public <E> List<E> query(Statement statement, ResultHandler resultHandler) throws SQLException {
/* 73 */     return this.delegate.query(statement, resultHandler);
/*    */   }
/*    */   
/*    */   public BoundSql getBoundSql() {
/* 77 */     return this.delegate.getBoundSql();
/*    */   }
/*    */   
/*    */   public ParameterHandler getParameterHandler() {
/* 81 */     return this.delegate.getParameterHandler();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\statement\RoutingStatementHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */