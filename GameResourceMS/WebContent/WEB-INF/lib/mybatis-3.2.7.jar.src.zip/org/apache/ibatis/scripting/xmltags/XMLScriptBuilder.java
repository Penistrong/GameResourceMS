/*     */ package org.apache.ibatis.scripting.xmltags;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.ibatis.builder.BaseBuilder;
/*     */ import org.apache.ibatis.builder.BuilderException;
/*     */ import org.apache.ibatis.mapping.SqlSource;
/*     */ import org.apache.ibatis.parsing.XNode;
/*     */ import org.apache.ibatis.scripting.defaults.RawSqlSource;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLScriptBuilder
/*     */   extends BaseBuilder
/*     */ {
/*     */   private XNode context;
/*     */   private boolean isDynamic;
/*     */   private Class<?> parameterType;
/*     */   
/*     */   public XMLScriptBuilder(Configuration configuration, XNode context)
/*     */   {
/*  42 */     this(configuration, context, null);
/*     */   }
/*     */   
/*     */   public XMLScriptBuilder(Configuration configuration, XNode context, Class<?> parameterType) {
/*  46 */     super(configuration);
/*  47 */     this.context = context;
/*  48 */     this.parameterType = parameterType;
/*     */   }
/*     */   
/*     */   public SqlSource parseScriptNode() {
/*  52 */     List<SqlNode> contents = parseDynamicTags(this.context);
/*  53 */     MixedSqlNode rootSqlNode = new MixedSqlNode(contents);
/*  54 */     SqlSource sqlSource = null;
/*  55 */     if (this.isDynamic) {
/*  56 */       sqlSource = new DynamicSqlSource(this.configuration, rootSqlNode);
/*     */     } else {
/*  58 */       sqlSource = new RawSqlSource(this.configuration, rootSqlNode, this.parameterType);
/*     */     }
/*  60 */     return sqlSource;
/*     */   }
/*     */   
/*     */   private List<SqlNode> parseDynamicTags(XNode node) {
/*  64 */     List<SqlNode> contents = new ArrayList();
/*  65 */     NodeList children = node.getNode().getChildNodes();
/*  66 */     for (int i = 0; i < children.getLength(); i++) {
/*  67 */       XNode child = node.newXNode(children.item(i));
/*  68 */       if ((child.getNode().getNodeType() == 4) || (child.getNode().getNodeType() == 3)) {
/*  69 */         String data = child.getStringBody("");
/*  70 */         TextSqlNode textSqlNode = new TextSqlNode(data);
/*  71 */         if (textSqlNode.isDynamic()) {
/*  72 */           contents.add(textSqlNode);
/*  73 */           this.isDynamic = true;
/*     */         } else {
/*  75 */           contents.add(new StaticTextSqlNode(data));
/*     */         }
/*  77 */       } else if (child.getNode().getNodeType() == 1) {
/*  78 */         String nodeName = child.getNode().getNodeName();
/*  79 */         NodeHandler handler = (NodeHandler)this.nodeHandlers.get(nodeName);
/*  80 */         if (handler == null) {
/*  81 */           throw new BuilderException("Unknown element <" + nodeName + "> in SQL statement.");
/*     */         }
/*  83 */         handler.handleNode(child, contents);
/*  84 */         this.isDynamic = true;
/*     */       }
/*     */     }
/*  87 */     return contents;
/*     */   }
/*     */   
/*  90 */   private Map<String, NodeHandler> nodeHandlers = new HashMap()
/*     */   {
/*     */     private static final long serialVersionUID = 7123056019193266281L;
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */   private static abstract interface NodeHandler
/*     */   {
/*     */     public abstract void handleNode(XNode paramXNode, List<SqlNode> paramList);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class BindHandler
/*     */     implements XMLScriptBuilder.NodeHandler
/*     */   {
/*     */     private BindHandler() {}
/*     */     
/*     */ 
/*     */     public void handleNode(XNode nodeToHandle, List<SqlNode> targetContents)
/*     */     {
/* 112 */       String name = nodeToHandle.getStringAttribute("name");
/* 113 */       String expression = nodeToHandle.getStringAttribute("value");
/* 114 */       VarDeclSqlNode node = new VarDeclSqlNode(name, expression);
/* 115 */       targetContents.add(node);
/*     */     }
/*     */   }
/*     */   
/*     */   private class TrimHandler implements XMLScriptBuilder.NodeHandler { private TrimHandler() {}
/*     */     
/* 121 */     public void handleNode(XNode nodeToHandle, List<SqlNode> targetContents) { List<SqlNode> contents = XMLScriptBuilder.this.parseDynamicTags(nodeToHandle);
/* 122 */       MixedSqlNode mixedSqlNode = new MixedSqlNode(contents);
/* 123 */       String prefix = nodeToHandle.getStringAttribute("prefix");
/* 124 */       String prefixOverrides = nodeToHandle.getStringAttribute("prefixOverrides");
/* 125 */       String suffix = nodeToHandle.getStringAttribute("suffix");
/* 126 */       String suffixOverrides = nodeToHandle.getStringAttribute("suffixOverrides");
/* 127 */       TrimSqlNode trim = new TrimSqlNode(XMLScriptBuilder.this.configuration, mixedSqlNode, prefix, prefixOverrides, suffix, suffixOverrides);
/* 128 */       targetContents.add(trim);
/*     */     }
/*     */   }
/*     */   
/*     */   private class WhereHandler implements XMLScriptBuilder.NodeHandler { private WhereHandler() {}
/*     */     
/* 134 */     public void handleNode(XNode nodeToHandle, List<SqlNode> targetContents) { List<SqlNode> contents = XMLScriptBuilder.this.parseDynamicTags(nodeToHandle);
/* 135 */       MixedSqlNode mixedSqlNode = new MixedSqlNode(contents);
/* 136 */       WhereSqlNode where = new WhereSqlNode(XMLScriptBuilder.this.configuration, mixedSqlNode);
/* 137 */       targetContents.add(where);
/*     */     }
/*     */   }
/*     */   
/*     */   private class SetHandler implements XMLScriptBuilder.NodeHandler { private SetHandler() {}
/*     */     
/* 143 */     public void handleNode(XNode nodeToHandle, List<SqlNode> targetContents) { List<SqlNode> contents = XMLScriptBuilder.this.parseDynamicTags(nodeToHandle);
/* 144 */       MixedSqlNode mixedSqlNode = new MixedSqlNode(contents);
/* 145 */       SetSqlNode set = new SetSqlNode(XMLScriptBuilder.this.configuration, mixedSqlNode);
/* 146 */       targetContents.add(set);
/*     */     }
/*     */   }
/*     */   
/*     */   private class ForEachHandler implements XMLScriptBuilder.NodeHandler { private ForEachHandler() {}
/*     */     
/* 152 */     public void handleNode(XNode nodeToHandle, List<SqlNode> targetContents) { List<SqlNode> contents = XMLScriptBuilder.this.parseDynamicTags(nodeToHandle);
/* 153 */       MixedSqlNode mixedSqlNode = new MixedSqlNode(contents);
/* 154 */       String collection = nodeToHandle.getStringAttribute("collection");
/* 155 */       String item = nodeToHandle.getStringAttribute("item");
/* 156 */       String index = nodeToHandle.getStringAttribute("index");
/* 157 */       String open = nodeToHandle.getStringAttribute("open");
/* 158 */       String close = nodeToHandle.getStringAttribute("close");
/* 159 */       String separator = nodeToHandle.getStringAttribute("separator");
/* 160 */       ForEachSqlNode forEachSqlNode = new ForEachSqlNode(XMLScriptBuilder.this.configuration, mixedSqlNode, collection, index, item, open, close, separator);
/* 161 */       targetContents.add(forEachSqlNode);
/*     */     }
/*     */   }
/*     */   
/*     */   private class IfHandler implements XMLScriptBuilder.NodeHandler { private IfHandler() {}
/*     */     
/* 167 */     public void handleNode(XNode nodeToHandle, List<SqlNode> targetContents) { List<SqlNode> contents = XMLScriptBuilder.this.parseDynamicTags(nodeToHandle);
/* 168 */       MixedSqlNode mixedSqlNode = new MixedSqlNode(contents);
/* 169 */       String test = nodeToHandle.getStringAttribute("test");
/* 170 */       IfSqlNode ifSqlNode = new IfSqlNode(mixedSqlNode, test);
/* 171 */       targetContents.add(ifSqlNode);
/*     */     }
/*     */   }
/*     */   
/*     */   private class OtherwiseHandler implements XMLScriptBuilder.NodeHandler { private OtherwiseHandler() {}
/*     */     
/* 177 */     public void handleNode(XNode nodeToHandle, List<SqlNode> targetContents) { List<SqlNode> contents = XMLScriptBuilder.this.parseDynamicTags(nodeToHandle);
/* 178 */       MixedSqlNode mixedSqlNode = new MixedSqlNode(contents);
/* 179 */       targetContents.add(mixedSqlNode);
/*     */     }
/*     */   }
/*     */   
/*     */   private class ChooseHandler implements XMLScriptBuilder.NodeHandler { private ChooseHandler() {}
/*     */     
/* 185 */     public void handleNode(XNode nodeToHandle, List<SqlNode> targetContents) { List<SqlNode> whenSqlNodes = new ArrayList();
/* 186 */       List<SqlNode> otherwiseSqlNodes = new ArrayList();
/* 187 */       handleWhenOtherwiseNodes(nodeToHandle, whenSqlNodes, otherwiseSqlNodes);
/* 188 */       SqlNode defaultSqlNode = getDefaultSqlNode(otherwiseSqlNodes);
/* 189 */       ChooseSqlNode chooseSqlNode = new ChooseSqlNode(whenSqlNodes, defaultSqlNode);
/* 190 */       targetContents.add(chooseSqlNode);
/*     */     }
/*     */     
/*     */     private void handleWhenOtherwiseNodes(XNode chooseSqlNode, List<SqlNode> ifSqlNodes, List<SqlNode> defaultSqlNodes) {
/* 194 */       List<XNode> children = chooseSqlNode.getChildren();
/* 195 */       for (XNode child : children) {
/* 196 */         String nodeName = child.getNode().getNodeName();
/* 197 */         XMLScriptBuilder.NodeHandler handler = (XMLScriptBuilder.NodeHandler)XMLScriptBuilder.this.nodeHandlers.get(nodeName);
/* 198 */         if ((handler instanceof XMLScriptBuilder.IfHandler)) {
/* 199 */           handler.handleNode(child, ifSqlNodes);
/* 200 */         } else if ((handler instanceof XMLScriptBuilder.OtherwiseHandler)) {
/* 201 */           handler.handleNode(child, defaultSqlNodes);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private SqlNode getDefaultSqlNode(List<SqlNode> defaultSqlNodes) {
/* 207 */       SqlNode defaultSqlNode = null;
/* 208 */       if (defaultSqlNodes.size() == 1) {
/* 209 */         defaultSqlNode = (SqlNode)defaultSqlNodes.get(0);
/* 210 */       } else if (defaultSqlNodes.size() > 1) {
/* 211 */         throw new BuilderException("Too many default (otherwise) elements in choose statement.");
/*     */       }
/* 213 */       return defaultSqlNode;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\xmltags\XMLScriptBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */