/*     */ package org.apache.ibatis.io;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassLoaderWrapper
/*     */ {
/*     */   ClassLoader defaultClassLoader;
/*     */   ClassLoader systemClassLoader;
/*     */   
/*     */   ClassLoaderWrapper()
/*     */   {
/*     */     try
/*     */     {
/*  33 */       this.systemClassLoader = ClassLoader.getSystemClassLoader();
/*     */     }
/*     */     catch (SecurityException ignored) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URL getResourceAsURL(String resource)
/*     */   {
/*  46 */     return getResourceAsURL(resource, getClassLoaders(null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URL getResourceAsURL(String resource, ClassLoader classLoader)
/*     */   {
/*  57 */     return getResourceAsURL(resource, getClassLoaders(classLoader));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStream getResourceAsStream(String resource)
/*     */   {
/*  67 */     return getResourceAsStream(resource, getClassLoaders(null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStream getResourceAsStream(String resource, ClassLoader classLoader)
/*     */   {
/*  78 */     return getResourceAsStream(resource, getClassLoaders(classLoader));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> classForName(String name)
/*     */     throws ClassNotFoundException
/*     */   {
/*  89 */     return classForName(name, getClassLoaders(null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> classForName(String name, ClassLoader classLoader)
/*     */     throws ClassNotFoundException
/*     */   {
/* 101 */     return classForName(name, getClassLoaders(classLoader));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   InputStream getResourceAsStream(String resource, ClassLoader[] classLoader)
/*     */   {
/* 112 */     for (ClassLoader cl : classLoader) {
/* 113 */       if (null != cl)
/*     */       {
/*     */ 
/* 116 */         InputStream returnValue = cl.getResourceAsStream(resource);
/*     */         
/*     */ 
/* 119 */         if (null == returnValue) { returnValue = cl.getResourceAsStream("/" + resource);
/*     */         }
/* 121 */         if (null != returnValue) return returnValue;
/*     */       }
/*     */     }
/* 124 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   URL getResourceAsURL(String resource, ClassLoader[] classLoader)
/*     */   {
/* 138 */     for (ClassLoader cl : classLoader)
/*     */     {
/* 140 */       if (null != cl)
/*     */       {
/*     */ 
/* 143 */         URL url = cl.getResource(resource);
/*     */         
/*     */ 
/*     */ 
/* 147 */         if (null == url) { url = cl.getResource("/" + resource);
/*     */         }
/*     */         
/*     */ 
/* 151 */         if (null != url) { return url;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 158 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Class<?> classForName(String name, ClassLoader[] classLoader)
/*     */     throws ClassNotFoundException
/*     */   {
/* 172 */     for (ClassLoader cl : classLoader)
/*     */     {
/* 174 */       if (null != cl)
/*     */       {
/*     */         try
/*     */         {
/* 178 */           Class<?> c = Class.forName(name, true, cl);
/*     */           
/* 180 */           if (null != c) { return c;
/*     */           }
/*     */         }
/*     */         catch (ClassNotFoundException e) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 190 */     throw new ClassNotFoundException("Cannot find class: " + name);
/*     */   }
/*     */   
/*     */   ClassLoader[] getClassLoaders(ClassLoader classLoader)
/*     */   {
/* 195 */     return new ClassLoader[] { classLoader, this.defaultClassLoader, Thread.currentThread().getContextClassLoader(), getClass().getClassLoader(), this.systemClassLoader };
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\io\ClassLoaderWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */