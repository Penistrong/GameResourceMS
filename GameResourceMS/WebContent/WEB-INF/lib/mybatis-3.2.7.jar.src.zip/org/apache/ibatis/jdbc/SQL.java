/*    */ package org.apache.ibatis.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQL
/*    */   extends AbstractSQL<SQL>
/*    */ {
/*    */   public SQL getSelf()
/*    */   {
/* 25 */     return this;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\jdbc\SQL.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */