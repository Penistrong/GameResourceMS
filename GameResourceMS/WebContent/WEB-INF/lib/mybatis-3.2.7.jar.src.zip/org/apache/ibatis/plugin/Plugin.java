/*     */ package org.apache.ibatis.plugin;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.ibatis.reflection.ExceptionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Plugin
/*     */   implements InvocationHandler
/*     */ {
/*     */   private Object target;
/*     */   private Interceptor interceptor;
/*     */   private Map<Class<?>, Set<Method>> signatureMap;
/*     */   
/*     */   private Plugin(Object target, Interceptor interceptor, Map<Class<?>, Set<Method>> signatureMap)
/*     */   {
/*  38 */     this.target = target;
/*  39 */     this.interceptor = interceptor;
/*  40 */     this.signatureMap = signatureMap;
/*     */   }
/*     */   
/*     */   public static Object wrap(Object target, Interceptor interceptor) {
/*  44 */     Map<Class<?>, Set<Method>> signatureMap = getSignatureMap(interceptor);
/*  45 */     Class<?> type = target.getClass();
/*  46 */     Class<?>[] interfaces = getAllInterfaces(type, signatureMap);
/*  47 */     if (interfaces.length > 0) {
/*  48 */       return Proxy.newProxyInstance(type.getClassLoader(), interfaces, new Plugin(target, interceptor, signatureMap));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  53 */     return target;
/*     */   }
/*     */   
/*     */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*     */     try {
/*  58 */       Set<Method> methods = (Set)this.signatureMap.get(method.getDeclaringClass());
/*  59 */       if ((methods != null) && (methods.contains(method))) {
/*  60 */         return this.interceptor.intercept(new Invocation(this.target, method, args));
/*     */       }
/*  62 */       return method.invoke(this.target, args);
/*     */     } catch (Exception e) {
/*  64 */       throw ExceptionUtil.unwrapThrowable(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private static Map<Class<?>, Set<Method>> getSignatureMap(Interceptor interceptor) {
/*  69 */     Intercepts interceptsAnnotation = (Intercepts)interceptor.getClass().getAnnotation(Intercepts.class);
/*  70 */     if (interceptsAnnotation == null) {
/*  71 */       throw new PluginException("No @Intercepts annotation was found in interceptor " + interceptor.getClass().getName());
/*     */     }
/*  73 */     Signature[] sigs = interceptsAnnotation.value();
/*  74 */     Map<Class<?>, Set<Method>> signatureMap = new HashMap();
/*  75 */     for (Signature sig : sigs) {
/*  76 */       Set<Method> methods = (Set)signatureMap.get(sig.type());
/*  77 */       if (methods == null) {
/*  78 */         methods = new HashSet();
/*  79 */         signatureMap.put(sig.type(), methods);
/*     */       }
/*     */       try {
/*  82 */         Method method = sig.type().getMethod(sig.method(), sig.args());
/*  83 */         methods.add(method);
/*     */       } catch (NoSuchMethodException e) {
/*  85 */         throw new PluginException("Could not find method on " + sig.type() + " named " + sig.method() + ". Cause: " + e, e);
/*     */       }
/*     */     }
/*  88 */     return signatureMap;
/*     */   }
/*     */   
/*     */   private static Class<?>[] getAllInterfaces(Class<?> type, Map<Class<?>, Set<Method>> signatureMap) {
/*  92 */     Set<Class<?>> interfaces = new HashSet();
/*  93 */     while (type != null) {
/*  94 */       for (Class<?> c : type.getInterfaces()) {
/*  95 */         if (signatureMap.containsKey(c)) {
/*  96 */           interfaces.add(c);
/*     */         }
/*     */       }
/*  99 */       type = type.getSuperclass();
/*     */     }
/* 101 */     return (Class[])interfaces.toArray(new Class[interfaces.size()]);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\plugin\Plugin.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */