/*    */ package org.apache.ibatis.session;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RowBounds
/*    */ {
/*    */   public static final int NO_ROW_OFFSET = 0;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final int NO_ROW_LIMIT = Integer.MAX_VALUE;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 25 */   public static final RowBounds DEFAULT = new RowBounds();
/*    */   private int offset;
/*    */   private int limit;
/*    */   
/*    */   public RowBounds()
/*    */   {
/* 31 */     this.offset = 0;
/* 32 */     this.limit = Integer.MAX_VALUE;
/*    */   }
/*    */   
/*    */   public RowBounds(int offset, int limit) {
/* 36 */     this.offset = offset;
/* 37 */     this.limit = limit;
/*    */   }
/*    */   
/*    */   public int getOffset() {
/* 41 */     return this.offset;
/*    */   }
/*    */   
/*    */   public int getLimit() {
/* 45 */     return this.limit;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\session\RowBounds.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */