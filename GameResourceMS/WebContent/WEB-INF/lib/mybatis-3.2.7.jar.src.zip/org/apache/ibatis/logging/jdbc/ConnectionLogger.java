/*    */ package org.apache.ibatis.logging.jdbc;
/*    */ 
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Proxy;
/*    */ import java.sql.Connection;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.Statement;
/*    */ import org.apache.ibatis.logging.Log;
/*    */ import org.apache.ibatis.reflection.ExceptionUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ConnectionLogger
/*    */   extends BaseJdbcLogger
/*    */   implements InvocationHandler
/*    */ {
/*    */   private Connection connection;
/*    */   
/*    */   private ConnectionLogger(Connection conn, Log statementLog, int queryStack)
/*    */   {
/* 40 */     super(statementLog, queryStack);
/* 41 */     this.connection = conn;
/*    */   }
/*    */   
/*    */   public Object invoke(Object proxy, Method method, Object[] params) throws Throwable
/*    */   {
/*    */     try {
/* 47 */       if (Object.class.equals(method.getDeclaringClass())) {
/* 48 */         return method.invoke(this, params);
/*    */       }
/* 50 */       if ("prepareStatement".equals(method.getName())) {
/* 51 */         if (isDebugEnabled()) {
/* 52 */           debug(" Preparing: " + removeBreakingWhitespace((String)params[0]), true);
/*    */         }
/* 54 */         PreparedStatement stmt = (PreparedStatement)method.invoke(this.connection, params);
/* 55 */         return PreparedStatementLogger.newInstance(stmt, this.statementLog, this.queryStack);
/*    */       }
/* 57 */       if ("prepareCall".equals(method.getName())) {
/* 58 */         if (isDebugEnabled()) {
/* 59 */           debug(" Preparing: " + removeBreakingWhitespace((String)params[0]), true);
/*    */         }
/* 61 */         PreparedStatement stmt = (PreparedStatement)method.invoke(this.connection, params);
/* 62 */         return PreparedStatementLogger.newInstance(stmt, this.statementLog, this.queryStack);
/*    */       }
/* 64 */       if ("createStatement".equals(method.getName())) {
/* 65 */         Statement stmt = (Statement)method.invoke(this.connection, params);
/* 66 */         return StatementLogger.newInstance(stmt, this.statementLog, this.queryStack);
/*    */       }
/*    */       
/* 69 */       return method.invoke(this.connection, params);
/*    */     }
/*    */     catch (Throwable t) {
/* 72 */       throw ExceptionUtil.unwrapThrowable(t);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Connection newInstance(Connection conn, Log statementLog, int queryStack)
/*    */   {
/* 83 */     InvocationHandler handler = new ConnectionLogger(conn, statementLog, queryStack);
/* 84 */     ClassLoader cl = Connection.class.getClassLoader();
/* 85 */     return (Connection)Proxy.newProxyInstance(cl, new Class[] { Connection.class }, handler);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Connection getConnection()
/*    */   {
/* 94 */     return this.connection;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\logging\jdbc\ConnectionLogger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */