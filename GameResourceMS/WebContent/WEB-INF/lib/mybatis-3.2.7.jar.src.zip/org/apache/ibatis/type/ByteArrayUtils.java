/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ByteArrayUtils
/*    */ {
/*    */   static byte[] convertToPrimitiveArray(Byte[] objects)
/*    */   {
/* 23 */     byte[] bytes = new byte[objects.length];
/* 24 */     for (int i = 0; i < objects.length; i++) {
/* 25 */       Byte b = objects[i];
/* 26 */       bytes[i] = b.byteValue();
/*    */     }
/* 28 */     return bytes;
/*    */   }
/*    */   
/*    */   static Byte[] convertToObjectArray(byte[] bytes) {
/* 32 */     Byte[] objects = new Byte[bytes.length];
/* 33 */     for (int i = 0; i < bytes.length; i++) {
/* 34 */       byte b = bytes[i];
/* 35 */       objects[i] = Byte.valueOf(b);
/*    */     }
/* 37 */     return objects;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\ByteArrayUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */