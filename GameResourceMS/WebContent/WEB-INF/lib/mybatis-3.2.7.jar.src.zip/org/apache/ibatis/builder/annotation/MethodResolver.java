/*    */ package org.apache.ibatis.builder.annotation;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodResolver
/*    */ {
/*    */   private final MapperAnnotationBuilder annotationBuilder;
/*    */   private Method method;
/*    */   
/*    */   public MethodResolver(MapperAnnotationBuilder annotationBuilder, Method method)
/*    */   {
/* 28 */     this.annotationBuilder = annotationBuilder;
/* 29 */     this.method = method;
/*    */   }
/*    */   
/*    */   public void resolve() {
/* 33 */     this.annotationBuilder.parseStatement(this.method);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\builder\annotation\MethodResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */