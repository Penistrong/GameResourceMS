/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayPropertyAccessor
/*     */   extends ObjectPropertyAccessor
/*     */   implements PropertyAccessor
/*     */ {
/*     */   public Object getProperty(Map context, Object target, Object name)
/*     */     throws OgnlException
/*     */   {
/*  47 */     Object result = null;
/*     */     
/*  49 */     if ((name instanceof String)) {
/*  50 */       if (name.equals("length")) {
/*  51 */         result = new Integer(Array.getLength(target));
/*     */       } else {
/*  53 */         result = super.getProperty(context, target, name);
/*     */       }
/*     */     } else {
/*  56 */       Object index = name;
/*     */       
/*  58 */       if ((index instanceof DynamicSubscript)) {
/*  59 */         int len = Array.getLength(target);
/*     */         
/*  61 */         switch (((DynamicSubscript)index).getFlag()) {
/*     */         case 3: 
/*  63 */           result = Array.newInstance(target.getClass().getComponentType(), len);
/*  64 */           System.arraycopy(target, 0, result, 0, len);
/*  65 */           break;
/*     */         case 0: 
/*  67 */           index = new Integer(len > 0 ? 0 : -1);
/*  68 */           break;
/*     */         case 1: 
/*  70 */           index = new Integer(len > 0 ? len / 2 : -1);
/*  71 */           break;
/*     */         case 2: 
/*  73 */           index = new Integer(len > 0 ? len - 1 : -1);
/*     */         }
/*     */         
/*     */       }
/*  77 */       if (result == null) {
/*  78 */         if ((index instanceof Number)) {
/*  79 */           int i = ((Number)index).intValue();
/*     */           
/*  81 */           result = i >= 0 ? Array.get(target, i) : null;
/*     */         } else {
/*  83 */           throw new NoSuchPropertyException(target, index);
/*     */         }
/*     */       }
/*     */     }
/*  87 */     return result;
/*     */   }
/*     */   
/*     */   public void setProperty(Map context, Object target, Object name, Object value) throws OgnlException
/*     */   {
/*  92 */     Object index = name;
/*  93 */     boolean isNumber = index instanceof Number;
/*     */     
/*  95 */     if ((isNumber) || ((index instanceof DynamicSubscript))) {
/*  96 */       TypeConverter converter = ((OgnlContext)context).getTypeConverter();
/*     */       
/*     */ 
/*  99 */       Object convertedValue = converter.convertValue(context, target, null, name.toString(), value, target.getClass().getComponentType());
/* 100 */       if (isNumber) {
/* 101 */         int i = ((Number)index).intValue();
/*     */         
/* 103 */         if (i >= 0) {
/* 104 */           Array.set(target, i, convertedValue);
/*     */         }
/*     */       } else {
/* 107 */         int len = Array.getLength(target);
/*     */         
/* 109 */         switch (((DynamicSubscript)index).getFlag()) {
/*     */         case 3: 
/* 111 */           System.arraycopy(target, 0, convertedValue, 0, len);
/* 112 */           return;
/*     */         case 0: 
/* 114 */           index = new Integer(len > 0 ? 0 : -1);
/* 115 */           break;
/*     */         case 1: 
/* 117 */           index = new Integer(len > 0 ? len / 2 : -1);
/* 118 */           break;
/*     */         case 2: 
/* 120 */           index = new Integer(len > 0 ? len - 1 : -1);
/*     */         }
/*     */         
/*     */       }
/*     */     }
/* 125 */     else if ((name instanceof String)) {
/* 126 */       super.setProperty(context, target, name, value);
/*     */     } else {
/* 128 */       throw new NoSuchPropertyException(target, index);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ArrayPropertyAccessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */