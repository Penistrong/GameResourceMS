/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import java.util.Date;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleTypeRegistry
/*    */ {
/* 29 */   private static final Set<Class<?>> SIMPLE_TYPE_SET = new HashSet();
/*    */   
/*    */   static {
/* 32 */     SIMPLE_TYPE_SET.add(String.class);
/* 33 */     SIMPLE_TYPE_SET.add(Byte.class);
/* 34 */     SIMPLE_TYPE_SET.add(Short.class);
/* 35 */     SIMPLE_TYPE_SET.add(Character.class);
/* 36 */     SIMPLE_TYPE_SET.add(Integer.class);
/* 37 */     SIMPLE_TYPE_SET.add(Long.class);
/* 38 */     SIMPLE_TYPE_SET.add(Float.class);
/* 39 */     SIMPLE_TYPE_SET.add(Double.class);
/* 40 */     SIMPLE_TYPE_SET.add(Boolean.class);
/* 41 */     SIMPLE_TYPE_SET.add(Date.class);
/* 42 */     SIMPLE_TYPE_SET.add(Class.class);
/* 43 */     SIMPLE_TYPE_SET.add(BigInteger.class);
/* 44 */     SIMPLE_TYPE_SET.add(BigDecimal.class);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static boolean isSimpleType(Class<?> clazz)
/*    */   {
/* 54 */     return SIMPLE_TYPE_SET.contains(clazz);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\SimpleTypeRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */