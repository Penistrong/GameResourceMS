/*    */ package org.apache.ibatis.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class IbatisException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 3880206998166270511L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public IbatisException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public IbatisException(String message)
/*    */   {
/* 31 */     super(message);
/*    */   }
/*    */   
/*    */   public IbatisException(String message, Throwable cause) {
/* 35 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public IbatisException(Throwable cause) {
/* 39 */     super(cause);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\exceptions\IbatisException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */