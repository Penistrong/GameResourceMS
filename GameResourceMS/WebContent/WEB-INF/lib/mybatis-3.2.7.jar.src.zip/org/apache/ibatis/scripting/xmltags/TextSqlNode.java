/*    */ package org.apache.ibatis.scripting.xmltags;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.ibatis.parsing.GenericTokenParser;
/*    */ import org.apache.ibatis.parsing.TokenHandler;
/*    */ import org.apache.ibatis.type.SimpleTypeRegistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextSqlNode
/*    */   implements SqlNode
/*    */ {
/*    */   private String text;
/*    */   
/*    */   public TextSqlNode(String text)
/*    */   {
/* 29 */     this.text = text;
/*    */   }
/*    */   
/*    */   public boolean isDynamic() {
/* 33 */     DynamicCheckerTokenParser checker = new DynamicCheckerTokenParser(null);
/* 34 */     GenericTokenParser parser = createParser(checker);
/* 35 */     parser.parse(this.text);
/* 36 */     return checker.isDynamic();
/*    */   }
/*    */   
/*    */   public boolean apply(DynamicContext context) {
/* 40 */     GenericTokenParser parser = createParser(new BindingTokenParser(context));
/* 41 */     context.appendSql(parser.parse(this.text));
/* 42 */     return true;
/*    */   }
/*    */   
/*    */   private GenericTokenParser createParser(TokenHandler handler) {
/* 46 */     return new GenericTokenParser("${", "}", handler);
/*    */   }
/*    */   
/*    */   private static class BindingTokenParser implements TokenHandler
/*    */   {
/*    */     private DynamicContext context;
/*    */     
/*    */     public BindingTokenParser(DynamicContext context) {
/* 54 */       this.context = context;
/*    */     }
/*    */     
/*    */     public String handleToken(String content) {
/* 58 */       Object parameter = this.context.getBindings().get("_parameter");
/* 59 */       if (parameter == null) {
/* 60 */         this.context.getBindings().put("value", null);
/* 61 */       } else if (SimpleTypeRegistry.isSimpleType(parameter.getClass())) {
/* 62 */         this.context.getBindings().put("value", parameter);
/*    */       }
/* 64 */       Object value = OgnlCache.getValue(content, this.context.getBindings());
/* 65 */       return value == null ? "" : String.valueOf(value);
/*    */     }
/*    */   }
/*    */   
/*    */   private static class DynamicCheckerTokenParser implements TokenHandler
/*    */   {
/*    */     private boolean isDynamic;
/*    */     
/*    */     public boolean isDynamic() {
/* 74 */       return this.isDynamic;
/*    */     }
/*    */     
/*    */     public String handleToken(String content) {
/* 78 */       this.isDynamic = true;
/* 79 */       return null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\xmltags\TextSqlNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */