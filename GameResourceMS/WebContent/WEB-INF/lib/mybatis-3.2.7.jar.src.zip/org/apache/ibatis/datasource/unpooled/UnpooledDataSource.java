/*     */ package org.apache.ibatis.datasource.unpooled;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Driver;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.DriverPropertyInfo;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.logging.Logger;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.ibatis.io.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnpooledDataSource
/*     */   implements DataSource
/*     */ {
/*     */   private ClassLoader driverClassLoader;
/*     */   private Properties driverProperties;
/*  42 */   private static Map<String, Driver> registeredDrivers = new ConcurrentHashMap();
/*     */   
/*     */   private String driver;
/*     */   private String url;
/*     */   private String username;
/*     */   private String password;
/*     */   private Boolean autoCommit;
/*     */   private Integer defaultTransactionIsolationLevel;
/*     */   
/*     */   static
/*     */   {
/*  53 */     Enumeration<Driver> drivers = DriverManager.getDrivers();
/*  54 */     while (drivers.hasMoreElements()) {
/*  55 */       Driver driver = (Driver)drivers.nextElement();
/*  56 */       registeredDrivers.put(driver.getClass().getName(), driver);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public UnpooledDataSource(String driver, String url, String username, String password)
/*     */   {
/*  64 */     this.driver = driver;
/*  65 */     this.url = url;
/*  66 */     this.username = username;
/*  67 */     this.password = password;
/*     */   }
/*     */   
/*     */   public UnpooledDataSource(String driver, String url, Properties driverProperties) {
/*  71 */     this.driver = driver;
/*  72 */     this.url = url;
/*  73 */     this.driverProperties = driverProperties;
/*     */   }
/*     */   
/*     */   public UnpooledDataSource(ClassLoader driverClassLoader, String driver, String url, String username, String password) {
/*  77 */     this.driverClassLoader = driverClassLoader;
/*  78 */     this.driver = driver;
/*  79 */     this.url = url;
/*  80 */     this.username = username;
/*  81 */     this.password = password;
/*     */   }
/*     */   
/*     */   public UnpooledDataSource(ClassLoader driverClassLoader, String driver, String url, Properties driverProperties) {
/*  85 */     this.driverClassLoader = driverClassLoader;
/*  86 */     this.driver = driver;
/*  87 */     this.url = url;
/*  88 */     this.driverProperties = driverProperties;
/*     */   }
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/*  92 */     return doGetConnection(this.username, this.password);
/*     */   }
/*     */   
/*     */   public Connection getConnection(String username, String password) throws SQLException {
/*  96 */     return doGetConnection(username, password);
/*     */   }
/*     */   
/*     */   public void setLoginTimeout(int loginTimeout) throws SQLException {
/* 100 */     DriverManager.setLoginTimeout(loginTimeout);
/*     */   }
/*     */   
/*     */   public int getLoginTimeout() throws SQLException {
/* 104 */     return DriverManager.getLoginTimeout();
/*     */   }
/*     */   
/*     */   public void setLogWriter(PrintWriter logWriter) throws SQLException {
/* 108 */     DriverManager.setLogWriter(logWriter);
/*     */   }
/*     */   
/*     */   public PrintWriter getLogWriter() throws SQLException {
/* 112 */     return DriverManager.getLogWriter();
/*     */   }
/*     */   
/*     */   public ClassLoader getDriverClassLoader() {
/* 116 */     return this.driverClassLoader;
/*     */   }
/*     */   
/*     */   public void setDriverClassLoader(ClassLoader driverClassLoader) {
/* 120 */     this.driverClassLoader = driverClassLoader;
/*     */   }
/*     */   
/*     */   public Properties getDriverProperties() {
/* 124 */     return this.driverProperties;
/*     */   }
/*     */   
/*     */   public void setDriverProperties(Properties driverProperties) {
/* 128 */     this.driverProperties = driverProperties;
/*     */   }
/*     */   
/*     */   public String getDriver() {
/* 132 */     return this.driver;
/*     */   }
/*     */   
/*     */   public synchronized void setDriver(String driver) {
/* 136 */     this.driver = driver;
/*     */   }
/*     */   
/*     */   public String getUrl() {
/* 140 */     return this.url;
/*     */   }
/*     */   
/*     */   public void setUrl(String url) {
/* 144 */     this.url = url;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 148 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 152 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 156 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 160 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Boolean isAutoCommit() {
/* 164 */     return this.autoCommit;
/*     */   }
/*     */   
/*     */   public void setAutoCommit(Boolean autoCommit) {
/* 168 */     this.autoCommit = autoCommit;
/*     */   }
/*     */   
/*     */   public Integer getDefaultTransactionIsolationLevel() {
/* 172 */     return this.defaultTransactionIsolationLevel;
/*     */   }
/*     */   
/*     */   public void setDefaultTransactionIsolationLevel(Integer defaultTransactionIsolationLevel) {
/* 176 */     this.defaultTransactionIsolationLevel = defaultTransactionIsolationLevel;
/*     */   }
/*     */   
/*     */   private Connection doGetConnection(String username, String password) throws SQLException {
/* 180 */     Properties props = new Properties();
/* 181 */     if (this.driverProperties != null) {
/* 182 */       props.putAll(this.driverProperties);
/*     */     }
/* 184 */     if (username != null) {
/* 185 */       props.setProperty("user", username);
/*     */     }
/* 187 */     if (password != null) {
/* 188 */       props.setProperty("password", password);
/*     */     }
/* 190 */     return doGetConnection(props);
/*     */   }
/*     */   
/*     */   private Connection doGetConnection(Properties properties) throws SQLException {
/* 194 */     initializeDriver();
/* 195 */     Connection connection = DriverManager.getConnection(this.url, properties);
/* 196 */     configureConnection(connection);
/* 197 */     return connection;
/*     */   }
/*     */   
/*     */   private synchronized void initializeDriver() throws SQLException {
/* 201 */     if (!registeredDrivers.containsKey(this.driver)) {
/*     */       try { Class<?> driverType;
/*     */         Class<?> driverType;
/* 204 */         if (this.driverClassLoader != null) {
/* 205 */           driverType = Class.forName(this.driver, true, this.driverClassLoader);
/*     */         } else {
/* 207 */           driverType = Resources.classForName(this.driver);
/*     */         }
/*     */         
/*     */ 
/* 211 */         Driver driverInstance = (Driver)driverType.newInstance();
/* 212 */         DriverManager.registerDriver(new DriverProxy(driverInstance));
/* 213 */         registeredDrivers.put(this.driver, driverInstance);
/*     */       } catch (Exception e) {
/* 215 */         throw new SQLException("Error setting driver on UnpooledDataSource. Cause: " + e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureConnection(Connection conn) throws SQLException {
/* 221 */     if ((this.autoCommit != null) && (this.autoCommit.booleanValue() != conn.getAutoCommit())) {
/* 222 */       conn.setAutoCommit(this.autoCommit.booleanValue());
/*     */     }
/* 224 */     if (this.defaultTransactionIsolationLevel != null) {
/* 225 */       conn.setTransactionIsolation(this.defaultTransactionIsolationLevel.intValue());
/*     */     }
/*     */   }
/*     */   
/*     */   private static class DriverProxy implements Driver {
/*     */     private Driver driver;
/*     */     
/*     */     DriverProxy(Driver d) {
/* 233 */       this.driver = d;
/*     */     }
/*     */     
/*     */     public boolean acceptsURL(String u) throws SQLException {
/* 237 */       return this.driver.acceptsURL(u);
/*     */     }
/*     */     
/*     */     public Connection connect(String u, Properties p) throws SQLException {
/* 241 */       return this.driver.connect(u, p);
/*     */     }
/*     */     
/*     */     public int getMajorVersion() {
/* 245 */       return this.driver.getMajorVersion();
/*     */     }
/*     */     
/*     */     public int getMinorVersion() {
/* 249 */       return this.driver.getMinorVersion();
/*     */     }
/*     */     
/*     */     public DriverPropertyInfo[] getPropertyInfo(String u, Properties p) throws SQLException {
/* 253 */       return this.driver.getPropertyInfo(u, p);
/*     */     }
/*     */     
/*     */     public boolean jdbcCompliant() {
/* 257 */       return this.driver.jdbcCompliant();
/*     */     }
/*     */     
/*     */     public Logger getParentLogger() {
/* 261 */       return Logger.getLogger("global");
/*     */     }
/*     */   }
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException {
/* 266 */     throw new SQLException(getClass().getName() + " is not a wrapper.");
/*     */   }
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 270 */     return false;
/*     */   }
/*     */   
/*     */   public Logger getParentLogger() {
/* 274 */     return Logger.getLogger("global");
/*     */   }
/*     */   
/*     */   public UnpooledDataSource() {}
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\datasource\unpooled\UnpooledDataSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */