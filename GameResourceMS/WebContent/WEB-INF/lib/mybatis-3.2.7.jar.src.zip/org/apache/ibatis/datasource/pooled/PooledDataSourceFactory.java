/*    */ package org.apache.ibatis.datasource.pooled;
/*    */ 
/*    */ import org.apache.ibatis.datasource.unpooled.UnpooledDataSourceFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PooledDataSourceFactory
/*    */   extends UnpooledDataSourceFactory
/*    */ {
/*    */   public PooledDataSourceFactory()
/*    */   {
/* 26 */     this.dataSource = new PooledDataSource();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\datasource\pooled\PooledDataSourceFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */