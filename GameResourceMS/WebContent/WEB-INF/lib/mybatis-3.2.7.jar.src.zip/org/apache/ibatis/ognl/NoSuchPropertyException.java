/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoSuchPropertyException
/*    */   extends OgnlException
/*    */ {
/*    */   private Object target;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private Object name;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public NoSuchPropertyException(Object target, Object name, Throwable reason)
/*    */   {
/* 47 */     super(((target instanceof Class) ? target.toString() : target.getClass().getName()) + "." + name, reason);
/* 48 */     this.target = target;
/* 49 */     this.name = name;
/*    */   }
/*    */   
/*    */   public NoSuchPropertyException(Object target, Object name)
/*    */   {
/* 54 */     this(target, name, null);
/*    */   }
/*    */   
/*    */   public Object getTarget()
/*    */   {
/* 59 */     return this.target;
/*    */   }
/*    */   
/*    */   public Object getName()
/*    */   {
/* 64 */     return this.name;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\NoSuchPropertyException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */