/*    */ package org.apache.ibatis.executor.loader;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractEnhancedDeserializationProxy
/*    */ {
/*    */   protected static final String FINALIZE_METHOD = "finalize";
/*    */   protected static final String WRITE_REPLACE_METHOD = "writeReplace";
/*    */   private Class<?> type;
/*    */   private Map<String, ResultLoaderMap.LoadPair> unloadedProperties;
/*    */   private ObjectFactory objectFactory;
/*    */   private List<Class<?>> constructorArgTypes;
/*    */   private List<Object> constructorArgs;
/*    */   private final Object reloadingPropertyLock;
/*    */   private boolean reloadingProperty;
/*    */   
/*    */   protected AbstractEnhancedDeserializationProxy(Class<?> type, Map<String, ResultLoaderMap.LoadPair> unloadedProperties, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs)
/*    */   {
/* 46 */     this.type = type;
/* 47 */     this.unloadedProperties = unloadedProperties;
/* 48 */     this.objectFactory = objectFactory;
/* 49 */     this.constructorArgTypes = constructorArgTypes;
/* 50 */     this.constructorArgs = constructorArgs;
/* 51 */     this.reloadingPropertyLock = new Object();
/* 52 */     this.reloadingProperty = false;
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   public final Object invoke(Object enhanced, java.lang.reflect.Method method, Object[] args)
/*    */     throws java.lang.Throwable
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_2
/*    */     //   1: invokevirtual 65	java/lang/reflect/Method:getName	()Ljava/lang/String;
/*    */     //   4: astore 4
/*    */     //   6: ldc 17
/*    */     //   8: aload 4
/*    */     //   10: invokevirtual 71	java/lang/String:equals	(Ljava/lang/Object;)Z
/*    */     //   13: ifeq +89 -> 102
/*    */     //   16: aload_0
/*    */     //   17: getfield 47	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:constructorArgTypes	Ljava/util/List;
/*    */     //   20: invokeinterface 77 1 0
/*    */     //   25: ifeq +21 -> 46
/*    */     //   28: aload_0
/*    */     //   29: getfield 45	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:objectFactory	Lorg/apache/ibatis/reflection/factory/ObjectFactory;
/*    */     //   32: aload_0
/*    */     //   33: getfield 41	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:type	Ljava/lang/Class;
/*    */     //   36: invokeinterface 83 2 0
/*    */     //   41: astore 5
/*    */     //   43: goto +26 -> 69
/*    */     //   46: aload_0
/*    */     //   47: getfield 45	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:objectFactory	Lorg/apache/ibatis/reflection/factory/ObjectFactory;
/*    */     //   50: aload_0
/*    */     //   51: getfield 41	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:type	Ljava/lang/Class;
/*    */     //   54: aload_0
/*    */     //   55: getfield 47	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:constructorArgTypes	Ljava/util/List;
/*    */     //   58: aload_0
/*    */     //   59: getfield 49	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:constructorArgs	Ljava/util/List;
/*    */     //   62: invokeinterface 86 4 0
/*    */     //   67: astore 5
/*    */     //   69: aload_0
/*    */     //   70: getfield 41	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:type	Ljava/lang/Class;
/*    */     //   73: aload_1
/*    */     //   74: aload 5
/*    */     //   76: invokestatic 92	org/apache/ibatis/reflection/property/PropertyCopier:copyBeanProperties	(Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/Object;)V
/*    */     //   79: aload_0
/*    */     //   80: aload 5
/*    */     //   82: aload_0
/*    */     //   83: getfield 43	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:unloadedProperties	Ljava/util/Map;
/*    */     //   86: aload_0
/*    */     //   87: getfield 45	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:objectFactory	Lorg/apache/ibatis/reflection/factory/ObjectFactory;
/*    */     //   90: aload_0
/*    */     //   91: getfield 47	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:constructorArgTypes	Ljava/util/List;
/*    */     //   94: aload_0
/*    */     //   95: getfield 49	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:constructorArgs	Ljava/util/List;
/*    */     //   98: invokevirtual 96	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:newSerialStateHolder	(Ljava/lang/Object;Ljava/util/Map;Lorg/apache/ibatis/reflection/factory/ObjectFactory;Ljava/util/List;Ljava/util/List;)Lorg/apache/ibatis/executor/loader/AbstractSerialStateHolder;
/*    */     //   101: areturn
/*    */     //   102: aload_0
/*    */     //   103: getfield 51	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:reloadingPropertyLock	Ljava/lang/Object;
/*    */     //   106: dup
/*    */     //   107: astore 5
/*    */     //   109: monitorenter
/*    */     //   110: ldc 14
/*    */     //   112: aload 4
/*    */     //   114: invokevirtual 71	java/lang/String:equals	(Ljava/lang/Object;)Z
/*    */     //   117: ifne +135 -> 252
/*    */     //   120: aload 4
/*    */     //   122: invokestatic 102	org/apache/ibatis/reflection/property/PropertyNamer:isProperty	(Ljava/lang/String;)Z
/*    */     //   125: ifeq +127 -> 252
/*    */     //   128: aload_0
/*    */     //   129: getfield 53	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:reloadingProperty	Z
/*    */     //   132: ifne +120 -> 252
/*    */     //   135: aload 4
/*    */     //   137: invokestatic 106	org/apache/ibatis/reflection/property/PropertyNamer:methodToProperty	(Ljava/lang/String;)Ljava/lang/String;
/*    */     //   140: astore 6
/*    */     //   142: aload 6
/*    */     //   144: getstatic 112	java/util/Locale:ENGLISH	Ljava/util/Locale;
/*    */     //   147: invokevirtual 116	java/lang/String:toUpperCase	(Ljava/util/Locale;)Ljava/lang/String;
/*    */     //   150: astore 7
/*    */     //   152: aload_0
/*    */     //   153: getfield 43	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:unloadedProperties	Ljava/util/Map;
/*    */     //   156: aload 7
/*    */     //   158: invokeinterface 121 2 0
/*    */     //   163: ifeq +89 -> 252
/*    */     //   166: aload_0
/*    */     //   167: getfield 43	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:unloadedProperties	Ljava/util/Map;
/*    */     //   170: aload 7
/*    */     //   172: invokeinterface 125 2 0
/*    */     //   177: checkcast 7	org/apache/ibatis/executor/loader/ResultLoaderMap$LoadPair
/*    */     //   180: astore 8
/*    */     //   182: aload 8
/*    */     //   184: ifnull +35 -> 219
/*    */     //   187: aload_0
/*    */     //   188: iconst_1
/*    */     //   189: putfield 53	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:reloadingProperty	Z
/*    */     //   192: aload 8
/*    */     //   194: aload_1
/*    */     //   195: invokevirtual 129	org/apache/ibatis/executor/loader/ResultLoaderMap$LoadPair:load	(Ljava/lang/Object;)V
/*    */     //   198: aload_0
/*    */     //   199: iconst_0
/*    */     //   200: putfield 53	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:reloadingProperty	Z
/*    */     //   203: goto +13 -> 216
/*    */     //   206: astore 9
/*    */     //   208: aload_0
/*    */     //   209: iconst_0
/*    */     //   210: putfield 53	org/apache/ibatis/executor/loader/AbstractEnhancedDeserializationProxy:reloadingProperty	Z
/*    */     //   213: aload 9
/*    */     //   215: athrow
/*    */     //   216: goto +36 -> 252
/*    */     //   219: new 133	org/apache/ibatis/executor/ExecutorException
/*    */     //   222: dup
/*    */     //   223: new 135	java/lang/StringBuilder
/*    */     //   226: dup
/*    */     //   227: invokespecial 136	java/lang/StringBuilder:<init>	()V
/*    */     //   230: ldc -118
/*    */     //   232: invokevirtual 142	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   235: aload 6
/*    */     //   237: invokevirtual 142	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   240: ldc -112
/*    */     //   242: invokevirtual 142	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   245: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*    */     //   248: invokespecial 150	org/apache/ibatis/executor/ExecutorException:<init>	(Ljava/lang/String;)V
/*    */     //   251: athrow
/*    */     //   252: aload_1
/*    */     //   253: aload 5
/*    */     //   255: monitorexit
/*    */     //   256: areturn
/*    */     //   257: astore 10
/*    */     //   259: aload 5
/*    */     //   261: monitorexit
/*    */     //   262: aload 10
/*    */     //   264: athrow
/*    */     //   265: astore 5
/*    */     //   267: aload 5
/*    */     //   269: invokestatic 156	org/apache/ibatis/reflection/ExceptionUtil:unwrapThrowable	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
/*    */     //   272: athrow
/*    */     // Line number table:
/*    */     //   Java source line #56	-> byte code offset #0
/*    */     //   Java source line #58	-> byte code offset #6
/*    */     //   Java source line #60	-> byte code offset #16
/*    */     //   Java source line #61	-> byte code offset #28
/*    */     //   Java source line #63	-> byte code offset #46
/*    */     //   Java source line #66	-> byte code offset #69
/*    */     //   Java source line #67	-> byte code offset #79
/*    */     //   Java source line #69	-> byte code offset #102
/*    */     //   Java source line #70	-> byte code offset #110
/*    */     //   Java source line #71	-> byte code offset #135
/*    */     //   Java source line #72	-> byte code offset #142
/*    */     //   Java source line #73	-> byte code offset #152
/*    */     //   Java source line #74	-> byte code offset #166
/*    */     //   Java source line #75	-> byte code offset #182
/*    */     //   Java source line #77	-> byte code offset #187
/*    */     //   Java source line #78	-> byte code offset #192
/*    */     //   Java source line #80	-> byte code offset #198
/*    */     //   Java source line #81	-> byte code offset #203
/*    */     //   Java source line #80	-> byte code offset #206
/*    */     //   Java source line #85	-> byte code offset #219
/*    */     //   Java source line #91	-> byte code offset #252
/*    */     //   Java source line #92	-> byte code offset #257
/*    */     //   Java source line #94	-> byte code offset #265
/*    */     //   Java source line #95	-> byte code offset #267
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	273	0	this	AbstractEnhancedDeserializationProxy
/*    */     //   0	273	1	enhanced	Object
/*    */     //   0	273	2	method	java.lang.reflect.Method
/*    */     //   0	273	3	args	Object[]
/*    */     //   4	132	4	methodName	String
/*    */     //   41	3	5	original	Object
/*    */     //   67	14	5	original	Object
/*    */     //   265	3	5	t	Throwable
/*    */     //   140	96	6	property	String
/*    */     //   150	21	7	propertyKey	String
/*    */     //   180	13	8	loadPair	ResultLoaderMap.LoadPair
/*    */     //   206	8	9	localObject1	Object
/*    */     //   257	6	10	localObject2	Object
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   187	198	206	finally
/*    */     //   206	208	206	finally
/*    */     //   110	256	257	finally
/*    */     //   257	262	257	finally
/*    */     //   6	101	265	java/lang/Throwable
/*    */     //   102	256	265	java/lang/Throwable
/*    */     //   257	265	265	java/lang/Throwable
/*    */   }
/*    */   
/*    */   protected abstract AbstractSerialStateHolder newSerialStateHolder(Object paramObject, Map<String, ResultLoaderMap.LoadPair> paramMap, ObjectFactory paramObjectFactory, List<Class<?>> paramList, List<Object> paramList1);
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\loader\AbstractEnhancedDeserializationProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */