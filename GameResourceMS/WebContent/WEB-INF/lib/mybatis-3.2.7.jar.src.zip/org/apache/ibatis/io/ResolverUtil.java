/*     */ package org.apache.ibatis.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.ibatis.logging.Log;
/*     */ import org.apache.ibatis.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResolverUtil<T>
/*     */ {
/*  63 */   private static final Log log = LogFactory.getLog(ResolverUtil.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static abstract interface Test
/*     */   {
/*     */     public abstract boolean matches(Class<?> paramClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class IsA
/*     */     implements ResolverUtil.Test
/*     */   {
/*     */     private Class<?> parent;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public IsA(Class<?> parentType)
/*     */     {
/*  86 */       this.parent = parentType;
/*     */     }
/*     */     
/*     */     public boolean matches(Class<?> type)
/*     */     {
/*  91 */       return (type != null) && (this.parent.isAssignableFrom(type));
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/*  96 */       return "is assignable to " + this.parent.getSimpleName();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class AnnotatedWith
/*     */     implements ResolverUtil.Test
/*     */   {
/*     */     private Class<? extends Annotation> annotation;
/*     */     
/*     */ 
/*     */     public AnnotatedWith(Class<? extends Annotation> annotation)
/*     */     {
/* 109 */       this.annotation = annotation;
/*     */     }
/*     */     
/*     */     public boolean matches(Class<?> type)
/*     */     {
/* 114 */       return (type != null) && (type.isAnnotationPresent(this.annotation));
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 119 */       return "annotated with @" + this.annotation.getSimpleName();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 124 */   private Set<Class<? extends T>> matches = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ClassLoader classloader;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<Class<? extends T>> getClasses()
/*     */   {
/* 139 */     return this.matches;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassLoader getClassLoader()
/*     */   {
/* 149 */     return this.classloader == null ? Thread.currentThread().getContextClassLoader() : this.classloader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setClassLoader(ClassLoader classloader)
/*     */   {
/* 159 */     this.classloader = classloader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResolverUtil<T> findImplementations(Class<?> parent, String... packageNames)
/*     */   {
/* 172 */     if (packageNames == null) {
/* 173 */       return this;
/*     */     }
/* 175 */     Test test = new IsA(parent);
/* 176 */     for (String pkg : packageNames) {
/* 177 */       find(test, pkg);
/*     */     }
/*     */     
/* 180 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResolverUtil<T> findAnnotated(Class<? extends Annotation> annotation, String... packageNames)
/*     */   {
/* 191 */     if (packageNames == null) {
/* 192 */       return this;
/*     */     }
/* 194 */     Test test = new AnnotatedWith(annotation);
/* 195 */     for (String pkg : packageNames) {
/* 196 */       find(test, pkg);
/*     */     }
/*     */     
/* 199 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResolverUtil<T> find(Test test, String packageName)
/*     */   {
/* 213 */     String path = getPackagePath(packageName);
/*     */     try
/*     */     {
/* 216 */       List<String> children = VFS.getInstance().list(path);
/* 217 */       for (String child : children) {
/* 218 */         if (child.endsWith(".class"))
/* 219 */           addIfMatching(test, child);
/*     */       }
/*     */     } catch (IOException ioe) {
/* 222 */       log.error("Could not read package: " + packageName, ioe);
/*     */     }
/*     */     
/* 225 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getPackagePath(String packageName)
/*     */   {
/* 235 */     return packageName == null ? null : packageName.replace('.', '/');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addIfMatching(Test test, String fqn)
/*     */   {
/*     */     try
/*     */     {
/* 248 */       String externalName = fqn.substring(0, fqn.indexOf('.')).replace('/', '.');
/* 249 */       ClassLoader loader = getClassLoader();
/* 250 */       log.debug("Checking to see if class " + externalName + " matches criteria [" + test + "]");
/*     */       
/* 252 */       Class<?> type = loader.loadClass(externalName);
/* 253 */       if (test.matches(type)) {
/* 254 */         this.matches.add(type);
/*     */       }
/*     */     } catch (Throwable t) {
/* 257 */       log.warn("Could not examine class '" + fqn + "'" + " due to a " + t.getClass().getName() + " with message: " + t.getMessage());
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\io\ResolverUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */