/*     */ package org.apache.ibatis.binding;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.ibatis.annotations.MapKey;
/*     */ import org.apache.ibatis.annotations.Param;
/*     */ import org.apache.ibatis.mapping.MappedStatement;
/*     */ import org.apache.ibatis.mapping.ResultMap;
/*     */ import org.apache.ibatis.mapping.SqlCommandType;
/*     */ import org.apache.ibatis.reflection.MetaObject;
/*     */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.session.ResultHandler;
/*     */ import org.apache.ibatis.session.RowBounds;
/*     */ import org.apache.ibatis.session.SqlSession;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapperMethod
/*     */ {
/*     */   private final SqlCommand command;
/*     */   private final MethodSignature method;
/*     */   
/*     */   public MapperMethod(Class<?> mapperInterface, Method method, Configuration config)
/*     */   {
/*  43 */     this.command = new SqlCommand(config, mapperInterface, method);
/*  44 */     this.method = new MethodSignature(config, method);
/*     */   }
/*     */   
/*     */   public Object execute(SqlSession sqlSession, Object[] args) {
/*     */     Object result;
/*  49 */     if (SqlCommandType.INSERT == this.command.getType()) {
/*  50 */       Object param = this.method.convertArgsToSqlCommandParam(args);
/*  51 */       result = rowCountResult(sqlSession.insert(this.command.getName(), param)); } else { Object result;
/*  52 */       if (SqlCommandType.UPDATE == this.command.getType()) {
/*  53 */         Object param = this.method.convertArgsToSqlCommandParam(args);
/*  54 */         result = rowCountResult(sqlSession.update(this.command.getName(), param)); } else { Object result;
/*  55 */         if (SqlCommandType.DELETE == this.command.getType()) {
/*  56 */           Object param = this.method.convertArgsToSqlCommandParam(args);
/*  57 */           result = rowCountResult(sqlSession.delete(this.command.getName(), param)); } else { Object result;
/*  58 */           if (SqlCommandType.SELECT == this.command.getType()) { Object result;
/*  59 */             if ((this.method.returnsVoid()) && (this.method.hasResultHandler())) {
/*  60 */               executeWithResultHandler(sqlSession, args);
/*  61 */               result = null; } else { Object result;
/*  62 */               if (this.method.returnsMany()) {
/*  63 */                 result = executeForMany(sqlSession, args); } else { Object result;
/*  64 */                 if (this.method.returnsMap()) {
/*  65 */                   result = executeForMap(sqlSession, args);
/*     */                 } else {
/*  67 */                   Object param = this.method.convertArgsToSqlCommandParam(args);
/*  68 */                   result = sqlSession.selectOne(this.command.getName(), param);
/*     */                 }
/*     */               }
/*  71 */             } } else { throw new BindingException("Unknown execution method for: " + this.command.getName()); } } } }
/*     */     Object result;
/*  73 */     if ((result == null) && (this.method.getReturnType().isPrimitive()) && (!this.method.returnsVoid())) {
/*  74 */       throw new BindingException("Mapper method '" + this.command.getName() + " attempted to return null from a method with a primitive return type (" + this.method.getReturnType() + ").");
/*     */     }
/*     */     
/*  77 */     return result;
/*     */   }
/*     */   
/*     */   private Object rowCountResult(int rowCount) {
/*     */     Object result;
/*  82 */     if (this.method.returnsVoid()) {
/*  83 */       result = null; } else { Object result;
/*  84 */       if ((Integer.class.equals(this.method.getReturnType())) || (Integer.TYPE.equals(this.method.getReturnType()))) {
/*  85 */         result = Integer.valueOf(rowCount); } else { Object result;
/*  86 */         if ((Long.class.equals(this.method.getReturnType())) || (Long.TYPE.equals(this.method.getReturnType()))) {
/*  87 */           result = Long.valueOf(rowCount); } else { Object result;
/*  88 */           if ((Boolean.class.equals(this.method.getReturnType())) || (Boolean.TYPE.equals(this.method.getReturnType()))) {
/*  89 */             result = Boolean.valueOf(rowCount > 0);
/*     */           } else
/*  91 */             throw new BindingException("Mapper method '" + this.command.getName() + "' has an unsupported return type: " + this.method.getReturnType()); } } }
/*     */     Object result;
/*  93 */     return result;
/*     */   }
/*     */   
/*     */   private void executeWithResultHandler(SqlSession sqlSession, Object[] args) {
/*  97 */     MappedStatement ms = sqlSession.getConfiguration().getMappedStatement(this.command.getName());
/*  98 */     if (Void.TYPE.equals(((ResultMap)ms.getResultMaps().get(0)).getType())) {
/*  99 */       throw new BindingException("method " + this.command.getName() + " needs either a @ResultMap annotation, a @ResultType annotation," + " or a resultType attribute in XML so a ResultHandler can be used as a parameter.");
/*     */     }
/*     */     
/*     */ 
/* 103 */     Object param = this.method.convertArgsToSqlCommandParam(args);
/* 104 */     if (this.method.hasRowBounds()) {
/* 105 */       RowBounds rowBounds = this.method.extractRowBounds(args);
/* 106 */       sqlSession.select(this.command.getName(), param, rowBounds, this.method.extractResultHandler(args));
/*     */     } else {
/* 108 */       sqlSession.select(this.command.getName(), param, this.method.extractResultHandler(args));
/*     */     }
/*     */   }
/*     */   
/*     */   private <E> Object executeForMany(SqlSession sqlSession, Object[] args)
/*     */   {
/* 114 */     Object param = this.method.convertArgsToSqlCommandParam(args);
/* 115 */     List<E> result; List<E> result; if (this.method.hasRowBounds()) {
/* 116 */       RowBounds rowBounds = this.method.extractRowBounds(args);
/* 117 */       result = sqlSession.selectList(this.command.getName(), param, rowBounds);
/*     */     } else {
/* 119 */       result = sqlSession.selectList(this.command.getName(), param);
/*     */     }
/*     */     
/* 122 */     if (!this.method.getReturnType().isAssignableFrom(result.getClass())) {
/* 123 */       if (this.method.getReturnType().isArray()) {
/* 124 */         return convertToArray(result);
/*     */       }
/* 126 */       return convertToDeclaredCollection(sqlSession.getConfiguration(), result);
/*     */     }
/*     */     
/* 129 */     return result;
/*     */   }
/*     */   
/*     */   private <E> Object convertToDeclaredCollection(Configuration config, List<E> list) {
/* 133 */     Object collection = config.getObjectFactory().create(this.method.getReturnType());
/* 134 */     MetaObject metaObject = config.newMetaObject(collection);
/* 135 */     metaObject.addAll(list);
/* 136 */     return collection;
/*     */   }
/*     */   
/*     */   private <E> E[] convertToArray(List<E> list)
/*     */   {
/* 141 */     E[] array = (Object[])Array.newInstance(this.method.getReturnType().getComponentType(), list.size());
/* 142 */     array = list.toArray(array);
/* 143 */     return array;
/*     */   }
/*     */   
/*     */   private <K, V> Map<K, V> executeForMap(SqlSession sqlSession, Object[] args)
/*     */   {
/* 148 */     Object param = this.method.convertArgsToSqlCommandParam(args);
/* 149 */     Map<K, V> result; Map<K, V> result; if (this.method.hasRowBounds()) {
/* 150 */       RowBounds rowBounds = this.method.extractRowBounds(args);
/* 151 */       result = sqlSession.selectMap(this.command.getName(), param, this.method.getMapKey(), rowBounds);
/*     */     } else {
/* 153 */       result = sqlSession.selectMap(this.command.getName(), param, this.method.getMapKey());
/*     */     }
/* 155 */     return result;
/*     */   }
/*     */   
/*     */   public static class ParamMap<V> extends HashMap<String, V>
/*     */   {
/*     */     private static final long serialVersionUID = -2212268410512043556L;
/*     */     
/*     */     public V get(Object key)
/*     */     {
/* 164 */       if (!super.containsKey(key)) {
/* 165 */         throw new BindingException("Parameter '" + key + "' not found. Available parameters are " + keySet());
/*     */       }
/* 167 */       return (V)super.get(key);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class SqlCommand
/*     */   {
/*     */     private final String name;
/*     */     private final SqlCommandType type;
/*     */     
/*     */     public SqlCommand(Configuration configuration, Class<?> mapperInterface, Method method) throws BindingException
/*     */     {
/* 178 */       String statementName = mapperInterface.getName() + "." + method.getName();
/* 179 */       MappedStatement ms = null;
/* 180 */       if (configuration.hasStatement(statementName)) {
/* 181 */         ms = configuration.getMappedStatement(statementName);
/* 182 */       } else if (!mapperInterface.equals(method.getDeclaringClass().getName())) {
/* 183 */         String parentStatementName = method.getDeclaringClass().getName() + "." + method.getName();
/* 184 */         if (configuration.hasStatement(parentStatementName)) {
/* 185 */           ms = configuration.getMappedStatement(parentStatementName);
/*     */         }
/*     */       }
/* 188 */       if (ms == null) {
/* 189 */         throw new BindingException("Invalid bound statement (not found): " + statementName);
/*     */       }
/* 191 */       this.name = ms.getId();
/* 192 */       this.type = ms.getSqlCommandType();
/* 193 */       if (this.type == SqlCommandType.UNKNOWN) {
/* 194 */         throw new BindingException("Unknown execution method for: " + this.name);
/*     */       }
/*     */     }
/*     */     
/*     */     public String getName() {
/* 199 */       return this.name;
/*     */     }
/*     */     
/*     */     public SqlCommandType getType() {
/* 203 */       return this.type;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class MethodSignature
/*     */   {
/*     */     private final boolean returnsMany;
/*     */     private final boolean returnsMap;
/*     */     private final boolean returnsVoid;
/*     */     private final Class<?> returnType;
/*     */     private final String mapKey;
/*     */     private final Integer resultHandlerIndex;
/*     */     private final Integer rowBoundsIndex;
/*     */     private final SortedMap<Integer, String> params;
/*     */     private final boolean hasNamedParameters;
/*     */     
/*     */     public MethodSignature(Configuration configuration, Method method) throws BindingException {
/* 220 */       this.returnType = method.getReturnType();
/* 221 */       this.returnsVoid = Void.TYPE.equals(this.returnType);
/* 222 */       this.returnsMany = ((configuration.getObjectFactory().isCollection(this.returnType)) || (this.returnType.isArray()));
/* 223 */       this.mapKey = getMapKey(method);
/* 224 */       this.returnsMap = (this.mapKey != null);
/* 225 */       this.hasNamedParameters = hasNamedParams(method);
/* 226 */       this.rowBoundsIndex = getUniqueParamIndex(method, RowBounds.class);
/* 227 */       this.resultHandlerIndex = getUniqueParamIndex(method, ResultHandler.class);
/* 228 */       this.params = Collections.unmodifiableSortedMap(getParams(method, this.hasNamedParameters));
/*     */     }
/*     */     
/*     */     public Object convertArgsToSqlCommandParam(Object[] args) {
/* 232 */       int paramCount = this.params.size();
/* 233 */       if ((args == null) || (paramCount == 0))
/* 234 */         return null;
/* 235 */       if ((!this.hasNamedParameters) && (paramCount == 1)) {
/* 236 */         return args[((Integer)this.params.keySet().iterator().next()).intValue()];
/*     */       }
/* 238 */       Map<String, Object> param = new MapperMethod.ParamMap();
/* 239 */       int i = 0;
/* 240 */       for (Map.Entry<Integer, String> entry : this.params.entrySet()) {
/* 241 */         param.put(entry.getValue(), args[((Integer)entry.getKey()).intValue()]);
/*     */         
/* 243 */         String genericParamName = "param" + String.valueOf(i + 1);
/* 244 */         if (!param.containsKey(genericParamName)) {
/* 245 */           param.put(genericParamName, args[((Integer)entry.getKey()).intValue()]);
/*     */         }
/* 247 */         i++;
/*     */       }
/* 249 */       return param;
/*     */     }
/*     */     
/*     */     public boolean hasRowBounds()
/*     */     {
/* 254 */       return this.rowBoundsIndex != null;
/*     */     }
/*     */     
/*     */     public RowBounds extractRowBounds(Object[] args) {
/* 258 */       return hasRowBounds() ? (RowBounds)args[this.rowBoundsIndex.intValue()] : null;
/*     */     }
/*     */     
/*     */     public boolean hasResultHandler() {
/* 262 */       return this.resultHandlerIndex != null;
/*     */     }
/*     */     
/*     */     public ResultHandler extractResultHandler(Object[] args) {
/* 266 */       return hasResultHandler() ? (ResultHandler)args[this.resultHandlerIndex.intValue()] : null;
/*     */     }
/*     */     
/*     */     public String getMapKey() {
/* 270 */       return this.mapKey;
/*     */     }
/*     */     
/*     */     public Class<?> getReturnType() {
/* 274 */       return this.returnType;
/*     */     }
/*     */     
/*     */     public boolean returnsMany() {
/* 278 */       return this.returnsMany;
/*     */     }
/*     */     
/*     */     public boolean returnsMap() {
/* 282 */       return this.returnsMap;
/*     */     }
/*     */     
/*     */     public boolean returnsVoid() {
/* 286 */       return this.returnsVoid;
/*     */     }
/*     */     
/*     */     private Integer getUniqueParamIndex(Method method, Class<?> paramType) {
/* 290 */       Integer index = null;
/* 291 */       Class<?>[] argTypes = method.getParameterTypes();
/* 292 */       for (int i = 0; i < argTypes.length; i++) {
/* 293 */         if (paramType.isAssignableFrom(argTypes[i])) {
/* 294 */           if (index == null) {
/* 295 */             index = Integer.valueOf(i);
/*     */           } else {
/* 297 */             throw new BindingException(method.getName() + " cannot have multiple " + paramType.getSimpleName() + " parameters");
/*     */           }
/*     */         }
/*     */       }
/* 301 */       return index;
/*     */     }
/*     */     
/*     */     private String getMapKey(Method method) {
/* 305 */       String mapKey = null;
/* 306 */       if (Map.class.isAssignableFrom(method.getReturnType())) {
/* 307 */         MapKey mapKeyAnnotation = (MapKey)method.getAnnotation(MapKey.class);
/* 308 */         if (mapKeyAnnotation != null) {
/* 309 */           mapKey = mapKeyAnnotation.value();
/*     */         }
/*     */       }
/* 312 */       return mapKey;
/*     */     }
/*     */     
/*     */     private SortedMap<Integer, String> getParams(Method method, boolean hasNamedParameters) {
/* 316 */       SortedMap<Integer, String> params = new TreeMap();
/* 317 */       Class<?>[] argTypes = method.getParameterTypes();
/* 318 */       for (int i = 0; i < argTypes.length; i++) {
/* 319 */         if ((!RowBounds.class.isAssignableFrom(argTypes[i])) && (!ResultHandler.class.isAssignableFrom(argTypes[i]))) {
/* 320 */           String paramName = String.valueOf(params.size());
/* 321 */           if (hasNamedParameters) {
/* 322 */             paramName = getParamNameFromAnnotation(method, i, paramName);
/*     */           }
/* 324 */           params.put(Integer.valueOf(i), paramName);
/*     */         }
/*     */       }
/* 327 */       return params;
/*     */     }
/*     */     
/*     */     private String getParamNameFromAnnotation(Method method, int i, String paramName) {
/* 331 */       Object[] paramAnnos = method.getParameterAnnotations()[i];
/* 332 */       for (Object paramAnno : paramAnnos) {
/* 333 */         if ((paramAnno instanceof Param)) {
/* 334 */           paramName = ((Param)paramAnno).value();
/*     */         }
/*     */       }
/* 337 */       return paramName;
/*     */     }
/*     */     
/*     */     private boolean hasNamedParams(Method method) {
/* 341 */       boolean hasNamedParams = false;
/* 342 */       Object[][] paramAnnos = method.getParameterAnnotations();
/* 343 */       for (Object[] paramAnno : paramAnnos) {
/* 344 */         for (Object aParamAnno : paramAnno) {
/* 345 */           if ((aParamAnno instanceof Param)) {
/* 346 */             hasNamedParams = true;
/* 347 */             break;
/*     */           }
/*     */         }
/*     */       }
/* 351 */       return hasNamedParams;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\binding\MapperMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */