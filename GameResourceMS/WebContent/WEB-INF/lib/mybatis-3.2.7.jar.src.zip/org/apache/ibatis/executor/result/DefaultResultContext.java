/*    */ package org.apache.ibatis.executor.result;
/*    */ 
/*    */ import org.apache.ibatis.session.ResultContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultResultContext
/*    */   implements ResultContext
/*    */ {
/*    */   private Object resultObject;
/*    */   private int resultCount;
/*    */   private boolean stopped;
/*    */   
/*    */   public DefaultResultContext()
/*    */   {
/* 30 */     this.resultObject = null;
/* 31 */     this.resultCount = 0;
/* 32 */     this.stopped = false;
/*    */   }
/*    */   
/*    */   public Object getResultObject() {
/* 36 */     return this.resultObject;
/*    */   }
/*    */   
/*    */   public int getResultCount() {
/* 40 */     return this.resultCount;
/*    */   }
/*    */   
/*    */   public boolean isStopped() {
/* 44 */     return this.stopped;
/*    */   }
/*    */   
/*    */   public void nextResultObject(Object resultObject) {
/* 48 */     this.resultCount += 1;
/* 49 */     this.resultObject = resultObject;
/*    */   }
/*    */   
/*    */   public void stop() {
/* 53 */     this.stopped = true;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\result\DefaultResultContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */