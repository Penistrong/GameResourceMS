package org.apache.ibatis.session;

import java.io.Closeable;
import java.sql.Connection;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.executor.BatchResult;

public abstract interface SqlSession
  extends Closeable
{
  public abstract <T> T selectOne(String paramString);
  
  public abstract <T> T selectOne(String paramString, Object paramObject);
  
  public abstract <E> List<E> selectList(String paramString);
  
  public abstract <E> List<E> selectList(String paramString, Object paramObject);
  
  public abstract <E> List<E> selectList(String paramString, Object paramObject, RowBounds paramRowBounds);
  
  public abstract <K, V> Map<K, V> selectMap(String paramString1, String paramString2);
  
  public abstract <K, V> Map<K, V> selectMap(String paramString1, Object paramObject, String paramString2);
  
  public abstract <K, V> Map<K, V> selectMap(String paramString1, Object paramObject, String paramString2, RowBounds paramRowBounds);
  
  public abstract void select(String paramString, Object paramObject, ResultHandler paramResultHandler);
  
  public abstract void select(String paramString, ResultHandler paramResultHandler);
  
  public abstract void select(String paramString, Object paramObject, RowBounds paramRowBounds, ResultHandler paramResultHandler);
  
  public abstract int insert(String paramString);
  
  public abstract int insert(String paramString, Object paramObject);
  
  public abstract int update(String paramString);
  
  public abstract int update(String paramString, Object paramObject);
  
  public abstract int delete(String paramString);
  
  public abstract int delete(String paramString, Object paramObject);
  
  public abstract void commit();
  
  public abstract void commit(boolean paramBoolean);
  
  public abstract void rollback();
  
  public abstract void rollback(boolean paramBoolean);
  
  public abstract List<BatchResult> flushStatements();
  
  public abstract void close();
  
  public abstract void clearCache();
  
  public abstract Configuration getConfiguration();
  
  public abstract <T> T getMapper(Class<T> paramClass);
  
  public abstract Connection getConnection();
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\session\SqlSession.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */