/*    */ package org.apache.ibatis.executor.statement;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import java.util.List;
/*    */ import org.apache.ibatis.executor.Executor;
/*    */ import org.apache.ibatis.executor.keygen.Jdbc3KeyGenerator;
/*    */ import org.apache.ibatis.executor.keygen.KeyGenerator;
/*    */ import org.apache.ibatis.executor.keygen.SelectKeyGenerator;
/*    */ import org.apache.ibatis.executor.resultset.ResultSetHandler;
/*    */ import org.apache.ibatis.mapping.BoundSql;
/*    */ import org.apache.ibatis.mapping.MappedStatement;
/*    */ import org.apache.ibatis.mapping.ResultSetType;
/*    */ import org.apache.ibatis.session.ResultHandler;
/*    */ import org.apache.ibatis.session.RowBounds;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleStatementHandler
/*    */   extends BaseStatementHandler
/*    */ {
/*    */   public SimpleStatementHandler(Executor executor, MappedStatement mappedStatement, Object parameter, RowBounds rowBounds, ResultHandler resultHandler, BoundSql boundSql)
/*    */   {
/* 39 */     super(executor, mappedStatement, parameter, rowBounds, resultHandler, boundSql);
/*    */   }
/*    */   
/*    */   public int update(Statement statement) throws SQLException
/*    */   {
/* 44 */     String sql = this.boundSql.getSql();
/* 45 */     Object parameterObject = this.boundSql.getParameterObject();
/* 46 */     KeyGenerator keyGenerator = this.mappedStatement.getKeyGenerator();
/*    */     int rows;
/* 48 */     if ((keyGenerator instanceof Jdbc3KeyGenerator)) {
/* 49 */       statement.execute(sql, 1);
/* 50 */       int rows = statement.getUpdateCount();
/* 51 */       keyGenerator.processAfter(this.executor, this.mappedStatement, statement, parameterObject);
/* 52 */     } else if ((keyGenerator instanceof SelectKeyGenerator)) {
/* 53 */       statement.execute(sql);
/* 54 */       int rows = statement.getUpdateCount();
/* 55 */       keyGenerator.processAfter(this.executor, this.mappedStatement, statement, parameterObject);
/*    */     } else {
/* 57 */       statement.execute(sql);
/* 58 */       rows = statement.getUpdateCount();
/*    */     }
/* 60 */     return rows;
/*    */   }
/*    */   
/*    */   public void batch(Statement statement) throws SQLException
/*    */   {
/* 65 */     String sql = this.boundSql.getSql();
/* 66 */     statement.addBatch(sql);
/*    */   }
/*    */   
/*    */   public <E> List<E> query(Statement statement, ResultHandler resultHandler) throws SQLException
/*    */   {
/* 71 */     String sql = this.boundSql.getSql();
/* 72 */     statement.execute(sql);
/* 73 */     return this.resultSetHandler.handleResultSets(statement);
/*    */   }
/*    */   
/*    */   protected Statement instantiateStatement(Connection connection) throws SQLException {
/* 77 */     if (this.mappedStatement.getResultSetType() != null) {
/* 78 */       return connection.createStatement(this.mappedStatement.getResultSetType().getValue(), 1007);
/*    */     }
/* 80 */     return connection.createStatement();
/*    */   }
/*    */   
/*    */   public void parameterize(Statement statement)
/*    */     throws SQLException
/*    */   {}
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\statement\SimpleStatementHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */