/*    */ package org.apache.ibatis.scripting.defaults;
/*    */ 
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import java.util.List;
/*    */ import org.apache.ibatis.executor.ErrorContext;
/*    */ import org.apache.ibatis.executor.parameter.ParameterHandler;
/*    */ import org.apache.ibatis.mapping.BoundSql;
/*    */ import org.apache.ibatis.mapping.MappedStatement;
/*    */ import org.apache.ibatis.mapping.ParameterMap;
/*    */ import org.apache.ibatis.mapping.ParameterMapping;
/*    */ import org.apache.ibatis.mapping.ParameterMode;
/*    */ import org.apache.ibatis.reflection.MetaObject;
/*    */ import org.apache.ibatis.session.Configuration;
/*    */ import org.apache.ibatis.type.JdbcType;
/*    */ import org.apache.ibatis.type.TypeHandler;
/*    */ import org.apache.ibatis.type.TypeHandlerRegistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultParameterHandler
/*    */   implements ParameterHandler
/*    */ {
/*    */   private final TypeHandlerRegistry typeHandlerRegistry;
/*    */   private final MappedStatement mappedStatement;
/*    */   private final Object parameterObject;
/*    */   private BoundSql boundSql;
/*    */   private Configuration configuration;
/*    */   
/*    */   public DefaultParameterHandler(MappedStatement mappedStatement, Object parameterObject, BoundSql boundSql)
/*    */   {
/* 48 */     this.mappedStatement = mappedStatement;
/* 49 */     this.configuration = mappedStatement.getConfiguration();
/* 50 */     this.typeHandlerRegistry = mappedStatement.getConfiguration().getTypeHandlerRegistry();
/* 51 */     this.parameterObject = parameterObject;
/* 52 */     this.boundSql = boundSql;
/*    */   }
/*    */   
/*    */   public Object getParameterObject() {
/* 56 */     return this.parameterObject;
/*    */   }
/*    */   
/*    */   public void setParameters(PreparedStatement ps) throws SQLException {
/* 60 */     ErrorContext.instance().activity("setting parameters").object(this.mappedStatement.getParameterMap().getId());
/* 61 */     List<ParameterMapping> parameterMappings = this.boundSql.getParameterMappings();
/* 62 */     if (parameterMappings != null) {
/* 63 */       for (int i = 0; i < parameterMappings.size(); i++) {
/* 64 */         ParameterMapping parameterMapping = (ParameterMapping)parameterMappings.get(i);
/* 65 */         if (parameterMapping.getMode() != ParameterMode.OUT)
/*    */         {
/* 67 */           String propertyName = parameterMapping.getProperty();
/* 68 */           Object value; Object value; if (this.boundSql.hasAdditionalParameter(propertyName)) {
/* 69 */             value = this.boundSql.getAdditionalParameter(propertyName); } else { Object value;
/* 70 */             if (this.parameterObject == null) {
/* 71 */               value = null; } else { Object value;
/* 72 */               if (this.typeHandlerRegistry.hasTypeHandler(this.parameterObject.getClass())) {
/* 73 */                 value = this.parameterObject;
/*    */               } else {
/* 75 */                 MetaObject metaObject = this.configuration.newMetaObject(this.parameterObject);
/* 76 */                 value = metaObject.getValue(propertyName);
/*    */               } } }
/* 78 */           TypeHandler typeHandler = parameterMapping.getTypeHandler();
/* 79 */           JdbcType jdbcType = parameterMapping.getJdbcType();
/* 80 */           if ((value == null) && (jdbcType == null)) jdbcType = this.configuration.getJdbcTypeForNull();
/* 81 */           typeHandler.setParameter(ps, i + 1, value, jdbcType);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\defaults\DefaultParameterHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */