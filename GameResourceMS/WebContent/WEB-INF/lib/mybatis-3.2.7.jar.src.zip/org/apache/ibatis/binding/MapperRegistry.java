/*     */ package org.apache.ibatis.binding;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.ibatis.builder.annotation.MapperAnnotationBuilder;
/*     */ import org.apache.ibatis.io.ResolverUtil;
/*     */ import org.apache.ibatis.io.ResolverUtil.IsA;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.session.SqlSession;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapperRegistry
/*     */ {
/*     */   private Configuration config;
/*  37 */   private final Map<Class<?>, MapperProxyFactory<?>> knownMappers = new HashMap();
/*     */   
/*     */   public MapperRegistry(Configuration config) {
/*  40 */     this.config = config;
/*     */   }
/*     */   
/*     */   public <T> T getMapper(Class<T> type, SqlSession sqlSession)
/*     */   {
/*  45 */     MapperProxyFactory<T> mapperProxyFactory = (MapperProxyFactory)this.knownMappers.get(type);
/*  46 */     if (mapperProxyFactory == null)
/*  47 */       throw new BindingException("Type " + type + " is not known to the MapperRegistry.");
/*     */     try {
/*  49 */       return (T)mapperProxyFactory.newInstance(sqlSession);
/*     */     } catch (Exception e) {
/*  51 */       throw new BindingException("Error getting mapper instance. Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   public <T> boolean hasMapper(Class<T> type) {
/*  56 */     return this.knownMappers.containsKey(type);
/*     */   }
/*     */   
/*     */   public <T> void addMapper(Class<T> type) {
/*  60 */     if (type.isInterface()) {
/*  61 */       if (hasMapper(type)) {
/*  62 */         throw new BindingException("Type " + type + " is already known to the MapperRegistry.");
/*     */       }
/*  64 */       boolean loadCompleted = false;
/*     */       try {
/*  66 */         this.knownMappers.put(type, new MapperProxyFactory(type));
/*     */         
/*     */ 
/*     */ 
/*  70 */         MapperAnnotationBuilder parser = new MapperAnnotationBuilder(this.config, type);
/*  71 */         parser.parse();
/*  72 */         loadCompleted = true;
/*     */       } finally {
/*  74 */         if (!loadCompleted) {
/*  75 */           this.knownMappers.remove(type);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Collection<Class<?>> getMappers()
/*     */   {
/*  85 */     return Collections.unmodifiableCollection(this.knownMappers.keySet());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addMappers(String packageName, Class<?> superType)
/*     */   {
/*  92 */     ResolverUtil<Class<?>> resolverUtil = new ResolverUtil();
/*  93 */     resolverUtil.find(new ResolverUtil.IsA(superType), packageName);
/*  94 */     Set<Class<? extends Class<?>>> mapperSet = resolverUtil.getClasses();
/*  95 */     for (Class<?> mapperClass : mapperSet) {
/*  96 */       addMapper(mapperClass);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addMappers(String packageName)
/*     */   {
/* 104 */     addMappers(packageName, Object.class);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\binding\MapperRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */