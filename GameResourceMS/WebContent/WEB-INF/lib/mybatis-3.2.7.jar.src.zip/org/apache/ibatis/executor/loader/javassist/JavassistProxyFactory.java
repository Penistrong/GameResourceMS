/*     */ package org.apache.ibatis.executor.loader.javassist;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import javassist.util.proxy.MethodHandler;
/*     */ import javassist.util.proxy.Proxy;
/*     */ import org.apache.ibatis.executor.ExecutorException;
/*     */ import org.apache.ibatis.executor.loader.AbstractEnhancedDeserializationProxy;
/*     */ import org.apache.ibatis.executor.loader.AbstractSerialStateHolder;
/*     */ import org.apache.ibatis.executor.loader.ResultLoaderMap;
/*     */ import org.apache.ibatis.executor.loader.ResultLoaderMap.LoadPair;
/*     */ import org.apache.ibatis.executor.loader.WriteReplaceInterface;
/*     */ import org.apache.ibatis.io.Resources;
/*     */ import org.apache.ibatis.logging.Log;
/*     */ import org.apache.ibatis.logging.LogFactory;
/*     */ import org.apache.ibatis.reflection.ExceptionUtil;
/*     */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*     */ import org.apache.ibatis.reflection.property.PropertyCopier;
/*     */ import org.apache.ibatis.reflection.property.PropertyNamer;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavassistProxyFactory
/*     */   implements org.apache.ibatis.executor.loader.ProxyFactory
/*     */ {
/*  47 */   private static final Log log = LogFactory.getLog(JavassistProxyFactory.class);
/*     */   private static final String FINALIZE_METHOD = "finalize";
/*     */   private static final String WRITE_REPLACE_METHOD = "writeReplace";
/*     */   
/*     */   public JavassistProxyFactory() {
/*     */     try {
/*  53 */       Resources.classForName("javassist.util.proxy.ProxyFactory");
/*     */     } catch (Throwable e) {
/*  55 */       throw new IllegalStateException("Cannot enable lazy loading because Javassist is not available. Add Javassist to your classpath.", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object createProxy(Object target, ResultLoaderMap lazyLoader, Configuration configuration, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs) {
/*  60 */     return EnhancedResultObjectProxyImpl.createProxy(target, lazyLoader, configuration, objectFactory, constructorArgTypes, constructorArgs);
/*     */   }
/*     */   
/*     */   public Object createDeserializationProxy(Object target, Map<String, ResultLoaderMap.LoadPair> unloadedProperties, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs) {
/*  64 */     return EnhancedDeserializationProxyImpl.createProxy(target, unloadedProperties, objectFactory, constructorArgTypes, constructorArgs);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setProperties(Properties properties) {}
/*     */   
/*     */   private static Object crateProxy(Class<?> type, MethodHandler callback, List<Class<?>> constructorArgTypes, List<Object> constructorArgs)
/*     */   {
/*  72 */     javassist.util.proxy.ProxyFactory enhancer = new javassist.util.proxy.ProxyFactory();
/*  73 */     enhancer.setSuperclass(type);
/*     */     try
/*     */     {
/*  76 */       type.getDeclaredMethod("writeReplace", new Class[0]);
/*     */       
/*  78 */       log.debug("writeReplace method was found on bean " + type + ", make sure it returns this");
/*     */     } catch (NoSuchMethodException e) {
/*  80 */       enhancer.setInterfaces(new Class[] { WriteReplaceInterface.class });
/*     */     }
/*     */     catch (SecurityException e) {}
/*     */     
/*     */ 
/*  85 */     Object enhanced = null;
/*  86 */     Class<?>[] typesArray = (Class[])constructorArgTypes.toArray(new Class[constructorArgTypes.size()]);
/*  87 */     Object[] valuesArray = constructorArgs.toArray(new Object[constructorArgs.size()]);
/*     */     try {
/*  89 */       enhanced = enhancer.create(typesArray, valuesArray);
/*     */     } catch (Exception e) {
/*  91 */       throw new ExecutorException("Error creating lazy proxy.  Cause: " + e, e);
/*     */     }
/*  93 */     ((Proxy)enhanced).setHandler(callback);
/*  94 */     return enhanced;
/*     */   }
/*     */   
/*     */   private static class EnhancedResultObjectProxyImpl implements MethodHandler
/*     */   {
/*     */     private Class<?> type;
/*     */     private ResultLoaderMap lazyLoader;
/*     */     private boolean aggressive;
/*     */     private Set<String> lazyLoadTriggerMethods;
/*     */     private ObjectFactory objectFactory;
/*     */     private List<Class<?>> constructorArgTypes;
/*     */     private List<Object> constructorArgs;
/*     */     
/*     */     private EnhancedResultObjectProxyImpl(Class<?> type, ResultLoaderMap lazyLoader, Configuration configuration, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs) {
/* 108 */       this.type = type;
/* 109 */       this.lazyLoader = lazyLoader;
/* 110 */       this.aggressive = configuration.isAggressiveLazyLoading();
/* 111 */       this.lazyLoadTriggerMethods = configuration.getLazyLoadTriggerMethods();
/* 112 */       this.objectFactory = objectFactory;
/* 113 */       this.constructorArgTypes = constructorArgTypes;
/* 114 */       this.constructorArgs = constructorArgs;
/*     */     }
/*     */     
/*     */     public static Object createProxy(Object target, ResultLoaderMap lazyLoader, Configuration configuration, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs) {
/* 118 */       Class<?> type = target.getClass();
/* 119 */       EnhancedResultObjectProxyImpl callback = new EnhancedResultObjectProxyImpl(type, lazyLoader, configuration, objectFactory, constructorArgTypes, constructorArgs);
/* 120 */       Object enhanced = JavassistProxyFactory.crateProxy(type, callback, constructorArgTypes, constructorArgs);
/* 121 */       PropertyCopier.copyBeanProperties(type, target, enhanced);
/* 122 */       return enhanced;
/*     */     }
/*     */     
/*     */     public Object invoke(Object enhanced, Method method, Method methodProxy, Object[] args) throws Throwable {
/* 126 */       String methodName = method.getName();
/*     */       try {
/* 128 */         synchronized (this.lazyLoader) {
/* 129 */           if ("writeReplace".equals(methodName)) {
/* 130 */             Object original = null;
/* 131 */             if (this.constructorArgTypes.isEmpty()) {
/* 132 */               original = this.objectFactory.create(this.type);
/*     */             } else {
/* 134 */               original = this.objectFactory.create(this.type, this.constructorArgTypes, this.constructorArgs);
/*     */             }
/* 136 */             PropertyCopier.copyBeanProperties(this.type, enhanced, original);
/* 137 */             if (this.lazyLoader.size() > 0) {
/* 138 */               return new JavassistSerialStateHolder(original, this.lazyLoader.getProperties(), this.objectFactory, this.constructorArgTypes, this.constructorArgs);
/*     */             }
/* 140 */             return original;
/*     */           }
/*     */           
/* 143 */           if ((this.lazyLoader.size() > 0) && (!"finalize".equals(methodName))) {
/* 144 */             if ((this.aggressive) || (this.lazyLoadTriggerMethods.contains(methodName))) {
/* 145 */               this.lazyLoader.loadAll();
/* 146 */             } else if (PropertyNamer.isProperty(methodName)) {
/* 147 */               String property = PropertyNamer.methodToProperty(methodName);
/* 148 */               if (this.lazyLoader.hasLoader(property)) {
/* 149 */                 this.lazyLoader.load(property);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 155 */         return methodProxy.invoke(enhanced, args);
/*     */       } catch (Throwable t) {
/* 157 */         throw ExceptionUtil.unwrapThrowable(t);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class EnhancedDeserializationProxyImpl extends AbstractEnhancedDeserializationProxy implements MethodHandler
/*     */   {
/*     */     private EnhancedDeserializationProxyImpl(Class<?> type, Map<String, ResultLoaderMap.LoadPair> unloadedProperties, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs)
/*     */     {
/* 166 */       super(unloadedProperties, objectFactory, constructorArgTypes, constructorArgs);
/*     */     }
/*     */     
/*     */     public static Object createProxy(Object target, Map<String, ResultLoaderMap.LoadPair> unloadedProperties, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs)
/*     */     {
/* 171 */       Class<?> type = target.getClass();
/* 172 */       EnhancedDeserializationProxyImpl callback = new EnhancedDeserializationProxyImpl(type, unloadedProperties, objectFactory, constructorArgTypes, constructorArgs);
/* 173 */       Object enhanced = JavassistProxyFactory.crateProxy(type, callback, constructorArgTypes, constructorArgs);
/* 174 */       PropertyCopier.copyBeanProperties(type, target, enhanced);
/* 175 */       return enhanced;
/*     */     }
/*     */     
/*     */     public Object invoke(Object enhanced, Method method, Method methodProxy, Object[] args) throws Throwable
/*     */     {
/* 180 */       Object o = super.invoke(enhanced, method, args);
/* 181 */       return (o instanceof AbstractSerialStateHolder) ? o : methodProxy.invoke(o, args);
/*     */     }
/*     */     
/*     */ 
/*     */     protected AbstractSerialStateHolder newSerialStateHolder(Object userBean, Map<String, ResultLoaderMap.LoadPair> unloadedProperties, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs)
/*     */     {
/* 187 */       return new JavassistSerialStateHolder(userBean, unloadedProperties, objectFactory, constructorArgTypes, constructorArgs);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\loader\javassist\JavassistProxyFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */