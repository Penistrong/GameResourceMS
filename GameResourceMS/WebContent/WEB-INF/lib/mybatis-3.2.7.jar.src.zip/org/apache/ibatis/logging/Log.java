package org.apache.ibatis.logging;

public abstract interface Log
{
  public abstract boolean isDebugEnabled();
  
  public abstract boolean isTraceEnabled();
  
  public abstract void error(String paramString, Throwable paramThrowable);
  
  public abstract void error(String paramString);
  
  public abstract void debug(String paramString);
  
  public abstract void trace(String paramString);
  
  public abstract void warn(String paramString);
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\logging\Log.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */