/*     */ package org.apache.ibatis.reflection.wrapper;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.ibatis.reflection.MetaObject;
/*     */ import org.apache.ibatis.reflection.SystemMetaObject;
/*     */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*     */ import org.apache.ibatis.reflection.property.PropertyTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapWrapper
/*     */   extends BaseWrapper
/*     */ {
/*     */   private Map<String, Object> map;
/*     */   
/*     */   public MapWrapper(MetaObject metaObject, Map<String, Object> map)
/*     */   {
/*  35 */     super(metaObject);
/*  36 */     this.map = map;
/*     */   }
/*     */   
/*     */   public Object get(PropertyTokenizer prop) {
/*  40 */     if (prop.getIndex() != null) {
/*  41 */       Object collection = resolveCollection(prop, this.map);
/*  42 */       return getCollectionValue(prop, collection);
/*     */     }
/*  44 */     return this.map.get(prop.getName());
/*     */   }
/*     */   
/*     */   public void set(PropertyTokenizer prop, Object value)
/*     */   {
/*  49 */     if (prop.getIndex() != null) {
/*  50 */       Object collection = resolveCollection(prop, this.map);
/*  51 */       setCollectionValue(prop, collection, value);
/*     */     } else {
/*  53 */       this.map.put(prop.getName(), value);
/*     */     }
/*     */   }
/*     */   
/*     */   public String findProperty(String name, boolean useCamelCaseMapping) {
/*  58 */     return name;
/*     */   }
/*     */   
/*     */   public String[] getGetterNames() {
/*  62 */     return (String[])this.map.keySet().toArray(new String[this.map.keySet().size()]);
/*     */   }
/*     */   
/*     */   public String[] getSetterNames() {
/*  66 */     return (String[])this.map.keySet().toArray(new String[this.map.keySet().size()]);
/*     */   }
/*     */   
/*     */   public Class<?> getSetterType(String name) {
/*  70 */     PropertyTokenizer prop = new PropertyTokenizer(name);
/*  71 */     if (prop.hasNext()) {
/*  72 */       MetaObject metaValue = this.metaObject.metaObjectForProperty(prop.getIndexedName());
/*  73 */       if (metaValue == SystemMetaObject.NULL_META_OBJECT) {
/*  74 */         return Object.class;
/*     */       }
/*  76 */       return metaValue.getSetterType(prop.getChildren());
/*     */     }
/*     */     
/*  79 */     if (this.map.get(name) != null) {
/*  80 */       return this.map.get(name).getClass();
/*     */     }
/*  82 */     return Object.class;
/*     */   }
/*     */   
/*     */ 
/*     */   public Class<?> getGetterType(String name)
/*     */   {
/*  88 */     PropertyTokenizer prop = new PropertyTokenizer(name);
/*  89 */     if (prop.hasNext()) {
/*  90 */       MetaObject metaValue = this.metaObject.metaObjectForProperty(prop.getIndexedName());
/*  91 */       if (metaValue == SystemMetaObject.NULL_META_OBJECT) {
/*  92 */         return Object.class;
/*     */       }
/*  94 */       return metaValue.getGetterType(prop.getChildren());
/*     */     }
/*     */     
/*  97 */     if (this.map.get(name) != null) {
/*  98 */       return this.map.get(name).getClass();
/*     */     }
/* 100 */     return Object.class;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean hasSetter(String name)
/*     */   {
/* 106 */     return true;
/*     */   }
/*     */   
/*     */   public boolean hasGetter(String name) {
/* 110 */     PropertyTokenizer prop = new PropertyTokenizer(name);
/* 111 */     if (prop.hasNext()) {
/* 112 */       if (this.map.containsKey(prop.getIndexedName())) {
/* 113 */         MetaObject metaValue = this.metaObject.metaObjectForProperty(prop.getIndexedName());
/* 114 */         if (metaValue == SystemMetaObject.NULL_META_OBJECT) {
/* 115 */           return true;
/*     */         }
/* 117 */         return metaValue.hasGetter(prop.getChildren());
/*     */       }
/*     */       
/* 120 */       return false;
/*     */     }
/*     */     
/* 123 */     return this.map.containsKey(prop.getName());
/*     */   }
/*     */   
/*     */   public MetaObject instantiatePropertyValue(String name, PropertyTokenizer prop, ObjectFactory objectFactory)
/*     */   {
/* 128 */     HashMap<String, Object> map = new HashMap();
/* 129 */     set(prop, map);
/* 130 */     return MetaObject.forObject(map, this.metaObject.getObjectFactory(), this.metaObject.getObjectWrapperFactory());
/*     */   }
/*     */   
/*     */   public boolean isCollection() {
/* 134 */     return false;
/*     */   }
/*     */   
/*     */   public void add(Object element) {
/* 138 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public <E> void addAll(List<E> element) {
/* 142 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\wrapper\MapWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */