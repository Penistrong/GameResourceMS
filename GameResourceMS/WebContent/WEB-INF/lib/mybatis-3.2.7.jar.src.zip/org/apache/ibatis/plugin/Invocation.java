/*    */ package org.apache.ibatis.plugin;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Invocation
/*    */ {
/*    */   private Object target;
/*    */   private Method method;
/*    */   private Object[] args;
/*    */   
/*    */   public Invocation(Object target, Method method, Object[] args)
/*    */   {
/* 31 */     this.target = target;
/* 32 */     this.method = method;
/* 33 */     this.args = args;
/*    */   }
/*    */   
/*    */   public Object getTarget() {
/* 37 */     return this.target;
/*    */   }
/*    */   
/*    */   public Method getMethod() {
/* 41 */     return this.method;
/*    */   }
/*    */   
/*    */   public Object[] getArgs() {
/* 45 */     return this.args;
/*    */   }
/*    */   
/*    */   public Object proceed() throws InvocationTargetException, IllegalAccessException {
/* 49 */     return this.method.invoke(this.target, this.args);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\plugin\Invocation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */