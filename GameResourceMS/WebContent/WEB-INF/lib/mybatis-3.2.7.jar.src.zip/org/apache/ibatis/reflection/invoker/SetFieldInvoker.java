/*    */ package org.apache.ibatis.reflection.invoker;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetFieldInvoker
/*    */   implements Invoker
/*    */ {
/*    */   private Field field;
/*    */   
/*    */   public SetFieldInvoker(Field field)
/*    */   {
/* 28 */     this.field = field;
/*    */   }
/*    */   
/*    */   public Object invoke(Object target, Object[] args) throws IllegalAccessException, InvocationTargetException {
/* 32 */     this.field.set(target, args[0]);
/* 33 */     return null;
/*    */   }
/*    */   
/*    */   public Class<?> getType() {
/* 37 */     return this.field.getType();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\invoker\SetFieldInvoker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */