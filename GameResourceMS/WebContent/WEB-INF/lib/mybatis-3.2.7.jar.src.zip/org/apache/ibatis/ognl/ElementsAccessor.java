package org.apache.ibatis.ognl;

import java.util.Enumeration;

public abstract interface ElementsAccessor
{
  public abstract Enumeration getElements(Object paramObject)
    throws OgnlException;
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ElementsAccessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */