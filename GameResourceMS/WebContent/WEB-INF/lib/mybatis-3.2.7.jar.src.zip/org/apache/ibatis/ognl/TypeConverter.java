package org.apache.ibatis.ognl;

import java.lang.reflect.Member;
import java.util.Map;

public abstract interface TypeConverter
{
  public abstract Object convertValue(Map paramMap, Object paramObject1, Member paramMember, String paramString, Object paramObject2, Class paramClass);
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\TypeConverter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */