/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteTypeHandler
/*    */   extends BaseTypeHandler<Byte>
/*    */ {
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, Byte parameter, JdbcType jdbcType)
/*    */     throws SQLException
/*    */   {
/* 31 */     ps.setByte(i, parameter.byteValue());
/*    */   }
/*    */   
/*    */   public Byte getNullableResult(ResultSet rs, String columnName)
/*    */     throws SQLException
/*    */   {
/* 37 */     return Byte.valueOf(rs.getByte(columnName));
/*    */   }
/*    */   
/*    */   public Byte getNullableResult(ResultSet rs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 43 */     return Byte.valueOf(rs.getByte(columnIndex));
/*    */   }
/*    */   
/*    */   public Byte getNullableResult(CallableStatement cs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 49 */     return Byte.valueOf(cs.getByte(columnIndex));
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\ByteTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */