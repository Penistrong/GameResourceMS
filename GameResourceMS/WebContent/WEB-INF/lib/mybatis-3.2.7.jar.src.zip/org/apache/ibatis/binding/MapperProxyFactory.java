/*    */ package org.apache.ibatis.binding;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Proxy;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import org.apache.ibatis.session.SqlSession;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MapperProxyFactory<T>
/*    */ {
/*    */   private final Class<T> mapperInterface;
/* 31 */   private Map<Method, MapperMethod> methodCache = new ConcurrentHashMap();
/*    */   
/*    */   public MapperProxyFactory(Class<T> mapperInterface) {
/* 34 */     this.mapperInterface = mapperInterface;
/*    */   }
/*    */   
/*    */   public Class<T> getMapperInterface() {
/* 38 */     return this.mapperInterface;
/*    */   }
/*    */   
/*    */   public Map<Method, MapperMethod> getMethodCache() {
/* 42 */     return this.methodCache;
/*    */   }
/*    */   
/*    */   protected T newInstance(MapperProxy<T> mapperProxy)
/*    */   {
/* 47 */     return (T)Proxy.newProxyInstance(this.mapperInterface.getClassLoader(), new Class[] { this.mapperInterface }, mapperProxy);
/*    */   }
/*    */   
/*    */   public T newInstance(SqlSession sqlSession) {
/* 51 */     MapperProxy<T> mapperProxy = new MapperProxy(sqlSession, this.mapperInterface, this.methodCache);
/* 52 */     return (T)newInstance(mapperProxy);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\binding\MapperProxyFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */