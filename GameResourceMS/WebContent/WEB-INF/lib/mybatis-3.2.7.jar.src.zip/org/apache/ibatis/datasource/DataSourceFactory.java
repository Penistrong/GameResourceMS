package org.apache.ibatis.datasource;

import java.util.Properties;
import javax.sql.DataSource;

public abstract interface DataSourceFactory
{
  public abstract void setProperties(Properties paramProperties);
  
  public abstract DataSource getDataSource();
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\datasource\DataSourceFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */