/*    */ package org.apache.ibatis.scripting.xmltags;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.apache.ibatis.session.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WhereSqlNode
/*    */   extends TrimSqlNode
/*    */ {
/* 28 */   private static List<String> prefixList = Arrays.asList(new String[] { "AND ", "OR ", "AND\n", "OR\n", "AND\r", "OR\r", "AND\t", "OR\t" });
/*    */   
/*    */   public WhereSqlNode(Configuration configuration, SqlNode contents) {
/* 31 */     super(configuration, contents, "WHERE", prefixList, null, null);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\xmltags\WhereSqlNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */