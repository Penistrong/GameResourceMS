/*    */ package org.apache.ibatis.builder;
/*    */ 
/*    */ import org.apache.ibatis.exceptions.PersistenceException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BuilderException
/*    */   extends PersistenceException
/*    */ {
/*    */   private static final long serialVersionUID = -3885164021020443281L;
/*    */   
/*    */   public BuilderException() {}
/*    */   
/*    */   public BuilderException(String message)
/*    */   {
/* 32 */     super(message);
/*    */   }
/*    */   
/*    */   public BuilderException(String message, Throwable cause) {
/* 36 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public BuilderException(Throwable cause) {
/* 40 */     super(cause);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\builder\BuilderException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */