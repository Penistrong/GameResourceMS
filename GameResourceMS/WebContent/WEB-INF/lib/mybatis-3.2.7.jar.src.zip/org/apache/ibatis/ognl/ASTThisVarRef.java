/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTThisVarRef
/*    */   extends ASTVarRef
/*    */ {
/*    */   private String name;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ASTThisVarRef(int id)
/*    */   {
/* 42 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTThisVarRef(OgnlParser p, int id) {
/* 46 */     super(p, id);
/*    */   }
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/* 50 */     return context.getCurrentObject();
/*    */   }
/*    */   
/*    */   protected void setValueBody(OgnlContext context, Object target, Object value) throws OgnlException {
/* 54 */     context.setCurrentObject(value);
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 59 */     return "#this";
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTThisVarRef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */