/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NumberElementsAccessor
/*    */   implements ElementsAccessor, NumericTypes
/*    */ {
/*    */   public Enumeration getElements(Object target)
/*    */   {
/* 45 */     new Enumeration() {
/*    */       private int type;
/*    */       private long next;
/*    */       private long finish;
/*    */       
/*    */       public boolean hasMoreElements() {
/* 51 */         return this.next < this.finish;
/*    */       }
/*    */       
/*    */       public Object nextElement() {
/* 55 */         if (this.next >= this.finish)
/* 56 */           throw new NoSuchElementException();
/* 57 */         return OgnlOps.newInteger(this.type, this.next++);
/*    */       }
/*    */     };
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\NumberElementsAccessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */