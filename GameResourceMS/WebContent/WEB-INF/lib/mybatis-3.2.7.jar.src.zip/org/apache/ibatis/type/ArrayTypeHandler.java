/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.sql.Array;
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayTypeHandler
/*    */   extends BaseTypeHandler<Object>
/*    */ {
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, Object parameter, JdbcType jdbcType)
/*    */     throws SQLException
/*    */   {
/* 35 */     ps.setArray(i, (Array)parameter);
/*    */   }
/*    */   
/*    */   public Object getNullableResult(ResultSet rs, String columnName) throws SQLException
/*    */   {
/* 40 */     Array array = rs.getArray(columnName);
/* 41 */     return array == null ? null : array.getArray();
/*    */   }
/*    */   
/*    */   public Object getNullableResult(ResultSet rs, int columnIndex) throws SQLException
/*    */   {
/* 46 */     Array array = rs.getArray(columnIndex);
/* 47 */     return array == null ? null : array.getArray();
/*    */   }
/*    */   
/*    */   public Object getNullableResult(CallableStatement cs, int columnIndex) throws SQLException
/*    */   {
/* 52 */     Array array = cs.getArray(columnIndex);
/* 53 */     return array == null ? null : array.getArray();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\ArrayTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */