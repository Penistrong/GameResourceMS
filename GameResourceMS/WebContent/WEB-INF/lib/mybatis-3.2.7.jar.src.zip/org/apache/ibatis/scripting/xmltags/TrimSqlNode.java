/*     */ package org.apache.ibatis.scripting.xmltags;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrimSqlNode
/*     */   implements SqlNode
/*     */ {
/*     */   private SqlNode contents;
/*     */   private String prefix;
/*     */   private String suffix;
/*     */   private List<String> prefixesToOverride;
/*     */   private List<String> suffixesToOverride;
/*     */   private Configuration configuration;
/*     */   
/*     */   public TrimSqlNode(Configuration configuration, SqlNode contents, String prefix, String prefixesToOverride, String suffix, String suffixesToOverride)
/*     */   {
/*  40 */     this(configuration, contents, prefix, parseOverrides(prefixesToOverride), suffix, parseOverrides(suffixesToOverride));
/*     */   }
/*     */   
/*     */   protected TrimSqlNode(Configuration configuration, SqlNode contents, String prefix, List<String> prefixesToOverride, String suffix, List<String> suffixesToOverride) {
/*  44 */     this.contents = contents;
/*  45 */     this.prefix = prefix;
/*  46 */     this.prefixesToOverride = prefixesToOverride;
/*  47 */     this.suffix = suffix;
/*  48 */     this.suffixesToOverride = suffixesToOverride;
/*  49 */     this.configuration = configuration;
/*     */   }
/*     */   
/*     */   public boolean apply(DynamicContext context) {
/*  53 */     FilteredDynamicContext filteredDynamicContext = new FilteredDynamicContext(context);
/*  54 */     boolean result = this.contents.apply(filteredDynamicContext);
/*  55 */     filteredDynamicContext.applyAll();
/*  56 */     return result;
/*     */   }
/*     */   
/*     */   private static List<String> parseOverrides(String overrides) {
/*  60 */     if (overrides != null) {
/*  61 */       StringTokenizer parser = new StringTokenizer(overrides, "|", false);
/*  62 */       new ArrayList()
/*     */       {
/*     */         private static final long serialVersionUID = -2504816393625384165L;
/*     */       };
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */   private class FilteredDynamicContext extends DynamicContext {
/*     */     private DynamicContext delegate;
/*     */     private boolean prefixApplied;
/*     */     private boolean suffixApplied;
/*     */     private StringBuilder sqlBuffer;
/*     */     
/*     */     public FilteredDynamicContext(DynamicContext delegate) {
/*  82 */       super(null);
/*  83 */       this.delegate = delegate;
/*  84 */       this.prefixApplied = false;
/*  85 */       this.suffixApplied = false;
/*  86 */       this.sqlBuffer = new StringBuilder();
/*     */     }
/*     */     
/*     */     public void applyAll() {
/*  90 */       this.sqlBuffer = new StringBuilder(this.sqlBuffer.toString().trim());
/*  91 */       String trimmedUppercaseSql = this.sqlBuffer.toString().toUpperCase(Locale.ENGLISH);
/*  92 */       if (trimmedUppercaseSql.length() > 0) {
/*  93 */         applyPrefix(this.sqlBuffer, trimmedUppercaseSql);
/*  94 */         applySuffix(this.sqlBuffer, trimmedUppercaseSql);
/*     */       }
/*  96 */       this.delegate.appendSql(this.sqlBuffer.toString());
/*     */     }
/*     */     
/*     */     public Map<String, Object> getBindings()
/*     */     {
/* 101 */       return this.delegate.getBindings();
/*     */     }
/*     */     
/*     */     public void bind(String name, Object value)
/*     */     {
/* 106 */       this.delegate.bind(name, value);
/*     */     }
/*     */     
/*     */     public int getUniqueNumber()
/*     */     {
/* 111 */       return this.delegate.getUniqueNumber();
/*     */     }
/*     */     
/*     */     public void appendSql(String sql)
/*     */     {
/* 116 */       this.sqlBuffer.append(sql);
/*     */     }
/*     */     
/*     */     public String getSql()
/*     */     {
/* 121 */       return this.delegate.getSql();
/*     */     }
/*     */     
/*     */     private void applyPrefix(StringBuilder sql, String trimmedUppercaseSql) {
/* 125 */       if (!this.prefixApplied) {
/* 126 */         this.prefixApplied = true;
/* 127 */         if (TrimSqlNode.this.prefixesToOverride != null) {
/* 128 */           for (String toRemove : TrimSqlNode.this.prefixesToOverride) {
/* 129 */             if (trimmedUppercaseSql.startsWith(toRemove)) {
/* 130 */               sql.delete(0, toRemove.trim().length());
/* 131 */               break;
/*     */             }
/*     */           }
/*     */         }
/* 135 */         if (TrimSqlNode.this.prefix != null) {
/* 136 */           sql.insert(0, " ");
/* 137 */           sql.insert(0, TrimSqlNode.this.prefix);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private void applySuffix(StringBuilder sql, String trimmedUppercaseSql) {
/* 143 */       if (!this.suffixApplied) {
/* 144 */         this.suffixApplied = true;
/* 145 */         if (TrimSqlNode.this.suffixesToOverride != null) {
/* 146 */           for (String toRemove : TrimSqlNode.this.suffixesToOverride) {
/* 147 */             if ((trimmedUppercaseSql.endsWith(toRemove)) || (trimmedUppercaseSql.endsWith(toRemove.trim()))) {
/* 148 */               int start = sql.length() - toRemove.trim().length();
/* 149 */               int end = sql.length();
/* 150 */               sql.delete(start, end);
/* 151 */               break;
/*     */             }
/*     */           }
/*     */         }
/* 155 */         if (TrimSqlNode.this.suffix != null) {
/* 156 */           sql.append(" ");
/* 157 */           sql.append(TrimSqlNode.this.suffix);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\xmltags\TrimSqlNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */