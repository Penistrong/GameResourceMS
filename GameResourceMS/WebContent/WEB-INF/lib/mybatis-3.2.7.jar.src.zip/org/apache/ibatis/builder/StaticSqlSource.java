/*    */ package org.apache.ibatis.builder;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.apache.ibatis.mapping.BoundSql;
/*    */ import org.apache.ibatis.mapping.ParameterMapping;
/*    */ import org.apache.ibatis.mapping.SqlSource;
/*    */ import org.apache.ibatis.session.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StaticSqlSource
/*    */   implements SqlSource
/*    */ {
/*    */   private String sql;
/*    */   private List<ParameterMapping> parameterMappings;
/*    */   private Configuration configuration;
/*    */   
/*    */   public StaticSqlSource(Configuration configuration, String sql)
/*    */   {
/* 35 */     this(configuration, sql, null);
/*    */   }
/*    */   
/*    */   public StaticSqlSource(Configuration configuration, String sql, List<ParameterMapping> parameterMappings) {
/* 39 */     this.sql = sql;
/* 40 */     this.parameterMappings = parameterMappings;
/* 41 */     this.configuration = configuration;
/*    */   }
/*    */   
/*    */   public BoundSql getBoundSql(Object parameterObject) {
/* 45 */     return new BoundSql(this.configuration, this.sql, this.parameterMappings, parameterObject);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\builder\StaticSqlSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */