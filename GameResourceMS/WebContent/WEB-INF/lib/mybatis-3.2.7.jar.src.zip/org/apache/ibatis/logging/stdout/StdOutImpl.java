/*    */ package org.apache.ibatis.logging.stdout;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import org.apache.ibatis.logging.Log;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StdOutImpl
/*    */   implements Log
/*    */ {
/*    */   public StdOutImpl(String clazz) {}
/*    */   
/*    */   public boolean isDebugEnabled()
/*    */   {
/* 29 */     return true;
/*    */   }
/*    */   
/*    */   public boolean isTraceEnabled() {
/* 33 */     return true;
/*    */   }
/*    */   
/*    */   public void error(String s, Throwable e) {
/* 37 */     System.err.println(s);
/* 38 */     e.printStackTrace(System.err);
/*    */   }
/*    */   
/*    */   public void error(String s) {
/* 42 */     System.err.println(s);
/*    */   }
/*    */   
/*    */   public void debug(String s) {
/* 46 */     System.out.println(s);
/*    */   }
/*    */   
/*    */   public void trace(String s) {
/* 50 */     System.out.println(s);
/*    */   }
/*    */   
/*    */   public void warn(String s) {
/* 54 */     System.out.println(s);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\logging\stdout\StdOutImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */