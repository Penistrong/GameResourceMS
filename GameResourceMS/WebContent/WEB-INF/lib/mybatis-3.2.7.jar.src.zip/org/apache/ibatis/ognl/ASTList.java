/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTList
/*    */   extends SimpleNode
/*    */ {
/*    */   public ASTList(int id)
/*    */   {
/* 42 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTList(OgnlParser p, int id) {
/* 46 */     super(p, id);
/*    */   }
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException
/*    */   {
/* 51 */     List answer = new ArrayList(jjtGetNumChildren());
/* 52 */     for (int i = 0; i < jjtGetNumChildren(); i++)
/* 53 */       answer.add(this.children[i].getValue(context, source));
/* 54 */     return answer;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 59 */     String result = "{ ";
/*    */     
/*    */ 
/* 62 */     for (int i = 0; i < jjtGetNumChildren(); i++) {
/* 63 */       if (i > 0) {
/* 64 */         result = result + ", ";
/*    */       }
/* 66 */       result = result + this.children[i].toString();
/*    */     }
/* 68 */     return result + " }";
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */