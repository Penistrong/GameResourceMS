/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Time;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SqlTimeTypeHandler
/*    */   extends BaseTypeHandler<Time>
/*    */ {
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, Time parameter, JdbcType jdbcType)
/*    */     throws SQLException
/*    */   {
/* 32 */     ps.setTime(i, parameter);
/*    */   }
/*    */   
/*    */   public Time getNullableResult(ResultSet rs, String columnName)
/*    */     throws SQLException
/*    */   {
/* 38 */     return rs.getTime(columnName);
/*    */   }
/*    */   
/*    */   public Time getNullableResult(ResultSet rs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 44 */     return rs.getTime(columnIndex);
/*    */   }
/*    */   
/*    */   public Time getNullableResult(CallableStatement cs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 50 */     return cs.getTime(columnIndex);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\SqlTimeTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */