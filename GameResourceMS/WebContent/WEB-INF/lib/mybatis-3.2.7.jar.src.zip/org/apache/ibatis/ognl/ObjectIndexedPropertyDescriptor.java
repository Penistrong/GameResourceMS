/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectIndexedPropertyDescriptor
/*     */   extends PropertyDescriptor
/*     */ {
/*     */   private Method indexedReadMethod;
/*     */   private Method indexedWriteMethod;
/*     */   private Class propertyType;
/*     */   
/*     */   public ObjectIndexedPropertyDescriptor(String propertyName, Class propertyType, Method indexedReadMethod, Method indexedWriteMethod)
/*     */     throws IntrospectionException
/*     */   {
/* 103 */     super(propertyName, null, null);
/* 104 */     this.propertyType = propertyType;
/* 105 */     this.indexedReadMethod = indexedReadMethod;
/* 106 */     this.indexedWriteMethod = indexedWriteMethod;
/*     */   }
/*     */   
/*     */   public Method getIndexedReadMethod()
/*     */   {
/* 111 */     return this.indexedReadMethod;
/*     */   }
/*     */   
/*     */   public Method getIndexedWriteMethod()
/*     */   {
/* 116 */     return this.indexedWriteMethod;
/*     */   }
/*     */   
/*     */   public Class getPropertyType()
/*     */   {
/* 121 */     return this.propertyType;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ObjectIndexedPropertyDescriptor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */