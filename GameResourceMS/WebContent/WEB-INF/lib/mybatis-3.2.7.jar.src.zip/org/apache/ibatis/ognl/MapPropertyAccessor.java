/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MapPropertyAccessor
/*    */   implements PropertyAccessor
/*    */ {
/*    */   public Object getProperty(Map context, Object target, Object name)
/*    */     throws OgnlException
/*    */   {
/* 46 */     Map map = (Map)target;
/* 47 */     Node currentNode = ((OgnlContext)context).getCurrentNode().jjtGetParent();
/* 48 */     boolean indexedAccess = false;
/*    */     
/* 50 */     if (currentNode == null) {
/* 51 */       throw new OgnlException("node is null for '" + name + "'");
/*    */     }
/* 53 */     if (!(currentNode instanceof ASTProperty)) {
/* 54 */       currentNode = currentNode.jjtGetParent();
/*    */     }
/* 56 */     if ((currentNode instanceof ASTProperty))
/* 57 */       indexedAccess = ((ASTProperty)currentNode).isIndexedAccess();
/*    */     Object result;
/* 59 */     Object result; if (((name instanceof String)) && (!indexedAccess)) { Object result;
/* 60 */       if (name.equals("size")) {
/* 61 */         result = new Integer(map.size());
/*    */       } else { Object result;
/* 63 */         if (name.equals("keys")) {
/* 64 */           result = map.keySet();
/*    */         } else { Object result;
/* 66 */           if (name.equals("values")) {
/* 67 */             result = map.values();
/*    */           } else { Object result;
/* 69 */             if (name.equals("isEmpty")) {
/* 70 */               result = map.isEmpty() ? Boolean.TRUE : Boolean.FALSE;
/*    */             } else {
/* 72 */               result = map.get(name);
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */     } else {
/* 78 */       result = map.get(name);
/*    */     }
/* 80 */     return result;
/*    */   }
/*    */   
/*    */   public void setProperty(Map context, Object target, Object name, Object value) throws OgnlException
/*    */   {
/* 85 */     Map map = (Map)target;
/* 86 */     map.put(name, value);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\MapPropertyAccessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */