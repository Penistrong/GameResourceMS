/*    */ package org.apache.ibatis.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NullCacheKey
/*    */   extends CacheKey
/*    */ {
/*    */   private static final long serialVersionUID = 3704229911977019465L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void update(Object object)
/*    */   {
/* 31 */     throw new CacheException("Not allowed to update a NullCacheKey instance.");
/*    */   }
/*    */   
/*    */   public void updateAll(Object[] objects)
/*    */   {
/* 36 */     throw new CacheException("Not allowed to update a NullCacheKey instance.");
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\cache\NullCacheKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */