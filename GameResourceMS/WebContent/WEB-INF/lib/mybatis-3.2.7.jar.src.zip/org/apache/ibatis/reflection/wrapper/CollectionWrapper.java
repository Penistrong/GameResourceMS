/*    */ package org.apache.ibatis.reflection.wrapper;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.apache.ibatis.reflection.MetaObject;
/*    */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*    */ import org.apache.ibatis.reflection.property.PropertyTokenizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CollectionWrapper
/*    */   implements ObjectWrapper
/*    */ {
/*    */   private Collection<Object> object;
/*    */   
/*    */   public CollectionWrapper(MetaObject metaObject, Collection<Object> object)
/*    */   {
/* 33 */     this.object = object;
/*    */   }
/*    */   
/*    */   public Object get(PropertyTokenizer prop) {
/* 37 */     throw new UnsupportedOperationException();
/*    */   }
/*    */   
/*    */   public void set(PropertyTokenizer prop, Object value) {
/* 41 */     throw new UnsupportedOperationException();
/*    */   }
/*    */   
/*    */   public String findProperty(String name, boolean useCamelCaseMapping) {
/* 45 */     throw new UnsupportedOperationException();
/*    */   }
/*    */   
/*    */   public String[] getGetterNames() {
/* 49 */     throw new UnsupportedOperationException();
/*    */   }
/*    */   
/*    */   public String[] getSetterNames() {
/* 53 */     throw new UnsupportedOperationException();
/*    */   }
/*    */   
/*    */   public Class<?> getSetterType(String name) {
/* 57 */     throw new UnsupportedOperationException();
/*    */   }
/*    */   
/*    */   public Class<?> getGetterType(String name) {
/* 61 */     throw new UnsupportedOperationException();
/*    */   }
/*    */   
/*    */   public boolean hasSetter(String name) {
/* 65 */     throw new UnsupportedOperationException();
/*    */   }
/*    */   
/*    */   public boolean hasGetter(String name) {
/* 69 */     throw new UnsupportedOperationException();
/*    */   }
/*    */   
/*    */   public MetaObject instantiatePropertyValue(String name, PropertyTokenizer prop, ObjectFactory objectFactory) {
/* 73 */     throw new UnsupportedOperationException();
/*    */   }
/*    */   
/*    */   public boolean isCollection() {
/* 77 */     return true;
/*    */   }
/*    */   
/*    */   public void add(Object element) {
/* 81 */     this.object.add(element);
/*    */   }
/*    */   
/*    */   public <E> void addAll(List<E> element) {
/* 85 */     this.object.addAll(element);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\wrapper\CollectionWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */