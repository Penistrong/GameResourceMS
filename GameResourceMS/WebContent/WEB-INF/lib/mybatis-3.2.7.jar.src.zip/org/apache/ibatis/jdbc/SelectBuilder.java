/*     */ package org.apache.ibatis.jdbc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class SelectBuilder
/*     */ {
/*  26 */   private static final ThreadLocal<SQL> localSQL = new ThreadLocal();
/*     */   
/*     */   static {
/*  29 */     BEGIN();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void RESET()
/*     */   {
/*  37 */     localSQL.set(new SQL());
/*     */   }
/*     */   
/*     */   public static void SELECT(String columns) {
/*  41 */     sql().SELECT(columns);
/*     */   }
/*     */   
/*     */   public static void SELECT_DISTINCT(String columns) {
/*  45 */     sql().SELECT_DISTINCT(columns);
/*     */   }
/*     */   
/*     */   public static void FROM(String table) {
/*  49 */     sql().FROM(table);
/*     */   }
/*     */   
/*     */   public static void JOIN(String join) {
/*  53 */     sql().JOIN(join);
/*     */   }
/*     */   
/*     */   public static void INNER_JOIN(String join) {
/*  57 */     sql().INNER_JOIN(join);
/*     */   }
/*     */   
/*     */   public static void LEFT_OUTER_JOIN(String join) {
/*  61 */     sql().LEFT_OUTER_JOIN(join);
/*     */   }
/*     */   
/*     */   public static void RIGHT_OUTER_JOIN(String join) {
/*  65 */     sql().RIGHT_OUTER_JOIN(join);
/*     */   }
/*     */   
/*     */   public static void OUTER_JOIN(String join) {
/*  69 */     sql().OUTER_JOIN(join);
/*     */   }
/*     */   
/*     */   public static void WHERE(String conditions) {
/*  73 */     sql().WHERE(conditions);
/*     */   }
/*     */   
/*     */   public static void OR() {
/*  77 */     sql().OR();
/*     */   }
/*     */   
/*     */   public static void AND() {
/*  81 */     sql().AND();
/*     */   }
/*     */   
/*     */   public static void GROUP_BY(String columns) {
/*  85 */     sql().GROUP_BY(columns);
/*     */   }
/*     */   
/*     */   public static void HAVING(String conditions) {
/*  89 */     sql().HAVING(conditions);
/*     */   }
/*     */   
/*     */   public static void ORDER_BY(String columns) {
/*  93 */     sql().ORDER_BY(columns);
/*     */   }
/*     */   
/*     */   public static String SQL() {
/*     */     try {
/*  98 */       return sql().toString();
/*     */     } finally {
/* 100 */       RESET();
/*     */     }
/*     */   }
/*     */   
/*     */   private static SQL sql() {
/* 105 */     return (SQL)localSQL.get();
/*     */   }
/*     */   
/*     */   public static void BEGIN() {}
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\jdbc\SelectBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */