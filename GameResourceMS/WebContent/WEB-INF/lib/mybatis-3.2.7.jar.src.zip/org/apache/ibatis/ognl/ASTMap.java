/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ASTMap
/*     */   extends SimpleNode
/*     */ {
/*     */   private static Class DEFAULT_MAP_CLASS;
/*     */   private String className;
/*     */   
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  47 */       DEFAULT_MAP_CLASS = Class.forName("java.util.LinkedHashMap");
/*     */     } catch (ClassNotFoundException ex) {
/*  49 */       DEFAULT_MAP_CLASS = HashMap.class;
/*     */     }
/*     */   }
/*     */   
/*     */   public ASTMap(int id) {
/*  54 */     super(id);
/*     */   }
/*     */   
/*     */   public ASTMap(OgnlParser p, int id) {
/*  58 */     super(p, id);
/*     */   }
/*     */   
/*     */   protected void setClassName(String value)
/*     */   {
/*  63 */     this.className = value;
/*     */   }
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source)
/*     */     throws OgnlException
/*     */   {
/*     */     Map answer;
/*  70 */     if (this.className == null) {
/*     */       try {
/*  72 */         answer = (Map)DEFAULT_MAP_CLASS.newInstance();
/*     */       } catch (Exception ex) {
/*     */         Map answer;
/*  75 */         throw new OgnlException("Default Map class '" + DEFAULT_MAP_CLASS.getName() + "' instantiation error", ex);
/*     */       }
/*     */     } else {
/*     */       try {
/*  79 */         answer = (Map)OgnlRuntime.classForName(context, this.className).newInstance();
/*     */       } catch (Exception ex) { Map answer;
/*  81 */         throw new OgnlException("Map implementor '" + this.className + "' not found", ex);
/*     */       }
/*     */     }
/*     */     Map answer;
/*  85 */     for (int i = 0; i < jjtGetNumChildren(); i++) {
/*  86 */       ASTKeyValue kv = (ASTKeyValue)this.children[i];
/*  87 */       Node k = kv.getKey();
/*  88 */       Node v = kv.getValue();
/*     */       
/*  90 */       answer.put(k.getValue(context, source), v == null ? null : v.getValue(context, source));
/*     */     }
/*  92 */     return answer;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  97 */     String result = "#";
/*     */     
/*  99 */     if (this.className != null) {
/* 100 */       result = result + "@" + this.className + "@";
/*     */     }
/* 102 */     result = result + "{ ";
/* 103 */     for (int i = 0; i < jjtGetNumChildren(); i++) {
/* 104 */       ASTKeyValue kv = (ASTKeyValue)this.children[i];
/*     */       
/* 106 */       if (i > 0) {
/* 107 */         result = result + ", ";
/*     */       }
/* 109 */       result = result + kv.getKey() + " : " + kv.getValue();
/*     */     }
/* 111 */     return result + " }";
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTMap.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */