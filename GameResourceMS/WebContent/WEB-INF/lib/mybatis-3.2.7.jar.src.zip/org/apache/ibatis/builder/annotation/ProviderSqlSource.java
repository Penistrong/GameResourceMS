/*    */ package org.apache.ibatis.builder.annotation;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.HashMap;
/*    */ import org.apache.ibatis.builder.BuilderException;
/*    */ import org.apache.ibatis.builder.SqlSourceBuilder;
/*    */ import org.apache.ibatis.mapping.BoundSql;
/*    */ import org.apache.ibatis.mapping.SqlSource;
/*    */ import org.apache.ibatis.session.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProviderSqlSource
/*    */   implements SqlSource
/*    */ {
/*    */   private SqlSourceBuilder sqlSourceParser;
/*    */   private Class<?> providerType;
/*    */   private Method providerMethod;
/*    */   private boolean providerTakesParameterObject;
/*    */   
/*    */   public ProviderSqlSource(Configuration config, Object provider)
/*    */   {
/* 38 */     String providerMethodName = null;
/*    */     try {
/* 40 */       this.sqlSourceParser = new SqlSourceBuilder(config);
/* 41 */       this.providerType = ((Class)provider.getClass().getMethod("type", new Class[0]).invoke(provider, new Object[0]));
/* 42 */       providerMethodName = (String)provider.getClass().getMethod("method", new Class[0]).invoke(provider, new Object[0]);
/*    */       
/* 44 */       for (Method m : this.providerType.getMethods()) {
/* 45 */         if ((providerMethodName.equals(m.getName())) && 
/* 46 */           (m.getParameterTypes().length < 2) && (m.getReturnType() == String.class))
/*    */         {
/* 48 */           this.providerMethod = m;
/* 49 */           this.providerTakesParameterObject = (m.getParameterTypes().length == 1);
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 54 */       throw new BuilderException("Error creating SqlSource for SqlProvider.  Cause: " + e, e);
/*    */     }
/* 56 */     if (this.providerMethod == null) {
/* 57 */       throw new BuilderException("Error creating SqlSource for SqlProvider. Method '" + providerMethodName + "' not found in SqlProvider '" + this.providerType.getName() + "'.");
/*    */     }
/*    */   }
/*    */   
/*    */   public BoundSql getBoundSql(Object parameterObject)
/*    */   {
/* 63 */     SqlSource sqlSource = createSqlSource(parameterObject);
/* 64 */     return sqlSource.getBoundSql(parameterObject);
/*    */   }
/*    */   
/*    */   private SqlSource createSqlSource(Object parameterObject) {
/*    */     try { String sql;
/*    */       String sql;
/* 70 */       if (this.providerTakesParameterObject) {
/* 71 */         sql = (String)this.providerMethod.invoke(this.providerType.newInstance(), new Object[] { parameterObject });
/*    */       } else {
/* 73 */         sql = (String)this.providerMethod.invoke(this.providerType.newInstance(), new Object[0]);
/*    */       }
/* 75 */       Class<?> parameterType = parameterObject == null ? Object.class : parameterObject.getClass();
/* 76 */       return this.sqlSourceParser.parse(sql, parameterType, new HashMap());
/*    */     } catch (Exception e) {
/* 78 */       throw new BuilderException("Error invoking SqlProvider method (" + this.providerType.getName() + "." + this.providerMethod.getName() + ").  Cause: " + e, e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\builder\annotation\ProviderSqlSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */