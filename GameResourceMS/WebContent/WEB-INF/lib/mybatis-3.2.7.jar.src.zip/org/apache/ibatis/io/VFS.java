/*     */ package org.apache.ibatis.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.ibatis.logging.Log;
/*     */ import org.apache.ibatis.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class VFS
/*     */ {
/*  36 */   private static final Log log = LogFactory.getLog(ResolverUtil.class);
/*     */   
/*     */ 
/*  39 */   public static final Class<?>[] IMPLEMENTATIONS = { JBoss6VFS.class, DefaultVFS.class };
/*     */   
/*     */ 
/*  42 */   public static final List<Class<? extends VFS>> USER_IMPLEMENTATIONS = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */   private static VFS instance;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static VFS getInstance()
/*     */   {
/*  53 */     if (instance != null) {
/*  54 */       return instance;
/*     */     }
/*     */     
/*  57 */     List<Class<? extends VFS>> impls = new ArrayList();
/*  58 */     impls.addAll(USER_IMPLEMENTATIONS);
/*  59 */     impls.addAll(Arrays.asList((Class[])IMPLEMENTATIONS));
/*     */     
/*     */ 
/*  62 */     VFS vfs = null;
/*  63 */     for (int i = 0; (vfs == null) || (!vfs.isValid()); i++) {
/*  64 */       Class<? extends VFS> impl = (Class)impls.get(i);
/*     */       try {
/*  66 */         vfs = (VFS)impl.newInstance();
/*  67 */         if ((vfs == null) || (!vfs.isValid())) {
/*  68 */           log.debug("VFS implementation " + impl.getName() + " is not valid in this environment.");
/*     */         }
/*     */       }
/*     */       catch (InstantiationException e) {
/*  72 */         log.error("Failed to instantiate " + impl, e);
/*  73 */         return null;
/*     */       } catch (IllegalAccessException e) {
/*  75 */         log.error("Failed to instantiate " + impl, e);
/*  76 */         return null;
/*     */       }
/*     */     }
/*     */     
/*  80 */     log.debug("Using VFS adapter " + vfs.getClass().getName());
/*  81 */     return instance = vfs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addImplClass(Class<? extends VFS> clazz)
/*     */   {
/*  91 */     if (clazz != null) {
/*  92 */       USER_IMPLEMENTATIONS.add(clazz);
/*     */     }
/*     */   }
/*     */   
/*     */   protected static Class<?> getClass(String className) {
/*     */     try {
/*  98 */       return Thread.currentThread().getContextClassLoader().loadClass(className);
/*     */     }
/*     */     catch (ClassNotFoundException e) {
/* 101 */       log.debug("Class not found: " + className); }
/* 102 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static Method getMethod(Class<?> clazz, String methodName, Class<?>... parameterTypes)
/*     */   {
/*     */     try
/*     */     {
/* 115 */       if (clazz == null) {
/* 116 */         return null;
/*     */       }
/* 118 */       return clazz.getMethod(methodName, parameterTypes);
/*     */     } catch (SecurityException e) {
/* 120 */       log.error("Security exception looking for method " + clazz.getName() + "." + methodName + ".  Cause: " + e);
/* 121 */       return null;
/*     */     } catch (NoSuchMethodException e) {
/* 123 */       log.error("Method not found " + clazz.getName() + "." + methodName + "." + methodName + ".  Cause: " + e); }
/* 124 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static <T> T invoke(Method method, Object object, Object... parameters)
/*     */     throws IOException, RuntimeException
/*     */   {
/*     */     try
/*     */     {
/* 142 */       return (T)method.invoke(object, parameters);
/*     */     } catch (IllegalArgumentException e) {
/* 144 */       throw new RuntimeException(e);
/*     */     } catch (IllegalAccessException e) {
/* 146 */       throw new RuntimeException(e);
/*     */     } catch (InvocationTargetException e) {
/* 148 */       if ((e.getTargetException() instanceof IOException)) {
/* 149 */         throw ((IOException)e.getTargetException());
/*     */       }
/* 151 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static List<URL> getResources(String path)
/*     */     throws IOException
/*     */   {
/* 164 */     return Collections.list(Thread.currentThread().getContextClassLoader().getResources(path));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean isValid();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract List<String> list(URL paramURL, String paramString)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> list(String path)
/*     */     throws IOException
/*     */   {
/* 191 */     List<String> names = new ArrayList();
/* 192 */     for (URL url : getResources(path)) {
/* 193 */       names.addAll(list(url, path));
/*     */     }
/* 195 */     return names;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\io\VFS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */