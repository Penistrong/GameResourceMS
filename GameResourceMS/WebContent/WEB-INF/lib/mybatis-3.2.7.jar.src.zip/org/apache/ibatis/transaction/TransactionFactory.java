package org.apache.ibatis.transaction;

import java.sql.Connection;
import java.util.Properties;
import javax.sql.DataSource;
import org.apache.ibatis.session.TransactionIsolationLevel;

public abstract interface TransactionFactory
{
  public abstract void setProperties(Properties paramProperties);
  
  public abstract Transaction newTransaction(Connection paramConnection);
  
  public abstract Transaction newTransaction(DataSource paramDataSource, TransactionIsolationLevel paramTransactionIsolationLevel, boolean paramBoolean);
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\transaction\TransactionFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */