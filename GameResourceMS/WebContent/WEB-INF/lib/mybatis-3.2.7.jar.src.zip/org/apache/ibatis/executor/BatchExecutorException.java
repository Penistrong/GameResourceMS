/*    */ package org.apache.ibatis.executor;
/*    */ 
/*    */ import java.sql.BatchUpdateException;
/*    */ import java.util.List;
/*    */ import org.apache.ibatis.mapping.MappedStatement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BatchExecutorException
/*    */   extends ExecutorException
/*    */ {
/*    */   private static final long serialVersionUID = 154049229650533990L;
/*    */   private final List<BatchResult> successfulBatchResults;
/*    */   private final BatchUpdateException batchUpdateException;
/*    */   private final BatchResult batchResult;
/*    */   
/*    */   public BatchExecutorException(String message, BatchUpdateException cause, List<BatchResult> successfulBatchResults, BatchResult batchResult)
/*    */   {
/* 40 */     super(message + " Cause: " + cause, cause);
/* 41 */     this.batchUpdateException = cause;
/* 42 */     this.successfulBatchResults = successfulBatchResults;
/* 43 */     this.batchResult = batchResult;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public BatchUpdateException getBatchUpdateException()
/*    */   {
/* 55 */     return this.batchUpdateException;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public List<BatchResult> getSuccessfulBatchResults()
/*    */   {
/* 67 */     return this.successfulBatchResults;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getFailingSqlStatement()
/*    */   {
/* 77 */     return this.batchResult.getSql();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getFailingStatementId()
/*    */   {
/* 86 */     return this.batchResult.getMappedStatement().getId();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\BatchExecutorException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */