/*    */ package org.apache.ibatis.reflection.property;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyCopier
/*    */ {
/*    */   public static void copyBeanProperties(Class<?> type, Object sourceBean, Object destinationBean)
/*    */   {
/* 26 */     Class<?> parent = type;
/* 27 */     while (parent != null) {
/* 28 */       Field[] fields = parent.getDeclaredFields();
/* 29 */       for (Field field : fields) {
/*    */         try {
/* 31 */           field.setAccessible(true);
/* 32 */           field.set(destinationBean, field.get(sourceBean));
/*    */         }
/*    */         catch (Exception e) {}
/*    */       }
/*    */       
/* 37 */       parent = parent.getSuperclass();
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\property\PropertyCopier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */