/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.lang.reflect.ParameterizedType;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TypeReference<T>
/*    */ {
/*    */   private final Type rawType;
/*    */   
/*    */   protected TypeReference()
/*    */   {
/* 33 */     this.rawType = getSuperclassTypeParameter(getClass());
/*    */   }
/*    */   
/*    */   Type getSuperclassTypeParameter(Class<?> clazz) {
/* 37 */     Type genericSuperclass = clazz.getGenericSuperclass();
/* 38 */     if ((genericSuperclass instanceof Class))
/*    */     {
/* 40 */       if (TypeReference.class != genericSuperclass) {
/* 41 */         return getSuperclassTypeParameter(clazz.getSuperclass());
/*    */       }
/*    */       
/* 44 */       throw new TypeException("'" + getClass() + "' extends TypeReference but misses the type parameter. " + "Remove the extension or add a type parameter to it.");
/*    */     }
/*    */     
/*    */ 
/* 48 */     Type rawType = ((ParameterizedType)genericSuperclass).getActualTypeArguments()[0];
/*    */     
/* 50 */     if ((rawType instanceof ParameterizedType)) {
/* 51 */       rawType = ((ParameterizedType)rawType).getRawType();
/*    */     }
/*    */     
/* 54 */     return rawType;
/*    */   }
/*    */   
/*    */   public final Type getRawType() {
/* 58 */     return this.rawType;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 63 */     return this.rawType.toString();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\TypeReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */