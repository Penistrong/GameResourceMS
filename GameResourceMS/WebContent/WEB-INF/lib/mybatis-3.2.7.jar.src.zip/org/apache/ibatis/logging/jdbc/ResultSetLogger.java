/*     */ package org.apache.ibatis.logging.jdbc;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.ibatis.logging.Log;
/*     */ import org.apache.ibatis.reflection.ExceptionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResultSetLogger
/*     */   extends BaseJdbcLogger
/*     */   implements InvocationHandler
/*     */ {
/*  40 */   private static Set<Integer> BLOB_TYPES = new HashSet();
/*  41 */   private boolean first = true;
/*  42 */   private int rows = 0;
/*     */   private ResultSet rs;
/*  44 */   private Set<Integer> blobColumns = new HashSet();
/*     */   
/*     */   static {
/*  47 */     BLOB_TYPES.add(Integer.valueOf(-2));
/*  48 */     BLOB_TYPES.add(Integer.valueOf(2004));
/*  49 */     BLOB_TYPES.add(Integer.valueOf(2005));
/*  50 */     BLOB_TYPES.add(Integer.valueOf(-16));
/*  51 */     BLOB_TYPES.add(Integer.valueOf(-4));
/*  52 */     BLOB_TYPES.add(Integer.valueOf(-1));
/*  53 */     BLOB_TYPES.add(Integer.valueOf(2011));
/*  54 */     BLOB_TYPES.add(Integer.valueOf(-3));
/*     */   }
/*     */   
/*     */   private ResultSetLogger(ResultSet rs, Log statementLog, int queryStack) {
/*  58 */     super(statementLog, queryStack);
/*  59 */     this.rs = rs;
/*     */   }
/*     */   
/*     */   public Object invoke(Object proxy, Method method, Object[] params) throws Throwable {
/*     */     try {
/*  64 */       if (Object.class.equals(method.getDeclaringClass())) {
/*  65 */         return method.invoke(this, params);
/*     */       }
/*  67 */       Object o = method.invoke(this.rs, params);
/*  68 */       if ("next".equals(method.getName())) {
/*  69 */         if (((Boolean)o).booleanValue()) {
/*  70 */           this.rows += 1;
/*  71 */           if (isTraceEnabled()) {
/*  72 */             ResultSetMetaData rsmd = this.rs.getMetaData();
/*  73 */             int columnCount = rsmd.getColumnCount();
/*  74 */             if (this.first) {
/*  75 */               this.first = false;
/*  76 */               printColumnHeaders(rsmd, columnCount);
/*     */             }
/*  78 */             printColumnValues(columnCount);
/*     */           }
/*     */         } else {
/*  81 */           debug("     Total: " + this.rows, false);
/*     */         }
/*     */       }
/*  84 */       clearColumnInfo();
/*  85 */       return o;
/*     */     } catch (Throwable t) {
/*  87 */       throw ExceptionUtil.unwrapThrowable(t);
/*     */     }
/*     */   }
/*     */   
/*     */   private void printColumnHeaders(ResultSetMetaData rsmd, int columnCount) throws SQLException {
/*  92 */     StringBuilder row = new StringBuilder();
/*  93 */     row.append("   Columns: ");
/*  94 */     for (int i = 1; i <= columnCount; i++) {
/*  95 */       if (BLOB_TYPES.contains(Integer.valueOf(rsmd.getColumnType(i)))) {
/*  96 */         this.blobColumns.add(Integer.valueOf(i));
/*     */       }
/*  98 */       String colname = rsmd.getColumnLabel(i);
/*  99 */       row.append(colname);
/* 100 */       if (i != columnCount) row.append(", ");
/*     */     }
/* 102 */     trace(row.toString(), false);
/*     */   }
/*     */   
/*     */   private void printColumnValues(int columnCount) throws SQLException {
/* 106 */     StringBuilder row = new StringBuilder();
/* 107 */     row.append("       Row: ");
/* 108 */     for (int i = 1; i <= columnCount; i++) {
/*     */       String colname;
/*     */       try { String colname;
/* 111 */         if (this.blobColumns.contains(Integer.valueOf(i))) {
/* 112 */           colname = "<<BLOB>>";
/*     */         } else {
/* 114 */           colname = this.rs.getString(i);
/*     */         }
/*     */       }
/*     */       catch (SQLException e) {
/* 118 */         colname = "<<Cannot Display>>";
/*     */       }
/* 120 */       row.append(colname);
/* 121 */       if (i != columnCount) row.append(", ");
/*     */     }
/* 123 */     trace(row.toString(), false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ResultSet newInstance(ResultSet rs, Log statementLog, int queryStack)
/*     */   {
/* 133 */     InvocationHandler handler = new ResultSetLogger(rs, statementLog, queryStack);
/* 134 */     ClassLoader cl = ResultSet.class.getClassLoader();
/* 135 */     return (ResultSet)Proxy.newProxyInstance(cl, new Class[] { ResultSet.class }, handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResultSet getRs()
/*     */   {
/* 144 */     return this.rs;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\logging\jdbc\ResultSetLogger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */