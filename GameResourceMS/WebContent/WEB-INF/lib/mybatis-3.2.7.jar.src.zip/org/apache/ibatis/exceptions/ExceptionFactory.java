/*    */ package org.apache.ibatis.exceptions;
/*    */ 
/*    */ import org.apache.ibatis.executor.ErrorContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExceptionFactory
/*    */ {
/*    */   public static RuntimeException wrapException(String message, Exception e)
/*    */   {
/* 26 */     return new PersistenceException(ErrorContext.instance().message(message).cause(e).toString(), e);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\exceptions\ExceptionFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */