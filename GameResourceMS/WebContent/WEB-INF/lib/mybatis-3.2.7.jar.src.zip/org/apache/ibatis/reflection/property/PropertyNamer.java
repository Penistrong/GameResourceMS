/*    */ package org.apache.ibatis.reflection.property;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.apache.ibatis.reflection.ReflectionException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyNamer
/*    */ {
/*    */   public static String methodToProperty(String name)
/*    */   {
/* 28 */     if (name.startsWith("is")) {
/* 29 */       name = name.substring(2);
/* 30 */     } else if ((name.startsWith("get")) || (name.startsWith("set"))) {
/* 31 */       name = name.substring(3);
/*    */     } else {
/* 33 */       throw new ReflectionException("Error parsing property name '" + name + "'.  Didn't start with 'is', 'get' or 'set'.");
/*    */     }
/*    */     
/* 36 */     if ((name.length() == 1) || ((name.length() > 1) && (!Character.isUpperCase(name.charAt(1))))) {
/* 37 */       name = name.substring(0, 1).toLowerCase(Locale.ENGLISH) + name.substring(1);
/*    */     }
/*    */     
/* 40 */     return name;
/*    */   }
/*    */   
/*    */   public static boolean isProperty(String name) {
/* 44 */     return (name.startsWith("get")) || (name.startsWith("set")) || (name.startsWith("is"));
/*    */   }
/*    */   
/*    */   public static boolean isGetter(String name) {
/* 48 */     return (name.startsWith("get")) || (name.startsWith("is"));
/*    */   }
/*    */   
/*    */   public static boolean isSetter(String name) {
/* 52 */     return name.startsWith("set");
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\property\PropertyNamer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */