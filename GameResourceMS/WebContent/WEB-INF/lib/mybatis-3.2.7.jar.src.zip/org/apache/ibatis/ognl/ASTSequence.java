/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTSequence
/*    */   extends SimpleNode
/*    */ {
/*    */   public ASTSequence(int id)
/*    */   {
/* 40 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTSequence(OgnlParser p, int id) {
/* 44 */     super(p, id);
/*    */   }
/*    */   
/*    */   public void jjtClose() {
/* 48 */     flattenTree();
/*    */   }
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException
/*    */   {
/* 53 */     Object result = null;
/* 54 */     for (int i = 0; i < this.children.length; i++) {
/* 55 */       result = this.children[i].getValue(context, source);
/*    */     }
/* 57 */     return result;
/*    */   }
/*    */   
/*    */   protected void setValueBody(OgnlContext context, Object target, Object value) throws OgnlException {
/* 61 */     int last = this.children.length - 1;
/* 62 */     for (int i = 0; i < last; i++) {
/* 63 */       this.children[i].getValue(context, target);
/*    */     }
/* 65 */     this.children[last].setValue(context, target, value);
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 70 */     String result = "";
/*    */     
/* 72 */     for (int i = 0; i < this.children.length; i++) {
/* 73 */       if (i > 0) {
/* 74 */         result = result + ", ";
/*    */       }
/* 76 */       result = result + this.children[i];
/*    */     }
/* 78 */     return result;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTSequence.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */