/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.sql.Blob;
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlobByteObjectArrayTypeHandler
/*    */   extends BaseTypeHandler<Byte[]>
/*    */ {
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, Byte[] parameter, JdbcType jdbcType)
/*    */     throws SQLException
/*    */   {
/* 29 */     ByteArrayInputStream bis = new ByteArrayInputStream(ByteArrayUtils.convertToPrimitiveArray(parameter));
/* 30 */     ps.setBinaryStream(i, bis, parameter.length);
/*    */   }
/*    */   
/*    */   public Byte[] getNullableResult(ResultSet rs, String columnName)
/*    */     throws SQLException
/*    */   {
/* 36 */     Blob blob = rs.getBlob(columnName);
/* 37 */     return getBytes(blob);
/*    */   }
/*    */   
/*    */   public Byte[] getNullableResult(ResultSet rs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 43 */     Blob blob = rs.getBlob(columnIndex);
/* 44 */     return getBytes(blob);
/*    */   }
/*    */   
/*    */   public Byte[] getNullableResult(CallableStatement cs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 50 */     Blob blob = cs.getBlob(columnIndex);
/* 51 */     return getBytes(blob);
/*    */   }
/*    */   
/*    */   private Byte[] getBytes(Blob blob) throws SQLException {
/* 55 */     Byte[] returnValue = null;
/* 56 */     if (blob != null) {
/* 57 */       returnValue = ByteArrayUtils.convertToObjectArray(blob.getBytes(1L, (int)blob.length()));
/*    */     }
/* 59 */     return returnValue;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\BlobByteObjectArrayTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */