/*     */ package org.apache.ibatis.parsing;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import org.w3c.dom.CharacterData;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XNode
/*     */ {
/*     */   private Node node;
/*     */   private String name;
/*     */   private String body;
/*     */   private Properties attributes;
/*     */   private Properties variables;
/*     */   private XPathParser xpathParser;
/*     */   
/*     */   public XNode(XPathParser xpathParser, Node node, Properties variables)
/*     */   {
/*  42 */     this.xpathParser = xpathParser;
/*  43 */     this.node = node;
/*  44 */     this.name = node.getNodeName();
/*  45 */     this.variables = variables;
/*  46 */     this.attributes = parseAttributes(node);
/*  47 */     this.body = parseBody(node);
/*     */   }
/*     */   
/*     */   public XNode newXNode(Node node) {
/*  51 */     return new XNode(this.xpathParser, node, this.variables);
/*     */   }
/*     */   
/*     */   public XNode getParent() {
/*  55 */     Node parent = this.node.getParentNode();
/*  56 */     if ((parent == null) || (!(parent instanceof Element))) {
/*  57 */       return null;
/*     */     }
/*  59 */     return new XNode(this.xpathParser, parent, this.variables);
/*     */   }
/*     */   
/*     */   public String getPath()
/*     */   {
/*  64 */     StringBuilder builder = new StringBuilder();
/*  65 */     Node current = this.node;
/*  66 */     while ((current != null) && ((current instanceof Element))) {
/*  67 */       if (current != this.node) {
/*  68 */         builder.insert(0, "/");
/*     */       }
/*  70 */       builder.insert(0, current.getNodeName());
/*  71 */       current = current.getParentNode();
/*     */     }
/*  73 */     return builder.toString();
/*     */   }
/*     */   
/*     */   public String getValueBasedIdentifier() {
/*  77 */     StringBuilder builder = new StringBuilder();
/*  78 */     XNode current = this;
/*  79 */     while (current != null) {
/*  80 */       if (current != this) {
/*  81 */         builder.insert(0, "_");
/*     */       }
/*  83 */       String value = current.getStringAttribute("id", current.getStringAttribute("value", current.getStringAttribute("property", null)));
/*     */       
/*     */ 
/*  86 */       if (value != null) {
/*  87 */         value = value.replace('.', '_');
/*  88 */         builder.insert(0, "]");
/*  89 */         builder.insert(0, value);
/*     */         
/*  91 */         builder.insert(0, "[");
/*     */       }
/*  93 */       builder.insert(0, current.getName());
/*  94 */       current = current.getParent();
/*     */     }
/*  96 */     return builder.toString();
/*     */   }
/*     */   
/*     */   public String evalString(String expression) {
/* 100 */     return this.xpathParser.evalString(this.node, expression);
/*     */   }
/*     */   
/*     */   public Boolean evalBoolean(String expression) {
/* 104 */     return this.xpathParser.evalBoolean(this.node, expression);
/*     */   }
/*     */   
/*     */   public Double evalDouble(String expression) {
/* 108 */     return this.xpathParser.evalDouble(this.node, expression);
/*     */   }
/*     */   
/*     */   public List<XNode> evalNodes(String expression) {
/* 112 */     return this.xpathParser.evalNodes(this.node, expression);
/*     */   }
/*     */   
/*     */   public XNode evalNode(String expression) {
/* 116 */     return this.xpathParser.evalNode(this.node, expression);
/*     */   }
/*     */   
/*     */   public Node getNode() {
/* 120 */     return this.node;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 124 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getStringBody() {
/* 128 */     return getStringBody(null);
/*     */   }
/*     */   
/*     */   public String getStringBody(String def) {
/* 132 */     if (this.body == null) {
/* 133 */       return def;
/*     */     }
/* 135 */     return this.body;
/*     */   }
/*     */   
/*     */   public Boolean getBooleanBody()
/*     */   {
/* 140 */     return getBooleanBody(null);
/*     */   }
/*     */   
/*     */   public Boolean getBooleanBody(Boolean def) {
/* 144 */     if (this.body == null) {
/* 145 */       return def;
/*     */     }
/* 147 */     return Boolean.valueOf(this.body);
/*     */   }
/*     */   
/*     */   public Integer getIntBody()
/*     */   {
/* 152 */     return getIntBody(null);
/*     */   }
/*     */   
/*     */   public Integer getIntBody(Integer def) {
/* 156 */     if (this.body == null) {
/* 157 */       return def;
/*     */     }
/* 159 */     return Integer.valueOf(Integer.parseInt(this.body));
/*     */   }
/*     */   
/*     */   public Long getLongBody()
/*     */   {
/* 164 */     return getLongBody(null);
/*     */   }
/*     */   
/*     */   public Long getLongBody(Long def) {
/* 168 */     if (this.body == null) {
/* 169 */       return def;
/*     */     }
/* 171 */     return Long.valueOf(Long.parseLong(this.body));
/*     */   }
/*     */   
/*     */   public Double getDoubleBody()
/*     */   {
/* 176 */     return getDoubleBody(null);
/*     */   }
/*     */   
/*     */   public Double getDoubleBody(Double def) {
/* 180 */     if (this.body == null) {
/* 181 */       return def;
/*     */     }
/* 183 */     return Double.valueOf(Double.parseDouble(this.body));
/*     */   }
/*     */   
/*     */   public Float getFloatBody()
/*     */   {
/* 188 */     return getFloatBody(null);
/*     */   }
/*     */   
/*     */   public Float getFloatBody(Float def) {
/* 192 */     if (this.body == null) {
/* 193 */       return def;
/*     */     }
/* 195 */     return Float.valueOf(Float.parseFloat(this.body));
/*     */   }
/*     */   
/*     */   public <T extends Enum<T>> T getEnumAttribute(Class<T> enumType, String name)
/*     */   {
/* 200 */     return getEnumAttribute(enumType, name, null);
/*     */   }
/*     */   
/*     */   public <T extends Enum<T>> T getEnumAttribute(Class<T> enumType, String name, T def) {
/* 204 */     String value = getStringAttribute(name);
/* 205 */     if (value == null) {
/* 206 */       return def;
/*     */     }
/* 208 */     return Enum.valueOf(enumType, value);
/*     */   }
/*     */   
/*     */   public String getStringAttribute(String name)
/*     */   {
/* 213 */     return getStringAttribute(name, null);
/*     */   }
/*     */   
/*     */   public String getStringAttribute(String name, String def) {
/* 217 */     String value = this.attributes.getProperty(name);
/* 218 */     if (value == null) {
/* 219 */       return def;
/*     */     }
/* 221 */     return value;
/*     */   }
/*     */   
/*     */   public Boolean getBooleanAttribute(String name)
/*     */   {
/* 226 */     return getBooleanAttribute(name, null);
/*     */   }
/*     */   
/*     */   public Boolean getBooleanAttribute(String name, Boolean def) {
/* 230 */     String value = this.attributes.getProperty(name);
/* 231 */     if (value == null) {
/* 232 */       return def;
/*     */     }
/* 234 */     return Boolean.valueOf(value);
/*     */   }
/*     */   
/*     */   public Integer getIntAttribute(String name)
/*     */   {
/* 239 */     return getIntAttribute(name, null);
/*     */   }
/*     */   
/*     */   public Integer getIntAttribute(String name, Integer def) {
/* 243 */     String value = this.attributes.getProperty(name);
/* 244 */     if (value == null) {
/* 245 */       return def;
/*     */     }
/* 247 */     return Integer.valueOf(Integer.parseInt(value));
/*     */   }
/*     */   
/*     */   public Long getLongAttribute(String name)
/*     */   {
/* 252 */     return getLongAttribute(name, null);
/*     */   }
/*     */   
/*     */   public Long getLongAttribute(String name, Long def) {
/* 256 */     String value = this.attributes.getProperty(name);
/* 257 */     if (value == null) {
/* 258 */       return def;
/*     */     }
/* 260 */     return Long.valueOf(Long.parseLong(value));
/*     */   }
/*     */   
/*     */   public Double getDoubleAttribute(String name)
/*     */   {
/* 265 */     return getDoubleAttribute(name, null);
/*     */   }
/*     */   
/*     */   public Double getDoubleAttribute(String name, Double def) {
/* 269 */     String value = this.attributes.getProperty(name);
/* 270 */     if (value == null) {
/* 271 */       return def;
/*     */     }
/* 273 */     return Double.valueOf(Double.parseDouble(value));
/*     */   }
/*     */   
/*     */   public Float getFloatAttribute(String name)
/*     */   {
/* 278 */     return getFloatAttribute(name, null);
/*     */   }
/*     */   
/*     */   public Float getFloatAttribute(String name, Float def) {
/* 282 */     String value = this.attributes.getProperty(name);
/* 283 */     if (value == null) {
/* 284 */       return def;
/*     */     }
/* 286 */     return Float.valueOf(Float.parseFloat(value));
/*     */   }
/*     */   
/*     */   public List<XNode> getChildren()
/*     */   {
/* 291 */     List<XNode> children = new ArrayList();
/* 292 */     NodeList nodeList = this.node.getChildNodes();
/* 293 */     if (nodeList != null) {
/* 294 */       int i = 0; for (int n = nodeList.getLength(); i < n; i++) {
/* 295 */         Node node = nodeList.item(i);
/* 296 */         if (node.getNodeType() == 1) {
/* 297 */           children.add(new XNode(this.xpathParser, node, this.variables));
/*     */         }
/*     */       }
/*     */     }
/* 301 */     return children;
/*     */   }
/*     */   
/*     */   public Properties getChildrenAsProperties() {
/* 305 */     Properties properties = new Properties();
/* 306 */     for (XNode child : getChildren()) {
/* 307 */       String name = child.getStringAttribute("name");
/* 308 */       String value = child.getStringAttribute("value");
/* 309 */       if ((name != null) && (value != null)) {
/* 310 */         properties.setProperty(name, value);
/*     */       }
/*     */     }
/* 313 */     return properties;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 317 */     StringBuilder builder = new StringBuilder();
/* 318 */     builder.append("<");
/* 319 */     builder.append(this.name);
/* 320 */     for (Map.Entry<Object, Object> entry : this.attributes.entrySet()) {
/* 321 */       builder.append(" ");
/* 322 */       builder.append(entry.getKey());
/* 323 */       builder.append("=\"");
/* 324 */       builder.append(entry.getValue());
/* 325 */       builder.append("\"");
/*     */     }
/* 327 */     List<XNode> children = getChildren();
/* 328 */     if (children.size() > 0) {
/* 329 */       builder.append(">\n");
/* 330 */       for (XNode node : children) {
/* 331 */         builder.append(node.toString());
/*     */       }
/* 333 */       builder.append("</");
/* 334 */       builder.append(this.name);
/* 335 */       builder.append(">");
/* 336 */     } else if (this.body != null) {
/* 337 */       builder.append(">");
/* 338 */       builder.append(this.body);
/* 339 */       builder.append("</");
/* 340 */       builder.append(this.name);
/* 341 */       builder.append(">");
/*     */     } else {
/* 343 */       builder.append("/>");
/*     */     }
/* 345 */     builder.append("\n");
/* 346 */     return builder.toString();
/*     */   }
/*     */   
/*     */   private Properties parseAttributes(Node n) {
/* 350 */     Properties attributes = new Properties();
/* 351 */     NamedNodeMap attributeNodes = n.getAttributes();
/* 352 */     if (attributeNodes != null) {
/* 353 */       for (int i = 0; i < attributeNodes.getLength(); i++) {
/* 354 */         Node attribute = attributeNodes.item(i);
/* 355 */         String value = PropertyParser.parse(attribute.getNodeValue(), this.variables);
/* 356 */         attributes.put(attribute.getNodeName(), value);
/*     */       }
/*     */     }
/* 359 */     return attributes;
/*     */   }
/*     */   
/*     */   private String parseBody(Node node) {
/* 363 */     String data = getBodyData(node);
/* 364 */     if (data == null) {
/* 365 */       NodeList children = node.getChildNodes();
/* 366 */       for (int i = 0; i < children.getLength(); i++) {
/* 367 */         Node child = children.item(i);
/* 368 */         data = getBodyData(child);
/* 369 */         if (data != null) break;
/*     */       }
/*     */     }
/* 372 */     return data;
/*     */   }
/*     */   
/*     */   private String getBodyData(Node child) {
/* 376 */     if ((child.getNodeType() == 4) || (child.getNodeType() == 3))
/*     */     {
/* 378 */       String data = ((CharacterData)child).getData();
/* 379 */       data = PropertyParser.parse(data, this.variables);
/* 380 */       return data;
/*     */     }
/* 382 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\parsing\XNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */