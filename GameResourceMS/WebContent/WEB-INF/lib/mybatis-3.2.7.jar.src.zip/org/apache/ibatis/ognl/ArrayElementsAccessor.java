/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import java.util.Enumeration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayElementsAccessor
/*    */   implements ElementsAccessor
/*    */ {
/*    */   public Enumeration getElements(Object target)
/*    */   {
/* 45 */     new Enumeration() { private int count;
/*    */       private int index;
/*    */       private final Object val$target;
/*    */       
/* 49 */       public boolean hasMoreElements() { return this.index < this.count; }
/*    */       
/*    */       public Object nextElement() {
/* 52 */         return Array.get(this.val$target, this.index++);
/*    */       }
/*    */     };
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ArrayElementsAccessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */