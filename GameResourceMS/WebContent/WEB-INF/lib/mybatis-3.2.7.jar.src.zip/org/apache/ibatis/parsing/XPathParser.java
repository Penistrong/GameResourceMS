/*     */ package org.apache.ibatis.parsing;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.xpath.XPath;
/*     */ import javax.xml.xpath.XPathConstants;
/*     */ import javax.xml.xpath.XPathFactory;
/*     */ import org.apache.ibatis.builder.BuilderException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XPathParser
/*     */ {
/*     */   private Document document;
/*     */   private boolean validation;
/*     */   private EntityResolver entityResolver;
/*     */   private Properties variables;
/*     */   private XPath xpath;
/*     */   
/*     */   public XPathParser(String xml)
/*     */   {
/*  54 */     commonConstructor(false, null, null);
/*  55 */     this.document = createDocument(new InputSource(new StringReader(xml)));
/*     */   }
/*     */   
/*     */   public XPathParser(Reader reader) {
/*  59 */     commonConstructor(false, null, null);
/*  60 */     this.document = createDocument(new InputSource(reader));
/*     */   }
/*     */   
/*     */   public XPathParser(InputStream inputStream) {
/*  64 */     commonConstructor(false, null, null);
/*  65 */     this.document = createDocument(new InputSource(inputStream));
/*     */   }
/*     */   
/*     */   public XPathParser(Document document) {
/*  69 */     commonConstructor(false, null, null);
/*  70 */     this.document = document;
/*     */   }
/*     */   
/*     */   public XPathParser(String xml, boolean validation) {
/*  74 */     commonConstructor(validation, null, null);
/*  75 */     this.document = createDocument(new InputSource(new StringReader(xml)));
/*     */   }
/*     */   
/*     */   public XPathParser(Reader reader, boolean validation) {
/*  79 */     commonConstructor(validation, null, null);
/*  80 */     this.document = createDocument(new InputSource(reader));
/*     */   }
/*     */   
/*     */   public XPathParser(InputStream inputStream, boolean validation) {
/*  84 */     commonConstructor(validation, null, null);
/*  85 */     this.document = createDocument(new InputSource(inputStream));
/*     */   }
/*     */   
/*     */   public XPathParser(Document document, boolean validation) {
/*  89 */     commonConstructor(validation, null, null);
/*  90 */     this.document = document;
/*     */   }
/*     */   
/*     */   public XPathParser(String xml, boolean validation, Properties variables) {
/*  94 */     commonConstructor(validation, variables, null);
/*  95 */     this.document = createDocument(new InputSource(new StringReader(xml)));
/*     */   }
/*     */   
/*     */   public XPathParser(Reader reader, boolean validation, Properties variables) {
/*  99 */     commonConstructor(validation, variables, null);
/* 100 */     this.document = createDocument(new InputSource(reader));
/*     */   }
/*     */   
/*     */   public XPathParser(InputStream inputStream, boolean validation, Properties variables) {
/* 104 */     commonConstructor(validation, variables, null);
/* 105 */     this.document = createDocument(new InputSource(inputStream));
/*     */   }
/*     */   
/*     */   public XPathParser(Document document, boolean validation, Properties variables) {
/* 109 */     commonConstructor(validation, variables, null);
/* 110 */     this.document = document;
/*     */   }
/*     */   
/*     */   public XPathParser(String xml, boolean validation, Properties variables, EntityResolver entityResolver) {
/* 114 */     commonConstructor(validation, variables, entityResolver);
/* 115 */     this.document = createDocument(new InputSource(new StringReader(xml)));
/*     */   }
/*     */   
/*     */   public XPathParser(Reader reader, boolean validation, Properties variables, EntityResolver entityResolver) {
/* 119 */     commonConstructor(validation, variables, entityResolver);
/* 120 */     this.document = createDocument(new InputSource(reader));
/*     */   }
/*     */   
/*     */   public XPathParser(InputStream inputStream, boolean validation, Properties variables, EntityResolver entityResolver) {
/* 124 */     commonConstructor(validation, variables, entityResolver);
/* 125 */     this.document = createDocument(new InputSource(inputStream));
/*     */   }
/*     */   
/*     */   public XPathParser(Document document, boolean validation, Properties variables, EntityResolver entityResolver) {
/* 129 */     commonConstructor(validation, variables, entityResolver);
/* 130 */     this.document = document;
/*     */   }
/*     */   
/*     */   public void setVariables(Properties variables) {
/* 134 */     this.variables = variables;
/*     */   }
/*     */   
/*     */   public String evalString(String expression) {
/* 138 */     return evalString(this.document, expression);
/*     */   }
/*     */   
/*     */   public String evalString(Object root, String expression) {
/* 142 */     String result = (String)evaluate(expression, root, XPathConstants.STRING);
/* 143 */     result = PropertyParser.parse(result, this.variables);
/* 144 */     return result;
/*     */   }
/*     */   
/*     */   public Boolean evalBoolean(String expression) {
/* 148 */     return evalBoolean(this.document, expression);
/*     */   }
/*     */   
/*     */   public Boolean evalBoolean(Object root, String expression) {
/* 152 */     return (Boolean)evaluate(expression, root, XPathConstants.BOOLEAN);
/*     */   }
/*     */   
/*     */   public Short evalShort(String expression) {
/* 156 */     return evalShort(this.document, expression);
/*     */   }
/*     */   
/*     */   public Short evalShort(Object root, String expression) {
/* 160 */     return Short.valueOf(evalString(root, expression));
/*     */   }
/*     */   
/*     */   public Integer evalInteger(String expression) {
/* 164 */     return evalInteger(this.document, expression);
/*     */   }
/*     */   
/*     */   public Integer evalInteger(Object root, String expression) {
/* 168 */     return Integer.valueOf(evalString(root, expression));
/*     */   }
/*     */   
/*     */   public Long evalLong(String expression) {
/* 172 */     return evalLong(this.document, expression);
/*     */   }
/*     */   
/*     */   public Long evalLong(Object root, String expression) {
/* 176 */     return Long.valueOf(evalString(root, expression));
/*     */   }
/*     */   
/*     */   public Float evalFloat(String expression) {
/* 180 */     return evalFloat(this.document, expression);
/*     */   }
/*     */   
/*     */   public Float evalFloat(Object root, String expression) {
/* 184 */     return Float.valueOf(evalString(root, expression));
/*     */   }
/*     */   
/*     */   public Double evalDouble(String expression) {
/* 188 */     return evalDouble(this.document, expression);
/*     */   }
/*     */   
/*     */   public Double evalDouble(Object root, String expression) {
/* 192 */     return (Double)evaluate(expression, root, XPathConstants.NUMBER);
/*     */   }
/*     */   
/*     */   public List<XNode> evalNodes(String expression) {
/* 196 */     return evalNodes(this.document, expression);
/*     */   }
/*     */   
/*     */   public List<XNode> evalNodes(Object root, String expression) {
/* 200 */     List<XNode> xnodes = new ArrayList();
/* 201 */     NodeList nodes = (NodeList)evaluate(expression, root, XPathConstants.NODESET);
/* 202 */     for (int i = 0; i < nodes.getLength(); i++) {
/* 203 */       xnodes.add(new XNode(this, nodes.item(i), this.variables));
/*     */     }
/* 205 */     return xnodes;
/*     */   }
/*     */   
/*     */   public XNode evalNode(String expression) {
/* 209 */     return evalNode(this.document, expression);
/*     */   }
/*     */   
/*     */   public XNode evalNode(Object root, String expression) {
/* 213 */     Node node = (Node)evaluate(expression, root, XPathConstants.NODE);
/* 214 */     if (node == null) {
/* 215 */       return null;
/*     */     }
/* 217 */     return new XNode(this, node, this.variables);
/*     */   }
/*     */   
/*     */   private Object evaluate(String expression, Object root, QName returnType) {
/*     */     try {
/* 222 */       return this.xpath.evaluate(expression, root, returnType);
/*     */     } catch (Exception e) {
/* 224 */       throw new BuilderException("Error evaluating XPath.  Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   private Document createDocument(InputSource inputSource)
/*     */   {
/*     */     try {
/* 231 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 232 */       factory.setValidating(this.validation);
/*     */       
/* 234 */       factory.setNamespaceAware(false);
/* 235 */       factory.setIgnoringComments(true);
/* 236 */       factory.setIgnoringElementContentWhitespace(false);
/* 237 */       factory.setCoalescing(false);
/* 238 */       factory.setExpandEntityReferences(true);
/*     */       
/* 240 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 241 */       builder.setEntityResolver(this.entityResolver);
/* 242 */       builder.setErrorHandler(new ErrorHandler() {
/*     */         public void error(SAXParseException exception) throws SAXException {
/* 244 */           throw exception;
/*     */         }
/*     */         
/*     */         public void fatalError(SAXParseException exception) throws SAXException {
/* 248 */           throw exception;
/*     */         }
/*     */         
/*     */         public void warning(SAXParseException exception) throws SAXException
/*     */         {}
/* 253 */       });
/* 254 */       return builder.parse(inputSource);
/*     */     } catch (Exception e) {
/* 256 */       throw new BuilderException("Error creating document instance.  Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   private void commonConstructor(boolean validation, Properties variables, EntityResolver entityResolver) {
/* 261 */     this.validation = validation;
/* 262 */     this.entityResolver = entityResolver;
/* 263 */     this.variables = variables;
/* 264 */     XPathFactory factory = XPathFactory.newInstance();
/* 265 */     this.xpath = factory.newXPath();
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\parsing\XPathParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */