/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTTest
/*    */   extends ExpressionNode
/*    */ {
/*    */   public ASTTest(int id)
/*    */   {
/* 40 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTTest(OgnlParser p, int id) {
/* 44 */     super(p, id);
/*    */   }
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException
/*    */   {
/* 49 */     Object test = this.children[0].getValue(context, source);
/* 50 */     int branch = OgnlOps.booleanValue(test) ? 1 : 2;
/* 51 */     return this.children[branch].getValue(context, source);
/*    */   }
/*    */   
/*    */   protected void setValueBody(OgnlContext context, Object target, Object value) throws OgnlException
/*    */   {
/* 56 */     Object test = this.children[0].getValue(context, target);
/* 57 */     int branch = OgnlOps.booleanValue(test) ? 1 : 2;
/* 58 */     this.children[branch].setValue(context, target, value);
/*    */   }
/*    */   
/*    */   public String getExpressionOperator(int index)
/*    */   {
/* 63 */     return index == 1 ? "?" : ":";
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTTest.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */