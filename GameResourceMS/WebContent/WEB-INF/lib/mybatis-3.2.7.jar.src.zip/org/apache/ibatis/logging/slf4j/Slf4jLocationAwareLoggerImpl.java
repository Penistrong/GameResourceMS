/*    */ package org.apache.ibatis.logging.slf4j;
/*    */ 
/*    */ import org.apache.ibatis.logging.Log;
/*    */ import org.slf4j.Marker;
/*    */ import org.slf4j.MarkerFactory;
/*    */ import org.slf4j.spi.LocationAwareLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Slf4jLocationAwareLoggerImpl
/*    */   implements Log
/*    */ {
/* 29 */   private static Marker MARKER = MarkerFactory.getMarker("MYBATIS");
/*    */   
/* 31 */   private static final String FQCN = Slf4jImpl.class.getName();
/*    */   private LocationAwareLogger logger;
/*    */   
/*    */   Slf4jLocationAwareLoggerImpl(LocationAwareLogger logger)
/*    */   {
/* 36 */     this.logger = logger;
/*    */   }
/*    */   
/*    */   public boolean isDebugEnabled() {
/* 40 */     return this.logger.isDebugEnabled();
/*    */   }
/*    */   
/*    */   public boolean isTraceEnabled() {
/* 44 */     return this.logger.isTraceEnabled();
/*    */   }
/*    */   
/*    */   public void error(String s, Throwable e) {
/* 48 */     this.logger.log(MARKER, FQCN, 40, s, null, e);
/*    */   }
/*    */   
/*    */   public void error(String s) {
/* 52 */     this.logger.log(MARKER, FQCN, 40, s, null, null);
/*    */   }
/*    */   
/*    */   public void debug(String s) {
/* 56 */     this.logger.log(MARKER, FQCN, 10, s, null, null);
/*    */   }
/*    */   
/*    */   public void trace(String s) {
/* 60 */     this.logger.log(MARKER, FQCN, 0, s, null, null);
/*    */   }
/*    */   
/*    */   public void warn(String s) {
/* 64 */     this.logger.log(MARKER, FQCN, 30, s, null, null);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\logging\slf4j\Slf4jLocationAwareLoggerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */