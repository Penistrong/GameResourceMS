/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BigDecimalTypeHandler
/*    */   extends BaseTypeHandler<BigDecimal>
/*    */ {
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, BigDecimal parameter, JdbcType jdbcType)
/*    */     throws SQLException
/*    */   {
/* 32 */     ps.setBigDecimal(i, parameter);
/*    */   }
/*    */   
/*    */   public BigDecimal getNullableResult(ResultSet rs, String columnName)
/*    */     throws SQLException
/*    */   {
/* 38 */     return rs.getBigDecimal(columnName);
/*    */   }
/*    */   
/*    */   public BigDecimal getNullableResult(ResultSet rs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 44 */     return rs.getBigDecimal(columnIndex);
/*    */   }
/*    */   
/*    */   public BigDecimal getNullableResult(CallableStatement cs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 50 */     return cs.getBigDecimal(columnIndex);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\BigDecimalTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */