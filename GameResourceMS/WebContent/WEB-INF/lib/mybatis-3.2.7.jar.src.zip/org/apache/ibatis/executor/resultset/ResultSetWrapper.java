/*     */ package org.apache.ibatis.executor.resultset;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.ibatis.io.Resources;
/*     */ import org.apache.ibatis.mapping.ResultMap;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.type.JdbcType;
/*     */ import org.apache.ibatis.type.ObjectTypeHandler;
/*     */ import org.apache.ibatis.type.TypeHandler;
/*     */ import org.apache.ibatis.type.TypeHandlerRegistry;
/*     */ import org.apache.ibatis.type.UnknownTypeHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ResultSetWrapper
/*     */ {
/*     */   private final ResultSet resultSet;
/*     */   private final TypeHandlerRegistry typeHandlerRegistry;
/*  45 */   private final List<String> columnNames = new ArrayList();
/*  46 */   private final List<String> classNames = new ArrayList();
/*  47 */   private final List<JdbcType> jdbcTypes = new ArrayList();
/*  48 */   private final Map<String, Map<Class<?>, TypeHandler<?>>> typeHandlerMap = new HashMap();
/*  49 */   private Map<String, List<String>> mappedColumnNamesMap = new HashMap();
/*  50 */   private Map<String, List<String>> unMappedColumnNamesMap = new HashMap();
/*     */   
/*     */   public ResultSetWrapper(ResultSet rs, Configuration configuration) throws SQLException
/*     */   {
/*  54 */     this.typeHandlerRegistry = configuration.getTypeHandlerRegistry();
/*  55 */     this.resultSet = rs;
/*  56 */     ResultSetMetaData metaData = rs.getMetaData();
/*  57 */     int columnCount = metaData.getColumnCount();
/*  58 */     for (int i = 1; i <= columnCount; i++) {
/*  59 */       this.columnNames.add(configuration.isUseColumnLabel() ? metaData.getColumnLabel(i) : metaData.getColumnName(i));
/*  60 */       this.jdbcTypes.add(JdbcType.forCode(metaData.getColumnType(i)));
/*  61 */       this.classNames.add(metaData.getColumnClassName(i));
/*     */     }
/*     */   }
/*     */   
/*     */   public ResultSet getResultSet() {
/*  66 */     return this.resultSet;
/*     */   }
/*     */   
/*     */   public List<String> getColumnNames() {
/*  70 */     return this.columnNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypeHandler<?> getTypeHandler(Class<?> propertyType, String columnName)
/*     */   {
/*  83 */     TypeHandler<?> handler = null;
/*  84 */     Map<Class<?>, TypeHandler<?>> columnHandlers = (Map)this.typeHandlerMap.get(columnName);
/*  85 */     if (columnHandlers == null) {
/*  86 */       columnHandlers = new HashMap();
/*  87 */       this.typeHandlerMap.put(columnName, columnHandlers);
/*     */     } else {
/*  89 */       handler = (TypeHandler)columnHandlers.get(propertyType);
/*     */     }
/*  91 */     if (handler == null) {
/*  92 */       handler = this.typeHandlerRegistry.getTypeHandler(propertyType);
/*     */       
/*     */ 
/*  95 */       if ((handler == null) || ((handler instanceof UnknownTypeHandler))) {
/*  96 */         int index = this.columnNames.indexOf(columnName);
/*  97 */         JdbcType jdbcType = (JdbcType)this.jdbcTypes.get(index);
/*  98 */         Class<?> javaType = resolveClass((String)this.classNames.get(index));
/*  99 */         if ((javaType != null) && (jdbcType != null)) {
/* 100 */           handler = this.typeHandlerRegistry.getTypeHandler(javaType, jdbcType);
/* 101 */         } else if (javaType != null) {
/* 102 */           handler = this.typeHandlerRegistry.getTypeHandler(javaType);
/* 103 */         } else if (jdbcType != null) {
/* 104 */           handler = this.typeHandlerRegistry.getTypeHandler(jdbcType);
/*     */         }
/*     */       }
/* 107 */       if ((handler == null) || ((handler instanceof UnknownTypeHandler))) {
/* 108 */         handler = new ObjectTypeHandler();
/*     */       }
/* 110 */       columnHandlers.put(propertyType, handler);
/*     */     }
/* 112 */     return handler;
/*     */   }
/*     */   
/*     */   private Class<?> resolveClass(String className) {
/*     */     try {
/* 117 */       return Resources.classForName(className);
/*     */     }
/*     */     catch (ClassNotFoundException e) {}
/* 120 */     return null;
/*     */   }
/*     */   
/*     */   private void loadMappedAndUnmappedColumnNames(ResultMap resultMap, String columnPrefix) throws SQLException
/*     */   {
/* 125 */     List<String> mappedColumnNames = new ArrayList();
/* 126 */     List<String> unmappedColumnNames = new ArrayList();
/* 127 */     String upperColumnPrefix = columnPrefix == null ? null : columnPrefix.toUpperCase(Locale.ENGLISH);
/* 128 */     Set<String> mappedColumns = prependPrefixes(resultMap.getMappedColumns(), upperColumnPrefix);
/* 129 */     for (String columnName : this.columnNames) {
/* 130 */       String upperColumnName = columnName.toUpperCase(Locale.ENGLISH);
/* 131 */       if (mappedColumns.contains(upperColumnName)) {
/* 132 */         mappedColumnNames.add(upperColumnName);
/*     */       } else {
/* 134 */         unmappedColumnNames.add(columnName);
/*     */       }
/*     */     }
/* 137 */     this.mappedColumnNamesMap.put(getMapKey(resultMap, columnPrefix), mappedColumnNames);
/* 138 */     this.unMappedColumnNamesMap.put(getMapKey(resultMap, columnPrefix), unmappedColumnNames);
/*     */   }
/*     */   
/*     */   public List<String> getMappedColumnNames(ResultMap resultMap, String columnPrefix) throws SQLException {
/* 142 */     List<String> mappedColumnNames = (List)this.mappedColumnNamesMap.get(getMapKey(resultMap, columnPrefix));
/* 143 */     if (mappedColumnNames == null) {
/* 144 */       loadMappedAndUnmappedColumnNames(resultMap, columnPrefix);
/* 145 */       mappedColumnNames = (List)this.mappedColumnNamesMap.get(getMapKey(resultMap, columnPrefix));
/*     */     }
/* 147 */     return mappedColumnNames;
/*     */   }
/*     */   
/*     */   public List<String> getUnmappedColumnNames(ResultMap resultMap, String columnPrefix) throws SQLException {
/* 151 */     List<String> unMappedColumnNames = (List)this.unMappedColumnNamesMap.get(getMapKey(resultMap, columnPrefix));
/* 152 */     if (unMappedColumnNames == null) {
/* 153 */       loadMappedAndUnmappedColumnNames(resultMap, columnPrefix);
/* 154 */       unMappedColumnNames = (List)this.unMappedColumnNamesMap.get(getMapKey(resultMap, columnPrefix));
/*     */     }
/* 156 */     return unMappedColumnNames;
/*     */   }
/*     */   
/*     */   private String getMapKey(ResultMap resultMap, String columnPrefix) {
/* 160 */     return resultMap.getId() + ":" + columnPrefix;
/*     */   }
/*     */   
/*     */   private Set<String> prependPrefixes(Set<String> columnNames, String prefix) {
/* 164 */     if ((columnNames == null) || (columnNames.isEmpty()) || (prefix == null) || (prefix.length() == 0)) {
/* 165 */       return columnNames;
/*     */     }
/* 167 */     Set<String> prefixed = new HashSet();
/* 168 */     for (String columnName : columnNames) {
/* 169 */       prefixed.add(prefix + columnName);
/*     */     }
/* 171 */     return prefixed;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\resultset\ResultSetWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */