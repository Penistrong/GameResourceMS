/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SimpleNode
/*     */   implements Node, Serializable
/*     */ {
/*     */   protected Node parent;
/*     */   protected Node[] children;
/*     */   protected int id;
/*     */   protected OgnlParser parser;
/*     */   private boolean constantValueCalculated;
/*     */   private boolean hasConstantValue;
/*     */   private Object constantValue;
/*     */   
/*     */   public SimpleNode(int i)
/*     */   {
/*  51 */     this.id = i;
/*     */   }
/*     */   
/*     */   public SimpleNode(OgnlParser p, int i) {
/*  55 */     this(i);
/*  56 */     this.parser = p;
/*     */   }
/*     */   
/*     */ 
/*     */   public void jjtOpen() {}
/*     */   
/*     */ 
/*     */   public void jjtClose() {}
/*     */   
/*  65 */   public void jjtSetParent(Node n) { this.parent = n; }
/*  66 */   public Node jjtGetParent() { return this.parent; }
/*     */   
/*     */   public void jjtAddChild(Node n, int i) {
/*  69 */     if (this.children == null) {
/*  70 */       this.children = new Node[i + 1];
/*  71 */     } else if (i >= this.children.length) {
/*  72 */       Node[] c = new Node[i + 1];
/*  73 */       System.arraycopy(this.children, 0, c, 0, this.children.length);
/*  74 */       this.children = c;
/*     */     }
/*  76 */     this.children[i] = n;
/*     */   }
/*     */   
/*     */   public Node jjtGetChild(int i) {
/*  80 */     return this.children[i];
/*     */   }
/*     */   
/*     */   public int jjtGetNumChildren() {
/*  84 */     return this.children == null ? 0 : this.children.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  93 */     return OgnlParserTreeConstants.jjtNodeName[this.id];
/*     */   }
/*     */   
/*     */   public String toString(String prefix) {
/*  97 */     return prefix + OgnlParserTreeConstants.jjtNodeName[this.id] + " " + toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public void dump(PrintWriter writer, String prefix)
/*     */   {
/* 103 */     writer.println(toString(prefix));
/* 104 */     if (this.children != null) {
/* 105 */       for (int i = 0; i < this.children.length; i++) {
/* 106 */         SimpleNode n = (SimpleNode)this.children[i];
/* 107 */         if (n != null) {
/* 108 */           n.dump(writer, prefix + "  ");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public int getIndexInParent()
/*     */   {
/* 116 */     int result = -1;
/*     */     
/* 118 */     if (this.parent != null) {
/* 119 */       int icount = this.parent.jjtGetNumChildren();
/*     */       
/* 121 */       for (int i = 0; i < icount; i++) {
/* 122 */         if (this.parent.jjtGetChild(i) == this) {
/* 123 */           result = i;
/* 124 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 128 */     return result;
/*     */   }
/*     */   
/*     */   public Node getNextSibling()
/*     */   {
/* 133 */     Node result = null;
/* 134 */     int i = getIndexInParent();
/*     */     
/* 136 */     if (i >= 0) {
/* 137 */       int icount = this.parent.jjtGetNumChildren();
/*     */       
/* 139 */       if (i < icount) {
/* 140 */         result = this.parent.jjtGetChild(i + 1);
/*     */       }
/*     */     }
/* 143 */     return result;
/*     */   }
/*     */   
/*     */   private static String getDepthString(int depth)
/*     */   {
/* 148 */     StringBuffer result = new StringBuffer("");
/*     */     
/* 150 */     while (depth > 0) {
/* 151 */       depth--;
/* 152 */       result.append("  ");
/*     */     }
/* 154 */     return new String(result);
/*     */   }
/*     */   
/*     */ 
/*     */   protected Object evaluateGetValueBody(OgnlContext context, Object source)
/*     */     throws OgnlException
/*     */   {
/* 161 */     context.setCurrentObject(source);
/* 162 */     context.setCurrentNode(this);
/* 163 */     if (!this.constantValueCalculated) {
/* 164 */       this.constantValueCalculated = true;
/* 165 */       this.hasConstantValue = isConstant(context);
/* 166 */       if (this.hasConstantValue) {
/* 167 */         this.constantValue = getValueBody(context, source);
/*     */       }
/*     */     }
/* 170 */     return this.hasConstantValue ? this.constantValue : getValueBody(context, source);
/*     */   }
/*     */   
/*     */   protected void evaluateSetValueBody(OgnlContext context, Object target, Object value) throws OgnlException
/*     */   {
/* 175 */     context.setCurrentObject(target);
/* 176 */     context.setCurrentNode(this);
/* 177 */     setValueBody(context, target, value);
/*     */   }
/*     */   
/*     */   public final Object getValue(OgnlContext context, Object source) throws OgnlException
/*     */   {
/* 182 */     if (context.getTraceEvaluations()) {
/* 183 */       EvaluationPool pool = OgnlRuntime.getEvaluationPool();
/* 184 */       Object result = null;
/* 185 */       Throwable evalException = null;
/* 186 */       Evaluation evaluation = pool.create(this, source);
/*     */       
/* 188 */       context.pushEvaluation(evaluation);
/*     */       try {
/* 190 */         result = evaluateGetValueBody(context, source);
/*     */       } catch (OgnlException ex) {
/* 192 */         evalException = ex;
/* 193 */         throw ex;
/*     */       } catch (RuntimeException ex) {
/* 195 */         evalException = ex;
/* 196 */         throw ex;
/*     */       } finally {
/* 198 */         Evaluation eval = context.popEvaluation();
/*     */         
/* 200 */         eval.setResult(result);
/* 201 */         if (evalException != null) {
/* 202 */           eval.setException(evalException);
/*     */         }
/* 204 */         if ((evalException == null) && (context.getRootEvaluation() == null) && (!context.getKeepLastEvaluation())) {
/* 205 */           pool.recycleAll(eval);
/*     */         }
/*     */       }
/* 208 */       return result;
/*     */     }
/* 210 */     return evaluateGetValueBody(context, source);
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract Object getValueBody(OgnlContext paramOgnlContext, Object paramObject)
/*     */     throws OgnlException;
/*     */   
/*     */   public final void setValue(OgnlContext context, Object target, Object value)
/*     */     throws OgnlException
/*     */   {
/* 220 */     if (context.getTraceEvaluations()) {
/* 221 */       EvaluationPool pool = OgnlRuntime.getEvaluationPool();
/* 222 */       Throwable evalException = null;
/* 223 */       Evaluation evaluation = pool.create(this, target, true);
/*     */       
/* 225 */       context.pushEvaluation(evaluation);
/*     */       try {
/* 227 */         evaluateSetValueBody(context, target, value);
/*     */       } catch (OgnlException ex) {
/* 229 */         evalException = ex;
/* 230 */         ex.setEvaluation(evaluation);
/* 231 */         throw ex;
/*     */       } catch (RuntimeException ex) {
/* 233 */         evalException = ex;
/* 234 */         throw ex;
/*     */       } finally {
/* 236 */         Evaluation eval = context.popEvaluation();
/*     */         
/* 238 */         if (evalException != null) {
/* 239 */           eval.setException(evalException);
/*     */         }
/* 241 */         if ((evalException == null) && (context.getRootEvaluation() == null) && (!context.getKeepLastEvaluation())) {
/* 242 */           pool.recycleAll(eval);
/*     */         }
/*     */       }
/*     */     } else {
/* 246 */       evaluateSetValueBody(context, target, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setValueBody(OgnlContext context, Object target, Object value)
/*     */     throws OgnlException
/*     */   {
/* 257 */     throw new InappropriateExpressionException(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isNodeConstant(OgnlContext context)
/*     */     throws OgnlException
/*     */   {
/* 265 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isConstant(OgnlContext context) throws OgnlException
/*     */   {
/* 270 */     return isNodeConstant(context);
/*     */   }
/*     */   
/*     */   public boolean isNodeSimpleProperty(OgnlContext context) throws OgnlException
/*     */   {
/* 275 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isSimpleProperty(OgnlContext context) throws OgnlException
/*     */   {
/* 280 */     return isNodeSimpleProperty(context);
/*     */   }
/*     */   
/*     */   public boolean isSimpleNavigationChain(OgnlContext context) throws OgnlException
/*     */   {
/* 285 */     return isSimpleProperty(context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void flattenTree()
/*     */   {
/* 293 */     boolean shouldFlatten = false;
/* 294 */     int newSize = 0;
/*     */     
/* 296 */     for (int i = 0; i < this.children.length; i++)
/* 297 */       if (this.children[i].getClass() == getClass()) {
/* 298 */         shouldFlatten = true;
/* 299 */         newSize += this.children[i].jjtGetNumChildren();
/*     */       }
/*     */       else {
/* 302 */         newSize++;
/*     */       }
/* 304 */     if (shouldFlatten)
/*     */     {
/* 306 */       Node[] newChildren = new Node[newSize];
/* 307 */       int j = 0;
/*     */       
/* 309 */       for (int i = 0; i < this.children.length; i++) {
/* 310 */         Node c = this.children[i];
/* 311 */         if (c.getClass() == getClass()) {
/* 312 */           for (int k = 0; k < c.jjtGetNumChildren(); k++) {
/* 313 */             newChildren[(j++)] = c.jjtGetChild(k);
/*     */           }
/*     */         } else {
/* 316 */           newChildren[(j++)] = c;
/*     */         }
/*     */       }
/* 319 */       if (j != newSize) {
/* 320 */         throw new Error("Assertion error: " + j + " != " + newSize);
/*     */       }
/* 322 */       this.children = newChildren;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\SimpleNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */