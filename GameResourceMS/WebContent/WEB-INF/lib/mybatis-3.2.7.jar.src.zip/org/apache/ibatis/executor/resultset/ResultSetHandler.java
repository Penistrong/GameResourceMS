package org.apache.ibatis.executor.resultset;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public abstract interface ResultSetHandler
{
  public abstract <E> List<E> handleResultSets(Statement paramStatement)
    throws SQLException;
  
  public abstract void handleOutputParameters(CallableStatement paramCallableStatement)
    throws SQLException;
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\resultset\ResultSetHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */