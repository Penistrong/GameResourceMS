package org.apache.ibatis.executor.statement;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import org.apache.ibatis.executor.parameter.ParameterHandler;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.session.ResultHandler;

public abstract interface StatementHandler
{
  public abstract Statement prepare(Connection paramConnection)
    throws SQLException;
  
  public abstract void parameterize(Statement paramStatement)
    throws SQLException;
  
  public abstract void batch(Statement paramStatement)
    throws SQLException;
  
  public abstract int update(Statement paramStatement)
    throws SQLException;
  
  public abstract <E> List<E> query(Statement paramStatement, ResultHandler paramResultHandler)
    throws SQLException;
  
  public abstract BoundSql getBoundSql();
  
  public abstract ParameterHandler getParameterHandler();
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\statement\StatementHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */