/*     */ package org.apache.ibatis.executor.loader.cglib;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import net.sf.cglib.proxy.Callback;
/*     */ import net.sf.cglib.proxy.Enhancer;
/*     */ import net.sf.cglib.proxy.MethodInterceptor;
/*     */ import net.sf.cglib.proxy.MethodProxy;
/*     */ import org.apache.ibatis.executor.loader.AbstractEnhancedDeserializationProxy;
/*     */ import org.apache.ibatis.executor.loader.AbstractSerialStateHolder;
/*     */ import org.apache.ibatis.executor.loader.ProxyFactory;
/*     */ import org.apache.ibatis.executor.loader.ResultLoaderMap;
/*     */ import org.apache.ibatis.executor.loader.ResultLoaderMap.LoadPair;
/*     */ import org.apache.ibatis.executor.loader.WriteReplaceInterface;
/*     */ import org.apache.ibatis.io.Resources;
/*     */ import org.apache.ibatis.logging.Log;
/*     */ import org.apache.ibatis.logging.LogFactory;
/*     */ import org.apache.ibatis.reflection.ExceptionUtil;
/*     */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*     */ import org.apache.ibatis.reflection.property.PropertyCopier;
/*     */ import org.apache.ibatis.reflection.property.PropertyNamer;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CglibProxyFactory
/*     */   implements ProxyFactory
/*     */ {
/*  48 */   private static final Log log = LogFactory.getLog(CglibProxyFactory.class);
/*     */   private static final String FINALIZE_METHOD = "finalize";
/*     */   private static final String WRITE_REPLACE_METHOD = "writeReplace";
/*     */   
/*     */   public CglibProxyFactory() {
/*     */     try {
/*  54 */       Resources.classForName("net.sf.cglib.proxy.Enhancer");
/*     */     } catch (Throwable e) {
/*  56 */       throw new IllegalStateException("Cannot enable lazy loading because CGLIB is not available. Add CGLIB to your classpath.", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object createProxy(Object target, ResultLoaderMap lazyLoader, Configuration configuration, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs) {
/*  61 */     return EnhancedResultObjectProxyImpl.createProxy(target, lazyLoader, configuration, objectFactory, constructorArgTypes, constructorArgs);
/*     */   }
/*     */   
/*     */   public Object createDeserializationProxy(Object target, Map<String, ResultLoaderMap.LoadPair> unloadedProperties, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs) {
/*  65 */     return EnhancedDeserializationProxyImpl.createProxy(target, unloadedProperties, objectFactory, constructorArgTypes, constructorArgs);
/*     */   }
/*     */   
/*     */   public void setProperties(Properties properties) {}
/*     */   
/*     */   private static Object crateProxy(Class<?> type, Callback callback, List<Class<?>> constructorArgTypes, List<Object> constructorArgs)
/*     */   {
/*  72 */     Enhancer enhancer = new Enhancer();
/*  73 */     enhancer.setCallback(callback);
/*  74 */     enhancer.setSuperclass(type);
/*     */     try {
/*  76 */       type.getDeclaredMethod("writeReplace", new Class[0]);
/*     */       
/*  78 */       log.debug("writeReplace method was found on bean " + type + ", make sure it returns this");
/*     */     } catch (NoSuchMethodException e) {
/*  80 */       enhancer.setInterfaces(new Class[] { WriteReplaceInterface.class });
/*     */     }
/*     */     catch (SecurityException e) {}
/*     */     
/*  84 */     Object enhanced = null;
/*  85 */     if (constructorArgTypes.isEmpty()) {
/*  86 */       enhanced = enhancer.create();
/*     */     } else {
/*  88 */       Class<?>[] typesArray = (Class[])constructorArgTypes.toArray(new Class[constructorArgTypes.size()]);
/*  89 */       Object[] valuesArray = constructorArgs.toArray(new Object[constructorArgs.size()]);
/*  90 */       enhanced = enhancer.create(typesArray, valuesArray);
/*     */     }
/*  92 */     return enhanced;
/*     */   }
/*     */   
/*     */   private static class EnhancedResultObjectProxyImpl implements MethodInterceptor
/*     */   {
/*     */     private Class<?> type;
/*     */     private ResultLoaderMap lazyLoader;
/*     */     private boolean aggressive;
/*     */     private Set<String> lazyLoadTriggerMethods;
/*     */     private ObjectFactory objectFactory;
/*     */     private List<Class<?>> constructorArgTypes;
/*     */     private List<Object> constructorArgs;
/*     */     
/*     */     private EnhancedResultObjectProxyImpl(Class<?> type, ResultLoaderMap lazyLoader, Configuration configuration, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs) {
/* 106 */       this.type = type;
/* 107 */       this.lazyLoader = lazyLoader;
/* 108 */       this.aggressive = configuration.isAggressiveLazyLoading();
/* 109 */       this.lazyLoadTriggerMethods = configuration.getLazyLoadTriggerMethods();
/* 110 */       this.objectFactory = objectFactory;
/* 111 */       this.constructorArgTypes = constructorArgTypes;
/* 112 */       this.constructorArgs = constructorArgs;
/*     */     }
/*     */     
/*     */     public static Object createProxy(Object target, ResultLoaderMap lazyLoader, Configuration configuration, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs) {
/* 116 */       Class<?> type = target.getClass();
/* 117 */       EnhancedResultObjectProxyImpl callback = new EnhancedResultObjectProxyImpl(type, lazyLoader, configuration, objectFactory, constructorArgTypes, constructorArgs);
/* 118 */       Object enhanced = CglibProxyFactory.crateProxy(type, callback, constructorArgTypes, constructorArgs);
/* 119 */       PropertyCopier.copyBeanProperties(type, target, enhanced);
/* 120 */       return enhanced;
/*     */     }
/*     */     
/*     */     public Object intercept(Object enhanced, Method method, Object[] args, MethodProxy methodProxy) throws Throwable {
/* 124 */       String methodName = method.getName();
/*     */       try {
/* 126 */         synchronized (this.lazyLoader) {
/* 127 */           if ("writeReplace".equals(methodName)) {
/* 128 */             Object original = null;
/* 129 */             if (this.constructorArgTypes.isEmpty()) {
/* 130 */               original = this.objectFactory.create(this.type);
/*     */             } else {
/* 132 */               original = this.objectFactory.create(this.type, this.constructorArgTypes, this.constructorArgs);
/*     */             }
/* 134 */             PropertyCopier.copyBeanProperties(this.type, enhanced, original);
/* 135 */             if (this.lazyLoader.size() > 0) {
/* 136 */               return new CglibSerialStateHolder(original, this.lazyLoader.getProperties(), this.objectFactory, this.constructorArgTypes, this.constructorArgs);
/*     */             }
/* 138 */             return original;
/*     */           }
/*     */           
/* 141 */           if ((this.lazyLoader.size() > 0) && (!"finalize".equals(methodName))) {
/* 142 */             if ((this.aggressive) || (this.lazyLoadTriggerMethods.contains(methodName))) {
/* 143 */               this.lazyLoader.loadAll();
/* 144 */             } else if (PropertyNamer.isProperty(methodName)) {
/* 145 */               String property = PropertyNamer.methodToProperty(methodName);
/* 146 */               if (this.lazyLoader.hasLoader(property)) {
/* 147 */                 this.lazyLoader.load(property);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 153 */         return methodProxy.invokeSuper(enhanced, args);
/*     */       } catch (Throwable t) {
/* 155 */         throw ExceptionUtil.unwrapThrowable(t);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class EnhancedDeserializationProxyImpl extends AbstractEnhancedDeserializationProxy implements MethodInterceptor
/*     */   {
/*     */     private EnhancedDeserializationProxyImpl(Class<?> type, Map<String, ResultLoaderMap.LoadPair> unloadedProperties, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs)
/*     */     {
/* 164 */       super(unloadedProperties, objectFactory, constructorArgTypes, constructorArgs);
/*     */     }
/*     */     
/*     */     public static Object createProxy(Object target, Map<String, ResultLoaderMap.LoadPair> unloadedProperties, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs)
/*     */     {
/* 169 */       Class<?> type = target.getClass();
/* 170 */       EnhancedDeserializationProxyImpl callback = new EnhancedDeserializationProxyImpl(type, unloadedProperties, objectFactory, constructorArgTypes, constructorArgs);
/* 171 */       Object enhanced = CglibProxyFactory.crateProxy(type, callback, constructorArgTypes, constructorArgs);
/* 172 */       PropertyCopier.copyBeanProperties(type, target, enhanced);
/* 173 */       return enhanced;
/*     */     }
/*     */     
/*     */     public Object intercept(Object enhanced, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*     */     {
/* 178 */       Object o = super.invoke(enhanced, method, args);
/* 179 */       return (o instanceof AbstractSerialStateHolder) ? o : methodProxy.invokeSuper(o, args);
/*     */     }
/*     */     
/*     */ 
/*     */     protected AbstractSerialStateHolder newSerialStateHolder(Object userBean, Map<String, ResultLoaderMap.LoadPair> unloadedProperties, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs)
/*     */     {
/* 185 */       return new CglibSerialStateHolder(userBean, unloadedProperties, objectFactory, constructorArgTypes, constructorArgs);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\loader\cglib\CglibProxyFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */