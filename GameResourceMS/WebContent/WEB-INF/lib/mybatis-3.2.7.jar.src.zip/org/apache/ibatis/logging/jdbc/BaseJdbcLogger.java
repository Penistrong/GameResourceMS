/*     */ package org.apache.ibatis.logging.jdbc;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.ibatis.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseJdbcLogger
/*     */ {
/*  37 */   protected static final Set<String> SET_METHODS = new HashSet();
/*  38 */   protected static final Set<String> EXECUTE_METHODS = new HashSet();
/*     */   
/*  40 */   private Map<Object, Object> columnMap = new HashMap();
/*     */   
/*  42 */   private List<Object> columnNames = new ArrayList();
/*  43 */   private List<Object> columnValues = new ArrayList();
/*     */   
/*     */   protected Log statementLog;
/*     */   
/*     */   protected int queryStack;
/*     */   
/*     */ 
/*     */   public BaseJdbcLogger(Log log, int queryStack)
/*     */   {
/*  52 */     this.statementLog = log;
/*  53 */     if (queryStack == 0) queryStack = 1;
/*  54 */     this.queryStack = queryStack;
/*     */   }
/*     */   
/*     */   static {
/*  58 */     SET_METHODS.add("setString");
/*  59 */     SET_METHODS.add("setInt");
/*  60 */     SET_METHODS.add("setByte");
/*  61 */     SET_METHODS.add("setShort");
/*  62 */     SET_METHODS.add("setLong");
/*  63 */     SET_METHODS.add("setDouble");
/*  64 */     SET_METHODS.add("setFloat");
/*  65 */     SET_METHODS.add("setTimestamp");
/*  66 */     SET_METHODS.add("setDate");
/*  67 */     SET_METHODS.add("setTime");
/*  68 */     SET_METHODS.add("setArray");
/*  69 */     SET_METHODS.add("setBigDecimal");
/*  70 */     SET_METHODS.add("setAsciiStream");
/*  71 */     SET_METHODS.add("setBinaryStream");
/*  72 */     SET_METHODS.add("setBlob");
/*  73 */     SET_METHODS.add("setBoolean");
/*  74 */     SET_METHODS.add("setBytes");
/*  75 */     SET_METHODS.add("setCharacterStream");
/*  76 */     SET_METHODS.add("setClob");
/*  77 */     SET_METHODS.add("setObject");
/*  78 */     SET_METHODS.add("setNull");
/*     */     
/*  80 */     EXECUTE_METHODS.add("execute");
/*  81 */     EXECUTE_METHODS.add("executeUpdate");
/*  82 */     EXECUTE_METHODS.add("executeQuery");
/*  83 */     EXECUTE_METHODS.add("addBatch");
/*     */   }
/*     */   
/*     */   protected void setColumn(Object key, Object value) {
/*  87 */     this.columnMap.put(key, value);
/*  88 */     this.columnNames.add(key);
/*  89 */     this.columnValues.add(value);
/*     */   }
/*     */   
/*     */   protected Object getColumn(Object key) {
/*  93 */     return this.columnMap.get(key);
/*     */   }
/*     */   
/*     */   protected String getParameterValueString() {
/*  97 */     List<Object> typeList = new ArrayList(this.columnValues.size());
/*  98 */     for (Object value : this.columnValues) {
/*  99 */       if (value == null) {
/* 100 */         typeList.add("null");
/*     */       } else {
/* 102 */         typeList.add(value + "(" + value.getClass().getSimpleName() + ")");
/*     */       }
/*     */     }
/* 105 */     String parameters = typeList.toString();
/* 106 */     return parameters.substring(1, parameters.length() - 1);
/*     */   }
/*     */   
/*     */   protected String getColumnString() {
/* 110 */     return this.columnNames.toString();
/*     */   }
/*     */   
/*     */   protected void clearColumnInfo() {
/* 114 */     this.columnMap.clear();
/* 115 */     this.columnNames.clear();
/* 116 */     this.columnValues.clear();
/*     */   }
/*     */   
/*     */   protected String removeBreakingWhitespace(String original) {
/* 120 */     StringTokenizer whitespaceStripper = new StringTokenizer(original);
/* 121 */     StringBuilder builder = new StringBuilder();
/* 122 */     while (whitespaceStripper.hasMoreTokens()) {
/* 123 */       builder.append(whitespaceStripper.nextToken());
/* 124 */       builder.append(" ");
/*     */     }
/* 126 */     return builder.toString();
/*     */   }
/*     */   
/*     */   protected boolean isDebugEnabled() {
/* 130 */     return this.statementLog.isDebugEnabled();
/*     */   }
/*     */   
/*     */   protected boolean isTraceEnabled() {
/* 134 */     return this.statementLog.isTraceEnabled();
/*     */   }
/*     */   
/*     */   protected void debug(String text, boolean input) {
/* 138 */     if (this.statementLog.isDebugEnabled()) {
/* 139 */       this.statementLog.debug(prefix(input) + text);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void trace(String text, boolean input) {
/* 144 */     if (this.statementLog.isTraceEnabled()) {
/* 145 */       this.statementLog.trace(prefix(input) + text);
/*     */     }
/*     */   }
/*     */   
/*     */   private String prefix(boolean isInput) {
/* 150 */     char[] buffer = new char[this.queryStack * 2 + 2];
/* 151 */     Arrays.fill(buffer, '=');
/* 152 */     buffer[(this.queryStack * 2 + 1)] = ' ';
/* 153 */     if (isInput) {
/* 154 */       buffer[(this.queryStack * 2)] = '>';
/*     */     } else {
/* 156 */       buffer[0] = '<';
/*     */     }
/* 158 */     return new String(buffer);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\logging\jdbc\BaseJdbcLogger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */