package org.apache.ibatis.type;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract interface TypeHandler<T>
{
  public abstract void setParameter(PreparedStatement paramPreparedStatement, int paramInt, T paramT, JdbcType paramJdbcType)
    throws SQLException;
  
  public abstract T getResult(ResultSet paramResultSet, String paramString)
    throws SQLException;
  
  public abstract T getResult(ResultSet paramResultSet, int paramInt)
    throws SQLException;
  
  public abstract T getResult(CallableStatement paramCallableStatement, int paramInt)
    throws SQLException;
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\TypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */