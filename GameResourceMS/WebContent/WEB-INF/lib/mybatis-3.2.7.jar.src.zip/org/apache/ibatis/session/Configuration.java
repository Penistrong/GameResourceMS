/*     */ package org.apache.ibatis.session;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.ibatis.binding.MapperRegistry;
/*     */ import org.apache.ibatis.builder.CacheRefResolver;
/*     */ import org.apache.ibatis.builder.ResultMapResolver;
/*     */ import org.apache.ibatis.builder.annotation.MethodResolver;
/*     */ import org.apache.ibatis.builder.xml.XMLStatementBuilder;
/*     */ import org.apache.ibatis.cache.Cache;
/*     */ import org.apache.ibatis.cache.decorators.FifoCache;
/*     */ import org.apache.ibatis.cache.decorators.LruCache;
/*     */ import org.apache.ibatis.cache.decorators.SoftCache;
/*     */ import org.apache.ibatis.cache.decorators.WeakCache;
/*     */ import org.apache.ibatis.cache.impl.PerpetualCache;
/*     */ import org.apache.ibatis.datasource.jndi.JndiDataSourceFactory;
/*     */ import org.apache.ibatis.datasource.pooled.PooledDataSourceFactory;
/*     */ import org.apache.ibatis.datasource.unpooled.UnpooledDataSourceFactory;
/*     */ import org.apache.ibatis.executor.BatchExecutor;
/*     */ import org.apache.ibatis.executor.CachingExecutor;
/*     */ import org.apache.ibatis.executor.Executor;
/*     */ import org.apache.ibatis.executor.ReuseExecutor;
/*     */ import org.apache.ibatis.executor.SimpleExecutor;
/*     */ import org.apache.ibatis.executor.keygen.KeyGenerator;
/*     */ import org.apache.ibatis.executor.loader.ProxyFactory;
/*     */ import org.apache.ibatis.executor.loader.cglib.CglibProxyFactory;
/*     */ import org.apache.ibatis.executor.loader.javassist.JavassistProxyFactory;
/*     */ import org.apache.ibatis.executor.parameter.ParameterHandler;
/*     */ import org.apache.ibatis.executor.resultset.DefaultResultSetHandler;
/*     */ import org.apache.ibatis.executor.resultset.ResultSetHandler;
/*     */ import org.apache.ibatis.executor.statement.RoutingStatementHandler;
/*     */ import org.apache.ibatis.executor.statement.StatementHandler;
/*     */ import org.apache.ibatis.logging.Log;
/*     */ import org.apache.ibatis.logging.LogFactory;
/*     */ import org.apache.ibatis.logging.commons.JakartaCommonsLoggingImpl;
/*     */ import org.apache.ibatis.logging.jdk14.Jdk14LoggingImpl;
/*     */ import org.apache.ibatis.logging.log4j.Log4jImpl;
/*     */ import org.apache.ibatis.logging.log4j2.Log4j2Impl;
/*     */ import org.apache.ibatis.logging.nologging.NoLoggingImpl;
/*     */ import org.apache.ibatis.logging.slf4j.Slf4jImpl;
/*     */ import org.apache.ibatis.logging.stdout.StdOutImpl;
/*     */ import org.apache.ibatis.mapping.BoundSql;
/*     */ import org.apache.ibatis.mapping.Discriminator;
/*     */ import org.apache.ibatis.mapping.Environment;
/*     */ import org.apache.ibatis.mapping.MappedStatement;
/*     */ import org.apache.ibatis.mapping.ParameterMap;
/*     */ import org.apache.ibatis.mapping.ResultMap;
/*     */ import org.apache.ibatis.mapping.VendorDatabaseIdProvider;
/*     */ import org.apache.ibatis.parsing.XNode;
/*     */ import org.apache.ibatis.plugin.Interceptor;
/*     */ import org.apache.ibatis.plugin.InterceptorChain;
/*     */ import org.apache.ibatis.reflection.MetaObject;
/*     */ import org.apache.ibatis.reflection.factory.DefaultObjectFactory;
/*     */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*     */ import org.apache.ibatis.reflection.wrapper.DefaultObjectWrapperFactory;
/*     */ import org.apache.ibatis.reflection.wrapper.ObjectWrapperFactory;
/*     */ import org.apache.ibatis.scripting.LanguageDriver;
/*     */ import org.apache.ibatis.scripting.LanguageDriverRegistry;
/*     */ import org.apache.ibatis.scripting.defaults.RawLanguageDriver;
/*     */ import org.apache.ibatis.scripting.xmltags.XMLLanguageDriver;
/*     */ import org.apache.ibatis.transaction.Transaction;
/*     */ import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;
/*     */ import org.apache.ibatis.transaction.managed.ManagedTransactionFactory;
/*     */ import org.apache.ibatis.type.JdbcType;
/*     */ import org.apache.ibatis.type.TypeAliasRegistry;
/*     */ import org.apache.ibatis.type.TypeHandlerRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Configuration
/*     */ {
/*     */   protected Environment environment;
/*  97 */   protected boolean safeRowBoundsEnabled = false;
/*  98 */   protected boolean safeResultHandlerEnabled = true;
/*  99 */   protected boolean mapUnderscoreToCamelCase = false;
/* 100 */   protected boolean aggressiveLazyLoading = true;
/* 101 */   protected boolean multipleResultSetsEnabled = true;
/* 102 */   protected boolean useGeneratedKeys = false;
/* 103 */   protected boolean useColumnLabel = true;
/* 104 */   protected boolean cacheEnabled = true;
/* 105 */   protected boolean callSettersOnNulls = false;
/*     */   protected String logPrefix;
/*     */   protected Class<? extends Log> logImpl;
/* 108 */   protected LocalCacheScope localCacheScope = LocalCacheScope.SESSION;
/* 109 */   protected JdbcType jdbcTypeForNull = JdbcType.OTHER;
/* 110 */   protected Set<String> lazyLoadTriggerMethods = new HashSet(Arrays.asList(new String[] { "equals", "clone", "hashCode", "toString" }));
/*     */   protected Integer defaultStatementTimeout;
/* 112 */   protected ExecutorType defaultExecutorType = ExecutorType.SIMPLE;
/* 113 */   protected AutoMappingBehavior autoMappingBehavior = AutoMappingBehavior.PARTIAL;
/*     */   
/* 115 */   protected Properties variables = new Properties();
/* 116 */   protected ObjectFactory objectFactory = new DefaultObjectFactory();
/* 117 */   protected ObjectWrapperFactory objectWrapperFactory = new DefaultObjectWrapperFactory();
/* 118 */   protected MapperRegistry mapperRegistry = new MapperRegistry(this);
/*     */   
/* 120 */   protected boolean lazyLoadingEnabled = false;
/*     */   
/*     */ 
/*     */   protected ProxyFactory proxyFactory;
/*     */   
/*     */ 
/*     */   protected String databaseId;
/*     */   
/*     */ 
/*     */   protected Class<?> configurationFactory;
/*     */   
/*     */ 
/* 132 */   protected final InterceptorChain interceptorChain = new InterceptorChain();
/* 133 */   protected final TypeHandlerRegistry typeHandlerRegistry = new TypeHandlerRegistry();
/* 134 */   protected final TypeAliasRegistry typeAliasRegistry = new TypeAliasRegistry();
/* 135 */   protected final LanguageDriverRegistry languageRegistry = new LanguageDriverRegistry();
/*     */   
/* 137 */   protected final Map<String, MappedStatement> mappedStatements = new StrictMap("Mapped Statements collection");
/* 138 */   protected final Map<String, Cache> caches = new StrictMap("Caches collection");
/* 139 */   protected final Map<String, ResultMap> resultMaps = new StrictMap("Result Maps collection");
/* 140 */   protected final Map<String, ParameterMap> parameterMaps = new StrictMap("Parameter Maps collection");
/* 141 */   protected final Map<String, KeyGenerator> keyGenerators = new StrictMap("Key Generators collection");
/*     */   
/* 143 */   protected final Set<String> loadedResources = new HashSet();
/* 144 */   protected final Map<String, XNode> sqlFragments = new StrictMap("XML fragments parsed from previous mappers");
/*     */   
/* 146 */   protected final Collection<XMLStatementBuilder> incompleteStatements = new LinkedList();
/* 147 */   protected final Collection<CacheRefResolver> incompleteCacheRefs = new LinkedList();
/* 148 */   protected final Collection<ResultMapResolver> incompleteResultMaps = new LinkedList();
/* 149 */   protected final Collection<MethodResolver> incompleteMethods = new LinkedList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */   protected final Map<String, String> cacheRefMap = new HashMap();
/*     */   
/*     */   public Configuration(Environment environment) {
/* 159 */     this();
/* 160 */     this.environment = environment;
/*     */   }
/*     */   
/*     */   public Configuration() {
/* 164 */     this.typeAliasRegistry.registerAlias("JDBC", JdbcTransactionFactory.class);
/* 165 */     this.typeAliasRegistry.registerAlias("MANAGED", ManagedTransactionFactory.class);
/*     */     
/* 167 */     this.typeAliasRegistry.registerAlias("JNDI", JndiDataSourceFactory.class);
/* 168 */     this.typeAliasRegistry.registerAlias("POOLED", PooledDataSourceFactory.class);
/* 169 */     this.typeAliasRegistry.registerAlias("UNPOOLED", UnpooledDataSourceFactory.class);
/*     */     
/* 171 */     this.typeAliasRegistry.registerAlias("PERPETUAL", PerpetualCache.class);
/* 172 */     this.typeAliasRegistry.registerAlias("FIFO", FifoCache.class);
/* 173 */     this.typeAliasRegistry.registerAlias("LRU", LruCache.class);
/* 174 */     this.typeAliasRegistry.registerAlias("SOFT", SoftCache.class);
/* 175 */     this.typeAliasRegistry.registerAlias("WEAK", WeakCache.class);
/*     */     
/* 177 */     this.typeAliasRegistry.registerAlias("DB_VENDOR", VendorDatabaseIdProvider.class);
/*     */     
/* 179 */     this.typeAliasRegistry.registerAlias("XML", XMLLanguageDriver.class);
/* 180 */     this.typeAliasRegistry.registerAlias("RAW", RawLanguageDriver.class);
/*     */     
/* 182 */     this.typeAliasRegistry.registerAlias("SLF4J", Slf4jImpl.class);
/* 183 */     this.typeAliasRegistry.registerAlias("COMMONS_LOGGING", JakartaCommonsLoggingImpl.class);
/* 184 */     this.typeAliasRegistry.registerAlias("LOG4J", Log4jImpl.class);
/* 185 */     this.typeAliasRegistry.registerAlias("LOG4J2", Log4j2Impl.class);
/* 186 */     this.typeAliasRegistry.registerAlias("JDK_LOGGING", Jdk14LoggingImpl.class);
/* 187 */     this.typeAliasRegistry.registerAlias("STDOUT_LOGGING", StdOutImpl.class);
/* 188 */     this.typeAliasRegistry.registerAlias("NO_LOGGING", NoLoggingImpl.class);
/*     */     
/* 190 */     this.typeAliasRegistry.registerAlias("CGLIB", CglibProxyFactory.class);
/* 191 */     this.typeAliasRegistry.registerAlias("JAVASSIST", JavassistProxyFactory.class);
/*     */     
/* 193 */     this.languageRegistry.setDefaultDriverClass(XMLLanguageDriver.class);
/* 194 */     this.languageRegistry.register(RawLanguageDriver.class);
/*     */   }
/*     */   
/*     */   public String getLogPrefix() {
/* 198 */     return this.logPrefix;
/*     */   }
/*     */   
/*     */   public void setLogPrefix(String logPrefix) {
/* 202 */     this.logPrefix = logPrefix;
/*     */   }
/*     */   
/*     */   public Class<? extends Log> getLogImpl() {
/* 206 */     return this.logImpl;
/*     */   }
/*     */   
/*     */   public void setLogImpl(Class<?> logImpl)
/*     */   {
/* 211 */     if (logImpl != null) {
/* 212 */       this.logImpl = logImpl;
/* 213 */       LogFactory.useCustomLogging(this.logImpl);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isCallSettersOnNulls() {
/* 218 */     return this.callSettersOnNulls;
/*     */   }
/*     */   
/*     */   public void setCallSettersOnNulls(boolean callSettersOnNulls) {
/* 222 */     this.callSettersOnNulls = callSettersOnNulls;
/*     */   }
/*     */   
/*     */   public String getDatabaseId() {
/* 226 */     return this.databaseId;
/*     */   }
/*     */   
/*     */   public void setDatabaseId(String databaseId) {
/* 230 */     this.databaseId = databaseId;
/*     */   }
/*     */   
/*     */   public Class<?> getConfigurationFactory() {
/* 234 */     return this.configurationFactory;
/*     */   }
/*     */   
/*     */   public void setConfigurationFactory(Class<?> configurationFactory) {
/* 238 */     this.configurationFactory = configurationFactory;
/*     */   }
/*     */   
/*     */   public boolean isSafeResultHandlerEnabled() {
/* 242 */     return this.safeResultHandlerEnabled;
/*     */   }
/*     */   
/*     */   public void setSafeResultHandlerEnabled(boolean safeResultHandlerEnabled) {
/* 246 */     this.safeResultHandlerEnabled = safeResultHandlerEnabled;
/*     */   }
/*     */   
/*     */   public boolean isSafeRowBoundsEnabled() {
/* 250 */     return this.safeRowBoundsEnabled;
/*     */   }
/*     */   
/*     */   public void setSafeRowBoundsEnabled(boolean safeRowBoundsEnabled) {
/* 254 */     this.safeRowBoundsEnabled = safeRowBoundsEnabled;
/*     */   }
/*     */   
/*     */   public boolean isMapUnderscoreToCamelCase() {
/* 258 */     return this.mapUnderscoreToCamelCase;
/*     */   }
/*     */   
/*     */   public void setMapUnderscoreToCamelCase(boolean mapUnderscoreToCamelCase) {
/* 262 */     this.mapUnderscoreToCamelCase = mapUnderscoreToCamelCase;
/*     */   }
/*     */   
/*     */   public void addLoadedResource(String resource) {
/* 266 */     this.loadedResources.add(resource);
/*     */   }
/*     */   
/*     */   public boolean isResourceLoaded(String resource) {
/* 270 */     return this.loadedResources.contains(resource);
/*     */   }
/*     */   
/*     */   public Environment getEnvironment() {
/* 274 */     return this.environment;
/*     */   }
/*     */   
/*     */   public void setEnvironment(Environment environment) {
/* 278 */     this.environment = environment;
/*     */   }
/*     */   
/*     */   public AutoMappingBehavior getAutoMappingBehavior() {
/* 282 */     return this.autoMappingBehavior;
/*     */   }
/*     */   
/*     */   public void setAutoMappingBehavior(AutoMappingBehavior autoMappingBehavior) {
/* 286 */     this.autoMappingBehavior = autoMappingBehavior;
/*     */   }
/*     */   
/*     */   public boolean isLazyLoadingEnabled() {
/* 290 */     return this.lazyLoadingEnabled;
/*     */   }
/*     */   
/*     */   public void setLazyLoadingEnabled(boolean lazyLoadingEnabled) {
/* 294 */     this.lazyLoadingEnabled = lazyLoadingEnabled;
/*     */   }
/*     */   
/*     */   public ProxyFactory getProxyFactory() {
/* 298 */     if (this.proxyFactory == null)
/*     */     {
/* 300 */       this.proxyFactory = new CglibProxyFactory();
/*     */     }
/* 302 */     return this.proxyFactory;
/*     */   }
/*     */   
/*     */   public void setProxyFactory(ProxyFactory proxyFactory) {
/* 306 */     this.proxyFactory = proxyFactory;
/*     */   }
/*     */   
/*     */   public boolean isAggressiveLazyLoading() {
/* 310 */     return this.aggressiveLazyLoading;
/*     */   }
/*     */   
/*     */   public void setAggressiveLazyLoading(boolean aggressiveLazyLoading) {
/* 314 */     this.aggressiveLazyLoading = aggressiveLazyLoading;
/*     */   }
/*     */   
/*     */   public boolean isMultipleResultSetsEnabled() {
/* 318 */     return this.multipleResultSetsEnabled;
/*     */   }
/*     */   
/*     */   public void setMultipleResultSetsEnabled(boolean multipleResultSetsEnabled) {
/* 322 */     this.multipleResultSetsEnabled = multipleResultSetsEnabled;
/*     */   }
/*     */   
/*     */   public Set<String> getLazyLoadTriggerMethods() {
/* 326 */     return this.lazyLoadTriggerMethods;
/*     */   }
/*     */   
/*     */   public void setLazyLoadTriggerMethods(Set<String> lazyLoadTriggerMethods) {
/* 330 */     this.lazyLoadTriggerMethods = lazyLoadTriggerMethods;
/*     */   }
/*     */   
/*     */   public boolean isUseGeneratedKeys() {
/* 334 */     return this.useGeneratedKeys;
/*     */   }
/*     */   
/*     */   public void setUseGeneratedKeys(boolean useGeneratedKeys) {
/* 338 */     this.useGeneratedKeys = useGeneratedKeys;
/*     */   }
/*     */   
/*     */   public ExecutorType getDefaultExecutorType() {
/* 342 */     return this.defaultExecutorType;
/*     */   }
/*     */   
/*     */   public void setDefaultExecutorType(ExecutorType defaultExecutorType) {
/* 346 */     this.defaultExecutorType = defaultExecutorType;
/*     */   }
/*     */   
/*     */   public boolean isCacheEnabled() {
/* 350 */     return this.cacheEnabled;
/*     */   }
/*     */   
/*     */   public void setCacheEnabled(boolean cacheEnabled) {
/* 354 */     this.cacheEnabled = cacheEnabled;
/*     */   }
/*     */   
/*     */   public Integer getDefaultStatementTimeout() {
/* 358 */     return this.defaultStatementTimeout;
/*     */   }
/*     */   
/*     */   public void setDefaultStatementTimeout(Integer defaultStatementTimeout) {
/* 362 */     this.defaultStatementTimeout = defaultStatementTimeout;
/*     */   }
/*     */   
/*     */   public boolean isUseColumnLabel() {
/* 366 */     return this.useColumnLabel;
/*     */   }
/*     */   
/*     */   public void setUseColumnLabel(boolean useColumnLabel) {
/* 370 */     this.useColumnLabel = useColumnLabel;
/*     */   }
/*     */   
/*     */   public LocalCacheScope getLocalCacheScope() {
/* 374 */     return this.localCacheScope;
/*     */   }
/*     */   
/*     */   public void setLocalCacheScope(LocalCacheScope localCacheScope) {
/* 378 */     this.localCacheScope = localCacheScope;
/*     */   }
/*     */   
/*     */   public JdbcType getJdbcTypeForNull() {
/* 382 */     return this.jdbcTypeForNull;
/*     */   }
/*     */   
/*     */   public void setJdbcTypeForNull(JdbcType jdbcTypeForNull) {
/* 386 */     this.jdbcTypeForNull = jdbcTypeForNull;
/*     */   }
/*     */   
/*     */   public Properties getVariables() {
/* 390 */     return this.variables;
/*     */   }
/*     */   
/*     */   public void setVariables(Properties variables) {
/* 394 */     this.variables = variables;
/*     */   }
/*     */   
/*     */   public TypeHandlerRegistry getTypeHandlerRegistry() {
/* 398 */     return this.typeHandlerRegistry;
/*     */   }
/*     */   
/*     */   public TypeAliasRegistry getTypeAliasRegistry() {
/* 402 */     return this.typeAliasRegistry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public MapperRegistry getMapperRegistry()
/*     */   {
/* 409 */     return this.mapperRegistry;
/*     */   }
/*     */   
/*     */   public ObjectFactory getObjectFactory() {
/* 413 */     return this.objectFactory;
/*     */   }
/*     */   
/*     */   public void setObjectFactory(ObjectFactory objectFactory) {
/* 417 */     this.objectFactory = objectFactory;
/*     */   }
/*     */   
/*     */   public ObjectWrapperFactory getObjectWrapperFactory() {
/* 421 */     return this.objectWrapperFactory;
/*     */   }
/*     */   
/*     */   public void setObjectWrapperFactory(ObjectWrapperFactory objectWrapperFactory) {
/* 425 */     this.objectWrapperFactory = objectWrapperFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Interceptor> getInterceptors()
/*     */   {
/* 432 */     return this.interceptorChain.getInterceptors();
/*     */   }
/*     */   
/*     */   public LanguageDriverRegistry getLanguageRegistry() {
/* 436 */     return this.languageRegistry;
/*     */   }
/*     */   
/*     */   public void setDefaultScriptingLanguage(Class<?> driver) {
/* 440 */     if (driver == null) {
/* 441 */       driver = XMLLanguageDriver.class;
/*     */     }
/* 443 */     getLanguageRegistry().setDefaultDriverClass(driver);
/*     */   }
/*     */   
/*     */   public LanguageDriver getDefaultScriptingLanuageInstance() {
/* 447 */     return this.languageRegistry.getDefaultDriver();
/*     */   }
/*     */   
/*     */   public MetaObject newMetaObject(Object object) {
/* 451 */     return MetaObject.forObject(object, this.objectFactory, this.objectWrapperFactory);
/*     */   }
/*     */   
/*     */   public ParameterHandler newParameterHandler(MappedStatement mappedStatement, Object parameterObject, BoundSql boundSql) {
/* 455 */     ParameterHandler parameterHandler = mappedStatement.getLang().createParameterHandler(mappedStatement, parameterObject, boundSql);
/* 456 */     parameterHandler = (ParameterHandler)this.interceptorChain.pluginAll(parameterHandler);
/* 457 */     return parameterHandler;
/*     */   }
/*     */   
/*     */   public ResultSetHandler newResultSetHandler(Executor executor, MappedStatement mappedStatement, RowBounds rowBounds, ParameterHandler parameterHandler, ResultHandler resultHandler, BoundSql boundSql)
/*     */   {
/* 462 */     ResultSetHandler resultSetHandler = new DefaultResultSetHandler(executor, mappedStatement, parameterHandler, resultHandler, boundSql, rowBounds);
/* 463 */     resultSetHandler = (ResultSetHandler)this.interceptorChain.pluginAll(resultSetHandler);
/* 464 */     return resultSetHandler;
/*     */   }
/*     */   
/*     */   public StatementHandler newStatementHandler(Executor executor, MappedStatement mappedStatement, Object parameterObject, RowBounds rowBounds, ResultHandler resultHandler, BoundSql boundSql) {
/* 468 */     StatementHandler statementHandler = new RoutingStatementHandler(executor, mappedStatement, parameterObject, rowBounds, resultHandler, boundSql);
/* 469 */     statementHandler = (StatementHandler)this.interceptorChain.pluginAll(statementHandler);
/* 470 */     return statementHandler;
/*     */   }
/*     */   
/*     */   public Executor newExecutor(Transaction transaction) {
/* 474 */     return newExecutor(transaction, this.defaultExecutorType);
/*     */   }
/*     */   
/*     */   public Executor newExecutor(Transaction transaction, ExecutorType executorType) {
/* 478 */     executorType = executorType == null ? this.defaultExecutorType : executorType;
/* 479 */     executorType = executorType == null ? ExecutorType.SIMPLE : executorType;
/*     */     Executor executor;
/* 481 */     if (ExecutorType.BATCH == executorType) {
/* 482 */       executor = new BatchExecutor(this, transaction); } else { Executor executor;
/* 483 */       if (ExecutorType.REUSE == executorType) {
/* 484 */         executor = new ReuseExecutor(this, transaction);
/*     */       } else
/* 486 */         executor = new SimpleExecutor(this, transaction);
/*     */     }
/* 488 */     if (this.cacheEnabled) {
/* 489 */       executor = new CachingExecutor(executor);
/*     */     }
/* 491 */     Executor executor = (Executor)this.interceptorChain.pluginAll(executor);
/* 492 */     return executor;
/*     */   }
/*     */   
/*     */   public void addKeyGenerator(String id, KeyGenerator keyGenerator) {
/* 496 */     this.keyGenerators.put(id, keyGenerator);
/*     */   }
/*     */   
/*     */   public Collection<String> getKeyGeneratorNames() {
/* 500 */     return this.keyGenerators.keySet();
/*     */   }
/*     */   
/*     */   public Collection<KeyGenerator> getKeyGenerators() {
/* 504 */     return this.keyGenerators.values();
/*     */   }
/*     */   
/*     */   public KeyGenerator getKeyGenerator(String id) {
/* 508 */     return (KeyGenerator)this.keyGenerators.get(id);
/*     */   }
/*     */   
/*     */   public boolean hasKeyGenerator(String id) {
/* 512 */     return this.keyGenerators.containsKey(id);
/*     */   }
/*     */   
/*     */   public void addCache(Cache cache) {
/* 516 */     this.caches.put(cache.getId(), cache);
/*     */   }
/*     */   
/*     */   public Collection<String> getCacheNames() {
/* 520 */     return this.caches.keySet();
/*     */   }
/*     */   
/*     */   public Collection<Cache> getCaches() {
/* 524 */     return this.caches.values();
/*     */   }
/*     */   
/*     */   public Cache getCache(String id) {
/* 528 */     return (Cache)this.caches.get(id);
/*     */   }
/*     */   
/*     */   public boolean hasCache(String id) {
/* 532 */     return this.caches.containsKey(id);
/*     */   }
/*     */   
/*     */   public void addResultMap(ResultMap rm) {
/* 536 */     this.resultMaps.put(rm.getId(), rm);
/* 537 */     checkLocallyForDiscriminatedNestedResultMaps(rm);
/* 538 */     checkGloballyForDiscriminatedNestedResultMaps(rm);
/*     */   }
/*     */   
/*     */   public Collection<String> getResultMapNames() {
/* 542 */     return this.resultMaps.keySet();
/*     */   }
/*     */   
/*     */   public Collection<ResultMap> getResultMaps() {
/* 546 */     return this.resultMaps.values();
/*     */   }
/*     */   
/*     */   public ResultMap getResultMap(String id) {
/* 550 */     return (ResultMap)this.resultMaps.get(id);
/*     */   }
/*     */   
/*     */   public boolean hasResultMap(String id) {
/* 554 */     return this.resultMaps.containsKey(id);
/*     */   }
/*     */   
/*     */   public void addParameterMap(ParameterMap pm) {
/* 558 */     this.parameterMaps.put(pm.getId(), pm);
/*     */   }
/*     */   
/*     */   public Collection<String> getParameterMapNames() {
/* 562 */     return this.parameterMaps.keySet();
/*     */   }
/*     */   
/*     */   public Collection<ParameterMap> getParameterMaps() {
/* 566 */     return this.parameterMaps.values();
/*     */   }
/*     */   
/*     */   public ParameterMap getParameterMap(String id) {
/* 570 */     return (ParameterMap)this.parameterMaps.get(id);
/*     */   }
/*     */   
/*     */   public boolean hasParameterMap(String id) {
/* 574 */     return this.parameterMaps.containsKey(id);
/*     */   }
/*     */   
/*     */   public void addMappedStatement(MappedStatement ms) {
/* 578 */     this.mappedStatements.put(ms.getId(), ms);
/*     */   }
/*     */   
/*     */   public Collection<String> getMappedStatementNames() {
/* 582 */     buildAllStatements();
/* 583 */     return this.mappedStatements.keySet();
/*     */   }
/*     */   
/*     */   public Collection<MappedStatement> getMappedStatements() {
/* 587 */     buildAllStatements();
/* 588 */     return this.mappedStatements.values();
/*     */   }
/*     */   
/*     */   public Collection<XMLStatementBuilder> getIncompleteStatements() {
/* 592 */     return this.incompleteStatements;
/*     */   }
/*     */   
/*     */   public void addIncompleteStatement(XMLStatementBuilder incompleteStatement) {
/* 596 */     this.incompleteStatements.add(incompleteStatement);
/*     */   }
/*     */   
/*     */   public Collection<CacheRefResolver> getIncompleteCacheRefs() {
/* 600 */     return this.incompleteCacheRefs;
/*     */   }
/*     */   
/*     */   public void addIncompleteCacheRef(CacheRefResolver incompleteCacheRef) {
/* 604 */     this.incompleteCacheRefs.add(incompleteCacheRef);
/*     */   }
/*     */   
/*     */   public Collection<ResultMapResolver> getIncompleteResultMaps() {
/* 608 */     return this.incompleteResultMaps;
/*     */   }
/*     */   
/*     */   public void addIncompleteResultMap(ResultMapResolver resultMapResolver) {
/* 612 */     this.incompleteResultMaps.add(resultMapResolver);
/*     */   }
/*     */   
/*     */   public void addIncompleteMethod(MethodResolver builder) {
/* 616 */     this.incompleteMethods.add(builder);
/*     */   }
/*     */   
/*     */   public Collection<MethodResolver> getIncompleteMethods() {
/* 620 */     return this.incompleteMethods;
/*     */   }
/*     */   
/*     */   public MappedStatement getMappedStatement(String id) {
/* 624 */     return getMappedStatement(id, true);
/*     */   }
/*     */   
/*     */   public MappedStatement getMappedStatement(String id, boolean validateIncompleteStatements) {
/* 628 */     if (validateIncompleteStatements) {
/* 629 */       buildAllStatements();
/*     */     }
/* 631 */     return (MappedStatement)this.mappedStatements.get(id);
/*     */   }
/*     */   
/*     */   public Map<String, XNode> getSqlFragments() {
/* 635 */     return this.sqlFragments;
/*     */   }
/*     */   
/*     */   public void addInterceptor(Interceptor interceptor) {
/* 639 */     this.interceptorChain.addInterceptor(interceptor);
/*     */   }
/*     */   
/*     */   public void addMappers(String packageName, Class<?> superType) {
/* 643 */     this.mapperRegistry.addMappers(packageName, superType);
/*     */   }
/*     */   
/*     */   public void addMappers(String packageName) {
/* 647 */     this.mapperRegistry.addMappers(packageName);
/*     */   }
/*     */   
/*     */   public <T> void addMapper(Class<T> type) {
/* 651 */     this.mapperRegistry.addMapper(type);
/*     */   }
/*     */   
/*     */   public <T> T getMapper(Class<T> type, SqlSession sqlSession) {
/* 655 */     return (T)this.mapperRegistry.getMapper(type, sqlSession);
/*     */   }
/*     */   
/*     */   public boolean hasMapper(Class<?> type) {
/* 659 */     return this.mapperRegistry.hasMapper(type);
/*     */   }
/*     */   
/*     */   public boolean hasStatement(String statementName) {
/* 663 */     return hasStatement(statementName, true);
/*     */   }
/*     */   
/*     */   public boolean hasStatement(String statementName, boolean validateIncompleteStatements) {
/* 667 */     if (validateIncompleteStatements) {
/* 668 */       buildAllStatements();
/*     */     }
/* 670 */     return this.mappedStatements.containsKey(statementName);
/*     */   }
/*     */   
/*     */   public void addCacheRef(String namespace, String referencedNamespace) {
/* 674 */     this.cacheRefMap.put(namespace, referencedNamespace);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void buildAllStatements()
/*     */   {
/* 683 */     if (!this.incompleteResultMaps.isEmpty()) {
/* 684 */       synchronized (this.incompleteResultMaps)
/*     */       {
/* 686 */         ((ResultMapResolver)this.incompleteResultMaps.iterator().next()).resolve();
/*     */       }
/*     */     }
/* 689 */     if (!this.incompleteCacheRefs.isEmpty()) {
/* 690 */       synchronized (this.incompleteCacheRefs)
/*     */       {
/* 692 */         ((CacheRefResolver)this.incompleteCacheRefs.iterator().next()).resolveCacheRef();
/*     */       }
/*     */     }
/* 695 */     if (!this.incompleteStatements.isEmpty()) {
/* 696 */       synchronized (this.incompleteStatements)
/*     */       {
/* 698 */         ((XMLStatementBuilder)this.incompleteStatements.iterator().next()).parseStatementNode();
/*     */       }
/*     */     }
/* 701 */     if (!this.incompleteMethods.isEmpty()) {
/* 702 */       synchronized (this.incompleteMethods)
/*     */       {
/* 704 */         ((MethodResolver)this.incompleteMethods.iterator().next()).resolve();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String extractNamespace(String statementId)
/*     */   {
/* 716 */     int lastPeriod = statementId.lastIndexOf('.');
/* 717 */     return lastPeriod > 0 ? statementId.substring(0, lastPeriod) : null;
/*     */   }
/*     */   
/*     */   protected void checkGloballyForDiscriminatedNestedResultMaps(ResultMap rm)
/*     */   {
/* 722 */     if (rm.hasNestedResultMaps()) {
/* 723 */       for (Map.Entry<String, ResultMap> entry : this.resultMaps.entrySet()) {
/* 724 */         Object value = entry.getValue();
/* 725 */         if ((value instanceof ResultMap)) {
/* 726 */           ResultMap entryResultMap = (ResultMap)value;
/* 727 */           if ((!entryResultMap.hasNestedResultMaps()) && (entryResultMap.getDiscriminator() != null)) {
/* 728 */             Collection<String> discriminatedResultMapNames = entryResultMap.getDiscriminator().getDiscriminatorMap().values();
/* 729 */             if (discriminatedResultMapNames.contains(rm.getId())) {
/* 730 */               entryResultMap.forceNestedResultMaps();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void checkLocallyForDiscriminatedNestedResultMaps(ResultMap rm)
/*     */   {
/* 740 */     if ((!rm.hasNestedResultMaps()) && (rm.getDiscriminator() != null)) {
/* 741 */       for (Map.Entry<String, String> entry : rm.getDiscriminator().getDiscriminatorMap().entrySet()) {
/* 742 */         String discriminatedResultMapName = (String)entry.getValue();
/* 743 */         if (hasResultMap(discriminatedResultMapName)) {
/* 744 */           ResultMap discriminatedResultMap = (ResultMap)this.resultMaps.get(discriminatedResultMapName);
/* 745 */           if (discriminatedResultMap.hasNestedResultMaps()) {
/* 746 */             rm.forceNestedResultMaps();
/* 747 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected static class StrictMap<V> extends HashMap<String, V>
/*     */   {
/*     */     private static final long serialVersionUID = -4950446264854982944L;
/*     */     private String name;
/*     */     
/*     */     public StrictMap(String name, int initialCapacity, float loadFactor) {
/* 760 */       super(loadFactor);
/* 761 */       this.name = name;
/*     */     }
/*     */     
/*     */     public StrictMap(String name, int initialCapacity) {
/* 765 */       super();
/* 766 */       this.name = name;
/*     */     }
/*     */     
/*     */     public StrictMap(String name)
/*     */     {
/* 771 */       this.name = name;
/*     */     }
/*     */     
/*     */     public StrictMap(String name, Map<String, ? extends V> m) {
/* 775 */       super();
/* 776 */       this.name = name;
/*     */     }
/*     */     
/*     */     public V put(String key, V value)
/*     */     {
/* 781 */       if (containsKey(key))
/* 782 */         throw new IllegalArgumentException(this.name + " already contains value for " + key);
/* 783 */       if (key.contains(".")) {
/* 784 */         String shortKey = getShortName(key);
/* 785 */         if (super.get(shortKey) == null) {
/* 786 */           super.put(shortKey, value);
/*     */         } else {
/* 788 */           super.put(shortKey, new Ambiguity(shortKey));
/*     */         }
/*     */       }
/* 791 */       return (V)super.put(key, value);
/*     */     }
/*     */     
/*     */     public V get(Object key) {
/* 795 */       V value = super.get(key);
/* 796 */       if (value == null) {
/* 797 */         throw new IllegalArgumentException(this.name + " does not contain value for " + key);
/*     */       }
/* 799 */       if ((value instanceof Ambiguity)) {
/* 800 */         throw new IllegalArgumentException(((Ambiguity)value).getSubject() + " is ambiguous in " + this.name + " (try using the full name including the namespace, or rename one of the entries)");
/*     */       }
/*     */       
/* 803 */       return value;
/*     */     }
/*     */     
/*     */     private String getShortName(String key) {
/* 807 */       String[] keyparts = key.split("\\.");
/* 808 */       String shortKey = keyparts[(keyparts.length - 1)];
/* 809 */       return shortKey;
/*     */     }
/*     */     
/*     */     protected static class Ambiguity {
/*     */       private String subject;
/*     */       
/*     */       public Ambiguity(String subject) {
/* 816 */         this.subject = subject;
/*     */       }
/*     */       
/*     */       public String getSubject() {
/* 820 */         return this.subject;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\session\Configuration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */