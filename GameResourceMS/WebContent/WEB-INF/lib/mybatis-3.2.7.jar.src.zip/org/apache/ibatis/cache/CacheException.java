/*    */ package org.apache.ibatis.cache;
/*    */ 
/*    */ import org.apache.ibatis.exceptions.PersistenceException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheException
/*    */   extends PersistenceException
/*    */ {
/*    */   private static final long serialVersionUID = -193202262468464650L;
/*    */   
/*    */   public CacheException() {}
/*    */   
/*    */   public CacheException(String message)
/*    */   {
/* 32 */     super(message);
/*    */   }
/*    */   
/*    */   public CacheException(String message, Throwable cause) {
/* 36 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public CacheException(Throwable cause) {
/* 40 */     super(cause);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\cache\CacheException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */