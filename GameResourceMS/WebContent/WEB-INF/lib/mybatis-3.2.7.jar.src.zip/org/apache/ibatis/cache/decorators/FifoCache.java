/*    */ package org.apache.ibatis.cache.decorators;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ import java.util.concurrent.locks.ReadWriteLock;
/*    */ import org.apache.ibatis.cache.Cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FifoCache
/*    */   implements Cache
/*    */ {
/*    */   private final Cache delegate;
/*    */   private LinkedList<Object> keyList;
/*    */   private int size;
/*    */   
/*    */   public FifoCache(Cache delegate)
/*    */   {
/* 35 */     this.delegate = delegate;
/* 36 */     this.keyList = new LinkedList();
/* 37 */     this.size = 1024;
/*    */   }
/*    */   
/*    */   public String getId()
/*    */   {
/* 42 */     return this.delegate.getId();
/*    */   }
/*    */   
/*    */   public int getSize()
/*    */   {
/* 47 */     return this.delegate.getSize();
/*    */   }
/*    */   
/*    */   public void setSize(int size) {
/* 51 */     this.size = size;
/*    */   }
/*    */   
/*    */   public void putObject(Object key, Object value)
/*    */   {
/* 56 */     cycleKeyList(key);
/* 57 */     this.delegate.putObject(key, value);
/*    */   }
/*    */   
/*    */   public Object getObject(Object key)
/*    */   {
/* 62 */     return this.delegate.getObject(key);
/*    */   }
/*    */   
/*    */   public Object removeObject(Object key)
/*    */   {
/* 67 */     return this.delegate.removeObject(key);
/*    */   }
/*    */   
/*    */   public void clear()
/*    */   {
/* 72 */     this.delegate.clear();
/* 73 */     this.keyList.clear();
/*    */   }
/*    */   
/*    */   public ReadWriteLock getReadWriteLock()
/*    */   {
/* 78 */     return null;
/*    */   }
/*    */   
/*    */   private void cycleKeyList(Object key) {
/* 82 */     this.keyList.addLast(key);
/* 83 */     if (this.keyList.size() > this.size) {
/* 84 */       Object oldestKey = this.keyList.removeFirst();
/* 85 */       this.delegate.removeObject(oldestKey);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\cache\decorators\FifoCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */