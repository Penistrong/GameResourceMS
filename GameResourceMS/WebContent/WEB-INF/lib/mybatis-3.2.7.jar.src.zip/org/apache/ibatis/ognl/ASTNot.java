/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTNot
/*    */   extends ExpressionNode
/*    */ {
/*    */   public ASTNot(int id)
/*    */   {
/* 40 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTNot(OgnlParser p, int id) {
/* 44 */     super(p, id);
/*    */   }
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException
/*    */   {
/* 49 */     return OgnlOps.booleanValue(this.children[0].getValue(context, source)) ? Boolean.FALSE : Boolean.TRUE;
/*    */   }
/*    */   
/*    */   public String getExpressionOperator(int index)
/*    */   {
/* 54 */     return "!";
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTNot.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */