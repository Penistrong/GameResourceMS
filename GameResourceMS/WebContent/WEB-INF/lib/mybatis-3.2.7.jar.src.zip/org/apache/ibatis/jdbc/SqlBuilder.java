/*     */ package org.apache.ibatis.jdbc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlBuilder
/*     */ {
/*  25 */   private static final ThreadLocal<SQL> localSQL = new ThreadLocal();
/*     */   
/*     */   static {
/*  28 */     BEGIN();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void RESET()
/*     */   {
/*  36 */     localSQL.set(new SQL());
/*     */   }
/*     */   
/*     */   public static void UPDATE(String table) {
/*  40 */     sql().UPDATE(table);
/*     */   }
/*     */   
/*     */   public static void SET(String sets) {
/*  44 */     sql().SET(sets);
/*     */   }
/*     */   
/*     */   public static String SQL() {
/*     */     try {
/*  49 */       return sql().toString();
/*     */     } finally {
/*  51 */       RESET();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void INSERT_INTO(String tableName) {
/*  56 */     sql().INSERT_INTO(tableName);
/*     */   }
/*     */   
/*     */   public static void VALUES(String columns, String values) {
/*  60 */     sql().VALUES(columns, values);
/*     */   }
/*     */   
/*     */   public static void SELECT(String columns) {
/*  64 */     sql().SELECT(columns);
/*     */   }
/*     */   
/*     */   public static void SELECT_DISTINCT(String columns) {
/*  68 */     sql().SELECT_DISTINCT(columns);
/*     */   }
/*     */   
/*     */   public static void DELETE_FROM(String table) {
/*  72 */     sql().DELETE_FROM(table);
/*     */   }
/*     */   
/*     */   public static void FROM(String table) {
/*  76 */     sql().FROM(table);
/*     */   }
/*     */   
/*     */   public static void JOIN(String join) {
/*  80 */     sql().JOIN(join);
/*     */   }
/*     */   
/*     */   public static void INNER_JOIN(String join) {
/*  84 */     sql().INNER_JOIN(join);
/*     */   }
/*     */   
/*     */   public static void LEFT_OUTER_JOIN(String join) {
/*  88 */     sql().LEFT_OUTER_JOIN(join);
/*     */   }
/*     */   
/*     */   public static void RIGHT_OUTER_JOIN(String join) {
/*  92 */     sql().RIGHT_OUTER_JOIN(join);
/*     */   }
/*     */   
/*     */   public static void OUTER_JOIN(String join) {
/*  96 */     sql().OUTER_JOIN(join);
/*     */   }
/*     */   
/*     */   public static void WHERE(String conditions) {
/* 100 */     sql().WHERE(conditions);
/*     */   }
/*     */   
/*     */   public static void OR() {
/* 104 */     sql().OR();
/*     */   }
/*     */   
/*     */   public static void AND() {
/* 108 */     sql().AND();
/*     */   }
/*     */   
/*     */   public static void GROUP_BY(String columns) {
/* 112 */     sql().GROUP_BY(columns);
/*     */   }
/*     */   
/*     */   public static void HAVING(String conditions) {
/* 116 */     sql().HAVING(conditions);
/*     */   }
/*     */   
/*     */   public static void ORDER_BY(String columns) {
/* 120 */     sql().ORDER_BY(columns);
/*     */   }
/*     */   
/*     */   private static SQL sql() {
/* 124 */     return (SQL)localSQL.get();
/*     */   }
/*     */   
/*     */   public static void BEGIN() {}
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\jdbc\SqlBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */