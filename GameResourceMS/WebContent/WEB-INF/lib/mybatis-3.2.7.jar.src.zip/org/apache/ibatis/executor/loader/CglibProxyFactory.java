package org.apache.ibatis.executor.loader;

@Deprecated
public class CglibProxyFactory
  extends org.apache.ibatis.executor.loader.cglib.CglibProxyFactory
{}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\loader\CglibProxyFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */