package org.apache.ibatis.cache;

import java.util.concurrent.locks.ReadWriteLock;

public abstract interface Cache
{
  public abstract String getId();
  
  public abstract void putObject(Object paramObject1, Object paramObject2);
  
  public abstract Object getObject(Object paramObject);
  
  public abstract Object removeObject(Object paramObject);
  
  public abstract void clear();
  
  public abstract int getSize();
  
  public abstract ReadWriteLock getReadWriteLock();
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\cache\Cache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */