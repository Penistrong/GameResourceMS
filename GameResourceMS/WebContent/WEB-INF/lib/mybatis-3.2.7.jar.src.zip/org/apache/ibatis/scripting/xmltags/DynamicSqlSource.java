/*    */ package org.apache.ibatis.scripting.xmltags;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import org.apache.ibatis.builder.SqlSourceBuilder;
/*    */ import org.apache.ibatis.mapping.BoundSql;
/*    */ import org.apache.ibatis.mapping.SqlSource;
/*    */ import org.apache.ibatis.session.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DynamicSqlSource
/*    */   implements SqlSource
/*    */ {
/*    */   private Configuration configuration;
/*    */   private SqlNode rootSqlNode;
/*    */   
/*    */   public DynamicSqlSource(Configuration configuration, SqlNode rootSqlNode)
/*    */   {
/* 34 */     this.configuration = configuration;
/* 35 */     this.rootSqlNode = rootSqlNode;
/*    */   }
/*    */   
/*    */   public BoundSql getBoundSql(Object parameterObject) {
/* 39 */     DynamicContext context = new DynamicContext(this.configuration, parameterObject);
/* 40 */     this.rootSqlNode.apply(context);
/* 41 */     SqlSourceBuilder sqlSourceParser = new SqlSourceBuilder(this.configuration);
/* 42 */     Class<?> parameterType = parameterObject == null ? Object.class : parameterObject.getClass();
/* 43 */     SqlSource sqlSource = sqlSourceParser.parse(context.getSql(), parameterType, context.getBindings());
/* 44 */     BoundSql boundSql = sqlSource.getBoundSql(parameterObject);
/* 45 */     for (Map.Entry<String, Object> entry : context.getBindings().entrySet()) {
/* 46 */       boundSql.setAdditionalParameter((String)entry.getKey(), entry.getValue());
/*    */     }
/* 48 */     return boundSql;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\xmltags\DynamicSqlSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */