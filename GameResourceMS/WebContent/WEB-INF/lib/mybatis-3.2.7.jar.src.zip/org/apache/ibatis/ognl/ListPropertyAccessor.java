/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListPropertyAccessor
/*     */   extends ObjectPropertyAccessor
/*     */   implements PropertyAccessor
/*     */ {
/*     */   public Object getProperty(Map context, Object target, Object name)
/*     */     throws OgnlException
/*     */   {
/*  46 */     List list = (List)target;
/*     */     
/*  48 */     if ((name instanceof String)) {
/*     */       Object result;
/*     */       Object result;
/*  51 */       if (name.equals("size")) {
/*  52 */         result = new Integer(list.size());
/*     */       } else { Object result;
/*  54 */         if (name.equals("iterator")) {
/*  55 */           result = list.iterator();
/*     */         } else { Object result;
/*  57 */           if (name.equals("isEmpty")) {
/*  58 */             result = list.isEmpty() ? Boolean.TRUE : Boolean.FALSE;
/*     */           } else {
/*  60 */             result = super.getProperty(context, target, name);
/*     */           }
/*     */         }
/*     */       }
/*  64 */       return result;
/*     */     }
/*     */     
/*  67 */     if ((name instanceof Number)) {
/*  68 */       return list.get(((Number)name).intValue());
/*     */     }
/*  70 */     if ((name instanceof DynamicSubscript))
/*     */     {
/*  72 */       int len = list.size();
/*  73 */       switch (((DynamicSubscript)name).getFlag()) {
/*     */       case 0: 
/*  75 */         return len > 0 ? list.get(0) : null;
/*  76 */       case 1:  return len > 0 ? list.get(len / 2) : null;
/*  77 */       case 2:  return len > 0 ? list.get(len - 1) : null;
/*  78 */       case 3:  return new ArrayList(list);
/*     */       }
/*     */       
/*     */     }
/*  82 */     throw new NoSuchPropertyException(target, name);
/*     */   }
/*     */   
/*     */   public void setProperty(Map context, Object target, Object name, Object value) throws OgnlException
/*     */   {
/*  87 */     if ((name instanceof String))
/*     */     {
/*  89 */       super.setProperty(context, target, name, value);
/*  90 */       return;
/*     */     }
/*     */     
/*  93 */     List list = (List)target;
/*     */     
/*  95 */     if ((name instanceof Number))
/*     */     {
/*  97 */       list.set(((Number)name).intValue(), value);
/*  98 */       return;
/*     */     }
/*     */     
/* 101 */     if ((name instanceof DynamicSubscript))
/*     */     {
/* 103 */       int len = list.size();
/* 104 */       switch (((DynamicSubscript)name).getFlag()) {
/*     */       case 0: 
/* 106 */         if (len > 0) list.set(0, value); return;
/* 107 */       case 1:  if (len > 0) list.set(len / 2, value); return;
/* 108 */       case 2:  if (len > 0) list.set(len - 1, value); return;
/*     */       
/*     */       case 3: 
/* 111 */         if (!(value instanceof Collection))
/* 112 */           throw new OgnlException("Value must be a collection");
/* 113 */         list.clear();
/* 114 */         list.addAll((Collection)value);
/* 115 */         return;
/*     */       }
/*     */       
/*     */     }
/*     */     
/* 120 */     throw new NoSuchPropertyException(target, name);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ListPropertyAccessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */