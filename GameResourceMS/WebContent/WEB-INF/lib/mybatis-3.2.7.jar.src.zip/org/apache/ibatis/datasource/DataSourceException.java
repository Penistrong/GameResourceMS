/*    */ package org.apache.ibatis.datasource;
/*    */ 
/*    */ import org.apache.ibatis.exceptions.PersistenceException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataSourceException
/*    */   extends PersistenceException
/*    */ {
/*    */   private static final long serialVersionUID = -5251396250407091334L;
/*    */   
/*    */   public DataSourceException() {}
/*    */   
/*    */   public DataSourceException(String message)
/*    */   {
/* 32 */     super(message);
/*    */   }
/*    */   
/*    */   public DataSourceException(String message, Throwable cause) {
/* 36 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public DataSourceException(Throwable cause) {
/* 40 */     super(cause);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\datasource\DataSourceException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */