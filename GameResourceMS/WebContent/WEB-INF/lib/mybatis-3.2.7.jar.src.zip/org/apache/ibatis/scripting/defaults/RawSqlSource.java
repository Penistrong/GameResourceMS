/*    */ package org.apache.ibatis.scripting.defaults;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import org.apache.ibatis.builder.SqlSourceBuilder;
/*    */ import org.apache.ibatis.mapping.BoundSql;
/*    */ import org.apache.ibatis.mapping.SqlSource;
/*    */ import org.apache.ibatis.scripting.xmltags.DynamicContext;
/*    */ import org.apache.ibatis.scripting.xmltags.SqlNode;
/*    */ import org.apache.ibatis.session.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RawSqlSource
/*    */   implements SqlSource
/*    */ {
/*    */   private final SqlSource sqlSource;
/*    */   
/*    */   public RawSqlSource(Configuration configuration, SqlNode rootSqlNode, Class<?> parameterType)
/*    */   {
/* 40 */     this(configuration, getSql(configuration, rootSqlNode), parameterType);
/*    */   }
/*    */   
/*    */   public RawSqlSource(Configuration configuration, String sql, Class<?> parameterType) {
/* 44 */     SqlSourceBuilder sqlSourceParser = new SqlSourceBuilder(configuration);
/* 45 */     Class<?> clazz = parameterType == null ? Object.class : parameterType;
/* 46 */     this.sqlSource = sqlSourceParser.parse(sql, clazz, new HashMap());
/*    */   }
/*    */   
/*    */   private static String getSql(Configuration configuration, SqlNode rootSqlNode) {
/* 50 */     DynamicContext context = new DynamicContext(configuration, null);
/* 51 */     rootSqlNode.apply(context);
/* 52 */     return context.getSql();
/*    */   }
/*    */   
/*    */   public BoundSql getBoundSql(Object parameterObject) {
/* 56 */     return this.sqlSource.getBoundSql(parameterObject);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\defaults\RawSqlSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */