/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum JdbcType
/*    */ {
/* 30 */   ARRAY(2003), 
/* 31 */   BIT(-7), 
/* 32 */   TINYINT(-6), 
/* 33 */   SMALLINT(5), 
/* 34 */   INTEGER(4), 
/* 35 */   BIGINT(-5), 
/* 36 */   FLOAT(6), 
/* 37 */   REAL(7), 
/* 38 */   DOUBLE(8), 
/* 39 */   NUMERIC(2), 
/* 40 */   DECIMAL(3), 
/* 41 */   CHAR(1), 
/* 42 */   VARCHAR(12), 
/* 43 */   LONGVARCHAR(-1), 
/* 44 */   DATE(91), 
/* 45 */   TIME(92), 
/* 46 */   TIMESTAMP(93), 
/* 47 */   BINARY(-2), 
/* 48 */   VARBINARY(-3), 
/* 49 */   LONGVARBINARY(-4), 
/* 50 */   NULL(0), 
/* 51 */   OTHER(1111), 
/* 52 */   BLOB(2004), 
/* 53 */   CLOB(2005), 
/* 54 */   BOOLEAN(16), 
/* 55 */   CURSOR(-10), 
/* 56 */   UNDEFINED(-2147482648), 
/* 57 */   NVARCHAR(-9), 
/* 58 */   NCHAR(-15), 
/* 59 */   NCLOB(2011), 
/* 60 */   STRUCT(2002);
/*    */   
/*    */   static {
/* 63 */     codeLookup = new HashMap();
/*    */     
/*    */ 
/* 66 */     for (JdbcType type : values())
/* 67 */       codeLookup.put(Integer.valueOf(type.TYPE_CODE), type);
/*    */   }
/*    */   
/*    */   public final int TYPE_CODE;
/*    */   private static Map<Integer, JdbcType> codeLookup;
/* 72 */   private JdbcType(int code) { this.TYPE_CODE = code; }
/*    */   
/*    */ 
/*    */   public static JdbcType forCode(int code) {
/* 76 */     return (JdbcType)codeLookup.get(Integer.valueOf(code));
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\JdbcType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */