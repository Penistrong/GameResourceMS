/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectNullHandler
/*    */   implements NullHandler
/*    */ {
/*    */   public Object nullMethodResult(Map context, Object target, String methodName, Object[] args)
/*    */   {
/* 46 */     return null;
/*    */   }
/*    */   
/*    */   public Object nullPropertyValue(Map context, Object target, Object property)
/*    */   {
/* 51 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ObjectNullHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */