/*     */ package org.apache.ibatis.transaction.jdbc;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.ibatis.logging.Log;
/*     */ import org.apache.ibatis.logging.LogFactory;
/*     */ import org.apache.ibatis.session.TransactionIsolationLevel;
/*     */ import org.apache.ibatis.transaction.Transaction;
/*     */ import org.apache.ibatis.transaction.TransactionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JdbcTransaction
/*     */   implements Transaction
/*     */ {
/*  42 */   private static final Log log = LogFactory.getLog(JdbcTransaction.class);
/*     */   protected Connection connection;
/*     */   protected DataSource dataSource;
/*     */   protected TransactionIsolationLevel level;
/*     */   protected boolean autoCommmit;
/*     */   
/*     */   public JdbcTransaction(DataSource ds, TransactionIsolationLevel desiredLevel, boolean desiredAutoCommit)
/*     */   {
/*  50 */     this.dataSource = ds;
/*  51 */     this.level = desiredLevel;
/*  52 */     this.autoCommmit = desiredAutoCommit;
/*     */   }
/*     */   
/*     */   public JdbcTransaction(Connection connection) {
/*  56 */     this.connection = connection;
/*     */   }
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/*  60 */     if (this.connection == null) {
/*  61 */       openConnection();
/*     */     }
/*  63 */     return this.connection;
/*     */   }
/*     */   
/*     */   public void commit() throws SQLException {
/*  67 */     if ((this.connection != null) && (!this.connection.getAutoCommit())) {
/*  68 */       if (log.isDebugEnabled()) {
/*  69 */         log.debug("Committing JDBC Connection [" + this.connection + "]");
/*     */       }
/*  71 */       this.connection.commit();
/*     */     }
/*     */   }
/*     */   
/*     */   public void rollback() throws SQLException {
/*  76 */     if ((this.connection != null) && (!this.connection.getAutoCommit())) {
/*  77 */       if (log.isDebugEnabled()) {
/*  78 */         log.debug("Rolling back JDBC Connection [" + this.connection + "]");
/*     */       }
/*  80 */       this.connection.rollback();
/*     */     }
/*     */   }
/*     */   
/*     */   public void close() throws SQLException {
/*  85 */     if (this.connection != null) {
/*  86 */       resetAutoCommit();
/*  87 */       if (log.isDebugEnabled()) {
/*  88 */         log.debug("Closing JDBC Connection [" + this.connection + "]");
/*     */       }
/*  90 */       this.connection.close();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void setDesiredAutoCommit(boolean desiredAutoCommit) {
/*     */     try {
/*  96 */       if (this.connection.getAutoCommit() != desiredAutoCommit) {
/*  97 */         if (log.isDebugEnabled()) {
/*  98 */           log.debug("Setting autocommit to " + desiredAutoCommit + " on JDBC Connection [" + this.connection + "]");
/*     */         }
/* 100 */         this.connection.setAutoCommit(desiredAutoCommit);
/*     */       }
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/* 105 */       throw new TransactionException("Error configuring AutoCommit.  Your driver may not support getAutoCommit() or setAutoCommit(). Requested setting: " + desiredAutoCommit + ".  Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void resetAutoCommit()
/*     */   {
/*     */     try
/*     */     {
/* 113 */       if (!this.connection.getAutoCommit())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 119 */         if (log.isDebugEnabled()) {
/* 120 */           log.debug("Resetting autocommit to true on JDBC Connection [" + this.connection + "]");
/*     */         }
/* 122 */         this.connection.setAutoCommit(true);
/*     */       }
/*     */     } catch (SQLException e) {
/* 125 */       log.debug("Error resetting autocommit to true before closing the connection.  Cause: " + e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void openConnection() throws SQLException
/*     */   {
/* 131 */     if (log.isDebugEnabled()) {
/* 132 */       log.debug("Opening JDBC Connection");
/*     */     }
/* 134 */     this.connection = this.dataSource.getConnection();
/* 135 */     if (this.level != null) {
/* 136 */       this.connection.setTransactionIsolation(this.level.getLevel());
/*     */     }
/* 138 */     setDesiredAutoCommit(this.autoCommmit);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\transaction\jdbc\JdbcTransaction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */