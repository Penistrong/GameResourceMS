/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetPropertyAccessor
/*    */   extends ObjectPropertyAccessor
/*    */   implements PropertyAccessor
/*    */ {
/*    */   public Object getProperty(Map context, Object target, Object name)
/*    */     throws OgnlException
/*    */   {
/* 46 */     Set set = (Set)target;
/*    */     
/* 48 */     if ((name instanceof String)) {
/*    */       Object result;
/*    */       Object result;
/* 51 */       if (name.equals("size")) {
/* 52 */         result = new Integer(set.size());
/*    */       } else { Object result;
/* 54 */         if (name.equals("iterator")) {
/* 55 */           result = set.iterator();
/*    */         } else { Object result;
/* 57 */           if (name.equals("isEmpty")) {
/* 58 */             result = set.isEmpty() ? Boolean.TRUE : Boolean.FALSE;
/*    */           } else {
/* 60 */             result = super.getProperty(context, target, name);
/*    */           }
/*    */         }
/*    */       }
/* 64 */       return result;
/*    */     }
/*    */     
/* 67 */     throw new NoSuchPropertyException(target, name);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\SetPropertyAccessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */