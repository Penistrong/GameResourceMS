/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Enumeration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CollectionElementsAccessor
/*    */   implements ElementsAccessor
/*    */ {
/*    */   public Enumeration getElements(Object target)
/*    */   {
/* 44 */     return new IteratorEnumeration(((Collection)target).iterator());
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\CollectionElementsAccessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */