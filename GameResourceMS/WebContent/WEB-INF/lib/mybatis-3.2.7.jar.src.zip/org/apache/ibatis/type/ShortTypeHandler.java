/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShortTypeHandler
/*    */   extends BaseTypeHandler<Short>
/*    */ {
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, Short parameter, JdbcType jdbcType)
/*    */     throws SQLException
/*    */   {
/* 31 */     ps.setShort(i, parameter.shortValue());
/*    */   }
/*    */   
/*    */   public Short getNullableResult(ResultSet rs, String columnName)
/*    */     throws SQLException
/*    */   {
/* 37 */     return Short.valueOf(rs.getShort(columnName));
/*    */   }
/*    */   
/*    */   public Short getNullableResult(ResultSet rs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 43 */     return Short.valueOf(rs.getShort(columnIndex));
/*    */   }
/*    */   
/*    */   public Short getNullableResult(CallableStatement cs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 49 */     return Short.valueOf(cs.getShort(columnIndex));
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\ShortTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */