/*    */ package org.apache.ibatis.builder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IncompleteElementException
/*    */   extends BuilderException
/*    */ {
/*    */   private static final long serialVersionUID = -3697292286890900315L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public IncompleteElementException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public IncompleteElementException(String message, Throwable cause)
/*    */   {
/* 29 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public IncompleteElementException(String message) {
/* 33 */     super(message);
/*    */   }
/*    */   
/*    */   public IncompleteElementException(Throwable cause) {
/* 37 */     super(cause);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\builder\IncompleteElementException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */