/*    */ package org.apache.ibatis.plugin;
/*    */ 
/*    */ import org.apache.ibatis.exceptions.PersistenceException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PluginException
/*    */   extends PersistenceException
/*    */ {
/*    */   private static final long serialVersionUID = 8548771664564998595L;
/*    */   
/*    */   public PluginException() {}
/*    */   
/*    */   public PluginException(String message)
/*    */   {
/* 32 */     super(message);
/*    */   }
/*    */   
/*    */   public PluginException(String message, Throwable cause) {
/* 36 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public PluginException(Throwable cause) {
/* 40 */     super(cause);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\plugin\PluginException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */