/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Enumeration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class OgnlOps
/*     */   implements NumericTypes
/*     */ {
/*     */   public static int compareWithConversion(Object v1, Object v2)
/*     */   {
/*  69 */     return compareWithConversion(v1, v2, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int compareWithConversion(Object v1, Object v2, boolean equals)
/*     */   {
/*     */     int result;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  98 */     if (v1 == v2) {
/*  99 */       result = 0;
/*     */     } else {
/* 101 */       int t1 = getNumericType(v1);
/* 102 */       int t2 = getNumericType(v2);
/* 103 */       int type = getNumericType(t1, t2, true);
/*     */       int result;
/* 105 */       int result; switch (type) {
/*     */       case 6: 
/* 107 */         result = bigIntValue(v1).compareTo(bigIntValue(v2));
/* 108 */         break;
/*     */       
/*     */       case 9: 
/* 111 */         result = bigDecValue(v1).compareTo(bigDecValue(v2));
/* 112 */         break;
/*     */       
/*     */       case 10: 
/* 115 */         if ((t1 == 10) && (t2 == 10)) { int result;
/* 116 */           if ((v1 == null) || (v2 == null)) {
/* 117 */             result = v1 == v2 ? 0 : 1;
/*     */           } else {
/* 119 */             if ((v1.getClass().isAssignableFrom(v2.getClass())) || (v2.getClass().isAssignableFrom(v1.getClass()))) {
/* 120 */               if ((v1 instanceof Comparable)) {
/* 121 */                 int result = ((Comparable)v1).compareTo(v2);
/* 122 */                 return result;
/*     */               }
/* 124 */               if (equals) {
/* 125 */                 int result = v1.equals(v2) ? 0 : 1;
/* 126 */                 return result;
/*     */               }
/*     */             }
/*     */             
/* 130 */             if (equals)
/*     */             {
/*     */ 
/* 133 */               int result = 1;
/* 134 */               return result;
/*     */             }
/* 136 */             throw new IllegalArgumentException("invalid comparison: " + v1.getClass().getName() + " and " + v2.getClass().getName());
/*     */           }
/*     */         }
/*     */       
/*     */ 
/*     */       case 7: 
/*     */       case 8: 
/* 143 */         double dv1 = doubleValue(v1);
/* 144 */         double dv2 = doubleValue(v2);
/*     */         
/* 146 */         return dv1 < dv2 ? -1 : dv1 == dv2 ? 0 : 1;
/*     */       }
/*     */       
/* 149 */       long lv1 = longValue(v1);
/* 150 */       long lv2 = longValue(v2);
/*     */       
/* 152 */       return lv1 < lv2 ? -1 : lv1 == lv2 ? 0 : 1;
/*     */     }
/*     */     int result;
/* 155 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isEqual(Object object1, Object object2)
/*     */   {
/* 170 */     boolean result = false;
/*     */     
/* 172 */     if (object1 == object2) {
/* 173 */       result = true;
/*     */     }
/* 175 */     else if ((object1 != null) && (object2 != null)) {
/* 176 */       if ((object1.getClass().isArray()) && (object2.getClass().isArray()) && (object2.getClass() == object1.getClass())) {
/* 177 */         result = Array.getLength(object1) == Array.getLength(object2);
/* 178 */         if (result) {
/* 179 */           int i = 0;int icount = Array.getLength(object1);
/* 180 */           do { result = isEqual(Array.get(object1, i), Array.get(object2, i));i++;
/* 179 */             if (!result) break; } while (i < icount);
/*     */         }
/*     */         
/*     */ 
/*     */       }
/* 184 */       else if ((object1 != null) && (object2 != null))
/*     */       {
/* 186 */         result = (compareWithConversion(object1, object2, true) == 0) || (object1.equals(object2));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 191 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean booleanValue(Object value)
/*     */   {
/* 204 */     if (value == null)
/* 205 */       return false;
/* 206 */     Class c = value.getClass();
/* 207 */     if (c == Boolean.class) {
/* 208 */       return ((Boolean)value).booleanValue();
/*     */     }
/*     */     
/* 211 */     if (c == Character.class)
/* 212 */       return ((Character)value).charValue() != 0;
/* 213 */     if ((value instanceof Number))
/* 214 */       return ((Number)value).doubleValue() != 0.0D;
/* 215 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long longValue(Object value)
/*     */     throws NumberFormatException
/*     */   {
/* 227 */     if (value == null)
/* 228 */       return 0L;
/* 229 */     Class c = value.getClass();
/* 230 */     if (c.getSuperclass() == Number.class)
/* 231 */       return ((Number)value).longValue();
/* 232 */     if (c == Boolean.class)
/* 233 */       return ((Boolean)value).booleanValue() ? 1 : 0;
/* 234 */     if (c == Character.class)
/* 235 */       return ((Character)value).charValue();
/* 236 */     return Long.parseLong(stringValue(value, true));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double doubleValue(Object value)
/*     */     throws NumberFormatException
/*     */   {
/* 248 */     if (value == null)
/* 249 */       return 0.0D;
/* 250 */     Class c = value.getClass();
/* 251 */     if (c.getSuperclass() == Number.class)
/* 252 */       return ((Number)value).doubleValue();
/* 253 */     if (c == Boolean.class)
/* 254 */       return ((Boolean)value).booleanValue() ? 1 : 0;
/* 255 */     if (c == Character.class)
/* 256 */       return ((Character)value).charValue();
/* 257 */     String s = stringValue(value, true);
/*     */     
/* 259 */     return s.length() == 0 ? 0.0D : Double.parseDouble(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BigInteger bigIntValue(Object value)
/*     */     throws NumberFormatException
/*     */   {
/* 275 */     if (value == null)
/* 276 */       return BigInteger.valueOf(0L);
/* 277 */     Class c = value.getClass();
/* 278 */     if (c == BigInteger.class)
/* 279 */       return (BigInteger)value;
/* 280 */     if (c == BigDecimal.class)
/* 281 */       return ((BigDecimal)value).toBigInteger();
/* 282 */     if (c.getSuperclass() == Number.class)
/* 283 */       return BigInteger.valueOf(((Number)value).longValue());
/* 284 */     if (c == Boolean.class)
/* 285 */       return BigInteger.valueOf(((Boolean)value).booleanValue() ? 1 : 0);
/* 286 */     if (c == Character.class)
/* 287 */       return BigInteger.valueOf(((Character)value).charValue());
/* 288 */     return new BigInteger(stringValue(value, true));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BigDecimal bigDecValue(Object value)
/*     */     throws NumberFormatException
/*     */   {
/* 300 */     if (value == null)
/* 301 */       return BigDecimal.valueOf(0L);
/* 302 */     Class c = value.getClass();
/* 303 */     if (c == BigDecimal.class)
/* 304 */       return (BigDecimal)value;
/* 305 */     if (c == BigInteger.class)
/* 306 */       return new BigDecimal((BigInteger)value);
/* 307 */     if (c.getSuperclass() == Number.class)
/* 308 */       return new BigDecimal(((Number)value).doubleValue());
/* 309 */     if (c == Boolean.class)
/* 310 */       return BigDecimal.valueOf(((Boolean)value).booleanValue() ? 1 : 0);
/* 311 */     if (c == Character.class)
/* 312 */       return BigDecimal.valueOf(((Character)value).charValue());
/* 313 */     return new BigDecimal(stringValue(value, true));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String stringValue(Object value, boolean trim)
/*     */   {
/*     */     String result;
/*     */     
/*     */ 
/*     */     String result;
/*     */     
/*     */ 
/* 327 */     if (value == null) {
/* 328 */       result = OgnlRuntime.NULL_STRING;
/*     */     } else {
/* 330 */       result = value.toString();
/* 331 */       if (trim) {
/* 332 */         result = result.trim();
/*     */       }
/*     */     }
/* 335 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String stringValue(Object value)
/*     */   {
/* 347 */     return stringValue(value, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getNumericType(Object value)
/*     */   {
/* 359 */     int result = 10;
/*     */     
/* 361 */     if (value != null) {
/* 362 */       Class c = value.getClass();
/* 363 */       if (c == Integer.class) return 4;
/* 364 */       if (c == Double.class) return 8;
/* 365 */       if (c == Boolean.class) return 0;
/* 366 */       if (c == Byte.class) return 1;
/* 367 */       if (c == Character.class) return 2;
/* 368 */       if (c == Short.class) return 3;
/* 369 */       if (c == Long.class) return 5;
/* 370 */       if (c == Float.class) return 7;
/* 371 */       if (c == BigInteger.class) return 6;
/* 372 */       if (c == BigDecimal.class) return 9;
/*     */     }
/* 374 */     return 10;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object convertValue(Object value, Class toType)
/*     */   {
/* 390 */     Object result = null;
/*     */     
/* 392 */     if (value != null)
/*     */     {
/* 394 */       if ((value.getClass().isArray()) && (toType.isArray())) {
/* 395 */         Class componentType = toType.getComponentType();
/*     */         
/* 397 */         result = Array.newInstance(componentType, Array.getLength(value));
/* 398 */         int i = 0; for (int icount = Array.getLength(value); i < icount; i++) {
/* 399 */           Array.set(result, i, convertValue(Array.get(value, i), componentType));
/*     */         }
/*     */       } else {
/* 402 */         if ((toType == Integer.class) || (toType == Integer.TYPE)) result = new Integer((int)longValue(value));
/* 403 */         if ((toType == Double.class) || (toType == Double.TYPE)) result = new Double(doubleValue(value));
/* 404 */         if ((toType == Boolean.class) || (toType == Boolean.TYPE)) result = booleanValue(value) ? Boolean.TRUE : Boolean.FALSE;
/* 405 */         if ((toType == Byte.class) || (toType == Byte.TYPE)) result = new Byte((byte)(int)longValue(value));
/* 406 */         if ((toType == Character.class) || (toType == Character.TYPE)) result = new Character((char)(int)longValue(value));
/* 407 */         if ((toType == Short.class) || (toType == Short.TYPE)) result = new Short((short)(int)longValue(value));
/* 408 */         if ((toType == Long.class) || (toType == Long.TYPE)) result = new Long(longValue(value));
/* 409 */         if ((toType == Float.class) || (toType == Float.TYPE)) result = new Float(doubleValue(value));
/* 410 */         if (toType == BigInteger.class) result = bigIntValue(value);
/* 411 */         if (toType == BigDecimal.class) result = bigDecValue(value);
/* 412 */         if (toType == String.class) result = stringValue(value);
/*     */       }
/*     */     }
/* 415 */     else if (toType.isPrimitive()) {
/* 416 */       result = OgnlRuntime.getPrimitiveDefaultValue(toType);
/*     */     }
/*     */     
/* 419 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getNumericType(Object v1, Object v2)
/*     */   {
/* 432 */     return getNumericType(v1, v2, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getNumericType(int t1, int t2, boolean canBeNonNumeric)
/*     */   {
/* 446 */     if (t1 == t2) {
/* 447 */       return t1;
/*     */     }
/* 449 */     if ((canBeNonNumeric) && ((t1 == 10) || (t2 == 10) || (t1 == 2) || (t2 == 2))) {
/* 450 */       return 10;
/*     */     }
/* 452 */     if (t1 == 10) t1 = 8;
/* 453 */     if (t2 == 10) { t2 = 8;
/*     */     }
/* 455 */     if (t1 >= 7)
/*     */     {
/* 457 */       if (t2 >= 7)
/* 458 */         return Math.max(t1, t2);
/* 459 */       if (t2 < 4)
/* 460 */         return t1;
/* 461 */       if (t2 == 6)
/* 462 */         return 9;
/* 463 */       return Math.max(8, t1);
/*     */     }
/* 465 */     if (t2 >= 7)
/*     */     {
/* 467 */       if (t1 < 4)
/* 468 */         return t2;
/* 469 */       if (t1 == 6)
/* 470 */         return 9;
/* 471 */       return Math.max(8, t2);
/*     */     }
/*     */     
/* 474 */     return Math.max(t1, t2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getNumericType(Object v1, Object v2, boolean canBeNonNumeric)
/*     */   {
/* 488 */     return getNumericType(getNumericType(v1), getNumericType(v2), canBeNonNumeric);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Number newInteger(int type, long value)
/*     */   {
/* 502 */     switch (type)
/*     */     {
/*     */     case 0: 
/*     */     case 2: 
/*     */     case 4: 
/* 507 */       return new Integer((int)value);
/*     */     
/*     */     case 7: 
/* 510 */       if ((float)value == value) {
/* 511 */         return new Float((float)value);
/*     */       }
/*     */     
/*     */     case 8: 
/* 515 */       if (value == value) {
/* 516 */         return new Double(value);
/*     */       }
/*     */     
/*     */     case 5: 
/* 520 */       return new Long(value);
/*     */     
/*     */     case 1: 
/* 523 */       return new Byte((byte)(int)value);
/*     */     
/*     */     case 3: 
/* 526 */       return new Short((short)(int)value);
/*     */     }
/*     */     
/* 529 */     return BigInteger.valueOf(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Number newReal(int type, double value)
/*     */   {
/* 545 */     if (type == 7)
/* 546 */       return new Float((float)value);
/* 547 */     return new Double(value);
/*     */   }
/*     */   
/*     */   public static Object binaryOr(Object v1, Object v2)
/*     */   {
/* 552 */     int type = getNumericType(v1, v2);
/* 553 */     if ((type == 6) || (type == 9))
/* 554 */       return bigIntValue(v1).or(bigIntValue(v2));
/* 555 */     return newInteger(type, longValue(v1) | longValue(v2));
/*     */   }
/*     */   
/*     */   public static Object binaryXor(Object v1, Object v2)
/*     */   {
/* 560 */     int type = getNumericType(v1, v2);
/* 561 */     if ((type == 6) || (type == 9))
/* 562 */       return bigIntValue(v1).xor(bigIntValue(v2));
/* 563 */     return newInteger(type, longValue(v1) ^ longValue(v2));
/*     */   }
/*     */   
/*     */   public static Object binaryAnd(Object v1, Object v2)
/*     */   {
/* 568 */     int type = getNumericType(v1, v2);
/* 569 */     if ((type == 6) || (type == 9))
/* 570 */       return bigIntValue(v1).and(bigIntValue(v2));
/* 571 */     return newInteger(type, longValue(v1) & longValue(v2));
/*     */   }
/*     */   
/*     */   public static boolean equal(Object v1, Object v2)
/*     */   {
/* 576 */     if (v1 == null)
/* 577 */       return v2 == null;
/* 578 */     if ((v1 == v2) || (isEqual(v1, v2)))
/* 579 */       return true;
/* 580 */     if (((v1 instanceof Number)) && ((v2 instanceof Number)))
/* 581 */       return ((Number)v1).doubleValue() == ((Number)v2).doubleValue();
/* 582 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean less(Object v1, Object v2)
/*     */   {
/* 587 */     return compareWithConversion(v1, v2) < 0;
/*     */   }
/*     */   
/*     */   public static boolean greater(Object v1, Object v2)
/*     */   {
/* 592 */     return compareWithConversion(v1, v2) > 0;
/*     */   }
/*     */   
/*     */   public static boolean in(Object v1, Object v2) throws OgnlException
/*     */   {
/* 597 */     if (v2 == null) {
/* 598 */       return false;
/*     */     }
/* 600 */     ElementsAccessor elementsAccessor = OgnlRuntime.getElementsAccessor(OgnlRuntime.getTargetClass(v2));
/* 601 */     for (Enumeration e = elementsAccessor.getElements(v2); e.hasMoreElements();) {
/* 602 */       Object o = e.nextElement();
/*     */       
/* 604 */       if (equal(v1, o))
/* 605 */         return true;
/*     */     }
/* 607 */     return false;
/*     */   }
/*     */   
/*     */   public static Object shiftLeft(Object v1, Object v2)
/*     */   {
/* 612 */     int type = getNumericType(v1);
/* 613 */     if ((type == 6) || (type == 9))
/* 614 */       return bigIntValue(v1).shiftLeft((int)longValue(v2));
/* 615 */     return newInteger(type, longValue(v1) << (int)longValue(v2));
/*     */   }
/*     */   
/*     */   public static Object shiftRight(Object v1, Object v2)
/*     */   {
/* 620 */     int type = getNumericType(v1);
/* 621 */     if ((type == 6) || (type == 9))
/* 622 */       return bigIntValue(v1).shiftRight((int)longValue(v2));
/* 623 */     return newInteger(type, longValue(v1) >> (int)longValue(v2));
/*     */   }
/*     */   
/*     */   public static Object unsignedShiftRight(Object v1, Object v2)
/*     */   {
/* 628 */     int type = getNumericType(v1);
/* 629 */     if ((type == 6) || (type == 9))
/* 630 */       return bigIntValue(v1).shiftRight((int)longValue(v2));
/* 631 */     if (type <= 4)
/* 632 */       return newInteger(4, (int)longValue(v1) >>> (int)longValue(v2));
/* 633 */     return newInteger(type, longValue(v1) >>> (int)longValue(v2));
/*     */   }
/*     */   
/*     */   public static Object add(Object v1, Object v2)
/*     */   {
/* 638 */     int type = getNumericType(v1, v2, true);
/* 639 */     switch (type) {
/*     */     case 6: 
/* 641 */       return bigIntValue(v1).add(bigIntValue(v2));
/* 642 */     case 9:  return bigDecValue(v1).add(bigDecValue(v2));
/*     */     case 7: case 8: 
/* 644 */       return newReal(type, doubleValue(v1) + doubleValue(v2));
/*     */     case 10: 
/* 646 */       int t1 = getNumericType(v1);
/* 647 */       int t2 = getNumericType(v2);
/*     */       
/* 649 */       if (((t1 != 10) && (v2 == null)) || ((t2 != 10) && (v1 == null))) {
/* 650 */         throw new NullPointerException();
/*     */       }
/* 652 */       return stringValue(v1) + stringValue(v2); }
/* 653 */     return newInteger(type, longValue(v1) + longValue(v2));
/*     */   }
/*     */   
/*     */ 
/*     */   public static Object subtract(Object v1, Object v2)
/*     */   {
/* 659 */     int type = getNumericType(v1, v2);
/* 660 */     switch (type) {
/*     */     case 6: 
/* 662 */       return bigIntValue(v1).subtract(bigIntValue(v2));
/* 663 */     case 9:  return bigDecValue(v1).subtract(bigDecValue(v2));
/*     */     case 7: case 8: 
/* 665 */       return newReal(type, doubleValue(v1) - doubleValue(v2)); }
/* 666 */     return newInteger(type, longValue(v1) - longValue(v2));
/*     */   }
/*     */   
/*     */ 
/*     */   public static Object multiply(Object v1, Object v2)
/*     */   {
/* 672 */     int type = getNumericType(v1, v2);
/* 673 */     switch (type) {
/*     */     case 6: 
/* 675 */       return bigIntValue(v1).multiply(bigIntValue(v2));
/* 676 */     case 9:  return bigDecValue(v1).multiply(bigDecValue(v2));
/*     */     case 7: case 8: 
/* 678 */       return newReal(type, doubleValue(v1) * doubleValue(v2)); }
/* 679 */     return newInteger(type, longValue(v1) * longValue(v2));
/*     */   }
/*     */   
/*     */ 
/*     */   public static Object divide(Object v1, Object v2)
/*     */   {
/* 685 */     int type = getNumericType(v1, v2);
/* 686 */     switch (type) {
/*     */     case 6: 
/* 688 */       return bigIntValue(v1).divide(bigIntValue(v2));
/* 689 */     case 9:  return bigDecValue(v1).divide(bigDecValue(v2), 6);
/*     */     case 7: case 8: 
/* 691 */       return newReal(type, doubleValue(v1) / doubleValue(v2)); }
/* 692 */     return newInteger(type, longValue(v1) / longValue(v2));
/*     */   }
/*     */   
/*     */ 
/*     */   public static Object remainder(Object v1, Object v2)
/*     */   {
/* 698 */     int type = getNumericType(v1, v2);
/* 699 */     switch (type) {
/*     */     case 6: 
/*     */     case 9: 
/* 702 */       return bigIntValue(v1).remainder(bigIntValue(v2)); }
/* 703 */     return newInteger(type, longValue(v1) % longValue(v2));
/*     */   }
/*     */   
/*     */ 
/*     */   public static Object negate(Object value)
/*     */   {
/* 709 */     int type = getNumericType(value);
/* 710 */     switch (type) {
/*     */     case 6: 
/* 712 */       return bigIntValue(value).negate();
/* 713 */     case 9:  return bigDecValue(value).negate();
/*     */     case 7: case 8: 
/* 715 */       return newReal(type, -doubleValue(value)); }
/* 716 */     return newInteger(type, -longValue(value));
/*     */   }
/*     */   
/*     */ 
/*     */   public static Object bitNegate(Object value)
/*     */   {
/* 722 */     int type = getNumericType(value);
/* 723 */     switch (type) {
/*     */     case 6: 
/*     */     case 9: 
/* 726 */       return bigIntValue(value).not(); }
/* 727 */     return newInteger(type, longValue(value) ^ 0xFFFFFFFFFFFFFFFF);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\OgnlOps.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */