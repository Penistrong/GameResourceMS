/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DynamicSubscript
/*    */ {
/*    */   public static final int FIRST = 0;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final int MID = 1;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final int LAST = 2;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final int ALL = 3;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 49 */   public static final DynamicSubscript first = new DynamicSubscript(0);
/* 50 */   public static final DynamicSubscript mid = new DynamicSubscript(1);
/* 51 */   public static final DynamicSubscript last = new DynamicSubscript(2);
/* 52 */   public static final DynamicSubscript all = new DynamicSubscript(3);
/*    */   
/*    */   private int flag;
/*    */   
/*    */   private DynamicSubscript(int flag)
/*    */   {
/* 58 */     this.flag = flag;
/*    */   }
/*    */   
/*    */   public int getFlag()
/*    */   {
/* 63 */     return this.flag;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 68 */     switch (this.flag) {
/*    */     case 0: 
/* 70 */       return "^";
/* 71 */     case 1:  return "|";
/* 72 */     case 2:  return "$";
/* 73 */     case 3:  return "*"; }
/* 74 */     return "?";
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\DynamicSubscript.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */