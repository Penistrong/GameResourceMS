/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BigIntegerTypeHandler
/*    */   extends BaseTypeHandler<BigInteger>
/*    */ {
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, BigInteger parameter, JdbcType jdbcType)
/*    */     throws SQLException
/*    */   {
/* 32 */     ps.setBigDecimal(i, new BigDecimal(parameter));
/*    */   }
/*    */   
/*    */   public BigInteger getNullableResult(ResultSet rs, String columnName) throws SQLException
/*    */   {
/* 37 */     BigDecimal bigDecimal = rs.getBigDecimal(columnName);
/* 38 */     return bigDecimal == null ? null : bigDecimal.toBigInteger();
/*    */   }
/*    */   
/*    */   public BigInteger getNullableResult(ResultSet rs, int columnIndex) throws SQLException
/*    */   {
/* 43 */     BigDecimal bigDecimal = rs.getBigDecimal(columnIndex);
/* 44 */     return bigDecimal == null ? null : bigDecimal.toBigInteger();
/*    */   }
/*    */   
/*    */   public BigInteger getNullableResult(CallableStatement cs, int columnIndex) throws SQLException
/*    */   {
/* 49 */     BigDecimal bigDecimal = cs.getBigDecimal(columnIndex);
/* 50 */     return bigDecimal == null ? null : bigDecimal.toBigInteger();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\BigIntegerTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */