package org.apache.ibatis.executor.loader;

@Deprecated
public final class JavassistProxyFactory
  extends org.apache.ibatis.executor.loader.javassist.JavassistProxyFactory
{}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\loader\JavassistProxyFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */