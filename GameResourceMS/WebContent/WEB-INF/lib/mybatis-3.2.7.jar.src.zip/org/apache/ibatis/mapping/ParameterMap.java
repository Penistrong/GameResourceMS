/*    */ package org.apache.ibatis.mapping;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.apache.ibatis.session.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParameterMap
/*    */ {
/*    */   private String id;
/*    */   private Class<?> type;
/*    */   private List<ParameterMapping> parameterMappings;
/*    */   
/*    */   public static class Builder
/*    */   {
/* 36 */     private ParameterMap parameterMap = new ParameterMap(null);
/*    */     
/*    */     public Builder(Configuration configuration, String id, Class<?> type, List<ParameterMapping> parameterMappings) {
/* 39 */       this.parameterMap.id = id;
/* 40 */       this.parameterMap.type = type;
/* 41 */       this.parameterMap.parameterMappings = parameterMappings;
/*    */     }
/*    */     
/*    */     public Class<?> type() {
/* 45 */       return this.parameterMap.type;
/*    */     }
/*    */     
/*    */     public ParameterMap build()
/*    */     {
/* 50 */       this.parameterMap.parameterMappings = Collections.unmodifiableList(this.parameterMap.parameterMappings);
/* 51 */       return this.parameterMap;
/*    */     }
/*    */   }
/*    */   
/*    */   public String getId() {
/* 56 */     return this.id;
/*    */   }
/*    */   
/*    */   public Class<?> getType() {
/* 60 */     return this.type;
/*    */   }
/*    */   
/*    */   public List<ParameterMapping> getParameterMappings() {
/* 64 */     return this.parameterMappings;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\mapping\ParameterMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */