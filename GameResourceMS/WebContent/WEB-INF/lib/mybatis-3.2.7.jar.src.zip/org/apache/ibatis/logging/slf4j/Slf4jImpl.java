/*    */ package org.apache.ibatis.logging.slf4j;
/*    */ 
/*    */ import org.apache.ibatis.logging.Log;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import org.slf4j.Marker;
/*    */ import org.slf4j.spi.LocationAwareLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Slf4jImpl
/*    */   implements Log
/*    */ {
/*    */   private Log log;
/*    */   
/*    */   public Slf4jImpl(String clazz)
/*    */   {
/* 33 */     Logger logger = LoggerFactory.getLogger(clazz);
/*    */     
/* 35 */     if ((logger instanceof LocationAwareLogger)) {
/*    */       try
/*    */       {
/* 38 */         logger.getClass().getMethod("log", new Class[] { Marker.class, String.class, Integer.TYPE, String.class, Object[].class, Throwable.class });
/* 39 */         this.log = new Slf4jLocationAwareLoggerImpl((LocationAwareLogger)logger);
/* 40 */         return;
/*    */       }
/*    */       catch (SecurityException e) {}catch (NoSuchMethodException e) {}
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 49 */     this.log = new Slf4jLoggerImpl(logger);
/*    */   }
/*    */   
/*    */   public boolean isDebugEnabled() {
/* 53 */     return this.log.isDebugEnabled();
/*    */   }
/*    */   
/*    */   public boolean isTraceEnabled() {
/* 57 */     return this.log.isTraceEnabled();
/*    */   }
/*    */   
/*    */   public void error(String s, Throwable e) {
/* 61 */     this.log.error(s, e);
/*    */   }
/*    */   
/*    */   public void error(String s) {
/* 65 */     this.log.error(s);
/*    */   }
/*    */   
/*    */   public void debug(String s) {
/* 69 */     this.log.debug(s);
/*    */   }
/*    */   
/*    */   public void trace(String s) {
/* 73 */     this.log.trace(s);
/*    */   }
/*    */   
/*    */   public void warn(String s) {
/* 77 */     this.log.warn(s);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\logging\slf4j\Slf4jImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */