/*     */ package org.apache.ibatis.executor;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import org.apache.ibatis.cache.Cache;
/*     */ import org.apache.ibatis.cache.CacheKey;
/*     */ import org.apache.ibatis.cache.TransactionalCacheManager;
/*     */ import org.apache.ibatis.mapping.BoundSql;
/*     */ import org.apache.ibatis.mapping.MappedStatement;
/*     */ import org.apache.ibatis.mapping.ParameterMapping;
/*     */ import org.apache.ibatis.mapping.ParameterMode;
/*     */ import org.apache.ibatis.mapping.StatementType;
/*     */ import org.apache.ibatis.reflection.MetaObject;
/*     */ import org.apache.ibatis.session.ResultHandler;
/*     */ import org.apache.ibatis.session.RowBounds;
/*     */ import org.apache.ibatis.transaction.Transaction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CachingExecutor
/*     */   implements Executor
/*     */ {
/*     */   private Executor delegate;
/*  41 */   private TransactionalCacheManager tcm = new TransactionalCacheManager();
/*     */   
/*     */   public CachingExecutor(Executor delegate) {
/*  44 */     this.delegate = delegate;
/*  45 */     delegate.setExecutorWrapper(this);
/*     */   }
/*     */   
/*     */   public Transaction getTransaction() {
/*  49 */     return this.delegate.getTransaction();
/*     */   }
/*     */   
/*     */   public void close(boolean forceRollback)
/*     */   {
/*     */     try {
/*  55 */       if (forceRollback) {
/*  56 */         this.tcm.rollback();
/*     */       } else {
/*  58 */         this.tcm.commit();
/*     */       }
/*     */     } finally {
/*  61 */       this.delegate.close(forceRollback);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isClosed() {
/*  66 */     return this.delegate.isClosed();
/*     */   }
/*     */   
/*     */   public int update(MappedStatement ms, Object parameterObject) throws SQLException {
/*  70 */     flushCacheIfRequired(ms);
/*  71 */     return this.delegate.update(ms, parameterObject);
/*     */   }
/*     */   
/*     */   public <E> List<E> query(MappedStatement ms, Object parameterObject, RowBounds rowBounds, ResultHandler resultHandler) throws SQLException {
/*  75 */     BoundSql boundSql = ms.getBoundSql(parameterObject);
/*  76 */     CacheKey key = createCacheKey(ms, parameterObject, rowBounds, boundSql);
/*  77 */     return query(ms, parameterObject, rowBounds, resultHandler, key, boundSql);
/*     */   }
/*     */   
/*     */   public <E> List<E> query(MappedStatement ms, Object parameterObject, RowBounds rowBounds, ResultHandler resultHandler, CacheKey key, BoundSql boundSql) throws SQLException
/*     */   {
/*  82 */     Cache cache = ms.getCache();
/*  83 */     if (cache != null) {
/*  84 */       flushCacheIfRequired(ms);
/*  85 */       if ((ms.isUseCache()) && (resultHandler == null)) {
/*  86 */         ensureNoOutParams(ms, parameterObject, boundSql);
/*     */         
/*  88 */         List<E> list = (List)this.tcm.getObject(cache, key);
/*  89 */         if (list == null) {
/*  90 */           list = this.delegate.query(ms, parameterObject, rowBounds, resultHandler, key, boundSql);
/*  91 */           this.tcm.putObject(cache, key, list);
/*     */         }
/*  93 */         return list;
/*     */       }
/*     */     }
/*  96 */     return this.delegate.query(ms, parameterObject, rowBounds, resultHandler, key, boundSql);
/*     */   }
/*     */   
/*     */   public List<BatchResult> flushStatements() throws SQLException {
/* 100 */     return this.delegate.flushStatements();
/*     */   }
/*     */   
/*     */   public void commit(boolean required) throws SQLException {
/* 104 */     this.delegate.commit(required);
/* 105 */     this.tcm.commit();
/*     */   }
/*     */   
/*     */   public void rollback(boolean required) throws SQLException {
/*     */     try {
/* 110 */       this.delegate.rollback(required);
/*     */     } finally {
/* 112 */       if (required) {
/* 113 */         this.tcm.rollback();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void ensureNoOutParams(MappedStatement ms, Object parameter, BoundSql boundSql) {
/* 119 */     if (ms.getStatementType() == StatementType.CALLABLE) {
/* 120 */       for (ParameterMapping parameterMapping : boundSql.getParameterMappings()) {
/* 121 */         if (parameterMapping.getMode() != ParameterMode.IN) {
/* 122 */           throw new ExecutorException("Caching stored procedures with OUT params is not supported.  Please configure useCache=false in " + ms.getId() + " statement.");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public CacheKey createCacheKey(MappedStatement ms, Object parameterObject, RowBounds rowBounds, BoundSql boundSql) {
/* 129 */     return this.delegate.createCacheKey(ms, parameterObject, rowBounds, boundSql);
/*     */   }
/*     */   
/*     */   public boolean isCached(MappedStatement ms, CacheKey key) {
/* 133 */     return this.delegate.isCached(ms, key);
/*     */   }
/*     */   
/*     */   public void deferLoad(MappedStatement ms, MetaObject resultObject, String property, CacheKey key, Class<?> targetType) {
/* 137 */     this.delegate.deferLoad(ms, resultObject, property, key, targetType);
/*     */   }
/*     */   
/*     */   public void clearLocalCache() {
/* 141 */     this.delegate.clearLocalCache();
/*     */   }
/*     */   
/*     */   private void flushCacheIfRequired(MappedStatement ms) {
/* 145 */     Cache cache = ms.getCache();
/* 146 */     if ((cache != null) && (ms.isFlushCacheRequired())) {
/* 147 */       this.tcm.clear(cache);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setExecutorWrapper(Executor executor)
/*     */   {
/* 153 */     throw new UnsupportedOperationException("This method should not be called");
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\CachingExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */