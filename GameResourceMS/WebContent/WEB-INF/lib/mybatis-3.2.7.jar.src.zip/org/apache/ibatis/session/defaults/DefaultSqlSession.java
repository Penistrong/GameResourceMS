/*     */ package org.apache.ibatis.session.defaults;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.ibatis.binding.BindingException;
/*     */ import org.apache.ibatis.exceptions.ExceptionFactory;
/*     */ import org.apache.ibatis.exceptions.TooManyResultsException;
/*     */ import org.apache.ibatis.executor.BatchResult;
/*     */ import org.apache.ibatis.executor.ErrorContext;
/*     */ import org.apache.ibatis.executor.Executor;
/*     */ import org.apache.ibatis.executor.result.DefaultMapResultHandler;
/*     */ import org.apache.ibatis.executor.result.DefaultResultContext;
/*     */ import org.apache.ibatis.mapping.MappedStatement;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.session.ResultHandler;
/*     */ import org.apache.ibatis.session.RowBounds;
/*     */ import org.apache.ibatis.session.SqlSession;
/*     */ import org.apache.ibatis.transaction.Transaction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultSqlSession
/*     */   implements SqlSession
/*     */ {
/*     */   private Configuration configuration;
/*     */   private Executor executor;
/*     */   private boolean autoCommit;
/*     */   private boolean dirty;
/*     */   
/*     */   public DefaultSqlSession(Configuration configuration, Executor executor, boolean autoCommit)
/*     */   {
/*  50 */     this.configuration = configuration;
/*  51 */     this.executor = executor;
/*  52 */     this.dirty = false;
/*  53 */     this.autoCommit = autoCommit;
/*     */   }
/*     */   
/*     */   public DefaultSqlSession(Configuration configuration, Executor executor) {
/*  57 */     this(configuration, executor, false);
/*     */   }
/*     */   
/*     */   public <T> T selectOne(String statement) {
/*  61 */     return (T)selectOne(statement, null);
/*     */   }
/*     */   
/*     */   public <T> T selectOne(String statement, Object parameter)
/*     */   {
/*  66 */     List<T> list = selectList(statement, parameter);
/*  67 */     if (list.size() == 1)
/*  68 */       return (T)list.get(0);
/*  69 */     if (list.size() > 1) {
/*  70 */       throw new TooManyResultsException("Expected one result (or null) to be returned by selectOne(), but found: " + list.size());
/*     */     }
/*  72 */     return null;
/*     */   }
/*     */   
/*     */   public <K, V> Map<K, V> selectMap(String statement, String mapKey)
/*     */   {
/*  77 */     return selectMap(statement, null, mapKey, RowBounds.DEFAULT);
/*     */   }
/*     */   
/*     */   public <K, V> Map<K, V> selectMap(String statement, Object parameter, String mapKey) {
/*  81 */     return selectMap(statement, parameter, mapKey, RowBounds.DEFAULT);
/*     */   }
/*     */   
/*     */   public <K, V> Map<K, V> selectMap(String statement, Object parameter, String mapKey, RowBounds rowBounds) {
/*  85 */     List<?> list = selectList(statement, parameter, rowBounds);
/*  86 */     DefaultMapResultHandler<K, V> mapResultHandler = new DefaultMapResultHandler(mapKey, this.configuration.getObjectFactory(), this.configuration.getObjectWrapperFactory());
/*     */     
/*  88 */     DefaultResultContext context = new DefaultResultContext();
/*  89 */     for (Object o : list) {
/*  90 */       context.nextResultObject(o);
/*  91 */       mapResultHandler.handleResult(context);
/*     */     }
/*  93 */     Map<K, V> selectedMap = mapResultHandler.getMappedResults();
/*  94 */     return selectedMap;
/*     */   }
/*     */   
/*     */   public <E> List<E> selectList(String statement) {
/*  98 */     return selectList(statement, null);
/*     */   }
/*     */   
/*     */   public <E> List<E> selectList(String statement, Object parameter) {
/* 102 */     return selectList(statement, parameter, RowBounds.DEFAULT);
/*     */   }
/*     */   
/*     */   public <E> List<E> selectList(String statement, Object parameter, RowBounds rowBounds) {
/*     */     try {
/* 107 */       MappedStatement ms = this.configuration.getMappedStatement(statement);
/* 108 */       List<E> result = this.executor.query(ms, wrapCollection(parameter), rowBounds, Executor.NO_RESULT_HANDLER);
/* 109 */       return result;
/*     */     } catch (Exception e) {
/* 111 */       throw ExceptionFactory.wrapException("Error querying database.  Cause: " + e, e);
/*     */     } finally {
/* 113 */       ErrorContext.instance().reset();
/*     */     }
/*     */   }
/*     */   
/*     */   public void select(String statement, Object parameter, ResultHandler handler) {
/* 118 */     select(statement, parameter, RowBounds.DEFAULT, handler);
/*     */   }
/*     */   
/*     */   public void select(String statement, ResultHandler handler) {
/* 122 */     select(statement, null, RowBounds.DEFAULT, handler);
/*     */   }
/*     */   
/*     */   public void select(String statement, Object parameter, RowBounds rowBounds, ResultHandler handler) {
/*     */     try {
/* 127 */       MappedStatement ms = this.configuration.getMappedStatement(statement);
/* 128 */       this.executor.query(ms, wrapCollection(parameter), rowBounds, handler);
/*     */     } catch (Exception e) {
/* 130 */       throw ExceptionFactory.wrapException("Error querying database.  Cause: " + e, e);
/*     */     } finally {
/* 132 */       ErrorContext.instance().reset();
/*     */     }
/*     */   }
/*     */   
/*     */   public int insert(String statement) {
/* 137 */     return insert(statement, null);
/*     */   }
/*     */   
/*     */   public int insert(String statement, Object parameter) {
/* 141 */     return update(statement, parameter);
/*     */   }
/*     */   
/*     */   public int update(String statement) {
/* 145 */     return update(statement, null);
/*     */   }
/*     */   
/*     */   public int update(String statement, Object parameter) {
/*     */     try {
/* 150 */       this.dirty = true;
/* 151 */       MappedStatement ms = this.configuration.getMappedStatement(statement);
/* 152 */       return this.executor.update(ms, wrapCollection(parameter));
/*     */     } catch (Exception e) {
/* 154 */       throw ExceptionFactory.wrapException("Error updating database.  Cause: " + e, e);
/*     */     } finally {
/* 156 */       ErrorContext.instance().reset();
/*     */     }
/*     */   }
/*     */   
/*     */   public int delete(String statement) {
/* 161 */     return update(statement, null);
/*     */   }
/*     */   
/*     */   public int delete(String statement, Object parameter) {
/* 165 */     return update(statement, parameter);
/*     */   }
/*     */   
/*     */   public void commit() {
/* 169 */     commit(false);
/*     */   }
/*     */   
/*     */   public void commit(boolean force) {
/*     */     try {
/* 174 */       this.executor.commit(isCommitOrRollbackRequired(force));
/* 175 */       this.dirty = false;
/*     */     } catch (Exception e) {
/* 177 */       throw ExceptionFactory.wrapException("Error committing transaction.  Cause: " + e, e);
/*     */     } finally {
/* 179 */       ErrorContext.instance().reset();
/*     */     }
/*     */   }
/*     */   
/*     */   public void rollback() {
/* 184 */     rollback(false);
/*     */   }
/*     */   
/*     */   public void rollback(boolean force) {
/*     */     try {
/* 189 */       this.executor.rollback(isCommitOrRollbackRequired(force));
/* 190 */       this.dirty = false;
/*     */     } catch (Exception e) {
/* 192 */       throw ExceptionFactory.wrapException("Error rolling back transaction.  Cause: " + e, e);
/*     */     } finally {
/* 194 */       ErrorContext.instance().reset();
/*     */     }
/*     */   }
/*     */   
/*     */   public List<BatchResult> flushStatements() {
/*     */     try {
/* 200 */       return this.executor.flushStatements();
/*     */     } catch (Exception e) {
/* 202 */       throw ExceptionFactory.wrapException("Error flushing statements.  Cause: " + e, e);
/*     */     } finally {
/* 204 */       ErrorContext.instance().reset();
/*     */     }
/*     */   }
/*     */   
/*     */   public void close() {
/*     */     try {
/* 210 */       this.executor.close(isCommitOrRollbackRequired(false));
/* 211 */       this.dirty = false;
/*     */     } finally {
/* 213 */       ErrorContext.instance().reset();
/*     */     }
/*     */   }
/*     */   
/*     */   public Configuration getConfiguration() {
/* 218 */     return this.configuration;
/*     */   }
/*     */   
/*     */   public <T> T getMapper(Class<T> type) {
/* 222 */     return (T)this.configuration.getMapper(type, this);
/*     */   }
/*     */   
/*     */   public Connection getConnection() {
/*     */     try {
/* 227 */       return this.executor.getTransaction().getConnection();
/*     */     } catch (SQLException e) {
/* 229 */       throw ExceptionFactory.wrapException("Error getting a new connection.  Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void clearCache() {
/* 234 */     this.executor.clearLocalCache();
/*     */   }
/*     */   
/*     */   private boolean isCommitOrRollbackRequired(boolean force) {
/* 238 */     return ((!this.autoCommit) && (this.dirty)) || (force);
/*     */   }
/*     */   
/*     */   private Object wrapCollection(Object object) {
/* 242 */     if ((object instanceof List)) {
/* 243 */       StrictMap<Object> map = new StrictMap();
/* 244 */       map.put("list", object);
/* 245 */       return map; }
/* 246 */     if ((object != null) && (object.getClass().isArray())) {
/* 247 */       StrictMap<Object> map = new StrictMap();
/* 248 */       map.put("array", object);
/* 249 */       return map;
/*     */     }
/* 251 */     return object;
/*     */   }
/*     */   
/*     */   public static class StrictMap<V> extends HashMap<String, V>
/*     */   {
/*     */     private static final long serialVersionUID = -5741767162221585340L;
/*     */     
/*     */     public V get(Object key)
/*     */     {
/* 260 */       if (!super.containsKey(key)) {
/* 261 */         throw new BindingException("Parameter '" + key + "' not found. Available parameters are " + keySet());
/*     */       }
/* 263 */       return (V)super.get(key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\session\defaults\DefaultSqlSession.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */