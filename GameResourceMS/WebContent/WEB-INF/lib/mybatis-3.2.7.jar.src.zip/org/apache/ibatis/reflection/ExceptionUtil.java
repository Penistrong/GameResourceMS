/*    */ package org.apache.ibatis.reflection;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.UndeclaredThrowableException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExceptionUtil
/*    */ {
/*    */   public static Throwable unwrapThrowable(Throwable wrapped)
/*    */   {
/* 27 */     Throwable unwrapped = wrapped;
/*    */     for (;;) {
/* 29 */       if ((unwrapped instanceof InvocationTargetException)) {
/* 30 */         unwrapped = ((InvocationTargetException)unwrapped).getTargetException();
/* 31 */       } else { if (!(unwrapped instanceof UndeclaredThrowableException)) break;
/* 32 */         unwrapped = ((UndeclaredThrowableException)unwrapped).getUndeclaredThrowable();
/*    */       } }
/* 34 */     return unwrapped;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\ExceptionUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */