/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Modifier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTStaticField
/*    */   extends SimpleNode
/*    */ {
/*    */   private String className;
/*    */   private String fieldName;
/*    */   
/*    */   public ASTStaticField(int id)
/*    */   {
/* 46 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTStaticField(OgnlParser p, int id) {
/* 50 */     super(p, id);
/*    */   }
/*    */   
/*    */   void init(String className, String fieldName)
/*    */   {
/* 55 */     this.className = className;
/* 56 */     this.fieldName = fieldName;
/*    */   }
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException
/*    */   {
/* 61 */     return OgnlRuntime.getStaticField(context, this.className, this.fieldName);
/*    */   }
/*    */   
/*    */   public boolean isNodeConstant(OgnlContext context) throws OgnlException
/*    */   {
/* 66 */     boolean result = false;
/* 67 */     Exception reason = null;
/*    */     try
/*    */     {
/* 70 */       Class c = OgnlRuntime.classForName(context, this.className);
/*    */       
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 77 */       if (this.fieldName.equals("class")) {
/* 78 */         result = true;
/*    */       } else {
/* 80 */         Field f = c.getField(this.fieldName);
/*    */         
/* 82 */         if (!Modifier.isStatic(f.getModifiers())) {
/* 83 */           throw new OgnlException("Field " + this.fieldName + " of class " + this.className + " is not static");
/*    */         }
/* 85 */         result = Modifier.isFinal(f.getModifiers());
/*    */       }
/* 87 */     } catch (ClassNotFoundException e) { reason = e;
/* 88 */     } catch (NoSuchFieldException e) { reason = e;
/* 89 */     } catch (SecurityException e) { reason = e;
/*    */     }
/* 91 */     if (reason != null) {
/* 92 */       throw new OgnlException("Could not get static field " + this.fieldName + " from class " + this.className, reason);
/*    */     }
/* 94 */     return result;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 99 */     return "@" + this.className + "@" + this.fieldName;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTStaticField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */