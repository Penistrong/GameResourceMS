/*     */ package org.apache.ibatis.builder.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.ibatis.annotations.Arg;
/*     */ import org.apache.ibatis.annotations.CacheNamespace;
/*     */ import org.apache.ibatis.annotations.CacheNamespaceRef;
/*     */ import org.apache.ibatis.annotations.Case;
/*     */ import org.apache.ibatis.annotations.ConstructorArgs;
/*     */ import org.apache.ibatis.annotations.Delete;
/*     */ import org.apache.ibatis.annotations.DeleteProvider;
/*     */ import org.apache.ibatis.annotations.Insert;
/*     */ import org.apache.ibatis.annotations.InsertProvider;
/*     */ import org.apache.ibatis.annotations.Lang;
/*     */ import org.apache.ibatis.annotations.Many;
/*     */ import org.apache.ibatis.annotations.MapKey;
/*     */ import org.apache.ibatis.annotations.One;
/*     */ import org.apache.ibatis.annotations.Options;
/*     */ import org.apache.ibatis.annotations.Result;
/*     */ import org.apache.ibatis.annotations.ResultMap;
/*     */ import org.apache.ibatis.annotations.ResultType;
/*     */ import org.apache.ibatis.annotations.Results;
/*     */ import org.apache.ibatis.annotations.Select;
/*     */ import org.apache.ibatis.annotations.SelectKey;
/*     */ import org.apache.ibatis.annotations.SelectProvider;
/*     */ import org.apache.ibatis.annotations.TypeDiscriminator;
/*     */ import org.apache.ibatis.annotations.Update;
/*     */ import org.apache.ibatis.annotations.UpdateProvider;
/*     */ import org.apache.ibatis.binding.BindingException;
/*     */ import org.apache.ibatis.binding.MapperMethod.ParamMap;
/*     */ import org.apache.ibatis.builder.BuilderException;
/*     */ import org.apache.ibatis.builder.IncompleteElementException;
/*     */ import org.apache.ibatis.builder.MapperBuilderAssistant;
/*     */ import org.apache.ibatis.builder.xml.XMLMapperBuilder;
/*     */ import org.apache.ibatis.executor.keygen.Jdbc3KeyGenerator;
/*     */ import org.apache.ibatis.executor.keygen.KeyGenerator;
/*     */ import org.apache.ibatis.executor.keygen.NoKeyGenerator;
/*     */ import org.apache.ibatis.executor.keygen.SelectKeyGenerator;
/*     */ import org.apache.ibatis.io.Resources;
/*     */ import org.apache.ibatis.mapping.Discriminator;
/*     */ import org.apache.ibatis.mapping.FetchType;
/*     */ import org.apache.ibatis.mapping.MappedStatement;
/*     */ import org.apache.ibatis.mapping.ResultFlag;
/*     */ import org.apache.ibatis.mapping.ResultMapping;
/*     */ import org.apache.ibatis.mapping.ResultSetType;
/*     */ import org.apache.ibatis.mapping.SqlCommandType;
/*     */ import org.apache.ibatis.mapping.SqlSource;
/*     */ import org.apache.ibatis.mapping.StatementType;
/*     */ import org.apache.ibatis.scripting.LanguageDriver;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.session.ResultHandler;
/*     */ import org.apache.ibatis.session.RowBounds;
/*     */ import org.apache.ibatis.type.JdbcType;
/*     */ import org.apache.ibatis.type.TypeHandler;
/*     */ import org.apache.ibatis.type.UnknownTypeHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapperAnnotationBuilder
/*     */ {
/*  91 */   private final Set<Class<? extends Annotation>> sqlAnnotationTypes = new HashSet();
/*  92 */   private final Set<Class<? extends Annotation>> sqlProviderAnnotationTypes = new HashSet();
/*     */   private Configuration configuration;
/*     */   private MapperBuilderAssistant assistant;
/*     */   private Class<?> type;
/*     */   
/*     */   public MapperAnnotationBuilder(Configuration configuration, Class<?> type)
/*     */   {
/*  99 */     String resource = type.getName().replace('.', '/') + ".java (best guess)";
/* 100 */     this.assistant = new MapperBuilderAssistant(configuration, resource);
/* 101 */     this.configuration = configuration;
/* 102 */     this.type = type;
/*     */     
/* 104 */     this.sqlAnnotationTypes.add(Select.class);
/* 105 */     this.sqlAnnotationTypes.add(Insert.class);
/* 106 */     this.sqlAnnotationTypes.add(Update.class);
/* 107 */     this.sqlAnnotationTypes.add(Delete.class);
/*     */     
/* 109 */     this.sqlProviderAnnotationTypes.add(SelectProvider.class);
/* 110 */     this.sqlProviderAnnotationTypes.add(InsertProvider.class);
/* 111 */     this.sqlProviderAnnotationTypes.add(UpdateProvider.class);
/* 112 */     this.sqlProviderAnnotationTypes.add(DeleteProvider.class);
/*     */   }
/*     */   
/*     */   public void parse() {
/* 116 */     String resource = this.type.toString();
/* 117 */     if (!this.configuration.isResourceLoaded(resource)) {
/* 118 */       loadXmlResource();
/* 119 */       this.configuration.addLoadedResource(resource);
/* 120 */       this.assistant.setCurrentNamespace(this.type.getName());
/* 121 */       parseCache();
/* 122 */       parseCacheRef();
/* 123 */       Method[] methods = this.type.getMethods();
/* 124 */       for (Method method : methods) {
/*     */         try {
/* 126 */           parseStatement(method);
/*     */         } catch (IncompleteElementException e) {
/* 128 */           this.configuration.addIncompleteMethod(new MethodResolver(this, method));
/*     */         }
/*     */       }
/*     */     }
/* 132 */     parsePendingMethods();
/*     */   }
/*     */   
/*     */   private void parsePendingMethods() {
/* 136 */     Collection<MethodResolver> incompleteMethods = this.configuration.getIncompleteMethods();
/* 137 */     synchronized (incompleteMethods) {
/* 138 */       Iterator<MethodResolver> iter = incompleteMethods.iterator();
/* 139 */       while (iter.hasNext()) {
/*     */         try {
/* 141 */           ((MethodResolver)iter.next()).resolve();
/* 142 */           iter.remove();
/*     */         }
/*     */         catch (IncompleteElementException e) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void loadXmlResource()
/*     */   {
/* 154 */     if (!this.configuration.isResourceLoaded("namespace:" + this.type.getName())) {
/* 155 */       String xmlResource = this.type.getName().replace('.', '/') + ".xml";
/* 156 */       InputStream inputStream = null;
/*     */       try {
/* 158 */         inputStream = Resources.getResourceAsStream(this.type.getClassLoader(), xmlResource);
/*     */       }
/*     */       catch (IOException e) {}
/*     */       
/* 162 */       if (inputStream != null) {
/* 163 */         XMLMapperBuilder xmlParser = new XMLMapperBuilder(inputStream, this.assistant.getConfiguration(), xmlResource, this.configuration.getSqlFragments(), this.type.getName());
/* 164 */         xmlParser.parse();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void parseCache() {
/* 170 */     CacheNamespace cacheDomain = (CacheNamespace)this.type.getAnnotation(CacheNamespace.class);
/* 171 */     if (cacheDomain != null) {
/* 172 */       this.assistant.useNewCache(cacheDomain.implementation(), cacheDomain.eviction(), Long.valueOf(cacheDomain.flushInterval()), Integer.valueOf(cacheDomain.size()), cacheDomain.readWrite(), null);
/*     */     }
/*     */   }
/*     */   
/*     */   private void parseCacheRef() {
/* 177 */     CacheNamespaceRef cacheDomainRef = (CacheNamespaceRef)this.type.getAnnotation(CacheNamespaceRef.class);
/* 178 */     if (cacheDomainRef != null) {
/* 179 */       this.assistant.useCacheRef(cacheDomainRef.value().getName());
/*     */     }
/*     */   }
/*     */   
/*     */   private String parseResultMap(Method method) {
/* 184 */     Class<?> returnType = getReturnType(method);
/* 185 */     ConstructorArgs args = (ConstructorArgs)method.getAnnotation(ConstructorArgs.class);
/* 186 */     Results results = (Results)method.getAnnotation(Results.class);
/* 187 */     TypeDiscriminator typeDiscriminator = (TypeDiscriminator)method.getAnnotation(TypeDiscriminator.class);
/* 188 */     String resultMapId = generateResultMapName(method);
/* 189 */     applyResultMap(resultMapId, returnType, argsIf(args), resultsIf(results), typeDiscriminator);
/* 190 */     return resultMapId;
/*     */   }
/*     */   
/*     */   private String generateResultMapName(Method method) {
/* 194 */     StringBuilder suffix = new StringBuilder();
/* 195 */     for (Class<?> c : method.getParameterTypes()) {
/* 196 */       suffix.append("-");
/* 197 */       suffix.append(c.getSimpleName());
/*     */     }
/* 199 */     if (suffix.length() < 1) {
/* 200 */       suffix.append("-void");
/*     */     }
/* 202 */     return this.type.getName() + "." + method.getName() + suffix;
/*     */   }
/*     */   
/*     */   private void applyResultMap(String resultMapId, Class<?> returnType, Arg[] args, Result[] results, TypeDiscriminator discriminator) {
/* 206 */     List<ResultMapping> resultMappings = new ArrayList();
/* 207 */     applyConstructorArgs(args, returnType, resultMappings);
/* 208 */     applyResults(results, returnType, resultMappings);
/* 209 */     Discriminator disc = applyDiscriminator(resultMapId, returnType, discriminator);
/* 210 */     this.assistant.addResultMap(resultMapId, returnType, null, disc, resultMappings, null);
/* 211 */     createDiscriminatorResultMaps(resultMapId, returnType, discriminator);
/*     */   }
/*     */   
/*     */   private void createDiscriminatorResultMaps(String resultMapId, Class<?> resultType, TypeDiscriminator discriminator) {
/* 215 */     if (discriminator != null) {
/* 216 */       for (Case c : discriminator.cases()) {
/* 217 */         String caseResultMapId = resultMapId + "-" + c.value();
/* 218 */         List<ResultMapping> resultMappings = new ArrayList();
/* 219 */         applyConstructorArgs(c.constructArgs(), resultType, resultMappings);
/* 220 */         applyResults(c.results(), resultType, resultMappings);
/* 221 */         this.assistant.addResultMap(caseResultMapId, c.type(), resultMapId, null, resultMappings, null);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Discriminator applyDiscriminator(String resultMapId, Class<?> resultType, TypeDiscriminator discriminator) {
/* 227 */     if (discriminator != null) {
/* 228 */       String column = discriminator.column();
/* 229 */       Class<?> javaType = discriminator.javaType() == Void.TYPE ? String.class : discriminator.javaType();
/* 230 */       JdbcType jdbcType = discriminator.jdbcType() == JdbcType.UNDEFINED ? null : discriminator.jdbcType();
/* 231 */       Class<? extends TypeHandler<?>> typeHandler = discriminator.typeHandler() == UnknownTypeHandler.class ? null : discriminator.typeHandler();
/* 232 */       Case[] cases = discriminator.cases();
/* 233 */       Map<String, String> discriminatorMap = new HashMap();
/* 234 */       for (Case c : cases) {
/* 235 */         String value = c.value();
/* 236 */         String caseResultMapId = resultMapId + "-" + value;
/* 237 */         discriminatorMap.put(value, caseResultMapId);
/*     */       }
/* 239 */       return this.assistant.buildDiscriminator(resultType, column, javaType, jdbcType, typeHandler, discriminatorMap);
/*     */     }
/* 241 */     return null;
/*     */   }
/*     */   
/*     */   void parseStatement(Method method) {
/* 245 */     Class<?> parameterTypeClass = getParameterType(method);
/* 246 */     LanguageDriver languageDriver = getLanguageDriver(method);
/* 247 */     SqlSource sqlSource = getSqlSourceFromAnnotations(method, parameterTypeClass, languageDriver);
/* 248 */     if (sqlSource != null) {
/* 249 */       Options options = (Options)method.getAnnotation(Options.class);
/* 250 */       String mappedStatementId = this.type.getName() + "." + method.getName();
/* 251 */       Integer fetchSize = null;
/* 252 */       Integer timeout = null;
/* 253 */       StatementType statementType = StatementType.PREPARED;
/* 254 */       ResultSetType resultSetType = ResultSetType.FORWARD_ONLY;
/* 255 */       SqlCommandType sqlCommandType = getSqlCommandType(method);
/* 256 */       boolean isSelect = sqlCommandType == SqlCommandType.SELECT;
/* 257 */       boolean flushCache = !isSelect;
/* 258 */       boolean useCache = isSelect;
/*     */       
/*     */ 
/* 261 */       String keyProperty = "id";
/* 262 */       String keyColumn = null;
/* 263 */       KeyGenerator keyGenerator; if ((SqlCommandType.INSERT.equals(sqlCommandType)) || (SqlCommandType.UPDATE.equals(sqlCommandType)))
/*     */       {
/* 265 */         SelectKey selectKey = (SelectKey)method.getAnnotation(SelectKey.class);
/* 266 */         if (selectKey != null) {
/* 267 */           KeyGenerator keyGenerator = handleSelectKeyAnnotation(selectKey, mappedStatementId, getParameterType(method), languageDriver);
/* 268 */           keyProperty = selectKey.keyProperty();
/*     */         } else { KeyGenerator keyGenerator;
/* 270 */           if (options == null) {
/* 271 */             keyGenerator = this.configuration.isUseGeneratedKeys() ? new Jdbc3KeyGenerator() : new NoKeyGenerator();
/*     */           } else {
/* 273 */             KeyGenerator keyGenerator = options.useGeneratedKeys() ? new Jdbc3KeyGenerator() : new NoKeyGenerator();
/* 274 */             keyProperty = options.keyProperty();
/* 275 */             keyColumn = options.keyColumn();
/*     */           }
/*     */         }
/*     */       } else {
/* 279 */         keyGenerator = new NoKeyGenerator();
/*     */       }
/*     */       
/* 282 */       if (options != null) {
/* 283 */         flushCache = options.flushCache();
/* 284 */         useCache = options.useCache();
/* 285 */         fetchSize = (options.fetchSize() > -1) || (options.fetchSize() == Integer.MIN_VALUE) ? Integer.valueOf(options.fetchSize()) : null;
/* 286 */         timeout = options.timeout() > -1 ? Integer.valueOf(options.timeout()) : null;
/* 287 */         statementType = options.statementType();
/* 288 */         resultSetType = options.resultSetType();
/*     */       }
/*     */       
/* 291 */       String resultMapId = null;
/* 292 */       ResultMap resultMapAnnotation = (ResultMap)method.getAnnotation(ResultMap.class);
/* 293 */       if (resultMapAnnotation != null) {
/* 294 */         String[] resultMaps = resultMapAnnotation.value();
/* 295 */         StringBuilder sb = new StringBuilder();
/* 296 */         for (String resultMap : resultMaps) {
/* 297 */           if (sb.length() > 0) sb.append(",");
/* 298 */           sb.append(resultMap);
/*     */         }
/* 300 */         resultMapId = sb.toString();
/* 301 */       } else if (isSelect) {
/* 302 */         resultMapId = parseResultMap(method);
/*     */       }
/*     */       
/* 305 */       this.assistant.addMappedStatement(mappedStatementId, sqlSource, statementType, sqlCommandType, fetchSize, timeout, null, parameterTypeClass, resultMapId, getReturnType(method), resultSetType, flushCache, useCache, false, keyGenerator, keyProperty, keyColumn, null, languageDriver, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private LanguageDriver getLanguageDriver(Method method)
/*     */   {
/* 330 */     Lang lang = (Lang)method.getAnnotation(Lang.class);
/* 331 */     Class<?> langClass = null;
/* 332 */     if (lang != null) {
/* 333 */       langClass = lang.value();
/*     */     }
/* 335 */     return this.assistant.getLanguageDriver(langClass);
/*     */   }
/*     */   
/*     */   private Class<?> getParameterType(Method method) {
/* 339 */     Class<?> parameterType = null;
/* 340 */     Class<?>[] parameterTypes = method.getParameterTypes();
/* 341 */     for (int i = 0; i < parameterTypes.length; i++) {
/* 342 */       if ((!RowBounds.class.isAssignableFrom(parameterTypes[i])) && (!ResultHandler.class.isAssignableFrom(parameterTypes[i]))) {
/* 343 */         if (parameterType == null) {
/* 344 */           parameterType = parameterTypes[i];
/*     */         } else {
/* 346 */           parameterType = MapperMethod.ParamMap.class;
/*     */         }
/*     */       }
/*     */     }
/* 350 */     return parameterType;
/*     */   }
/*     */   
/*     */   private Class<?> getReturnType(Method method) {
/* 354 */     Class<?> returnType = method.getReturnType();
/* 355 */     if (Void.TYPE.equals(returnType)) {
/* 356 */       ResultType rt = (ResultType)method.getAnnotation(ResultType.class);
/* 357 */       if (rt != null) {
/* 358 */         returnType = rt.value();
/*     */       }
/* 360 */     } else if (Collection.class.isAssignableFrom(returnType)) {
/* 361 */       Type returnTypeParameter = method.getGenericReturnType();
/* 362 */       if ((returnTypeParameter instanceof ParameterizedType)) {
/* 363 */         Type[] actualTypeArguments = ((ParameterizedType)returnTypeParameter).getActualTypeArguments();
/* 364 */         if ((actualTypeArguments != null) && (actualTypeArguments.length == 1)) {
/* 365 */           returnTypeParameter = actualTypeArguments[0];
/* 366 */           if ((returnTypeParameter instanceof Class)) {
/* 367 */             returnType = (Class)returnTypeParameter;
/* 368 */           } else if ((returnTypeParameter instanceof ParameterizedType)) {
/* 369 */             returnType = (Class)((ParameterizedType)returnTypeParameter).getRawType();
/* 370 */           } else if ((returnTypeParameter instanceof GenericArrayType)) {
/* 371 */             Class<?> componentType = (Class)((GenericArrayType)returnTypeParameter).getGenericComponentType();
/* 372 */             returnType = Array.newInstance(componentType, 0).getClass();
/*     */           }
/*     */         }
/*     */       }
/* 376 */     } else if ((method.isAnnotationPresent(MapKey.class)) && (Map.class.isAssignableFrom(returnType)))
/*     */     {
/* 378 */       Type returnTypeParameter = method.getGenericReturnType();
/* 379 */       if ((returnTypeParameter instanceof ParameterizedType)) {
/* 380 */         Type[] actualTypeArguments = ((ParameterizedType)returnTypeParameter).getActualTypeArguments();
/* 381 */         if ((actualTypeArguments != null) && (actualTypeArguments.length == 2)) {
/* 382 */           returnTypeParameter = actualTypeArguments[1];
/* 383 */           if ((returnTypeParameter instanceof Class)) {
/* 384 */             returnType = (Class)returnTypeParameter;
/* 385 */           } else if ((returnTypeParameter instanceof ParameterizedType)) {
/* 386 */             returnType = (Class)((ParameterizedType)returnTypeParameter).getRawType();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 392 */     return returnType;
/*     */   }
/*     */   
/*     */   private SqlSource getSqlSourceFromAnnotations(Method method, Class<?> parameterType, LanguageDriver languageDriver) {
/*     */     try {
/* 397 */       Class<? extends Annotation> sqlAnnotationType = getSqlAnnotationType(method);
/* 398 */       Class<? extends Annotation> sqlProviderAnnotationType = getSqlProviderAnnotationType(method);
/* 399 */       if (sqlAnnotationType != null) {
/* 400 */         if (sqlProviderAnnotationType != null) {
/* 401 */           throw new BindingException("You cannot supply both a static SQL and SqlProvider to method named " + method.getName());
/*     */         }
/* 403 */         Annotation sqlAnnotation = method.getAnnotation(sqlAnnotationType);
/* 404 */         String[] strings = (String[])sqlAnnotation.getClass().getMethod("value", new Class[0]).invoke(sqlAnnotation, new Object[0]);
/* 405 */         return buildSqlSourceFromStrings(strings, parameterType, languageDriver); }
/* 406 */       if (sqlProviderAnnotationType != null) {
/* 407 */         Annotation sqlProviderAnnotation = method.getAnnotation(sqlProviderAnnotationType);
/* 408 */         return new ProviderSqlSource(this.assistant.getConfiguration(), sqlProviderAnnotation);
/*     */       }
/* 410 */       return null;
/*     */     } catch (Exception e) {
/* 412 */       throw new BuilderException("Could not find value method on SQL annotation.  Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   private SqlSource buildSqlSourceFromStrings(String[] strings, Class<?> parameterTypeClass, LanguageDriver languageDriver) {
/* 417 */     StringBuilder sql = new StringBuilder();
/* 418 */     for (String fragment : strings) {
/* 419 */       sql.append(fragment);
/* 420 */       sql.append(" ");
/*     */     }
/* 422 */     return languageDriver.createSqlSource(this.configuration, sql.toString(), parameterTypeClass);
/*     */   }
/*     */   
/*     */   private SqlCommandType getSqlCommandType(Method method) {
/* 426 */     Class<? extends Annotation> type = getSqlAnnotationType(method);
/*     */     
/* 428 */     if (type == null) {
/* 429 */       type = getSqlProviderAnnotationType(method);
/*     */       
/* 431 */       if (type == null) {
/* 432 */         return SqlCommandType.UNKNOWN;
/*     */       }
/*     */       
/* 435 */       if (type == SelectProvider.class) {
/* 436 */         type = Select.class;
/* 437 */       } else if (type == InsertProvider.class) {
/* 438 */         type = Insert.class;
/* 439 */       } else if (type == UpdateProvider.class) {
/* 440 */         type = Update.class;
/* 441 */       } else if (type == DeleteProvider.class) {
/* 442 */         type = Delete.class;
/*     */       }
/*     */     }
/*     */     
/* 446 */     return SqlCommandType.valueOf(type.getSimpleName().toUpperCase(Locale.ENGLISH));
/*     */   }
/*     */   
/*     */   private Class<? extends Annotation> getSqlAnnotationType(Method method) {
/* 450 */     return chooseAnnotationType(method, this.sqlAnnotationTypes);
/*     */   }
/*     */   
/*     */   private Class<? extends Annotation> getSqlProviderAnnotationType(Method method) {
/* 454 */     return chooseAnnotationType(method, this.sqlProviderAnnotationTypes);
/*     */   }
/*     */   
/*     */   private Class<? extends Annotation> chooseAnnotationType(Method method, Set<Class<? extends Annotation>> types) {
/* 458 */     for (Class<? extends Annotation> type : types) {
/* 459 */       Annotation annotation = method.getAnnotation(type);
/* 460 */       if (annotation != null) {
/* 461 */         return type;
/*     */       }
/*     */     }
/* 464 */     return null;
/*     */   }
/*     */   
/*     */   private void applyResults(Result[] results, Class<?> resultType, List<ResultMapping> resultMappings) {
/* 468 */     for (Result result : results) {
/* 469 */       ArrayList<ResultFlag> flags = new ArrayList();
/* 470 */       if (result.id()) flags.add(ResultFlag.ID);
/* 471 */       ResultMapping resultMapping = this.assistant.buildResultMapping(resultType, nullOrEmpty(result.property()), nullOrEmpty(result.column()), result.javaType() == Void.TYPE ? null : result.javaType(), result.jdbcType() == JdbcType.UNDEFINED ? null : result.jdbcType(), hasNestedSelect(result) ? nestedSelectId(result) : null, null, null, null, result.typeHandler() == UnknownTypeHandler.class ? null : result.typeHandler(), flags, null, null, isLazy(result));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 486 */       resultMappings.add(resultMapping);
/*     */     }
/*     */   }
/*     */   
/*     */   private String nestedSelectId(Result result) {
/* 491 */     String nestedSelect = result.one().select();
/* 492 */     if (nestedSelect.length() < 1) {
/* 493 */       nestedSelect = result.many().select();
/*     */     }
/* 495 */     if (!nestedSelect.contains(".")) {
/* 496 */       nestedSelect = this.type.getName() + "." + nestedSelect;
/*     */     }
/* 498 */     return nestedSelect;
/*     */   }
/*     */   
/*     */   private boolean isLazy(Result result) {
/* 502 */     Boolean isLazy = Boolean.valueOf(this.configuration.isLazyLoadingEnabled());
/* 503 */     if ((result.one().select().length() > 0) && (FetchType.DEFAULT != result.one().fetchType())) {
/* 504 */       isLazy = Boolean.valueOf(result.one().fetchType() == FetchType.LAZY);
/* 505 */     } else if ((result.many().select().length() > 0) && (FetchType.DEFAULT != result.many().fetchType())) {
/* 506 */       isLazy = Boolean.valueOf(result.many().fetchType() == FetchType.LAZY);
/*     */     }
/* 508 */     return isLazy.booleanValue();
/*     */   }
/*     */   
/*     */   private boolean hasNestedSelect(Result result) {
/* 512 */     if ((result.one().select().length() > 0) && (result.many().select().length() > 0)) {
/* 513 */       throw new BuilderException("Cannot use both @One and @Many annotations in the same @Result");
/*     */     }
/* 515 */     return (result.one().select().length() > 0) || (result.many().select().length() > 0);
/*     */   }
/*     */   
/*     */   private void applyConstructorArgs(Arg[] args, Class<?> resultType, List<ResultMapping> resultMappings) {
/* 519 */     for (Arg arg : args) {
/* 520 */       ArrayList<ResultFlag> flags = new ArrayList();
/* 521 */       flags.add(ResultFlag.CONSTRUCTOR);
/* 522 */       if (arg.id()) flags.add(ResultFlag.ID);
/* 523 */       ResultMapping resultMapping = this.assistant.buildResultMapping(resultType, null, nullOrEmpty(arg.column()), arg.javaType() == Void.TYPE ? null : arg.javaType(), arg.jdbcType() == JdbcType.UNDEFINED ? null : arg.jdbcType(), nullOrEmpty(arg.select()), nullOrEmpty(arg.resultMap()), null, null, arg.typeHandler() == UnknownTypeHandler.class ? null : arg.typeHandler(), flags, null, null, false);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 538 */       resultMappings.add(resultMapping);
/*     */     }
/*     */   }
/*     */   
/*     */   private String nullOrEmpty(String value) {
/* 543 */     return (value == null) || (value.trim().length() == 0) ? null : value;
/*     */   }
/*     */   
/*     */   private Result[] resultsIf(Results results) {
/* 547 */     return results == null ? new Result[0] : results.value();
/*     */   }
/*     */   
/*     */   private Arg[] argsIf(ConstructorArgs args) {
/* 551 */     return args == null ? new Arg[0] : args.value();
/*     */   }
/*     */   
/*     */   private KeyGenerator handleSelectKeyAnnotation(SelectKey selectKeyAnnotation, String baseStatementId, Class<?> parameterTypeClass, LanguageDriver languageDriver) {
/* 555 */     String id = baseStatementId + "!selectKey";
/* 556 */     Class<?> resultTypeClass = selectKeyAnnotation.resultType();
/* 557 */     StatementType statementType = selectKeyAnnotation.statementType();
/* 558 */     String keyProperty = selectKeyAnnotation.keyProperty();
/* 559 */     String keyColumn = selectKeyAnnotation.keyColumn();
/* 560 */     boolean executeBefore = selectKeyAnnotation.before();
/*     */     
/*     */ 
/* 563 */     boolean useCache = false;
/* 564 */     KeyGenerator keyGenerator = new NoKeyGenerator();
/* 565 */     Integer fetchSize = null;
/* 566 */     Integer timeout = null;
/* 567 */     boolean flushCache = false;
/* 568 */     String parameterMap = null;
/* 569 */     String resultMap = null;
/* 570 */     ResultSetType resultSetTypeEnum = null;
/*     */     
/* 572 */     SqlSource sqlSource = buildSqlSourceFromStrings(selectKeyAnnotation.statement(), parameterTypeClass, languageDriver);
/* 573 */     SqlCommandType sqlCommandType = SqlCommandType.SELECT;
/*     */     
/* 575 */     this.assistant.addMappedStatement(id, sqlSource, statementType, sqlCommandType, fetchSize, timeout, parameterMap, parameterTypeClass, resultMap, resultTypeClass, resultSetTypeEnum, flushCache, useCache, false, keyGenerator, keyProperty, keyColumn, null, languageDriver, null);
/*     */     
/*     */ 
/*     */ 
/* 579 */     id = this.assistant.applyCurrentNamespace(id, false);
/*     */     
/* 581 */     MappedStatement keyStatement = this.configuration.getMappedStatement(id, false);
/* 582 */     SelectKeyGenerator answer = new SelectKeyGenerator(keyStatement, executeBefore);
/* 583 */     this.configuration.addKeyGenerator(id, answer);
/* 584 */     return answer;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\builder\annotation\MapperAnnotationBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */