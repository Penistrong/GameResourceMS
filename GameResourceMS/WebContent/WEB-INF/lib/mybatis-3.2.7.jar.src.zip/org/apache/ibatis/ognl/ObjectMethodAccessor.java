/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectMethodAccessor
/*    */   implements MethodAccessor
/*    */ {
/*    */   public Object callStaticMethod(Map context, Class targetClass, String methodName, Object[] args)
/*    */     throws MethodFailedException
/*    */   {
/* 46 */     List methods = OgnlRuntime.getMethods(targetClass, methodName, true);
/*    */     
/* 48 */     return OgnlRuntime.callAppropriateMethod((OgnlContext)context, targetClass, null, methodName, null, methods, args);
/*    */   }
/*    */   
/*    */   public Object callMethod(Map context, Object target, String methodName, Object[] args) throws MethodFailedException
/*    */   {
/* 53 */     Class targetClass = target == null ? null : target.getClass();
/* 54 */     Object source = target;
/* 55 */     List methods = OgnlRuntime.getMethods(targetClass, methodName, false);
/*    */     
/* 57 */     if ((methods == null) || (methods.size() == 0)) {
/* 58 */       methods = OgnlRuntime.getMethods(targetClass, methodName, true);
/* 59 */       source = targetClass;
/*    */     }
/* 61 */     return OgnlRuntime.callAppropriateMethod((OgnlContext)context, target, target, methodName, null, methods, args);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ObjectMethodAccessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */