/*     */ package org.apache.ibatis.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.type.JdbcType;
/*     */ import org.apache.ibatis.type.TypeHandler;
/*     */ import org.apache.ibatis.type.TypeHandlerRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResultMapping
/*     */ {
/*     */   private Configuration configuration;
/*     */   private String property;
/*     */   private String column;
/*     */   private Class<?> javaType;
/*     */   private JdbcType jdbcType;
/*     */   private TypeHandler<?> typeHandler;
/*     */   private String nestedResultMapId;
/*     */   private String nestedQueryId;
/*     */   private Set<String> notNullColumns;
/*     */   private String columnPrefix;
/*     */   private List<ResultFlag> flags;
/*     */   private List<ResultMapping> composites;
/*     */   private String resultSet;
/*     */   private String foreignColumn;
/*     */   private boolean lazy;
/*     */   
/*     */   public static class Builder
/*     */   {
/*  53 */     private ResultMapping resultMapping = new ResultMapping(null);
/*     */     
/*     */     public Builder(Configuration configuration, String property, String column, TypeHandler<?> typeHandler) {
/*  56 */       this(configuration, property);
/*  57 */       this.resultMapping.column = column;
/*  58 */       this.resultMapping.typeHandler = typeHandler;
/*     */     }
/*     */     
/*     */     public Builder(Configuration configuration, String property, String column, Class<?> javaType) {
/*  62 */       this(configuration, property);
/*  63 */       this.resultMapping.column = column;
/*  64 */       this.resultMapping.javaType = javaType;
/*     */     }
/*     */     
/*     */     public Builder(Configuration configuration, String property) {
/*  68 */       this.resultMapping.configuration = configuration;
/*  69 */       this.resultMapping.property = property;
/*  70 */       this.resultMapping.flags = new ArrayList();
/*  71 */       this.resultMapping.composites = new ArrayList();
/*  72 */       this.resultMapping.lazy = configuration.isLazyLoadingEnabled();
/*     */     }
/*     */     
/*     */     public Builder javaType(Class<?> javaType) {
/*  76 */       this.resultMapping.javaType = javaType;
/*  77 */       return this;
/*     */     }
/*     */     
/*     */     public Builder jdbcType(JdbcType jdbcType) {
/*  81 */       this.resultMapping.jdbcType = jdbcType;
/*  82 */       return this;
/*     */     }
/*     */     
/*     */     public Builder nestedResultMapId(String nestedResultMapId) {
/*  86 */       this.resultMapping.nestedResultMapId = nestedResultMapId;
/*  87 */       return this;
/*     */     }
/*     */     
/*     */     public Builder nestedQueryId(String nestedQueryId) {
/*  91 */       this.resultMapping.nestedQueryId = nestedQueryId;
/*  92 */       return this;
/*     */     }
/*     */     
/*     */     public Builder resultSet(String resultSet) {
/*  96 */       this.resultMapping.resultSet = resultSet;
/*  97 */       return this;
/*     */     }
/*     */     
/*     */     public Builder foreignColumn(String foreignColumn) {
/* 101 */       this.resultMapping.foreignColumn = foreignColumn;
/* 102 */       return this;
/*     */     }
/*     */     
/*     */     public Builder notNullColumns(Set<String> notNullColumns) {
/* 106 */       this.resultMapping.notNullColumns = notNullColumns;
/* 107 */       return this;
/*     */     }
/*     */     
/*     */     public Builder columnPrefix(String columnPrefix) {
/* 111 */       this.resultMapping.columnPrefix = columnPrefix;
/* 112 */       return this;
/*     */     }
/*     */     
/*     */     public Builder flags(List<ResultFlag> flags) {
/* 116 */       this.resultMapping.flags = flags;
/* 117 */       return this;
/*     */     }
/*     */     
/*     */     public Builder typeHandler(TypeHandler<?> typeHandler) {
/* 121 */       this.resultMapping.typeHandler = typeHandler;
/* 122 */       return this;
/*     */     }
/*     */     
/*     */     public Builder composites(List<ResultMapping> composites) {
/* 126 */       this.resultMapping.composites = composites;
/* 127 */       return this;
/*     */     }
/*     */     
/*     */     public Builder lazy(boolean lazy) {
/* 131 */       this.resultMapping.lazy = lazy;
/* 132 */       return this;
/*     */     }
/*     */     
/*     */     public ResultMapping build()
/*     */     {
/* 137 */       this.resultMapping.flags = Collections.unmodifiableList(this.resultMapping.flags);
/* 138 */       this.resultMapping.composites = Collections.unmodifiableList(this.resultMapping.composites);
/* 139 */       resolveTypeHandler();
/* 140 */       validate();
/* 141 */       return this.resultMapping;
/*     */     }
/*     */     
/*     */     private void validate()
/*     */     {
/* 146 */       if ((this.resultMapping.nestedQueryId != null) && (this.resultMapping.nestedResultMapId != null)) {
/* 147 */         throw new IllegalStateException("Cannot define both nestedQueryId and nestedResultMapId in property " + this.resultMapping.property);
/*     */       }
/*     */       
/* 150 */       if ((this.resultMapping.nestedQueryId == null) && (this.resultMapping.nestedResultMapId == null) && (this.resultMapping.typeHandler == null)) {
/* 151 */         throw new IllegalStateException("No typehandler found for property " + this.resultMapping.property);
/*     */       }
/*     */       
/* 154 */       if ((this.resultMapping.nestedResultMapId == null) && (this.resultMapping.column == null) && (this.resultMapping.composites.size() == 0)) {
/* 155 */         throw new IllegalStateException("Mapping is missing column attribute for property " + this.resultMapping.property);
/*     */       }
/* 157 */       if (this.resultMapping.getResultSet() != null) {
/* 158 */         int numColums = 0;
/* 159 */         if (this.resultMapping.column != null) {
/* 160 */           numColums = this.resultMapping.column.split(",").length;
/*     */         }
/* 162 */         int numForeignColumns = 0;
/* 163 */         if (this.resultMapping.foreignColumn != null) {
/* 164 */           numForeignColumns = this.resultMapping.foreignColumn.split(",").length;
/*     */         }
/* 166 */         if (numColums != numForeignColumns) {
/* 167 */           throw new IllegalStateException("There should be the same number of columns and foreignColumns in property " + this.resultMapping.property);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private void resolveTypeHandler() {
/* 173 */       if ((this.resultMapping.typeHandler == null) && (this.resultMapping.javaType != null)) {
/* 174 */         Configuration configuration = this.resultMapping.configuration;
/* 175 */         TypeHandlerRegistry typeHandlerRegistry = configuration.getTypeHandlerRegistry();
/* 176 */         this.resultMapping.typeHandler = typeHandlerRegistry.getTypeHandler(this.resultMapping.javaType, this.resultMapping.jdbcType);
/*     */       }
/*     */     }
/*     */     
/*     */     public Builder column(String column) {
/* 181 */       this.resultMapping.column = column;
/* 182 */       return this;
/*     */     }
/*     */   }
/*     */   
/*     */   public String getProperty() {
/* 187 */     return this.property;
/*     */   }
/*     */   
/*     */   public String getColumn() {
/* 191 */     return this.column;
/*     */   }
/*     */   
/*     */   public Class<?> getJavaType() {
/* 195 */     return this.javaType;
/*     */   }
/*     */   
/*     */   public JdbcType getJdbcType() {
/* 199 */     return this.jdbcType;
/*     */   }
/*     */   
/*     */   public TypeHandler<?> getTypeHandler() {
/* 203 */     return this.typeHandler;
/*     */   }
/*     */   
/*     */   public String getNestedResultMapId() {
/* 207 */     return this.nestedResultMapId;
/*     */   }
/*     */   
/*     */   public String getNestedQueryId() {
/* 211 */     return this.nestedQueryId;
/*     */   }
/*     */   
/*     */   public Set<String> getNotNullColumns() {
/* 215 */     return this.notNullColumns;
/*     */   }
/*     */   
/*     */   public String getColumnPrefix() {
/* 219 */     return this.columnPrefix;
/*     */   }
/*     */   
/*     */   public List<ResultFlag> getFlags() {
/* 223 */     return this.flags;
/*     */   }
/*     */   
/*     */   public List<ResultMapping> getComposites() {
/* 227 */     return this.composites;
/*     */   }
/*     */   
/*     */   public boolean isCompositeResult() {
/* 231 */     return (this.composites != null) && (!this.composites.isEmpty());
/*     */   }
/*     */   
/*     */   public String getResultSet() {
/* 235 */     return this.resultSet;
/*     */   }
/*     */   
/*     */   public String getForeignColumn() {
/* 239 */     return this.foreignColumn;
/*     */   }
/*     */   
/*     */   public void setForeignColumn(String foreignColumn) {
/* 243 */     this.foreignColumn = foreignColumn;
/*     */   }
/*     */   
/*     */   public boolean isLazy() {
/* 247 */     return this.lazy;
/*     */   }
/*     */   
/*     */   public void setLazy(boolean lazy) {
/* 251 */     this.lazy = lazy;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o)
/*     */   {
/* 256 */     if (this == o) {
/* 257 */       return true;
/*     */     }
/* 259 */     if ((o == null) || (getClass() != o.getClass())) {
/* 260 */       return false;
/*     */     }
/*     */     
/* 263 */     ResultMapping that = (ResultMapping)o;
/*     */     
/* 265 */     if ((this.property == null) || (!this.property.equals(that.property))) {
/* 266 */       return false;
/*     */     }
/*     */     
/* 269 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 274 */     if (this.property != null)
/* 275 */       return this.property.hashCode();
/* 276 */     if (this.column != null) {
/* 277 */       return this.column.hashCode();
/*     */     }
/* 279 */     return 0;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\mapping\ResultMapping.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */