/*    */ package org.apache.ibatis.parsing;
/*    */ 
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyParser
/*    */ {
/*    */   public static String parse(String string, Properties variables)
/*    */   {
/* 26 */     VariableTokenHandler handler = new VariableTokenHandler(variables);
/* 27 */     GenericTokenParser parser = new GenericTokenParser("${", "}", handler);
/* 28 */     return parser.parse(string);
/*    */   }
/*    */   
/*    */   private static class VariableTokenHandler implements TokenHandler {
/*    */     private Properties variables;
/*    */     
/*    */     public VariableTokenHandler(Properties variables) {
/* 35 */       this.variables = variables;
/*    */     }
/*    */     
/*    */     public String handleToken(String content) {
/* 39 */       if ((this.variables != null) && (this.variables.containsKey(content))) {
/* 40 */         return this.variables.getProperty(content);
/*    */       }
/* 42 */       return "${" + content + "}";
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\parsing\PropertyParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */