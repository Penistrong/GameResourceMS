package org.apache.ibatis.ognl;

import java.util.Map;

public abstract interface MethodAccessor
{
  public abstract Object callStaticMethod(Map paramMap, Class paramClass, String paramString, Object[] paramArrayOfObject)
    throws MethodFailedException;
  
  public abstract Object callMethod(Map paramMap, Object paramObject, String paramString, Object[] paramArrayOfObject)
    throws MethodFailedException;
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\MethodAccessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */