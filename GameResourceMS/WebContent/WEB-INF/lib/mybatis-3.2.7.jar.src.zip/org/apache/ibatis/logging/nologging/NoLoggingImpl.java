/*    */ package org.apache.ibatis.logging.nologging;
/*    */ 
/*    */ import org.apache.ibatis.logging.Log;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoLoggingImpl
/*    */   implements Log
/*    */ {
/*    */   public NoLoggingImpl(String clazz) {}
/*    */   
/*    */   public boolean isDebugEnabled()
/*    */   {
/* 29 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isTraceEnabled() {
/* 33 */     return false;
/*    */   }
/*    */   
/*    */   public void error(String s, Throwable e) {}
/*    */   
/*    */   public void error(String s) {}
/*    */   
/*    */   public void debug(String s) {}
/*    */   
/*    */   public void trace(String s) {}
/*    */   
/*    */   public void warn(String s) {}
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\logging\nologging\NoLoggingImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */