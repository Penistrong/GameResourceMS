/*    */ package org.apache.ibatis.scripting.xmltags;
/*    */ 
/*    */ import org.apache.ibatis.builder.xml.XMLMapperEntityResolver;
/*    */ import org.apache.ibatis.executor.parameter.ParameterHandler;
/*    */ import org.apache.ibatis.mapping.BoundSql;
/*    */ import org.apache.ibatis.mapping.MappedStatement;
/*    */ import org.apache.ibatis.mapping.SqlSource;
/*    */ import org.apache.ibatis.parsing.PropertyParser;
/*    */ import org.apache.ibatis.parsing.XNode;
/*    */ import org.apache.ibatis.parsing.XPathParser;
/*    */ import org.apache.ibatis.scripting.LanguageDriver;
/*    */ import org.apache.ibatis.scripting.defaults.DefaultParameterHandler;
/*    */ import org.apache.ibatis.scripting.defaults.RawSqlSource;
/*    */ import org.apache.ibatis.session.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLLanguageDriver
/*    */   implements LanguageDriver
/*    */ {
/*    */   public ParameterHandler createParameterHandler(MappedStatement mappedStatement, Object parameterObject, BoundSql boundSql)
/*    */   {
/* 37 */     return new DefaultParameterHandler(mappedStatement, parameterObject, boundSql);
/*    */   }
/*    */   
/*    */   public SqlSource createSqlSource(Configuration configuration, XNode script, Class<?> parameterType) {
/* 41 */     XMLScriptBuilder builder = new XMLScriptBuilder(configuration, script, parameterType);
/* 42 */     return builder.parseScriptNode();
/*    */   }
/*    */   
/*    */   public SqlSource createSqlSource(Configuration configuration, String script, Class<?> parameterType) {
/* 46 */     if (script.startsWith("<script>")) {
/* 47 */       XPathParser parser = new XPathParser(script, false, configuration.getVariables(), new XMLMapperEntityResolver());
/* 48 */       return createSqlSource(configuration, parser.evalNode("/script"), parameterType);
/*    */     }
/* 50 */     script = PropertyParser.parse(script, configuration.getVariables());
/* 51 */     TextSqlNode textSqlNode = new TextSqlNode(script);
/* 52 */     if (textSqlNode.isDynamic()) {
/* 53 */       return new DynamicSqlSource(configuration, textSqlNode);
/*    */     }
/* 55 */     return new RawSqlSource(configuration, script, parameterType);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\xmltags\XMLLanguageDriver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */