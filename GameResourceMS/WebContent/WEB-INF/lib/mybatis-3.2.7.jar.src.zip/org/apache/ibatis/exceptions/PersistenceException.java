/*    */ package org.apache.ibatis.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PersistenceException
/*    */   extends IbatisException
/*    */ {
/*    */   private static final long serialVersionUID = -7537395265357977271L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PersistenceException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PersistenceException(String message)
/*    */   {
/* 31 */     super(message);
/*    */   }
/*    */   
/*    */   public PersistenceException(String message, Throwable cause) {
/* 35 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public PersistenceException(Throwable cause) {
/* 39 */     super(cause);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\exceptions\PersistenceException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */