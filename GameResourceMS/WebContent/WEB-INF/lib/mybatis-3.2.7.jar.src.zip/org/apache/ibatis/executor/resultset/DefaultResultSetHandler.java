/*     */ package org.apache.ibatis.executor.resultset;
/*     */ 
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.ibatis.cache.CacheKey;
/*     */ import org.apache.ibatis.executor.Executor;
/*     */ import org.apache.ibatis.executor.ExecutorException;
/*     */ import org.apache.ibatis.executor.loader.ProxyFactory;
/*     */ import org.apache.ibatis.executor.loader.ResultLoader;
/*     */ import org.apache.ibatis.executor.loader.ResultLoaderMap;
/*     */ import org.apache.ibatis.executor.parameter.ParameterHandler;
/*     */ import org.apache.ibatis.executor.result.DefaultResultContext;
/*     */ import org.apache.ibatis.executor.result.DefaultResultHandler;
/*     */ import org.apache.ibatis.mapping.BoundSql;
/*     */ import org.apache.ibatis.mapping.Discriminator;
/*     */ import org.apache.ibatis.mapping.MappedStatement;
/*     */ import org.apache.ibatis.mapping.ParameterMap;
/*     */ import org.apache.ibatis.mapping.ParameterMapping;
/*     */ import org.apache.ibatis.mapping.ParameterMode;
/*     */ import org.apache.ibatis.mapping.ResultMap;
/*     */ import org.apache.ibatis.mapping.ResultMapping;
/*     */ import org.apache.ibatis.reflection.MetaClass;
/*     */ import org.apache.ibatis.reflection.MetaObject;
/*     */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*     */ import org.apache.ibatis.session.AutoMappingBehavior;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.session.ResultContext;
/*     */ import org.apache.ibatis.session.ResultHandler;
/*     */ import org.apache.ibatis.session.RowBounds;
/*     */ import org.apache.ibatis.type.TypeHandler;
/*     */ import org.apache.ibatis.type.TypeHandlerRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultResultSetHandler
/*     */   implements ResultSetHandler
/*     */ {
/*  62 */   private static final Object NO_VALUE = new Object();
/*     */   
/*     */   private final Executor executor;
/*     */   
/*     */   private final Configuration configuration;
/*     */   
/*     */   private final MappedStatement mappedStatement;
/*     */   private final RowBounds rowBounds;
/*     */   private final ParameterHandler parameterHandler;
/*     */   private final ResultHandler resultHandler;
/*     */   private final BoundSql boundSql;
/*     */   private final TypeHandlerRegistry typeHandlerRegistry;
/*     */   private final ObjectFactory objectFactory;
/*  75 */   private final Map<CacheKey, Object> nestedResultObjects = new HashMap();
/*  76 */   private final Map<CacheKey, Object> ancestorObjects = new HashMap();
/*  77 */   private final Map<String, String> ancestorColumnPrefix = new HashMap();
/*     */   
/*     */ 
/*  80 */   private final Map<String, ResultMapping> nextResultMaps = new HashMap();
/*  81 */   private final Map<CacheKey, PendingRelation> pendingRelations = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultResultSetHandler(Executor executor, MappedStatement mappedStatement, ParameterHandler parameterHandler, ResultHandler resultHandler, BoundSql boundSql, RowBounds rowBounds)
/*     */   {
/*  90 */     this.executor = executor;
/*  91 */     this.configuration = mappedStatement.getConfiguration();
/*  92 */     this.mappedStatement = mappedStatement;
/*  93 */     this.rowBounds = rowBounds;
/*  94 */     this.parameterHandler = parameterHandler;
/*  95 */     this.boundSql = boundSql;
/*  96 */     this.typeHandlerRegistry = this.configuration.getTypeHandlerRegistry();
/*  97 */     this.objectFactory = this.configuration.getObjectFactory();
/*  98 */     this.resultHandler = resultHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleOutputParameters(CallableStatement cs)
/*     */     throws SQLException
/*     */   {
/* 106 */     Object parameterObject = this.parameterHandler.getParameterObject();
/* 107 */     MetaObject metaParam = this.configuration.newMetaObject(parameterObject);
/* 108 */     List<ParameterMapping> parameterMappings = this.boundSql.getParameterMappings();
/* 109 */     for (int i = 0; i < parameterMappings.size(); i++) {
/* 110 */       ParameterMapping parameterMapping = (ParameterMapping)parameterMappings.get(i);
/* 111 */       if ((parameterMapping.getMode() == ParameterMode.OUT) || (parameterMapping.getMode() == ParameterMode.INOUT)) {
/* 112 */         if (ResultSet.class.equals(parameterMapping.getJavaType())) {
/* 113 */           handleRefCursorOutputParameter((ResultSet)cs.getObject(i + 1), parameterMapping, metaParam);
/*     */         } else {
/* 115 */           TypeHandler<?> typeHandler = parameterMapping.getTypeHandler();
/* 116 */           metaParam.setValue(parameterMapping.getProperty(), typeHandler.getResult(cs, i + 1));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void handleRefCursorOutputParameter(ResultSet rs, ParameterMapping parameterMapping, MetaObject metaParam) throws SQLException {
/*     */     try {
/* 124 */       String resultMapId = parameterMapping.getResultMapId();
/* 125 */       ResultMap resultMap = this.configuration.getResultMap(resultMapId);
/* 126 */       DefaultResultHandler resultHandler = new DefaultResultHandler(this.objectFactory);
/* 127 */       ResultSetWrapper rsw = new ResultSetWrapper(rs, this.configuration);
/* 128 */       handleRowValues(rsw, resultMap, resultHandler, new RowBounds(), null);
/* 129 */       metaParam.setValue(parameterMapping.getProperty(), resultHandler.getResultList());
/*     */     } finally {
/* 131 */       closeResultSet(rs);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Object> handleResultSets(Statement stmt)
/*     */     throws SQLException
/*     */   {
/* 140 */     List<Object> multipleResults = new ArrayList();
/*     */     
/* 142 */     int resultSetCount = 0;
/* 143 */     ResultSetWrapper rsw = getFirstResultSet(stmt);
/*     */     
/* 145 */     List<ResultMap> resultMaps = this.mappedStatement.getResultMaps();
/* 146 */     int resultMapCount = resultMaps.size();
/* 147 */     validateResultMapsCount(rsw, resultMapCount);
/* 148 */     while ((rsw != null) && (resultMapCount > resultSetCount)) {
/* 149 */       ResultMap resultMap = (ResultMap)resultMaps.get(resultSetCount);
/* 150 */       handleResultSet(rsw, resultMap, multipleResults, null);
/* 151 */       rsw = getNextResultSet(stmt);
/* 152 */       cleanUpAfterHandlingResultSet();
/* 153 */       resultSetCount++;
/*     */     }
/*     */     
/* 156 */     String[] resultSets = this.mappedStatement.getResulSets();
/* 157 */     if (resultSets != null) {
/* 158 */       while ((rsw != null) && (resultSetCount < resultSets.length)) {
/* 159 */         ResultMapping parentMapping = (ResultMapping)this.nextResultMaps.get(resultSets[resultSetCount]);
/* 160 */         if (parentMapping != null) {
/* 161 */           String nestedResultMapId = parentMapping.getNestedResultMapId();
/* 162 */           ResultMap resultMap = this.configuration.getResultMap(nestedResultMapId);
/* 163 */           handleResultSet(rsw, resultMap, null, parentMapping);
/*     */         }
/* 165 */         rsw = getNextResultSet(stmt);
/* 166 */         cleanUpAfterHandlingResultSet();
/* 167 */         resultSetCount++;
/*     */       }
/*     */     }
/*     */     
/* 171 */     return collapseSingleResultList(multipleResults);
/*     */   }
/*     */   
/*     */   private ResultSetWrapper getFirstResultSet(Statement stmt) throws SQLException {
/* 175 */     ResultSet rs = stmt.getResultSet();
/* 176 */     while (rs == null)
/*     */     {
/*     */ 
/* 179 */       if (stmt.getMoreResults()) {
/* 180 */         rs = stmt.getResultSet();
/*     */       }
/* 182 */       else if (stmt.getUpdateCount() == -1) {
/*     */         break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 188 */     return rs != null ? new ResultSetWrapper(rs, this.configuration) : null;
/*     */   }
/*     */   
/*     */   private ResultSetWrapper getNextResultSet(Statement stmt) throws SQLException
/*     */   {
/*     */     try {
/* 194 */       if (stmt.getConnection().getMetaData().supportsMultipleResultSets())
/*     */       {
/* 196 */         if ((stmt.getMoreResults()) || (stmt.getUpdateCount() != -1)) {
/* 197 */           ResultSet rs = stmt.getResultSet();
/* 198 */           return rs != null ? new ResultSetWrapper(rs, this.configuration) : null;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/* 204 */     return null;
/*     */   }
/*     */   
/*     */   private void closeResultSet(ResultSet rs) {
/*     */     try {
/* 209 */       if (rs != null) {
/* 210 */         rs.close();
/*     */       }
/*     */     }
/*     */     catch (SQLException e) {}
/*     */   }
/*     */   
/*     */   private void cleanUpAfterHandlingResultSet()
/*     */   {
/* 218 */     this.nestedResultObjects.clear();
/* 219 */     this.ancestorColumnPrefix.clear();
/*     */   }
/*     */   
/*     */   private void validateResultMapsCount(ResultSetWrapper rsw, int resultMapCount) {
/* 223 */     if ((rsw != null) && (resultMapCount < 1)) {
/* 224 */       throw new ExecutorException("A query was run and no Result Maps were found for the Mapped Statement '" + this.mappedStatement.getId() + "'.  It's likely that neither a Result Type nor a Result Map was specified.");
/*     */     }
/*     */   }
/*     */   
/*     */   private void handleResultSet(ResultSetWrapper rsw, ResultMap resultMap, List<Object> multipleResults, ResultMapping parentMapping) throws SQLException
/*     */   {
/*     */     try {
/* 231 */       if (parentMapping != null) {
/* 232 */         handleRowValues(rsw, resultMap, null, RowBounds.DEFAULT, parentMapping);
/*     */       }
/* 234 */       else if (this.resultHandler == null) {
/* 235 */         DefaultResultHandler defaultResultHandler = new DefaultResultHandler(this.objectFactory);
/* 236 */         handleRowValues(rsw, resultMap, defaultResultHandler, this.rowBounds, null);
/* 237 */         multipleResults.add(defaultResultHandler.getResultList());
/*     */       } else {
/* 239 */         handleRowValues(rsw, resultMap, this.resultHandler, this.rowBounds, null);
/*     */       }
/*     */     }
/*     */     finally {
/* 243 */       closeResultSet(rsw.getResultSet());
/*     */     }
/*     */   }
/*     */   
/*     */   private List<Object> collapseSingleResultList(List<Object> multipleResults) {
/* 248 */     if (multipleResults.size() == 1)
/*     */     {
/* 250 */       List<Object> returned = (List)multipleResults.get(0);
/* 251 */       return returned;
/*     */     }
/* 253 */     return multipleResults;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void handleRowValues(ResultSetWrapper rsw, ResultMap resultMap, ResultHandler resultHandler, RowBounds rowBounds, ResultMapping parentMapping)
/*     */     throws SQLException
/*     */   {
/* 261 */     if (resultMap.hasNestedResultMaps()) {
/* 262 */       ensureNoRowBounds();
/* 263 */       checkResultHandler();
/* 264 */       handleRowValuesForNestedResultMap(rsw, resultMap, resultHandler, rowBounds, parentMapping);
/*     */     } else {
/* 266 */       handleRowValuesForSimpleResultMap(rsw, resultMap, resultHandler, rowBounds, parentMapping);
/*     */     }
/*     */   }
/*     */   
/*     */   private void ensureNoRowBounds() {
/* 271 */     if ((this.configuration.isSafeRowBoundsEnabled()) && (this.rowBounds != null) && ((this.rowBounds.getLimit() < Integer.MAX_VALUE) || (this.rowBounds.getOffset() > 0))) {
/* 272 */       throw new ExecutorException("Mapped Statements with nested result mappings cannot be safely constrained by RowBounds. Use safeRowBoundsEnabled=false setting to bypass this check.");
/*     */     }
/*     */   }
/*     */   
/*     */   protected void checkResultHandler()
/*     */   {
/* 278 */     if ((this.resultHandler != null) && (this.configuration.isSafeResultHandlerEnabled()) && (!this.mappedStatement.isResultOrdered())) {
/* 279 */       throw new ExecutorException("Mapped Statements with nested result mappings cannot be safely used with a custom ResultHandler. Use safeResultHandlerEnabled=false setting to bypass this check or ensure your statement returns ordered data and set resultOrdered=true on it.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void handleRowValuesForSimpleResultMap(ResultSetWrapper rsw, ResultMap resultMap, ResultHandler resultHandler, RowBounds rowBounds, ResultMapping parentMapping)
/*     */     throws SQLException
/*     */   {
/* 287 */     DefaultResultContext resultContext = new DefaultResultContext();
/* 288 */     skipRows(rsw.getResultSet(), rowBounds);
/* 289 */     while (shouldProcessMoreRows(rsw.getResultSet(), resultContext, rowBounds)) {
/* 290 */       ResultMap discriminatedResultMap = resolveDiscriminatedResultMap(rsw.getResultSet(), resultMap, null);
/* 291 */       Object rowValue = getRowValue(rsw, discriminatedResultMap);
/* 292 */       storeObject(resultHandler, resultContext, rowValue, parentMapping, rsw.getResultSet());
/*     */     }
/*     */   }
/*     */   
/*     */   private void storeObject(ResultHandler resultHandler, DefaultResultContext resultContext, Object rowValue, ResultMapping parentMapping, ResultSet rs) throws SQLException {
/* 297 */     if (parentMapping != null) {
/* 298 */       linkToParent(rs, parentMapping, rowValue);
/*     */     } else {
/* 300 */       callResultHandler(resultHandler, resultContext, rowValue);
/*     */     }
/*     */   }
/*     */   
/*     */   private void callResultHandler(ResultHandler resultHandler, DefaultResultContext resultContext, Object rowValue) {
/* 305 */     resultContext.nextResultObject(rowValue);
/* 306 */     resultHandler.handleResult(resultContext);
/*     */   }
/*     */   
/*     */   private boolean shouldProcessMoreRows(ResultSet rs, ResultContext context, RowBounds rowBounds) throws SQLException {
/* 310 */     return (!context.isStopped()) && (rs.next()) && (context.getResultCount() < rowBounds.getLimit());
/*     */   }
/*     */   
/*     */   private void skipRows(ResultSet rs, RowBounds rowBounds) throws SQLException {
/* 314 */     if (rs.getType() != 1003) {
/* 315 */       if (rowBounds.getOffset() != 0) {
/* 316 */         rs.absolute(rowBounds.getOffset());
/*     */       }
/*     */     } else {
/* 319 */       for (int i = 0; i < rowBounds.getOffset(); i++) {
/* 320 */         rs.next();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Object getRowValue(ResultSetWrapper rsw, ResultMap resultMap)
/*     */     throws SQLException
/*     */   {
/* 330 */     ResultLoaderMap lazyLoader = new ResultLoaderMap();
/* 331 */     Object resultObject = createResultObject(rsw, resultMap, lazyLoader, null);
/* 332 */     if ((resultObject != null) && (!this.typeHandlerRegistry.hasTypeHandler(resultMap.getType()))) {
/* 333 */       MetaObject metaObject = this.configuration.newMetaObject(resultObject);
/* 334 */       boolean foundValues = resultMap.getConstructorResultMappings().size() > 0;
/* 335 */       if (shouldApplyAutomaticMappings(resultMap, !AutoMappingBehavior.NONE.equals(this.configuration.getAutoMappingBehavior()))) {
/* 336 */         foundValues = (applyAutomaticMappings(rsw, resultMap, metaObject, null)) || (foundValues);
/*     */       }
/* 338 */       foundValues = (applyPropertyMappings(rsw, resultMap, metaObject, lazyLoader, null)) || (foundValues);
/* 339 */       foundValues = (lazyLoader.size() > 0) || (foundValues);
/* 340 */       resultObject = foundValues ? resultObject : null;
/* 341 */       return resultObject;
/*     */     }
/* 343 */     return resultObject;
/*     */   }
/*     */   
/*     */   private boolean shouldApplyAutomaticMappings(ResultMap resultMap, boolean def) {
/* 347 */     return resultMap.getAutoMapping() != null ? resultMap.getAutoMapping().booleanValue() : def;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean applyPropertyMappings(ResultSetWrapper rsw, ResultMap resultMap, MetaObject metaObject, ResultLoaderMap lazyLoader, String columnPrefix)
/*     */     throws SQLException
/*     */   {
/* 356 */     List<String> mappedColumnNames = rsw.getMappedColumnNames(resultMap, columnPrefix);
/* 357 */     boolean foundValues = false;
/* 358 */     List<ResultMapping> propertyMappings = resultMap.getPropertyResultMappings();
/* 359 */     for (ResultMapping propertyMapping : propertyMappings) {
/* 360 */       String column = prependPrefix(propertyMapping.getColumn(), columnPrefix);
/* 361 */       if ((propertyMapping.isCompositeResult()) || ((column != null) && (mappedColumnNames.contains(column.toUpperCase(Locale.ENGLISH)))) || (propertyMapping.getResultSet() != null))
/*     */       {
/*     */ 
/* 364 */         Object value = getPropertyMappingValue(rsw.getResultSet(), metaObject, propertyMapping, lazyLoader, columnPrefix);
/* 365 */         String property = propertyMapping.getProperty();
/* 366 */         if ((value != NO_VALUE) && (property != null) && ((value != null) || (this.configuration.isCallSettersOnNulls()))) {
/* 367 */           if ((value != null) || (!metaObject.getSetterType(property).isPrimitive())) {
/* 368 */             metaObject.setValue(property, value);
/*     */           }
/* 370 */           foundValues = true;
/*     */         }
/*     */       }
/*     */     }
/* 374 */     return foundValues;
/*     */   }
/*     */   
/*     */   private Object getPropertyMappingValue(ResultSet rs, MetaObject metaResultObject, ResultMapping propertyMapping, ResultLoaderMap lazyLoader, String columnPrefix) throws SQLException
/*     */   {
/* 379 */     if (propertyMapping.getNestedQueryId() != null)
/* 380 */       return getNestedQueryMappingValue(rs, metaResultObject, propertyMapping, lazyLoader, columnPrefix);
/* 381 */     if (propertyMapping.getResultSet() != null) {
/* 382 */       addPendingChildRelation(rs, metaResultObject, propertyMapping);
/* 383 */       return NO_VALUE; }
/* 384 */     if (propertyMapping.getNestedResultMapId() != null)
/*     */     {
/* 386 */       return NO_VALUE;
/*     */     }
/* 388 */     TypeHandler<?> typeHandler = propertyMapping.getTypeHandler();
/* 389 */     String column = prependPrefix(propertyMapping.getColumn(), columnPrefix);
/* 390 */     return typeHandler.getResult(rs, column);
/*     */   }
/*     */   
/*     */   private boolean applyAutomaticMappings(ResultSetWrapper rsw, ResultMap resultMap, MetaObject metaObject, String columnPrefix) throws SQLException
/*     */   {
/* 395 */     List<String> unmappedColumnNames = rsw.getUnmappedColumnNames(resultMap, columnPrefix);
/* 396 */     boolean foundValues = false;
/* 397 */     for (String columnName : unmappedColumnNames) {
/* 398 */       String propertyName = columnName;
/* 399 */       if ((columnPrefix != null) && (columnPrefix.length() > 0))
/*     */       {
/*     */ 
/* 402 */         if (columnName.toUpperCase(Locale.ENGLISH).startsWith(columnPrefix)) {
/* 403 */           propertyName = columnName.substring(columnPrefix.length());
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 408 */         String property = metaObject.findProperty(propertyName, this.configuration.isMapUnderscoreToCamelCase());
/* 409 */         if ((property != null) && (metaObject.hasSetter(property))) {
/* 410 */           Class<?> propertyType = metaObject.getSetterType(property);
/* 411 */           if (this.typeHandlerRegistry.hasTypeHandler(propertyType)) {
/* 412 */             TypeHandler<?> typeHandler = rsw.getTypeHandler(propertyType, columnName);
/* 413 */             Object value = typeHandler.getResult(rsw.getResultSet(), columnName);
/* 414 */             if ((value != null) || (this.configuration.isCallSettersOnNulls())) {
/* 415 */               if ((value != null) || (!propertyType.isPrimitive())) {
/* 416 */                 metaObject.setValue(property, value);
/*     */               }
/* 418 */               foundValues = true;
/*     */             }
/*     */           }
/*     */         }
/*     */       } }
/* 423 */     return foundValues;
/*     */   }
/*     */   
/*     */   private void linkToParent(ResultSet rs, ResultMapping parentMapping, Object rowValue)
/*     */     throws SQLException
/*     */   {
/* 429 */     CacheKey parentKey = createKeyForMultipleResults(rs, parentMapping, parentMapping.getColumn(), parentMapping.getForeignColumn());
/* 430 */     PendingRelation parent = (PendingRelation)this.pendingRelations.get(parentKey);
/* 431 */     if (parent != null) {
/* 432 */       Object collectionProperty = instantiateCollectionPropertyIfAppropriate(parent.propertyMapping, parent.metaObject);
/* 433 */       if (rowValue != null) {
/* 434 */         if (collectionProperty != null) {
/* 435 */           MetaObject targetMetaObject = this.configuration.newMetaObject(collectionProperty);
/* 436 */           targetMetaObject.add(rowValue);
/*     */         } else {
/* 438 */           parent.metaObject.setValue(parent.propertyMapping.getProperty(), rowValue);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Object instantiateCollectionPropertyIfAppropriate(ResultMapping resultMapping, MetaObject metaObject) {
/* 445 */     String propertyName = resultMapping.getProperty();
/* 446 */     Object propertyValue = metaObject.getValue(propertyName);
/* 447 */     if (propertyValue == null) {
/* 448 */       Class<?> type = resultMapping.getJavaType();
/* 449 */       if (type == null) {
/* 450 */         type = metaObject.getSetterType(propertyName);
/*     */       }
/*     */       try {
/* 453 */         if (this.objectFactory.isCollection(type)) {
/* 454 */           propertyValue = this.objectFactory.create(type);
/* 455 */           metaObject.setValue(propertyName, propertyValue);
/* 456 */           return propertyValue;
/*     */         }
/*     */       } catch (Exception e) {
/* 459 */         throw new ExecutorException("Error instantiating collection property for result '" + resultMapping.getProperty() + "'.  Cause: " + e, e);
/*     */       }
/* 461 */     } else if (this.objectFactory.isCollection(propertyValue.getClass())) {
/* 462 */       return propertyValue;
/*     */     }
/* 464 */     return null;
/*     */   }
/*     */   
/*     */   private void addPendingChildRelation(ResultSet rs, MetaObject metaResultObject, ResultMapping parentMapping) throws SQLException {
/* 468 */     CacheKey cacheKey = createKeyForMultipleResults(rs, parentMapping, parentMapping.getColumn(), parentMapping.getColumn());
/* 469 */     PendingRelation deferLoad = new PendingRelation(null);
/* 470 */     deferLoad.metaObject = metaResultObject;
/* 471 */     deferLoad.propertyMapping = parentMapping;
/* 472 */     this.pendingRelations.put(cacheKey, deferLoad);
/* 473 */     ResultMapping previous = (ResultMapping)this.nextResultMaps.get(parentMapping.getResultSet());
/* 474 */     if (previous == null) {
/* 475 */       this.nextResultMaps.put(parentMapping.getResultSet(), parentMapping);
/*     */     }
/* 477 */     else if (!previous.equals(parentMapping)) {
/* 478 */       throw new ExecutorException("Two different properties are mapped to the same resultSet");
/*     */     }
/*     */   }
/*     */   
/*     */   private CacheKey createKeyForMultipleResults(ResultSet rs, ResultMapping resultMapping, String names, String columns) throws SQLException
/*     */   {
/* 484 */     CacheKey cacheKey = new CacheKey();
/* 485 */     cacheKey.update(resultMapping);
/* 486 */     if ((columns != null) && (names != null)) {
/* 487 */       String[] columnsArray = columns.split(",");
/* 488 */       String[] namesArray = names.split(",");
/* 489 */       for (int i = 0; i < columnsArray.length; i++) {
/* 490 */         Object value = rs.getString(columnsArray[i]);
/* 491 */         if (value != null) {
/* 492 */           cacheKey.update(namesArray[i]);
/* 493 */           cacheKey.update(value);
/*     */         }
/*     */       }
/*     */     }
/* 497 */     return cacheKey;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Object createResultObject(ResultSetWrapper rsw, ResultMap resultMap, ResultLoaderMap lazyLoader, String columnPrefix)
/*     */     throws SQLException
/*     */   {
/* 505 */     List<Class<?>> constructorArgTypes = new ArrayList();
/* 506 */     List<Object> constructorArgs = new ArrayList();
/* 507 */     Object resultObject = createResultObject(rsw, resultMap, constructorArgTypes, constructorArgs, columnPrefix);
/* 508 */     if ((resultObject != null) && (!this.typeHandlerRegistry.hasTypeHandler(resultMap.getType()))) {
/* 509 */       List<ResultMapping> propertyMappings = resultMap.getPropertyResultMappings();
/* 510 */       for (ResultMapping propertyMapping : propertyMappings) {
/* 511 */         if ((propertyMapping.getNestedQueryId() != null) && (propertyMapping.isLazy())) {
/* 512 */           return this.configuration.getProxyFactory().createProxy(resultObject, lazyLoader, this.configuration, this.objectFactory, constructorArgTypes, constructorArgs);
/*     */         }
/*     */       }
/*     */     }
/* 516 */     return resultObject;
/*     */   }
/*     */   
/*     */   private Object createResultObject(ResultSetWrapper rsw, ResultMap resultMap, List<Class<?>> constructorArgTypes, List<Object> constructorArgs, String columnPrefix) throws SQLException
/*     */   {
/* 521 */     Class<?> resultType = resultMap.getType();
/* 522 */     List<ResultMapping> constructorMappings = resultMap.getConstructorResultMappings();
/* 523 */     if (this.typeHandlerRegistry.hasTypeHandler(resultType))
/* 524 */       return createPrimitiveResultObject(rsw, resultMap, columnPrefix);
/* 525 */     if (constructorMappings.size() > 0) {
/* 526 */       return createParameterizedResultObject(rsw, resultType, constructorMappings, constructorArgTypes, constructorArgs, columnPrefix);
/*     */     }
/* 528 */     return this.objectFactory.create(resultType);
/*     */   }
/*     */   
/*     */   private Object createParameterizedResultObject(ResultSetWrapper rsw, Class<?> resultType, List<ResultMapping> constructorMappings, List<Class<?>> constructorArgTypes, List<Object> constructorArgs, String columnPrefix)
/*     */     throws SQLException
/*     */   {
/* 534 */     boolean foundValues = false;
/* 535 */     for (ResultMapping constructorMapping : constructorMappings) {
/* 536 */       Class<?> parameterType = constructorMapping.getJavaType();
/* 537 */       String column = constructorMapping.getColumn();
/*     */       Object value;
/* 539 */       Object value; if (constructorMapping.getNestedQueryId() != null) {
/* 540 */         value = getNestedQueryConstructorValue(rsw.getResultSet(), constructorMapping, columnPrefix); } else { Object value;
/* 541 */         if (constructorMapping.getNestedResultMapId() != null) {
/* 542 */           ResultMap resultMap = this.configuration.getResultMap(constructorMapping.getNestedResultMapId());
/* 543 */           value = getRowValue(rsw, resultMap);
/*     */         } else {
/* 545 */           TypeHandler<?> typeHandler = constructorMapping.getTypeHandler();
/* 546 */           value = typeHandler.getResult(rsw.getResultSet(), prependPrefix(column, columnPrefix));
/*     */         } }
/* 548 */       constructorArgTypes.add(parameterType);
/* 549 */       constructorArgs.add(value);
/* 550 */       foundValues = (value != null) || (foundValues);
/*     */     }
/* 552 */     return foundValues ? this.objectFactory.create(resultType, constructorArgTypes, constructorArgs) : null;
/*     */   }
/*     */   
/*     */   private Object createPrimitiveResultObject(ResultSetWrapper rsw, ResultMap resultMap, String columnPrefix) throws SQLException {
/* 556 */     Class<?> resultType = resultMap.getType();
/*     */     String columnName;
/* 558 */     String columnName; if (resultMap.getResultMappings().size() > 0) {
/* 559 */       List<ResultMapping> resultMappingList = resultMap.getResultMappings();
/* 560 */       ResultMapping mapping = (ResultMapping)resultMappingList.get(0);
/* 561 */       columnName = prependPrefix(mapping.getColumn(), columnPrefix);
/*     */     } else {
/* 563 */       columnName = (String)rsw.getColumnNames().get(0);
/*     */     }
/* 565 */     TypeHandler<?> typeHandler = rsw.getTypeHandler(resultType, columnName);
/* 566 */     return typeHandler.getResult(rsw.getResultSet(), columnName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Object getNestedQueryConstructorValue(ResultSet rs, ResultMapping constructorMapping, String columnPrefix)
/*     */     throws SQLException
/*     */   {
/* 574 */     String nestedQueryId = constructorMapping.getNestedQueryId();
/* 575 */     MappedStatement nestedQuery = this.configuration.getMappedStatement(nestedQueryId);
/* 576 */     Class<?> nestedQueryParameterType = nestedQuery.getParameterMap().getType();
/* 577 */     Object nestedQueryParameterObject = prepareParameterForNestedQuery(rs, constructorMapping, nestedQueryParameterType, columnPrefix);
/* 578 */     Object value = null;
/* 579 */     if (nestedQueryParameterObject != null) {
/* 580 */       BoundSql nestedBoundSql = nestedQuery.getBoundSql(nestedQueryParameterObject);
/* 581 */       CacheKey key = this.executor.createCacheKey(nestedQuery, nestedQueryParameterObject, RowBounds.DEFAULT, nestedBoundSql);
/* 582 */       Class<?> targetType = constructorMapping.getJavaType();
/* 583 */       ResultLoader resultLoader = new ResultLoader(this.configuration, this.executor, nestedQuery, nestedQueryParameterObject, targetType, key, nestedBoundSql);
/* 584 */       value = resultLoader.loadResult();
/*     */     }
/* 586 */     return value;
/*     */   }
/*     */   
/*     */   private Object getNestedQueryMappingValue(ResultSet rs, MetaObject metaResultObject, ResultMapping propertyMapping, ResultLoaderMap lazyLoader, String columnPrefix) throws SQLException
/*     */   {
/* 591 */     String nestedQueryId = propertyMapping.getNestedQueryId();
/* 592 */     String property = propertyMapping.getProperty();
/* 593 */     MappedStatement nestedQuery = this.configuration.getMappedStatement(nestedQueryId);
/* 594 */     Class<?> nestedQueryParameterType = nestedQuery.getParameterMap().getType();
/* 595 */     Object nestedQueryParameterObject = prepareParameterForNestedQuery(rs, propertyMapping, nestedQueryParameterType, columnPrefix);
/* 596 */     Object value = NO_VALUE;
/* 597 */     if (nestedQueryParameterObject != null) {
/* 598 */       BoundSql nestedBoundSql = nestedQuery.getBoundSql(nestedQueryParameterObject);
/* 599 */       CacheKey key = this.executor.createCacheKey(nestedQuery, nestedQueryParameterObject, RowBounds.DEFAULT, nestedBoundSql);
/* 600 */       Class<?> targetType = propertyMapping.getJavaType();
/* 601 */       if (this.executor.isCached(nestedQuery, key)) {
/* 602 */         this.executor.deferLoad(nestedQuery, metaResultObject, property, key, targetType);
/*     */       } else {
/* 604 */         ResultLoader resultLoader = new ResultLoader(this.configuration, this.executor, nestedQuery, nestedQueryParameterObject, targetType, key, nestedBoundSql);
/* 605 */         if (propertyMapping.isLazy()) {
/* 606 */           lazyLoader.addLoader(property, metaResultObject, resultLoader);
/*     */         } else {
/* 608 */           value = resultLoader.loadResult();
/*     */         }
/*     */       }
/*     */     }
/* 612 */     return value;
/*     */   }
/*     */   
/*     */   private Object prepareParameterForNestedQuery(ResultSet rs, ResultMapping resultMapping, Class<?> parameterType, String columnPrefix) throws SQLException {
/* 616 */     if (resultMapping.isCompositeResult()) {
/* 617 */       return prepareCompositeKeyParameter(rs, resultMapping, parameterType, columnPrefix);
/*     */     }
/* 619 */     return prepareSimpleKeyParameter(rs, resultMapping, parameterType, columnPrefix);
/*     */   }
/*     */   
/*     */   private Object prepareSimpleKeyParameter(ResultSet rs, ResultMapping resultMapping, Class<?> parameterType, String columnPrefix) throws SQLException {
/*     */     TypeHandler<?> typeHandler;
/*     */     TypeHandler<?> typeHandler;
/* 625 */     if (this.typeHandlerRegistry.hasTypeHandler(parameterType)) {
/* 626 */       typeHandler = this.typeHandlerRegistry.getTypeHandler(parameterType);
/*     */     } else {
/* 628 */       typeHandler = this.typeHandlerRegistry.getUnknownTypeHandler();
/*     */     }
/* 630 */     return typeHandler.getResult(rs, prependPrefix(resultMapping.getColumn(), columnPrefix));
/*     */   }
/*     */   
/*     */   private Object prepareCompositeKeyParameter(ResultSet rs, ResultMapping resultMapping, Class<?> parameterType, String columnPrefix) throws SQLException {
/* 634 */     Object parameterObject = instantiateParameterObject(parameterType);
/* 635 */     MetaObject metaObject = this.configuration.newMetaObject(parameterObject);
/* 636 */     boolean foundValues = false;
/* 637 */     for (ResultMapping innerResultMapping : resultMapping.getComposites()) {
/* 638 */       Class<?> propType = metaObject.getSetterType(innerResultMapping.getProperty());
/* 639 */       TypeHandler<?> typeHandler = this.typeHandlerRegistry.getTypeHandler(propType);
/* 640 */       Object propValue = typeHandler.getResult(rs, prependPrefix(innerResultMapping.getColumn(), columnPrefix));
/* 641 */       if (propValue != null) {
/* 642 */         metaObject.setValue(innerResultMapping.getProperty(), propValue);
/* 643 */         foundValues = true;
/*     */       }
/*     */     }
/* 646 */     return foundValues ? parameterObject : null;
/*     */   }
/*     */   
/*     */   private Object instantiateParameterObject(Class<?> parameterType) {
/* 650 */     if (parameterType == null) {
/* 651 */       return new HashMap();
/*     */     }
/* 653 */     return this.objectFactory.create(parameterType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResultMap resolveDiscriminatedResultMap(ResultSet rs, ResultMap resultMap, String columnPrefix)
/*     */     throws SQLException
/*     */   {
/* 662 */     Set<String> pastDiscriminators = new HashSet();
/* 663 */     Discriminator discriminator = resultMap.getDiscriminator();
/* 664 */     while (discriminator != null) {
/* 665 */       Object value = getDiscriminatorValue(rs, discriminator, columnPrefix);
/* 666 */       String discriminatedMapId = discriminator.getMapIdFor(String.valueOf(value));
/* 667 */       if (!this.configuration.hasResultMap(discriminatedMapId)) break;
/* 668 */       resultMap = this.configuration.getResultMap(discriminatedMapId);
/* 669 */       Discriminator lastDiscriminator = discriminator;
/* 670 */       discriminator = resultMap.getDiscriminator();
/* 671 */       if ((discriminator == lastDiscriminator) || (!pastDiscriminators.add(discriminatedMapId))) {
/*     */         break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 678 */     return resultMap;
/*     */   }
/*     */   
/*     */   private Object getDiscriminatorValue(ResultSet rs, Discriminator discriminator, String columnPrefix) throws SQLException {
/* 682 */     ResultMapping resultMapping = discriminator.getResultMapping();
/* 683 */     TypeHandler<?> typeHandler = resultMapping.getTypeHandler();
/* 684 */     return typeHandler.getResult(rs, prependPrefix(resultMapping.getColumn(), columnPrefix));
/*     */   }
/*     */   
/*     */   private String prependPrefix(String columnName, String prefix) {
/* 688 */     if ((columnName == null) || (columnName.length() == 0) || (prefix == null) || (prefix.length() == 0)) {
/* 689 */       return columnName;
/*     */     }
/* 691 */     return prefix + columnName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void handleRowValuesForNestedResultMap(ResultSetWrapper rsw, ResultMap resultMap, ResultHandler resultHandler, RowBounds rowBounds, ResultMapping parentMapping)
/*     */     throws SQLException
/*     */   {
/* 699 */     DefaultResultContext resultContext = new DefaultResultContext();
/* 700 */     skipRows(rsw.getResultSet(), rowBounds);
/* 701 */     Object rowValue = null;
/* 702 */     while (shouldProcessMoreRows(rsw.getResultSet(), resultContext, rowBounds)) {
/* 703 */       ResultMap discriminatedResultMap = resolveDiscriminatedResultMap(rsw.getResultSet(), resultMap, null);
/* 704 */       CacheKey rowKey = createRowKey(discriminatedResultMap, rsw, null);
/* 705 */       Object partialObject = this.nestedResultObjects.get(rowKey);
/* 706 */       if (this.mappedStatement.isResultOrdered()) {
/* 707 */         if ((partialObject == null) && (rowValue != null)) {
/* 708 */           this.nestedResultObjects.clear();
/* 709 */           storeObject(resultHandler, resultContext, rowValue, parentMapping, rsw.getResultSet());
/*     */         }
/* 711 */         rowValue = getRowValue(rsw, discriminatedResultMap, rowKey, rowKey, null, partialObject);
/*     */       } else {
/* 713 */         rowValue = getRowValue(rsw, discriminatedResultMap, rowKey, rowKey, null, partialObject);
/* 714 */         if (partialObject == null) {
/* 715 */           storeObject(resultHandler, resultContext, rowValue, parentMapping, rsw.getResultSet());
/*     */         }
/*     */       }
/*     */     }
/* 719 */     if ((rowValue != null) && (this.mappedStatement.isResultOrdered())) {
/* 720 */       storeObject(resultHandler, resultContext, rowValue, parentMapping, rsw.getResultSet());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Object getRowValue(ResultSetWrapper rsw, ResultMap resultMap, CacheKey combinedKey, CacheKey absoluteKey, String columnPrefix, Object partialObject)
/*     */     throws SQLException
/*     */   {
/* 729 */     String resultMapId = resultMap.getId();
/* 730 */     Object resultObject = partialObject;
/* 731 */     if (resultObject != null) {
/* 732 */       MetaObject metaObject = this.configuration.newMetaObject(resultObject);
/* 733 */       putAncestor(absoluteKey, resultObject, resultMapId, columnPrefix);
/* 734 */       applyNestedResultMappings(rsw, resultMap, metaObject, columnPrefix, combinedKey, false);
/* 735 */       this.ancestorObjects.remove(absoluteKey);
/*     */     } else {
/* 737 */       ResultLoaderMap lazyLoader = new ResultLoaderMap();
/* 738 */       resultObject = createResultObject(rsw, resultMap, lazyLoader, columnPrefix);
/* 739 */       if ((resultObject != null) && (!this.typeHandlerRegistry.hasTypeHandler(resultMap.getType()))) {
/* 740 */         MetaObject metaObject = this.configuration.newMetaObject(resultObject);
/* 741 */         boolean foundValues = resultMap.getConstructorResultMappings().size() > 0;
/* 742 */         if (shouldApplyAutomaticMappings(resultMap, AutoMappingBehavior.FULL.equals(this.configuration.getAutoMappingBehavior()))) {
/* 743 */           foundValues = (applyAutomaticMappings(rsw, resultMap, metaObject, columnPrefix)) || (foundValues);
/*     */         }
/* 745 */         foundValues = (applyPropertyMappings(rsw, resultMap, metaObject, lazyLoader, columnPrefix)) || (foundValues);
/* 746 */         putAncestor(absoluteKey, resultObject, resultMapId, columnPrefix);
/* 747 */         foundValues = (applyNestedResultMappings(rsw, resultMap, metaObject, columnPrefix, combinedKey, true)) || (foundValues);
/* 748 */         this.ancestorObjects.remove(absoluteKey);
/* 749 */         foundValues = (lazyLoader.size() > 0) || (foundValues);
/* 750 */         resultObject = foundValues ? resultObject : null;
/*     */       }
/* 752 */       if (combinedKey != CacheKey.NULL_CACHE_KEY) this.nestedResultObjects.put(combinedKey, resultObject);
/*     */     }
/* 754 */     return resultObject;
/*     */   }
/*     */   
/*     */   private void putAncestor(CacheKey rowKey, Object resultObject, String resultMapId, String columnPrefix) {
/* 758 */     if (!this.ancestorColumnPrefix.containsKey(resultMapId)) {
/* 759 */       this.ancestorColumnPrefix.put(resultMapId, columnPrefix);
/*     */     }
/* 761 */     this.ancestorObjects.put(rowKey, resultObject);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean applyNestedResultMappings(ResultSetWrapper rsw, ResultMap resultMap, MetaObject metaObject, String parentPrefix, CacheKey parentRowKey, boolean newObject)
/*     */   {
/* 769 */     boolean foundValues = false;
/* 770 */     for (ResultMapping resultMapping : resultMap.getPropertyResultMappings()) {
/* 771 */       String nestedResultMapId = resultMapping.getNestedResultMapId();
/* 772 */       if ((nestedResultMapId != null) && (resultMapping.getResultSet() == null)) {
/*     */         try {
/* 774 */           String columnPrefix = getColumnPrefix(parentPrefix, resultMapping);
/* 775 */           ResultMap nestedResultMap = getNestedResultMap(rsw.getResultSet(), nestedResultMapId, columnPrefix);
/* 776 */           CacheKey rowKey = null;
/* 777 */           Object ancestorObject = null;
/* 778 */           if (this.ancestorColumnPrefix.containsKey(nestedResultMapId)) {
/* 779 */             rowKey = createRowKey(nestedResultMap, rsw, (String)this.ancestorColumnPrefix.get(nestedResultMapId));
/* 780 */             ancestorObject = this.ancestorObjects.get(rowKey);
/*     */           }
/* 782 */           if (ancestorObject != null) {
/* 783 */             if (newObject) metaObject.setValue(resultMapping.getProperty(), ancestorObject);
/*     */           } else {
/* 785 */             rowKey = createRowKey(nestedResultMap, rsw, columnPrefix);
/* 786 */             CacheKey combinedKey = combineKeys(rowKey, parentRowKey);
/* 787 */             Object rowValue = this.nestedResultObjects.get(combinedKey);
/* 788 */             boolean knownValue = rowValue != null;
/* 789 */             Object collectionProperty = instantiateCollectionPropertyIfAppropriate(resultMapping, metaObject);
/* 790 */             if (anyNotNullColumnHasValue(resultMapping, columnPrefix, rsw.getResultSet())) {
/* 791 */               rowValue = getRowValue(rsw, nestedResultMap, combinedKey, rowKey, columnPrefix, rowValue);
/* 792 */               if ((rowValue != null) && (!knownValue)) {
/* 793 */                 if (collectionProperty != null) {
/* 794 */                   MetaObject targetMetaObject = this.configuration.newMetaObject(collectionProperty);
/* 795 */                   targetMetaObject.add(rowValue);
/*     */                 } else {
/* 797 */                   metaObject.setValue(resultMapping.getProperty(), rowValue);
/*     */                 }
/* 799 */                 foundValues = true;
/*     */               }
/*     */             }
/*     */           }
/*     */         } catch (SQLException e) {
/* 804 */           throw new ExecutorException("Error getting nested result map values for '" + resultMapping.getProperty() + "'.  Cause: " + e, e);
/*     */         }
/*     */       }
/*     */     }
/* 808 */     return foundValues;
/*     */   }
/*     */   
/*     */   private String getColumnPrefix(String parentPrefix, ResultMapping resultMapping) {
/* 812 */     StringBuilder columnPrefixBuilder = new StringBuilder();
/* 813 */     if (parentPrefix != null) columnPrefixBuilder.append(parentPrefix);
/* 814 */     if (resultMapping.getColumnPrefix() != null) columnPrefixBuilder.append(resultMapping.getColumnPrefix());
/* 815 */     String columnPrefix = columnPrefixBuilder.length() == 0 ? null : columnPrefixBuilder.toString().toUpperCase(Locale.ENGLISH);
/* 816 */     return columnPrefix;
/*     */   }
/*     */   
/*     */   private boolean anyNotNullColumnHasValue(ResultMapping resultMapping, String columnPrefix, ResultSet rs) throws SQLException {
/* 820 */     Set<String> notNullColumns = resultMapping.getNotNullColumns();
/* 821 */     boolean anyNotNullColumnHasValue = true;
/* 822 */     if ((notNullColumns != null) && (!notNullColumns.isEmpty())) {
/* 823 */       anyNotNullColumnHasValue = false;
/* 824 */       for (String column : notNullColumns) {
/* 825 */         rs.getObject(prependPrefix(column, columnPrefix));
/* 826 */         if (!rs.wasNull()) {
/* 827 */           anyNotNullColumnHasValue = true;
/* 828 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 832 */     return anyNotNullColumnHasValue;
/*     */   }
/*     */   
/*     */   private ResultMap getNestedResultMap(ResultSet rs, String nestedResultMapId, String columnPrefix) throws SQLException {
/* 836 */     ResultMap nestedResultMap = this.configuration.getResultMap(nestedResultMapId);
/* 837 */     nestedResultMap = resolveDiscriminatedResultMap(rs, nestedResultMap, columnPrefix);
/* 838 */     return nestedResultMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private CacheKey createRowKey(ResultMap resultMap, ResultSetWrapper rsw, String columnPrefix)
/*     */     throws SQLException
/*     */   {
/* 846 */     CacheKey cacheKey = new CacheKey();
/* 847 */     cacheKey.update(resultMap.getId());
/* 848 */     List<ResultMapping> resultMappings = getResultMappingsForRowKey(resultMap);
/* 849 */     if (resultMappings.size() == 0) {
/* 850 */       if (Map.class.isAssignableFrom(resultMap.getType())) {
/* 851 */         createRowKeyForMap(rsw, cacheKey);
/*     */       } else {
/* 853 */         createRowKeyForUnmappedProperties(resultMap, rsw, cacheKey, columnPrefix);
/*     */       }
/*     */     } else {
/* 856 */       createRowKeyForMappedProperties(resultMap, rsw, cacheKey, resultMappings, columnPrefix);
/*     */     }
/* 858 */     return cacheKey;
/*     */   }
/*     */   
/*     */   private CacheKey combineKeys(CacheKey rowKey, CacheKey parentRowKey) {
/* 862 */     if ((rowKey.getUpdateCount() > 1) && (parentRowKey.getUpdateCount() > 1)) {
/*     */       CacheKey combinedKey;
/*     */       try {
/* 865 */         combinedKey = rowKey.clone();
/*     */       } catch (CloneNotSupportedException e) {
/* 867 */         throw new ExecutorException("Error cloning cache key.  Cause: " + e, e);
/*     */       }
/* 869 */       combinedKey.update(parentRowKey);
/* 870 */       return combinedKey;
/*     */     }
/* 872 */     return CacheKey.NULL_CACHE_KEY;
/*     */   }
/*     */   
/*     */   private List<ResultMapping> getResultMappingsForRowKey(ResultMap resultMap) {
/* 876 */     List<ResultMapping> resultMappings = resultMap.getIdResultMappings();
/* 877 */     if (resultMappings.size() == 0) {
/* 878 */       resultMappings = resultMap.getPropertyResultMappings();
/*     */     }
/* 880 */     return resultMappings;
/*     */   }
/*     */   
/*     */   private void createRowKeyForMappedProperties(ResultMap resultMap, ResultSetWrapper rsw, CacheKey cacheKey, List<ResultMapping> resultMappings, String columnPrefix) throws SQLException {
/* 884 */     for (ResultMapping resultMapping : resultMappings) {
/* 885 */       if ((resultMapping.getNestedResultMapId() != null) && (resultMapping.getResultSet() == null)) {
/* 886 */         ResultMap nestedResultMap = this.configuration.getResultMap(resultMapping.getNestedResultMapId());
/* 887 */         createRowKeyForMappedProperties(nestedResultMap, rsw, cacheKey, nestedResultMap.getConstructorResultMappings(), prependPrefix(resultMapping.getColumnPrefix(), columnPrefix));
/*     */       }
/* 889 */       else if (resultMapping.getNestedQueryId() == null) {
/* 890 */         String column = prependPrefix(resultMapping.getColumn(), columnPrefix);
/* 891 */         TypeHandler<?> th = resultMapping.getTypeHandler();
/* 892 */         List<String> mappedColumnNames = rsw.getMappedColumnNames(resultMap, columnPrefix);
/* 893 */         if ((column != null) && (mappedColumnNames.contains(column.toUpperCase(Locale.ENGLISH)))) {
/* 894 */           Object value = th.getResult(rsw.getResultSet(), column);
/* 895 */           if (value != null) {
/* 896 */             cacheKey.update(column);
/* 897 */             cacheKey.update(value);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void createRowKeyForUnmappedProperties(ResultMap resultMap, ResultSetWrapper rsw, CacheKey cacheKey, String columnPrefix) throws SQLException {
/* 905 */     MetaClass metaType = MetaClass.forClass(resultMap.getType());
/* 906 */     List<String> unmappedColumnNames = rsw.getUnmappedColumnNames(resultMap, columnPrefix);
/* 907 */     for (String column : unmappedColumnNames) {
/* 908 */       String property = column;
/* 909 */       if ((columnPrefix != null) && (columnPrefix.length() > 0))
/*     */       {
/*     */ 
/* 912 */         if (column.toUpperCase(Locale.ENGLISH).startsWith(columnPrefix)) {
/* 913 */           property = column.substring(columnPrefix.length());
/*     */         }
/*     */         
/*     */ 
/*     */       }
/* 918 */       else if (metaType.findProperty(property, this.configuration.isMapUnderscoreToCamelCase()) != null) {
/* 919 */         String value = rsw.getResultSet().getString(column);
/* 920 */         if (value != null) {
/* 921 */           cacheKey.update(column);
/* 922 */           cacheKey.update(value);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void createRowKeyForMap(ResultSetWrapper rsw, CacheKey cacheKey) throws SQLException {
/* 929 */     List<String> columnNames = rsw.getColumnNames();
/* 930 */     for (String columnName : columnNames) {
/* 931 */       String value = rsw.getResultSet().getString(columnName);
/* 932 */       if (value != null) {
/* 933 */         cacheKey.update(columnName);
/* 934 */         cacheKey.update(value);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PendingRelation
/*     */   {
/*     */     public MetaObject metaObject;
/*     */     public ResultMapping propertyMapping;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\resultset\DefaultResultSetHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */