/*    */ package org.apache.ibatis.executor.loader.javassist;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.apache.ibatis.executor.loader.AbstractSerialStateHolder;
/*    */ import org.apache.ibatis.executor.loader.ResultLoaderMap.LoadPair;
/*    */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JavassistSerialStateHolder
/*    */   extends AbstractSerialStateHolder
/*    */ {
/*    */   private static final long serialVersionUID = 8940388717901644661L;
/*    */   
/*    */   public JavassistSerialStateHolder() {}
/*    */   
/*    */   public JavassistSerialStateHolder(Object userBean, Map<String, ResultLoaderMap.LoadPair> unloadedProperties, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs)
/*    */   {
/* 41 */     super(userBean, unloadedProperties, objectFactory, constructorArgTypes, constructorArgs);
/*    */   }
/*    */   
/*    */ 
/*    */   protected Object createDeserializationProxy(Object target, Map<String, ResultLoaderMap.LoadPair> unloadedProperties, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs)
/*    */   {
/* 47 */     return new JavassistProxyFactory().createDeserializationProxy(target, unloadedProperties, objectFactory, constructorArgTypes, constructorArgs);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\loader\javassist\JavassistSerialStateHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */