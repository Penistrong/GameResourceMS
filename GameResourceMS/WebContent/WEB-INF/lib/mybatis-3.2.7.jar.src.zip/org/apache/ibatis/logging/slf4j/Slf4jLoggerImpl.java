/*    */ package org.apache.ibatis.logging.slf4j;
/*    */ 
/*    */ import org.apache.ibatis.logging.Log;
/*    */ import org.slf4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Slf4jLoggerImpl
/*    */   implements Log
/*    */ {
/*    */   private Logger log;
/*    */   
/*    */   public Slf4jLoggerImpl(Logger logger)
/*    */   {
/* 29 */     this.log = logger;
/*    */   }
/*    */   
/*    */   public boolean isDebugEnabled() {
/* 33 */     return this.log.isDebugEnabled();
/*    */   }
/*    */   
/*    */   public boolean isTraceEnabled() {
/* 37 */     return this.log.isTraceEnabled();
/*    */   }
/*    */   
/*    */   public void error(String s, Throwable e) {
/* 41 */     this.log.error(s, e);
/*    */   }
/*    */   
/*    */   public void error(String s) {
/* 45 */     this.log.error(s);
/*    */   }
/*    */   
/*    */   public void debug(String s) {
/* 49 */     this.log.debug(s);
/*    */   }
/*    */   
/*    */   public void trace(String s) {
/* 53 */     this.log.trace(s);
/*    */   }
/*    */   
/*    */   public void warn(String s) {
/* 57 */     this.log.warn(s);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\logging\slf4j\Slf4jLoggerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */