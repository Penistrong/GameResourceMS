package org.apache.ibatis.type;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({java.lang.annotation.ElementType.TYPE})
public @interface MappedJdbcTypes
{
  JdbcType[] value();
  
  boolean includeNullJdbcType() default false;
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\MappedJdbcTypes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */