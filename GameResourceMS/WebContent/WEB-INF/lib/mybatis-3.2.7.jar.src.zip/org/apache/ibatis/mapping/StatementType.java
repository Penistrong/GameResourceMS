package org.apache.ibatis.mapping;

public enum StatementType
{
  STATEMENT,  PREPARED,  CALLABLE;
  
  private StatementType() {}
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\mapping\StatementType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */