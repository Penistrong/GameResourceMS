/*    */ package org.apache.ibatis.cache.decorators;
/*    */ 
/*    */ import java.util.concurrent.locks.ReadWriteLock;
/*    */ import org.apache.ibatis.cache.Cache;
/*    */ import org.apache.ibatis.logging.Log;
/*    */ import org.apache.ibatis.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggingCache
/*    */   implements Cache
/*    */ {
/*    */   private Log log;
/*    */   private Cache delegate;
/* 31 */   protected int requests = 0;
/* 32 */   protected int hits = 0;
/*    */   
/*    */   public LoggingCache(Cache delegate) {
/* 35 */     this.delegate = delegate;
/* 36 */     this.log = LogFactory.getLog(getId());
/*    */   }
/*    */   
/*    */   public String getId()
/*    */   {
/* 41 */     return this.delegate.getId();
/*    */   }
/*    */   
/*    */   public int getSize()
/*    */   {
/* 46 */     return this.delegate.getSize();
/*    */   }
/*    */   
/*    */   public void putObject(Object key, Object object)
/*    */   {
/* 51 */     this.delegate.putObject(key, object);
/*    */   }
/*    */   
/*    */   public Object getObject(Object key)
/*    */   {
/* 56 */     this.requests += 1;
/* 57 */     Object value = this.delegate.getObject(key);
/* 58 */     if (value != null) {
/* 59 */       this.hits += 1;
/*    */     }
/* 61 */     if (this.log.isDebugEnabled()) {
/* 62 */       this.log.debug("Cache Hit Ratio [" + getId() + "]: " + getHitRatio());
/*    */     }
/* 64 */     return value;
/*    */   }
/*    */   
/*    */   public Object removeObject(Object key)
/*    */   {
/* 69 */     return this.delegate.removeObject(key);
/*    */   }
/*    */   
/*    */   public void clear()
/*    */   {
/* 74 */     this.delegate.clear();
/*    */   }
/*    */   
/*    */   public ReadWriteLock getReadWriteLock()
/*    */   {
/* 79 */     return null;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 84 */     return this.delegate.hashCode();
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 89 */     return this.delegate.equals(obj);
/*    */   }
/*    */   
/*    */   private double getHitRatio() {
/* 93 */     return this.hits / this.requests;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\cache\decorators\LoggingCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */