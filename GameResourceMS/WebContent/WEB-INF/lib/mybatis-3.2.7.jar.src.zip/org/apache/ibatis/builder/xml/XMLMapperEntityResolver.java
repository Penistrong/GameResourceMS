/*     */ package org.apache.ibatis.builder.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.ibatis.io.Resources;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLMapperEntityResolver
/*     */   implements EntityResolver
/*     */ {
/*  36 */   private static final Map<String, String> doctypeMap = new HashMap();
/*     */   
/*  38 */   private static final String IBATIS_CONFIG_PUBLIC = "-//ibatis.apache.org//DTD Config 3.0//EN".toUpperCase(Locale.ENGLISH);
/*  39 */   private static final String IBATIS_CONFIG_SYSTEM = "http://ibatis.apache.org/dtd/ibatis-3-config.dtd".toUpperCase(Locale.ENGLISH);
/*     */   
/*  41 */   private static final String IBATIS_MAPPER_PUBLIC = "-//ibatis.apache.org//DTD Mapper 3.0//EN".toUpperCase(Locale.ENGLISH);
/*  42 */   private static final String IBATIS_MAPPER_SYSTEM = "http://ibatis.apache.org/dtd/ibatis-3-mapper.dtd".toUpperCase(Locale.ENGLISH);
/*     */   
/*  44 */   private static final String MYBATIS_CONFIG_PUBLIC = "-//mybatis.org//DTD Config 3.0//EN".toUpperCase(Locale.ENGLISH);
/*  45 */   private static final String MYBATIS_CONFIG_SYSTEM = "http://mybatis.org/dtd/mybatis-3-config.dtd".toUpperCase(Locale.ENGLISH);
/*     */   
/*  47 */   private static final String MYBATIS_MAPPER_PUBLIC = "-//mybatis.org//DTD Mapper 3.0//EN".toUpperCase(Locale.ENGLISH);
/*  48 */   private static final String MYBATIS_MAPPER_SYSTEM = "http://mybatis.org/dtd/mybatis-3-mapper.dtd".toUpperCase(Locale.ENGLISH);
/*     */   private static final String MYBATIS_CONFIG_DTD = "org/apache/ibatis/builder/xml/mybatis-3-config.dtd";
/*     */   private static final String MYBATIS_MAPPER_DTD = "org/apache/ibatis/builder/xml/mybatis-3-mapper.dtd";
/*     */   
/*     */   static
/*     */   {
/*  54 */     doctypeMap.put(IBATIS_CONFIG_SYSTEM, "org/apache/ibatis/builder/xml/mybatis-3-config.dtd");
/*  55 */     doctypeMap.put(IBATIS_CONFIG_PUBLIC, "org/apache/ibatis/builder/xml/mybatis-3-config.dtd");
/*     */     
/*  57 */     doctypeMap.put(IBATIS_MAPPER_SYSTEM, "org/apache/ibatis/builder/xml/mybatis-3-mapper.dtd");
/*  58 */     doctypeMap.put(IBATIS_MAPPER_PUBLIC, "org/apache/ibatis/builder/xml/mybatis-3-mapper.dtd");
/*     */     
/*  60 */     doctypeMap.put(MYBATIS_CONFIG_SYSTEM, "org/apache/ibatis/builder/xml/mybatis-3-config.dtd");
/*  61 */     doctypeMap.put(MYBATIS_CONFIG_PUBLIC, "org/apache/ibatis/builder/xml/mybatis-3-config.dtd");
/*     */     
/*  63 */     doctypeMap.put(MYBATIS_MAPPER_SYSTEM, "org/apache/ibatis/builder/xml/mybatis-3-mapper.dtd");
/*  64 */     doctypeMap.put(MYBATIS_MAPPER_PUBLIC, "org/apache/ibatis/builder/xml/mybatis-3-mapper.dtd");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputSource resolveEntity(String publicId, String systemId)
/*     */     throws SAXException
/*     */   {
/*  78 */     if (publicId != null) publicId = publicId.toUpperCase(Locale.ENGLISH);
/*  79 */     if (systemId != null) { systemId = systemId.toUpperCase(Locale.ENGLISH);
/*     */     }
/*  81 */     InputSource source = null;
/*     */     try {
/*  83 */       String path = (String)doctypeMap.get(publicId);
/*  84 */       source = getInputSource(path, source);
/*  85 */       if (source == null) {
/*  86 */         path = (String)doctypeMap.get(systemId);
/*  87 */         source = getInputSource(path, source);
/*     */       }
/*     */     } catch (Exception e) {
/*  90 */       throw new SAXException(e.toString());
/*     */     }
/*  92 */     return source;
/*     */   }
/*     */   
/*     */   private InputSource getInputSource(String path, InputSource source) {
/*  96 */     if (path != null) {
/*     */       try
/*     */       {
/*  99 */         InputStream in = Resources.getResourceAsStream(path);
/* 100 */         source = new InputSource(in);
/*     */       }
/*     */       catch (IOException e) {}
/*     */     }
/*     */     
/* 105 */     return source;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\builder\xml\XMLMapperEntityResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */