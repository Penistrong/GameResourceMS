/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTStaticMethod
/*    */   extends SimpleNode
/*    */ {
/*    */   private String className;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private String methodName;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ASTStaticMethod(int id)
/*    */   {
/* 43 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTStaticMethod(OgnlParser p, int id) {
/* 47 */     super(p, id);
/*    */   }
/*    */   
/*    */   void init(String className, String methodName)
/*    */   {
/* 52 */     this.className = className;
/* 53 */     this.methodName = methodName;
/*    */   }
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException
/*    */   {
/* 58 */     Object[] args = OgnlRuntime.getObjectArrayPool().create(jjtGetNumChildren());
/* 59 */     Object root = context.getRoot();
/*    */     try
/*    */     {
/* 62 */       int i = 0; for (int icount = args.length; i < icount; i++) {
/* 63 */         args[i] = this.children[i].getValue(context, root);
/*    */       }
/* 65 */       return OgnlRuntime.callStaticMethod(context, this.className, this.methodName, args);
/*    */     } finally {
/* 67 */       OgnlRuntime.getObjectArrayPool().recycle(args);
/*    */     }
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 73 */     String result = "@" + this.className + "@" + this.methodName;
/*    */     
/* 75 */     result = result + "(";
/* 76 */     if ((this.children != null) && (this.children.length > 0)) {
/* 77 */       for (int i = 0; i < this.children.length; i++) {
/* 78 */         if (i > 0) {
/* 79 */           result = result + ", ";
/*    */         }
/* 81 */         result = result + this.children[i];
/*    */       }
/*    */     }
/* 84 */     result = result + ")";
/* 85 */     return result;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTStaticMethod.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */