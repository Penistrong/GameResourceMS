/*     */ package org.apache.ibatis.scripting.xmltags;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.ibatis.ognl.OgnlException;
/*     */ import org.apache.ibatis.ognl.OgnlRuntime;
/*     */ import org.apache.ibatis.ognl.PropertyAccessor;
/*     */ import org.apache.ibatis.reflection.MetaObject;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DynamicContext
/*     */ {
/*     */   public static final String PARAMETER_OBJECT_KEY = "_parameter";
/*     */   public static final String DATABASE_ID_KEY = "_databaseId";
/*     */   private final ContextMap bindings;
/*     */   
/*     */   static
/*     */   {
/*  37 */     OgnlRuntime.setPropertyAccessor(ContextMap.class, new ContextAccessor());
/*     */   }
/*     */   
/*     */ 
/*  41 */   private final StringBuilder sqlBuilder = new StringBuilder();
/*  42 */   private int uniqueNumber = 0;
/*     */   
/*     */   public DynamicContext(Configuration configuration, Object parameterObject) {
/*  45 */     if ((parameterObject != null) && (!(parameterObject instanceof Map))) {
/*  46 */       MetaObject metaObject = configuration.newMetaObject(parameterObject);
/*  47 */       this.bindings = new ContextMap(metaObject);
/*     */     } else {
/*  49 */       this.bindings = new ContextMap(null);
/*     */     }
/*  51 */     this.bindings.put("_parameter", parameterObject);
/*  52 */     this.bindings.put("_databaseId", configuration.getDatabaseId());
/*     */   }
/*     */   
/*     */   public Map<String, Object> getBindings() {
/*  56 */     return this.bindings;
/*     */   }
/*     */   
/*     */   public void bind(String name, Object value) {
/*  60 */     this.bindings.put(name, value);
/*     */   }
/*     */   
/*     */   public void appendSql(String sql) {
/*  64 */     this.sqlBuilder.append(sql);
/*  65 */     this.sqlBuilder.append(" ");
/*     */   }
/*     */   
/*     */   public String getSql() {
/*  69 */     return this.sqlBuilder.toString().trim();
/*     */   }
/*     */   
/*     */   public int getUniqueNumber() {
/*  73 */     return this.uniqueNumber++;
/*     */   }
/*     */   
/*     */   static class ContextMap extends HashMap<String, Object> {
/*     */     private static final long serialVersionUID = 2977601501966151582L;
/*     */     private MetaObject parameterMetaObject;
/*     */     
/*     */     public ContextMap(MetaObject parameterMetaObject) {
/*  81 */       this.parameterMetaObject = parameterMetaObject;
/*     */     }
/*     */     
/*     */     public Object put(String key, Object value)
/*     */     {
/*  86 */       return super.put(key, value);
/*     */     }
/*     */     
/*     */     public Object get(Object key)
/*     */     {
/*  91 */       String strKey = (String)key;
/*  92 */       if (super.containsKey(strKey)) {
/*  93 */         return super.get(strKey);
/*     */       }
/*     */       
/*  96 */       if (this.parameterMetaObject != null) {
/*  97 */         Object object = this.parameterMetaObject.getValue(strKey);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */         return object;
/*     */       }
/*     */       
/* 106 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   static class ContextAccessor implements PropertyAccessor
/*     */   {
/*     */     public Object getProperty(Map context, Object target, Object name) throws OgnlException
/*     */     {
/* 114 */       Map map = (Map)target;
/*     */       
/* 116 */       Object result = map.get(name);
/* 117 */       if (result != null) {
/* 118 */         return result;
/*     */       }
/*     */       
/* 121 */       Object parameterObject = map.get("_parameter");
/* 122 */       if ((parameterObject instanceof Map)) {
/* 123 */         return ((Map)parameterObject).get(name);
/*     */       }
/*     */       
/* 126 */       return null;
/*     */     }
/*     */     
/*     */     public void setProperty(Map context, Object target, Object name, Object value) throws OgnlException
/*     */     {
/* 131 */       Map map = (Map)target;
/* 132 */       map.put(name, value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\xmltags\DynamicContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */