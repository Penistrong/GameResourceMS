/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ import java.security.BasicPermission;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OgnlInvokePermission
/*    */   extends BasicPermission
/*    */ {
/*    */   public OgnlInvokePermission(String name)
/*    */   {
/* 48 */     super(name);
/*    */   }
/*    */   
/*    */   public OgnlInvokePermission(String name, String actions)
/*    */   {
/* 53 */     super(name, actions);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\OgnlInvokePermission.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */