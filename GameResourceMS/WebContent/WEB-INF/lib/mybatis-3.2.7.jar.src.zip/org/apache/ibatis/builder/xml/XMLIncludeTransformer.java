/*    */ package org.apache.ibatis.builder.xml;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.ibatis.builder.IncompleteElementException;
/*    */ import org.apache.ibatis.builder.MapperBuilderAssistant;
/*    */ import org.apache.ibatis.parsing.PropertyParser;
/*    */ import org.apache.ibatis.parsing.XNode;
/*    */ import org.apache.ibatis.session.Configuration;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.NamedNodeMap;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.NodeList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLIncludeTransformer
/*    */ {
/*    */   private final Configuration configuration;
/*    */   private final MapperBuilderAssistant builderAssistant;
/*    */   
/*    */   public XMLIncludeTransformer(Configuration configuration, MapperBuilderAssistant builderAssistant)
/*    */   {
/* 35 */     this.configuration = configuration;
/* 36 */     this.builderAssistant = builderAssistant;
/*    */   }
/*    */   
/*    */   public void applyIncludes(Node source) {
/* 40 */     if (source.getNodeName().equals("include")) {
/* 41 */       Node toInclude = findSqlFragment(getStringAttribute(source, "refid"));
/* 42 */       applyIncludes(toInclude);
/* 43 */       if (toInclude.getOwnerDocument() != source.getOwnerDocument()) {
/* 44 */         toInclude = source.getOwnerDocument().importNode(toInclude, true);
/*    */       }
/* 46 */       source.getParentNode().replaceChild(toInclude, source);
/* 47 */       while (toInclude.hasChildNodes()) {
/* 48 */         toInclude.getParentNode().insertBefore(toInclude.getFirstChild(), toInclude);
/*    */       }
/* 50 */       toInclude.getParentNode().removeChild(toInclude);
/* 51 */     } else if (source.getNodeType() == 1) {
/* 52 */       NodeList children = source.getChildNodes();
/* 53 */       for (int i = 0; i < children.getLength(); i++) {
/* 54 */         applyIncludes(children.item(i));
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   private Node findSqlFragment(String refid) {
/* 60 */     refid = PropertyParser.parse(refid, this.configuration.getVariables());
/* 61 */     refid = this.builderAssistant.applyCurrentNamespace(refid, true);
/*    */     try {
/* 63 */       XNode nodeToInclude = (XNode)this.configuration.getSqlFragments().get(refid);
/* 64 */       return nodeToInclude.getNode().cloneNode(true);
/*    */     }
/*    */     catch (IllegalArgumentException e) {
/* 67 */       throw new IncompleteElementException("Could not find SQL statement to include with refid '" + refid + "'", e);
/*    */     }
/*    */   }
/*    */   
/*    */   private String getStringAttribute(Node node, String name) {
/* 72 */     return node.getAttributes().getNamedItem(name).getNodeValue();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\builder\xml\XMLIncludeTransformer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */