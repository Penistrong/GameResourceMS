/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharacterTypeHandler
/*    */   extends BaseTypeHandler<Character>
/*    */ {
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, Character parameter, JdbcType jdbcType)
/*    */     throws SQLException
/*    */   {
/* 30 */     ps.setString(i, parameter.toString());
/*    */   }
/*    */   
/*    */   public Character getNullableResult(ResultSet rs, String columnName) throws SQLException
/*    */   {
/* 35 */     String columnValue = rs.getString(columnName);
/* 36 */     if (columnValue != null) {
/* 37 */       return Character.valueOf(columnValue.charAt(0));
/*    */     }
/* 39 */     return null;
/*    */   }
/*    */   
/*    */   public Character getNullableResult(ResultSet rs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 45 */     String columnValue = rs.getString(columnIndex);
/* 46 */     if (columnValue != null) {
/* 47 */       return Character.valueOf(columnValue.charAt(0));
/*    */     }
/* 49 */     return null;
/*    */   }
/*    */   
/*    */   public Character getNullableResult(CallableStatement cs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 55 */     String columnValue = cs.getString(columnIndex);
/* 56 */     if (columnValue != null) {
/* 57 */       return Character.valueOf(columnValue.charAt(0));
/*    */     }
/* 59 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\CharacterTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */