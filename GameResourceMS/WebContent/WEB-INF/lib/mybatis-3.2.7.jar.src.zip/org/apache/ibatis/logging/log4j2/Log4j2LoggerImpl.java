/*    */ package org.apache.ibatis.logging.log4j2;
/*    */ 
/*    */ import org.apache.ibatis.logging.Log;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.logging.log4j.Marker;
/*    */ import org.apache.logging.log4j.MarkerManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Log4j2LoggerImpl
/*    */   implements Log
/*    */ {
/* 29 */   private static Marker MARKER = MarkerManager.getMarker("MYBATIS");
/*    */   private Logger log;
/*    */   
/*    */   public Log4j2LoggerImpl(Logger logger)
/*    */   {
/* 34 */     this.log = logger;
/*    */   }
/*    */   
/*    */   public boolean isDebugEnabled() {
/* 38 */     return this.log.isDebugEnabled();
/*    */   }
/*    */   
/*    */   public boolean isTraceEnabled() {
/* 42 */     return this.log.isTraceEnabled();
/*    */   }
/*    */   
/*    */   public void error(String s, Throwable e) {
/* 46 */     this.log.error(MARKER, s, e);
/*    */   }
/*    */   
/*    */   public void error(String s) {
/* 50 */     this.log.error(MARKER, s);
/*    */   }
/*    */   
/*    */   public void debug(String s) {
/* 54 */     this.log.debug(MARKER, s);
/*    */   }
/*    */   
/*    */   public void trace(String s) {
/* 58 */     this.log.trace(MARKER, s);
/*    */   }
/*    */   
/*    */   public void warn(String s) {
/* 62 */     this.log.warn(MARKER, s);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\logging\log4j2\Log4j2LoggerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */