package org.apache.ibatis.ognl;

import java.util.Map;

public abstract interface NullHandler
{
  public abstract Object nullMethodResult(Map paramMap, Object paramObject, String paramString, Object[] paramArrayOfObject);
  
  public abstract Object nullPropertyValue(Map paramMap, Object paramObject1, Object paramObject2);
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\NullHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */