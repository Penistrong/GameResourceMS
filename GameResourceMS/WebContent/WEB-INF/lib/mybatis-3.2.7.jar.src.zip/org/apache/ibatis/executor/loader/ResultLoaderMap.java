/*     */ package org.apache.ibatis.executor.loader;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.ibatis.executor.BaseExecutor;
/*     */ import org.apache.ibatis.executor.BatchResult;
/*     */ import org.apache.ibatis.executor.ExecutorException;
/*     */ import org.apache.ibatis.logging.Log;
/*     */ import org.apache.ibatis.logging.LogFactory;
/*     */ import org.apache.ibatis.mapping.BoundSql;
/*     */ import org.apache.ibatis.mapping.MappedStatement;
/*     */ import org.apache.ibatis.reflection.MetaObject;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.session.ResultHandler;
/*     */ import org.apache.ibatis.session.RowBounds;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResultLoaderMap
/*     */ {
/*     */   private final Map<String, LoadPair> loaderMap;
/*     */   
/*  49 */   public ResultLoaderMap() { this.loaderMap = new HashMap(); }
/*     */   
/*     */   public void addLoader(String property, MetaObject metaResultObject, ResultLoader resultLoader) {
/*  52 */     String upperFirst = getUppercaseFirstProperty(property);
/*  53 */     if ((!upperFirst.equalsIgnoreCase(property)) && (this.loaderMap.containsKey(upperFirst))) {
/*  54 */       throw new ExecutorException("Nested lazy loaded result property '" + property + "' for query id '" + resultLoader.mappedStatement.getId() + " already exists in the result map. The leftmost property of all lazy loaded properties must be unique within a result map.");
/*     */     }
/*     */     
/*     */ 
/*  58 */     this.loaderMap.put(upperFirst, new LoadPair(property, metaResultObject, resultLoader, null));
/*     */   }
/*     */   
/*     */   public final Map<String, LoadPair> getProperties() {
/*  62 */     return new HashMap(this.loaderMap);
/*     */   }
/*     */   
/*     */   public Set<String> getPropertyNames() {
/*  66 */     return this.loaderMap.keySet();
/*     */   }
/*     */   
/*     */   public int size() {
/*  70 */     return this.loaderMap.size();
/*     */   }
/*     */   
/*     */   public boolean hasLoader(String property) {
/*  74 */     return this.loaderMap.containsKey(property.toUpperCase(Locale.ENGLISH));
/*     */   }
/*     */   
/*     */   public boolean load(String property) throws SQLException {
/*  78 */     LoadPair pair = (LoadPair)this.loaderMap.remove(property.toUpperCase(Locale.ENGLISH));
/*  79 */     if (pair != null) {
/*  80 */       pair.load();
/*  81 */       return true;
/*     */     }
/*  83 */     return false;
/*     */   }
/*     */   
/*     */   public void loadAll() throws SQLException {
/*  87 */     Set<String> methodNameSet = this.loaderMap.keySet();
/*  88 */     String[] methodNames = (String[])methodNameSet.toArray(new String[methodNameSet.size()]);
/*  89 */     for (String methodName : methodNames) {
/*  90 */       load(methodName);
/*     */     }
/*     */   }
/*     */   
/*     */   private static String getUppercaseFirstProperty(String property) {
/*  95 */     String[] parts = property.split("\\.");
/*  96 */     return parts[0].toUpperCase(Locale.ENGLISH);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class LoadPair
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 20130412L;
/*     */     
/*     */ 
/*     */ 
/*     */     private static final String FACTORY_METHOD = "getConfiguration";
/*     */     
/*     */ 
/* 112 */     private final transient Object serializationCheck = new Object();
/*     */     
/*     */ 
/*     */ 
/*     */     private transient MetaObject metaResultObject;
/*     */     
/*     */ 
/*     */ 
/*     */     private transient ResultLoader resultLoader;
/*     */     
/*     */ 
/*     */ 
/*     */     private transient Log log;
/*     */     
/*     */ 
/*     */ 
/*     */     private Class<?> configurationFactory;
/*     */     
/*     */ 
/*     */     private String property;
/*     */     
/*     */ 
/*     */     private String mappedStatement;
/*     */     
/*     */ 
/*     */     private Serializable mappedParameter;
/*     */     
/*     */ 
/*     */ 
/*     */     private LoadPair(String property, MetaObject metaResultObject, ResultLoader resultLoader)
/*     */     {
/* 143 */       this.property = property;
/* 144 */       this.metaResultObject = metaResultObject;
/* 145 */       this.resultLoader = resultLoader;
/*     */       
/*     */ 
/* 148 */       if ((metaResultObject != null) && ((metaResultObject.getOriginalObject() instanceof Serializable))) {
/* 149 */         Object mappedStatementParameter = resultLoader.parameterObject;
/*     */         
/*     */ 
/* 152 */         if ((mappedStatementParameter instanceof Serializable)) {
/* 153 */           this.mappedStatement = resultLoader.mappedStatement.getId();
/* 154 */           this.mappedParameter = ((Serializable)mappedStatementParameter);
/*     */           
/* 156 */           this.configurationFactory = resultLoader.configuration.getConfigurationFactory();
/*     */         } else {
/* 158 */           getLogger().debug("Property [" + this.property + "] of [" + metaResultObject.getOriginalObject().getClass() + "] cannot be loaded " + "after deserialization. Make sure it's loaded before serializing " + "forenamed object.");
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void load()
/*     */       throws SQLException
/*     */     {
/* 169 */       if (this.metaResultObject == null) throw new IllegalArgumentException("metaResultObject is null");
/* 170 */       if (this.resultLoader == null) { throw new IllegalArgumentException("resultLoader is null");
/*     */       }
/* 172 */       load(null);
/*     */     }
/*     */     
/*     */     public void load(Object userObject) throws SQLException {
/* 176 */       if ((this.metaResultObject == null) || (this.resultLoader == null)) {
/* 177 */         if (this.mappedParameter == null) {
/* 178 */           throw new ExecutorException("Property [" + this.property + "] cannot be loaded because " + "required parameter of mapped statement [" + this.mappedStatement + "] is not serializable.");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 183 */         Configuration config = getConfiguration();
/* 184 */         MappedStatement ms = config.getMappedStatement(this.mappedStatement);
/* 185 */         if (ms == null) {
/* 186 */           throw new ExecutorException("Cannot lazy load property [" + this.property + "] of deserialized object [" + userObject.getClass() + "] because configuration does not contain statement [" + this.mappedStatement + "]");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 192 */         this.metaResultObject = config.newMetaObject(userObject);
/* 193 */         this.resultLoader = new ResultLoader(config, new ResultLoaderMap.ClosedExecutor(), ms, this.mappedParameter, this.metaResultObject.getSetterType(this.property), null, null);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 201 */       if (this.serializationCheck == null) {
/* 202 */         ResultLoader old = this.resultLoader;
/* 203 */         this.resultLoader = new ResultLoader(old.configuration, new ResultLoaderMap.ClosedExecutor(), old.mappedStatement, old.parameterObject, old.targetType, old.cacheKey, old.boundSql);
/*     */       }
/*     */       
/*     */ 
/* 207 */       this.metaResultObject.setValue(this.property, this.resultLoader.loadResult());
/*     */     }
/*     */     
/*     */     private Configuration getConfiguration() {
/* 211 */       if (this.configurationFactory == null) {
/* 212 */         throw new ExecutorException("Cannot get Configuration as configuration factory was not set.");
/*     */       }
/*     */       
/* 215 */       Object configurationObject = null;
/*     */       try {
/* 217 */         final Method factoryMethod = this.configurationFactory.getDeclaredMethod("getConfiguration", new Class[0]);
/* 218 */         if (!Modifier.isStatic(factoryMethod.getModifiers())) {
/* 219 */           throw new ExecutorException("Cannot get Configuration as factory method [" + this.configurationFactory + "]#[" + "getConfiguration" + "] is not static.");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 224 */         if (!factoryMethod.isAccessible()) {
/* 225 */           configurationObject = AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */           {
/*     */             public Object run() throws Exception {
/*     */               try {
/* 229 */                 factoryMethod.setAccessible(true);
/* 230 */                 return factoryMethod.invoke(null, new Object[0]);
/*     */               } finally {
/* 232 */                 factoryMethod.setAccessible(false);
/*     */               }
/*     */             }
/*     */           });
/*     */         } else {
/* 237 */           configurationObject = factoryMethod.invoke(null, new Object[0]);
/*     */         }
/*     */       } catch (NoSuchMethodException ex) {
/* 240 */         throw new ExecutorException("Cannot get Configuration as factory class [" + this.configurationFactory + "] is missing factory method of name [" + "getConfiguration" + "].", ex);
/*     */       }
/*     */       catch (PrivilegedActionException ex)
/*     */       {
/* 244 */         throw new ExecutorException("Cannot get Configuration as factory method [" + this.configurationFactory + "]#[" + "getConfiguration" + "] threw an exception.", ex.getCause());
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 248 */         throw new ExecutorException("Cannot get Configuration as factory method [" + this.configurationFactory + "]#[" + "getConfiguration" + "] threw an exception.", ex);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 253 */       if (!(configurationObject instanceof Configuration)) {
/* 254 */         boolean isNull = configurationObject == null;
/* 255 */         throw new ExecutorException("Cannot get Configuration as factory method [" + this.configurationFactory + "]#[" + "getConfiguration" + "] didn't return [" + Configuration.class + "] but [" + (isNull ? "null" : configurationObject.getClass()) + "].");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 261 */       return (Configuration)Configuration.class.cast(configurationObject);
/*     */     }
/*     */     
/*     */     private Log getLogger() {
/* 265 */       if (this.log == null) {
/* 266 */         this.log = LogFactory.getLog(getClass());
/*     */       }
/* 268 */       return this.log;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class ClosedExecutor extends BaseExecutor
/*     */   {
/*     */     public ClosedExecutor() {
/* 275 */       super(null);
/*     */     }
/*     */     
/*     */     public boolean isClosed()
/*     */     {
/* 280 */       return true;
/*     */     }
/*     */     
/*     */     protected int doUpdate(MappedStatement ms, Object parameter) throws SQLException
/*     */     {
/* 285 */       throw new UnsupportedOperationException("Not supported.");
/*     */     }
/*     */     
/*     */     protected List<BatchResult> doFlushStatements(boolean isRollback) throws SQLException
/*     */     {
/* 290 */       throw new UnsupportedOperationException("Not supported.");
/*     */     }
/*     */     
/*     */     protected <E> List<E> doQuery(MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler, BoundSql boundSql) throws SQLException
/*     */     {
/* 295 */       throw new UnsupportedOperationException("Not supported.");
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\loader\ResultLoaderMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */