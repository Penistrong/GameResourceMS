/*     */ package org.apache.ibatis.datasource.pooled;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.logging.Logger;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.ibatis.datasource.unpooled.UnpooledDataSource;
/*     */ import org.apache.ibatis.logging.Log;
/*     */ import org.apache.ibatis.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PooledDataSource
/*     */   implements DataSource
/*     */ {
/*  42 */   private static final Log log = LogFactory.getLog(PooledDataSource.class);
/*     */   
/*  44 */   private final PoolState state = new PoolState(this);
/*     */   
/*     */ 
/*     */   private final UnpooledDataSource dataSource;
/*     */   
/*  49 */   protected int poolMaximumActiveConnections = 10;
/*  50 */   protected int poolMaximumIdleConnections = 5;
/*  51 */   protected int poolMaximumCheckoutTime = 20000;
/*  52 */   protected int poolTimeToWait = 20000;
/*  53 */   protected String poolPingQuery = "NO PING QUERY SET";
/*  54 */   protected boolean poolPingEnabled = false;
/*  55 */   protected int poolPingConnectionsNotUsedFor = 0;
/*     */   private int expectedConnectionTypeCode;
/*     */   
/*     */   public PooledDataSource()
/*     */   {
/*  60 */     this.dataSource = new UnpooledDataSource();
/*     */   }
/*     */   
/*     */   public PooledDataSource(String driver, String url, String username, String password) {
/*  64 */     this.dataSource = new UnpooledDataSource(driver, url, username, password);
/*  65 */     this.expectedConnectionTypeCode = assembleConnectionTypeCode(this.dataSource.getUrl(), this.dataSource.getUsername(), this.dataSource.getPassword());
/*     */   }
/*     */   
/*     */   public PooledDataSource(String driver, String url, Properties driverProperties) {
/*  69 */     this.dataSource = new UnpooledDataSource(driver, url, driverProperties);
/*  70 */     this.expectedConnectionTypeCode = assembleConnectionTypeCode(this.dataSource.getUrl(), this.dataSource.getUsername(), this.dataSource.getPassword());
/*     */   }
/*     */   
/*     */   public PooledDataSource(ClassLoader driverClassLoader, String driver, String url, String username, String password) {
/*  74 */     this.dataSource = new UnpooledDataSource(driverClassLoader, driver, url, username, password);
/*  75 */     this.expectedConnectionTypeCode = assembleConnectionTypeCode(this.dataSource.getUrl(), this.dataSource.getUsername(), this.dataSource.getPassword());
/*     */   }
/*     */   
/*     */   public PooledDataSource(ClassLoader driverClassLoader, String driver, String url, Properties driverProperties) {
/*  79 */     this.dataSource = new UnpooledDataSource(driverClassLoader, driver, url, driverProperties);
/*  80 */     this.expectedConnectionTypeCode = assembleConnectionTypeCode(this.dataSource.getUrl(), this.dataSource.getUsername(), this.dataSource.getPassword());
/*     */   }
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/*  84 */     return popConnection(this.dataSource.getUsername(), this.dataSource.getPassword()).getProxyConnection();
/*     */   }
/*     */   
/*     */   public Connection getConnection(String username, String password) throws SQLException {
/*  88 */     return popConnection(username, password).getProxyConnection();
/*     */   }
/*     */   
/*     */   public void setLoginTimeout(int loginTimeout) throws SQLException {
/*  92 */     DriverManager.setLoginTimeout(loginTimeout);
/*     */   }
/*     */   
/*     */   public int getLoginTimeout() throws SQLException {
/*  96 */     return DriverManager.getLoginTimeout();
/*     */   }
/*     */   
/*     */   public void setLogWriter(PrintWriter logWriter) throws SQLException {
/* 100 */     DriverManager.setLogWriter(logWriter);
/*     */   }
/*     */   
/*     */   public PrintWriter getLogWriter() throws SQLException {
/* 104 */     return DriverManager.getLogWriter();
/*     */   }
/*     */   
/*     */   public void setDriver(String driver) {
/* 108 */     this.dataSource.setDriver(driver);
/* 109 */     forceCloseAll();
/*     */   }
/*     */   
/*     */   public void setUrl(String url) {
/* 113 */     this.dataSource.setUrl(url);
/* 114 */     forceCloseAll();
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 118 */     this.dataSource.setUsername(username);
/* 119 */     forceCloseAll();
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 123 */     this.dataSource.setPassword(password);
/* 124 */     forceCloseAll();
/*     */   }
/*     */   
/*     */   public void setDefaultAutoCommit(boolean defaultAutoCommit) {
/* 128 */     this.dataSource.setAutoCommit(Boolean.valueOf(defaultAutoCommit));
/* 129 */     forceCloseAll();
/*     */   }
/*     */   
/*     */   public void setDefaultTransactionIsolationLevel(Integer defaultTransactionIsolationLevel) {
/* 133 */     this.dataSource.setDefaultTransactionIsolationLevel(defaultTransactionIsolationLevel);
/* 134 */     forceCloseAll();
/*     */   }
/*     */   
/*     */   public void setDriverProperties(Properties driverProps) {
/* 138 */     this.dataSource.setDriverProperties(driverProps);
/* 139 */     forceCloseAll();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPoolMaximumActiveConnections(int poolMaximumActiveConnections)
/*     */   {
/* 148 */     this.poolMaximumActiveConnections = poolMaximumActiveConnections;
/* 149 */     forceCloseAll();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPoolMaximumIdleConnections(int poolMaximumIdleConnections)
/*     */   {
/* 158 */     this.poolMaximumIdleConnections = poolMaximumIdleConnections;
/* 159 */     forceCloseAll();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPoolMaximumCheckoutTime(int poolMaximumCheckoutTime)
/*     */   {
/* 169 */     this.poolMaximumCheckoutTime = poolMaximumCheckoutTime;
/* 170 */     forceCloseAll();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPoolTimeToWait(int poolTimeToWait)
/*     */   {
/* 179 */     this.poolTimeToWait = poolTimeToWait;
/* 180 */     forceCloseAll();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPoolPingQuery(String poolPingQuery)
/*     */   {
/* 189 */     this.poolPingQuery = poolPingQuery;
/* 190 */     forceCloseAll();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPoolPingEnabled(boolean poolPingEnabled)
/*     */   {
/* 199 */     this.poolPingEnabled = poolPingEnabled;
/* 200 */     forceCloseAll();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPoolPingConnectionsNotUsedFor(int milliseconds)
/*     */   {
/* 210 */     this.poolPingConnectionsNotUsedFor = milliseconds;
/* 211 */     forceCloseAll();
/*     */   }
/*     */   
/*     */   public String getDriver() {
/* 215 */     return this.dataSource.getDriver();
/*     */   }
/*     */   
/*     */   public String getUrl() {
/* 219 */     return this.dataSource.getUrl();
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 223 */     return this.dataSource.getUsername();
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 227 */     return this.dataSource.getPassword();
/*     */   }
/*     */   
/*     */   public boolean isAutoCommit() {
/* 231 */     return this.dataSource.isAutoCommit().booleanValue();
/*     */   }
/*     */   
/*     */   public Integer getDefaultTransactionIsolationLevel() {
/* 235 */     return this.dataSource.getDefaultTransactionIsolationLevel();
/*     */   }
/*     */   
/*     */   public Properties getDriverProperties() {
/* 239 */     return this.dataSource.getDriverProperties();
/*     */   }
/*     */   
/*     */   public int getPoolMaximumActiveConnections() {
/* 243 */     return this.poolMaximumActiveConnections;
/*     */   }
/*     */   
/*     */   public int getPoolMaximumIdleConnections() {
/* 247 */     return this.poolMaximumIdleConnections;
/*     */   }
/*     */   
/*     */   public int getPoolMaximumCheckoutTime() {
/* 251 */     return this.poolMaximumCheckoutTime;
/*     */   }
/*     */   
/*     */   public int getPoolTimeToWait() {
/* 255 */     return this.poolTimeToWait;
/*     */   }
/*     */   
/*     */   public String getPoolPingQuery() {
/* 259 */     return this.poolPingQuery;
/*     */   }
/*     */   
/*     */   public boolean isPoolPingEnabled() {
/* 263 */     return this.poolPingEnabled;
/*     */   }
/*     */   
/*     */   public int getPoolPingConnectionsNotUsedFor() {
/* 267 */     return this.poolPingConnectionsNotUsedFor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void forceCloseAll()
/*     */   {
/* 274 */     synchronized (this.state) {
/* 275 */       this.expectedConnectionTypeCode = assembleConnectionTypeCode(this.dataSource.getUrl(), this.dataSource.getUsername(), this.dataSource.getPassword());
/* 276 */       for (int i = this.state.activeConnections.size(); i > 0; i--) {
/*     */         try {
/* 278 */           PooledConnection conn = (PooledConnection)this.state.activeConnections.remove(i - 1);
/* 279 */           conn.invalidate();
/*     */           
/* 281 */           Connection realConn = conn.getRealConnection();
/* 282 */           if (!realConn.getAutoCommit()) {
/* 283 */             realConn.rollback();
/*     */           }
/* 285 */           realConn.close();
/*     */         }
/*     */         catch (Exception e) {}
/*     */       }
/*     */       
/* 290 */       for (int i = this.state.idleConnections.size(); i > 0; i--) {
/*     */         try {
/* 292 */           PooledConnection conn = (PooledConnection)this.state.idleConnections.remove(i - 1);
/* 293 */           conn.invalidate();
/*     */           
/* 295 */           Connection realConn = conn.getRealConnection();
/* 296 */           if (!realConn.getAutoCommit()) {
/* 297 */             realConn.rollback();
/*     */           }
/* 299 */           realConn.close();
/*     */         }
/*     */         catch (Exception e) {}
/*     */       }
/*     */     }
/*     */     
/* 305 */     if (log.isDebugEnabled()) {
/* 306 */       log.debug("PooledDataSource forcefully closed/removed all connections.");
/*     */     }
/*     */   }
/*     */   
/*     */   public PoolState getPoolState() {
/* 311 */     return this.state;
/*     */   }
/*     */   
/*     */   private int assembleConnectionTypeCode(String url, String username, String password) {
/* 315 */     return ("" + url + username + password).hashCode();
/*     */   }
/*     */   
/*     */   protected void pushConnection(PooledConnection conn) throws SQLException
/*     */   {
/* 320 */     synchronized (this.state) {
/* 321 */       this.state.activeConnections.remove(conn);
/* 322 */       if (conn.isValid()) {
/* 323 */         if ((this.state.idleConnections.size() < this.poolMaximumIdleConnections) && (conn.getConnectionTypeCode() == this.expectedConnectionTypeCode)) {
/* 324 */           this.state.accumulatedCheckoutTime += conn.getCheckoutTime();
/* 325 */           if (!conn.getRealConnection().getAutoCommit()) {
/* 326 */             conn.getRealConnection().rollback();
/*     */           }
/* 328 */           PooledConnection newConn = new PooledConnection(conn.getRealConnection(), this);
/* 329 */           this.state.idleConnections.add(newConn);
/* 330 */           newConn.setCreatedTimestamp(conn.getCreatedTimestamp());
/* 331 */           newConn.setLastUsedTimestamp(conn.getLastUsedTimestamp());
/* 332 */           conn.invalidate();
/* 333 */           if (log.isDebugEnabled()) {
/* 334 */             log.debug("Returned connection " + newConn.getRealHashCode() + " to pool.");
/*     */           }
/* 336 */           this.state.notifyAll();
/*     */         } else {
/* 338 */           this.state.accumulatedCheckoutTime += conn.getCheckoutTime();
/* 339 */           if (!conn.getRealConnection().getAutoCommit()) {
/* 340 */             conn.getRealConnection().rollback();
/*     */           }
/* 342 */           conn.getRealConnection().close();
/* 343 */           if (log.isDebugEnabled()) {
/* 344 */             log.debug("Closed connection " + conn.getRealHashCode() + ".");
/*     */           }
/* 346 */           conn.invalidate();
/*     */         }
/*     */       } else {
/* 349 */         if (log.isDebugEnabled()) {
/* 350 */           log.debug("A bad connection (" + conn.getRealHashCode() + ") attempted to return to the pool, discarding connection.");
/*     */         }
/* 352 */         this.state.badConnectionCount += 1L;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private PooledConnection popConnection(String username, String password) throws SQLException {
/* 358 */     boolean countedWait = false;
/* 359 */     PooledConnection conn = null;
/* 360 */     long t = System.currentTimeMillis();
/* 361 */     int localBadConnectionCount = 0;
/*     */     
/* 363 */     while (conn == null) {
/* 364 */       synchronized (this.state) {
/* 365 */         if (this.state.idleConnections.size() > 0)
/*     */         {
/* 367 */           conn = (PooledConnection)this.state.idleConnections.remove(0);
/* 368 */           if (log.isDebugEnabled()) {
/* 369 */             log.debug("Checked out connection " + conn.getRealHashCode() + " from pool.");
/*     */           }
/*     */           
/*     */         }
/* 373 */         else if (this.state.activeConnections.size() < this.poolMaximumActiveConnections)
/*     */         {
/* 375 */           conn = new PooledConnection(this.dataSource.getConnection(), this);
/*     */           
/*     */ 
/* 378 */           Connection realConn = conn.getRealConnection();
/* 379 */           if (log.isDebugEnabled()) {
/* 380 */             log.debug("Created connection " + conn.getRealHashCode() + ".");
/*     */           }
/*     */         }
/*     */         else {
/* 384 */           PooledConnection oldestActiveConnection = (PooledConnection)this.state.activeConnections.get(0);
/* 385 */           long longestCheckoutTime = oldestActiveConnection.getCheckoutTime();
/* 386 */           if (longestCheckoutTime > this.poolMaximumCheckoutTime)
/*     */           {
/* 388 */             this.state.claimedOverdueConnectionCount += 1L;
/* 389 */             this.state.accumulatedCheckoutTimeOfOverdueConnections += longestCheckoutTime;
/* 390 */             this.state.accumulatedCheckoutTime += longestCheckoutTime;
/* 391 */             this.state.activeConnections.remove(oldestActiveConnection);
/* 392 */             if (!oldestActiveConnection.getRealConnection().getAutoCommit()) {
/* 393 */               oldestActiveConnection.getRealConnection().rollback();
/*     */             }
/* 395 */             conn = new PooledConnection(oldestActiveConnection.getRealConnection(), this);
/* 396 */             oldestActiveConnection.invalidate();
/* 397 */             if (log.isDebugEnabled()) {
/* 398 */               log.debug("Claimed overdue connection " + conn.getRealHashCode() + ".");
/*     */             }
/*     */           }
/*     */           else {
/*     */             try {
/* 403 */               if (!countedWait) {
/* 404 */                 this.state.hadToWaitCount += 1L;
/* 405 */                 countedWait = true;
/*     */               }
/* 407 */               if (log.isDebugEnabled()) {
/* 408 */                 log.debug("Waiting as long as " + this.poolTimeToWait + " milliseconds for connection.");
/*     */               }
/* 410 */               long wt = System.currentTimeMillis();
/* 411 */               this.state.wait(this.poolTimeToWait);
/* 412 */               this.state.accumulatedWaitTime += System.currentTimeMillis() - wt;
/*     */             }
/*     */             catch (InterruptedException e) {
/*     */               break;
/*     */             }
/*     */           }
/*     */         }
/* 419 */         if (conn != null) {
/* 420 */           if (conn.isValid()) {
/* 421 */             if (!conn.getRealConnection().getAutoCommit()) {
/* 422 */               conn.getRealConnection().rollback();
/*     */             }
/* 424 */             conn.setConnectionTypeCode(assembleConnectionTypeCode(this.dataSource.getUrl(), username, password));
/* 425 */             conn.setCheckoutTimestamp(System.currentTimeMillis());
/* 426 */             conn.setLastUsedTimestamp(System.currentTimeMillis());
/* 427 */             this.state.activeConnections.add(conn);
/* 428 */             this.state.requestCount += 1L;
/* 429 */             this.state.accumulatedRequestTime += System.currentTimeMillis() - t;
/*     */           } else {
/* 431 */             if (log.isDebugEnabled()) {
/* 432 */               log.debug("A bad connection (" + conn.getRealHashCode() + ") was returned from the pool, getting another connection.");
/*     */             }
/* 434 */             this.state.badConnectionCount += 1L;
/* 435 */             localBadConnectionCount++;
/* 436 */             conn = null;
/* 437 */             if (localBadConnectionCount > this.poolMaximumIdleConnections + 3) {
/* 438 */               if (log.isDebugEnabled()) {
/* 439 */                 log.debug("PooledDataSource: Could not get a good connection to the database.");
/*     */               }
/* 441 */               throw new SQLException("PooledDataSource: Could not get a good connection to the database.");
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 449 */     if (conn == null) {
/* 450 */       if (log.isDebugEnabled()) {
/* 451 */         log.debug("PooledDataSource: Unknown severe error condition.  The connection pool returned a null connection.");
/*     */       }
/* 453 */       throw new SQLException("PooledDataSource: Unknown severe error condition.  The connection pool returned a null connection.");
/*     */     }
/*     */     
/* 456 */     return conn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean pingConnection(PooledConnection conn)
/*     */   {
/* 466 */     boolean result = true;
/*     */     try
/*     */     {
/* 469 */       result = !conn.getRealConnection().isClosed();
/*     */     } catch (SQLException e) {
/* 471 */       if (log.isDebugEnabled()) {
/* 472 */         log.debug("Connection " + conn.getRealHashCode() + " is BAD: " + e.getMessage());
/*     */       }
/* 474 */       result = false;
/*     */     }
/*     */     
/* 477 */     if ((result) && 
/* 478 */       (this.poolPingEnabled) && 
/* 479 */       (this.poolPingConnectionsNotUsedFor >= 0) && (conn.getTimeElapsedSinceLastUse() > this.poolPingConnectionsNotUsedFor)) {
/*     */       try {
/* 481 */         if (log.isDebugEnabled()) {
/* 482 */           log.debug("Testing connection " + conn.getRealHashCode() + " ...");
/*     */         }
/* 484 */         Connection realConn = conn.getRealConnection();
/* 485 */         Statement statement = realConn.createStatement();
/* 486 */         ResultSet rs = statement.executeQuery(this.poolPingQuery);
/* 487 */         rs.close();
/* 488 */         statement.close();
/* 489 */         if (!realConn.getAutoCommit()) {
/* 490 */           realConn.rollback();
/*     */         }
/* 492 */         result = true;
/* 493 */         if (log.isDebugEnabled()) {
/* 494 */           log.debug("Connection " + conn.getRealHashCode() + " is GOOD!");
/*     */         }
/*     */       } catch (Exception e) {
/* 497 */         log.warn("Execution of ping query '" + this.poolPingQuery + "' failed: " + e.getMessage());
/*     */         try {
/* 499 */           conn.getRealConnection().close();
/*     */         }
/*     */         catch (Exception e2) {}
/*     */         
/* 503 */         result = false;
/* 504 */         if (log.isDebugEnabled()) {
/* 505 */           log.debug("Connection " + conn.getRealHashCode() + " is BAD: " + e.getMessage());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 511 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Connection unwrapConnection(Connection conn)
/*     */   {
/* 521 */     if (Proxy.isProxyClass(conn.getClass())) {
/* 522 */       InvocationHandler handler = Proxy.getInvocationHandler(conn);
/* 523 */       if ((handler instanceof PooledConnection)) {
/* 524 */         return ((PooledConnection)handler).getRealConnection();
/*     */       }
/*     */     }
/* 527 */     return conn;
/*     */   }
/*     */   
/*     */   protected void finalize() throws Throwable {
/* 531 */     forceCloseAll();
/*     */   }
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException {
/* 535 */     throw new SQLException(getClass().getName() + " is not a wrapper.");
/*     */   }
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 539 */     return false;
/*     */   }
/*     */   
/*     */   public Logger getParentLogger() {
/* 543 */     return Logger.getLogger("global");
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\datasource\pooled\PooledDataSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */