/*    */ package org.apache.ibatis.reflection.wrapper;
/*    */ 
/*    */ import org.apache.ibatis.reflection.MetaObject;
/*    */ import org.apache.ibatis.reflection.ReflectionException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultObjectWrapperFactory
/*    */   implements ObjectWrapperFactory
/*    */ {
/*    */   public boolean hasWrapperFor(Object object)
/*    */   {
/* 27 */     return false;
/*    */   }
/*    */   
/*    */   public ObjectWrapper getWrapperFor(MetaObject metaObject, Object object) {
/* 31 */     throw new ReflectionException("The DefaultObjectWrapperFactory should never be called to provide an ObjectWrapper.");
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\wrapper\DefaultObjectWrapperFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */