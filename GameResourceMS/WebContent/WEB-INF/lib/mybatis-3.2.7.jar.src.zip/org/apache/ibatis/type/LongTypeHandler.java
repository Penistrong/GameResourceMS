/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LongTypeHandler
/*    */   extends BaseTypeHandler<Long>
/*    */ {
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, Long parameter, JdbcType jdbcType)
/*    */     throws SQLException
/*    */   {
/* 31 */     ps.setLong(i, parameter.longValue());
/*    */   }
/*    */   
/*    */   public Long getNullableResult(ResultSet rs, String columnName)
/*    */     throws SQLException
/*    */   {
/* 37 */     return Long.valueOf(rs.getLong(columnName));
/*    */   }
/*    */   
/*    */   public Long getNullableResult(ResultSet rs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 43 */     return Long.valueOf(rs.getLong(columnIndex));
/*    */   }
/*    */   
/*    */   public Long getNullableResult(CallableStatement cs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 49 */     return Long.valueOf(cs.getLong(columnIndex));
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\LongTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */