/*     */ package org.apache.ibatis.builder;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.ibatis.mapping.ParameterMapping;
/*     */ import org.apache.ibatis.mapping.ParameterMapping.Builder;
/*     */ import org.apache.ibatis.mapping.SqlSource;
/*     */ import org.apache.ibatis.parsing.GenericTokenParser;
/*     */ import org.apache.ibatis.parsing.TokenHandler;
/*     */ import org.apache.ibatis.reflection.MetaClass;
/*     */ import org.apache.ibatis.reflection.MetaObject;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.type.JdbcType;
/*     */ import org.apache.ibatis.type.TypeHandlerRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlSourceBuilder
/*     */   extends BaseBuilder
/*     */ {
/*     */   private static final String parameterProperties = "javaType,jdbcType,mode,numericScale,resultMap,typeHandler,jdbcTypeName";
/*     */   
/*     */   public SqlSourceBuilder(Configuration configuration)
/*     */   {
/*  39 */     super(configuration);
/*     */   }
/*     */   
/*     */   public SqlSource parse(String originalSql, Class<?> parameterType, Map<String, Object> additionalParameters) {
/*  43 */     ParameterMappingTokenHandler handler = new ParameterMappingTokenHandler(this.configuration, parameterType, additionalParameters);
/*  44 */     GenericTokenParser parser = new GenericTokenParser("#{", "}", handler);
/*  45 */     String sql = parser.parse(originalSql);
/*  46 */     return new StaticSqlSource(this.configuration, sql, handler.getParameterMappings());
/*     */   }
/*     */   
/*     */   private static class ParameterMappingTokenHandler extends BaseBuilder implements TokenHandler
/*     */   {
/*  51 */     private List<ParameterMapping> parameterMappings = new ArrayList();
/*     */     private Class<?> parameterType;
/*     */     private MetaObject metaParameters;
/*     */     
/*     */     public ParameterMappingTokenHandler(Configuration configuration, Class<?> parameterType, Map<String, Object> additionalParameters) {
/*  56 */       super();
/*  57 */       this.parameterType = parameterType;
/*  58 */       this.metaParameters = configuration.newMetaObject(additionalParameters);
/*     */     }
/*     */     
/*     */     public List<ParameterMapping> getParameterMappings() {
/*  62 */       return this.parameterMappings;
/*     */     }
/*     */     
/*     */     public String handleToken(String content) {
/*  66 */       this.parameterMappings.add(buildParameterMapping(content));
/*  67 */       return "?";
/*     */     }
/*     */     
/*     */     private ParameterMapping buildParameterMapping(String content) {
/*  71 */       Map<String, String> propertiesMap = parseParameterMapping(content);
/*  72 */       String property = (String)propertiesMap.get("property");
/*     */       Class<?> propertyType;
/*  74 */       Class<?> propertyType; if (this.metaParameters.hasGetter(property)) {
/*  75 */         propertyType = this.metaParameters.getGetterType(property); } else { Class<?> propertyType;
/*  76 */         if (this.typeHandlerRegistry.hasTypeHandler(this.parameterType)) {
/*  77 */           propertyType = this.parameterType; } else { Class<?> propertyType;
/*  78 */           if (JdbcType.CURSOR.name().equals(propertiesMap.get("jdbcType"))) {
/*  79 */             propertyType = ResultSet.class; } else { Class<?> propertyType;
/*  80 */             if (property != null) {
/*  81 */               MetaClass metaClass = MetaClass.forClass(this.parameterType);
/*  82 */               Class<?> propertyType; if (metaClass.hasGetter(property)) {
/*  83 */                 propertyType = metaClass.getGetterType(property);
/*     */               } else {
/*  85 */                 propertyType = Object.class;
/*     */               }
/*     */             } else {
/*  88 */               propertyType = Object.class;
/*     */             } } } }
/*  90 */       ParameterMapping.Builder builder = new ParameterMapping.Builder(this.configuration, property, propertyType);
/*  91 */       Class<?> javaType = propertyType;
/*  92 */       String typeHandlerAlias = null;
/*  93 */       for (Map.Entry<String, String> entry : propertiesMap.entrySet()) {
/*  94 */         String name = (String)entry.getKey();
/*  95 */         String value = (String)entry.getValue();
/*  96 */         if ("javaType".equals(name)) {
/*  97 */           javaType = resolveClass(value);
/*  98 */           builder.javaType(javaType);
/*  99 */         } else if ("jdbcType".equals(name)) {
/* 100 */           builder.jdbcType(resolveJdbcType(value));
/* 101 */         } else if ("mode".equals(name)) {
/* 102 */           builder.mode(resolveParameterMode(value));
/* 103 */         } else if ("numericScale".equals(name)) {
/* 104 */           builder.numericScale(Integer.valueOf(value));
/* 105 */         } else if ("resultMap".equals(name)) {
/* 106 */           builder.resultMapId(value);
/* 107 */         } else if ("typeHandler".equals(name)) {
/* 108 */           typeHandlerAlias = value;
/* 109 */         } else if ("jdbcTypeName".equals(name)) {
/* 110 */           builder.jdbcTypeName(value);
/* 111 */         } else if (!"property".equals(name))
/*     */         {
/* 113 */           if ("expression".equals(name)) {
/* 114 */             throw new BuilderException("Expression based parameters are not supported yet");
/*     */           }
/* 116 */           throw new BuilderException("An invalid property '" + name + "' was found in mapping #{" + content + "}.  Valid properties are " + "javaType,jdbcType,mode,numericScale,resultMap,typeHandler,jdbcTypeName");
/*     */         }
/*     */       }
/* 119 */       if (typeHandlerAlias != null) {
/* 120 */         builder.typeHandler(resolveTypeHandler(javaType, typeHandlerAlias));
/*     */       }
/* 122 */       return builder.build();
/*     */     }
/*     */     
/*     */     private Map<String, String> parseParameterMapping(String content) {
/*     */       try {
/* 127 */         return new ParameterExpression(content);
/*     */       } catch (BuilderException ex) {
/* 129 */         throw ex;
/*     */       } catch (Exception ex) {
/* 131 */         throw new BuilderException("Parsing error was found in mapping #{" + content + "}.  Check syntax #{property|(expression), var1=value1, var2=value2, ...} ", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\builder\SqlSourceBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */