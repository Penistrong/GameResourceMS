/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTGreaterEq
/*    */   extends ExpressionNode
/*    */ {
/*    */   public ASTGreaterEq(int id)
/*    */   {
/* 40 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTGreaterEq(OgnlParser p, int id) {
/* 44 */     super(p, id);
/*    */   }
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException
/*    */   {
/* 49 */     Object v1 = this.children[0].getValue(context, source);
/* 50 */     Object v2 = this.children[1].getValue(context, source);
/* 51 */     return OgnlOps.less(v1, v2) ? Boolean.FALSE : Boolean.TRUE;
/*    */   }
/*    */   
/*    */   public String getExpressionOperator(int index)
/*    */   {
/* 56 */     return ">=";
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTGreaterEq.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */