/*     */ package org.apache.ibatis.datasource.pooled;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PoolState
/*     */ {
/*     */   protected PooledDataSource dataSource;
/*  28 */   protected final List<PooledConnection> idleConnections = new ArrayList();
/*  29 */   protected final List<PooledConnection> activeConnections = new ArrayList();
/*  30 */   protected long requestCount = 0L;
/*  31 */   protected long accumulatedRequestTime = 0L;
/*  32 */   protected long accumulatedCheckoutTime = 0L;
/*  33 */   protected long claimedOverdueConnectionCount = 0L;
/*  34 */   protected long accumulatedCheckoutTimeOfOverdueConnections = 0L;
/*  35 */   protected long accumulatedWaitTime = 0L;
/*  36 */   protected long hadToWaitCount = 0L;
/*  37 */   protected long badConnectionCount = 0L;
/*     */   
/*     */   public PoolState(PooledDataSource dataSource) {
/*  40 */     this.dataSource = dataSource;
/*     */   }
/*     */   
/*     */   public synchronized long getRequestCount() {
/*  44 */     return this.requestCount;
/*     */   }
/*     */   
/*     */   public synchronized long getAverageRequestTime() {
/*  48 */     return this.requestCount == 0L ? 0L : this.accumulatedRequestTime / this.requestCount;
/*     */   }
/*     */   
/*     */   public synchronized long getAverageWaitTime() {
/*  52 */     return this.hadToWaitCount == 0L ? 0L : this.accumulatedWaitTime / this.hadToWaitCount;
/*     */   }
/*     */   
/*     */   public synchronized long getHadToWaitCount()
/*     */   {
/*  57 */     return this.hadToWaitCount;
/*     */   }
/*     */   
/*     */   public synchronized long getBadConnectionCount() {
/*  61 */     return this.badConnectionCount;
/*     */   }
/*     */   
/*     */   public synchronized long getClaimedOverdueConnectionCount() {
/*  65 */     return this.claimedOverdueConnectionCount;
/*     */   }
/*     */   
/*     */   public synchronized long getAverageOverdueCheckoutTime() {
/*  69 */     return this.claimedOverdueConnectionCount == 0L ? 0L : this.accumulatedCheckoutTimeOfOverdueConnections / this.claimedOverdueConnectionCount;
/*     */   }
/*     */   
/*     */   public synchronized long getAverageCheckoutTime() {
/*  73 */     return this.requestCount == 0L ? 0L : this.accumulatedCheckoutTime / this.requestCount;
/*     */   }
/*     */   
/*     */   public synchronized int getIdleConnectionCount()
/*     */   {
/*  78 */     return this.idleConnections.size();
/*     */   }
/*     */   
/*     */   public synchronized int getActiveConnectionCount() {
/*  82 */     return this.activeConnections.size();
/*     */   }
/*     */   
/*     */   public synchronized String toString() {
/*  86 */     StringBuffer buffer = new StringBuffer();
/*  87 */     buffer.append("\n===CONFINGURATION==============================================");
/*  88 */     buffer.append("\n jdbcDriver                     ").append(this.dataSource.getDriver());
/*  89 */     buffer.append("\n jdbcUrl                        ").append(this.dataSource.getUrl());
/*  90 */     buffer.append("\n jdbcUsername                   ").append(this.dataSource.getUsername());
/*  91 */     buffer.append("\n jdbcPassword                   ").append(this.dataSource.getPassword() == null ? "NULL" : "************");
/*  92 */     buffer.append("\n poolMaxActiveConnections       ").append(this.dataSource.poolMaximumActiveConnections);
/*  93 */     buffer.append("\n poolMaxIdleConnections         ").append(this.dataSource.poolMaximumIdleConnections);
/*  94 */     buffer.append("\n poolMaxCheckoutTime            ").append(this.dataSource.poolMaximumCheckoutTime);
/*  95 */     buffer.append("\n poolTimeToWait                 ").append(this.dataSource.poolTimeToWait);
/*  96 */     buffer.append("\n poolPingEnabled                ").append(this.dataSource.poolPingEnabled);
/*  97 */     buffer.append("\n poolPingQuery                  ").append(this.dataSource.poolPingQuery);
/*  98 */     buffer.append("\n poolPingConnectionsNotUsedFor  ").append(this.dataSource.poolPingConnectionsNotUsedFor);
/*  99 */     buffer.append("\n ---STATUS-----------------------------------------------------");
/* 100 */     buffer.append("\n activeConnections              ").append(getActiveConnectionCount());
/* 101 */     buffer.append("\n idleConnections                ").append(getIdleConnectionCount());
/* 102 */     buffer.append("\n requestCount                   ").append(getRequestCount());
/* 103 */     buffer.append("\n averageRequestTime             ").append(getAverageRequestTime());
/* 104 */     buffer.append("\n averageCheckoutTime            ").append(getAverageCheckoutTime());
/* 105 */     buffer.append("\n claimedOverdue                 ").append(getClaimedOverdueConnectionCount());
/* 106 */     buffer.append("\n averageOverdueCheckoutTime     ").append(getAverageOverdueCheckoutTime());
/* 107 */     buffer.append("\n hadToWait                      ").append(getHadToWaitCount());
/* 108 */     buffer.append("\n averageWaitTime                ").append(getAverageWaitTime());
/* 109 */     buffer.append("\n badConnectionCount             ").append(getBadConnectionCount());
/* 110 */     buffer.append("\n===============================================================");
/* 111 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\datasource\pooled\PoolState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */