/*     */ package org.apache.ibatis.reflection;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*     */ import org.apache.ibatis.reflection.property.PropertyTokenizer;
/*     */ import org.apache.ibatis.reflection.wrapper.BeanWrapper;
/*     */ import org.apache.ibatis.reflection.wrapper.CollectionWrapper;
/*     */ import org.apache.ibatis.reflection.wrapper.MapWrapper;
/*     */ import org.apache.ibatis.reflection.wrapper.ObjectWrapper;
/*     */ import org.apache.ibatis.reflection.wrapper.ObjectWrapperFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MetaObject
/*     */ {
/*     */   private Object originalObject;
/*     */   private ObjectWrapper objectWrapper;
/*     */   private ObjectFactory objectFactory;
/*     */   private ObjectWrapperFactory objectWrapperFactory;
/*     */   
/*     */   private MetaObject(Object object, ObjectFactory objectFactory, ObjectWrapperFactory objectWrapperFactory)
/*     */   {
/*  41 */     this.originalObject = object;
/*  42 */     this.objectFactory = objectFactory;
/*  43 */     this.objectWrapperFactory = objectWrapperFactory;
/*     */     
/*  45 */     if ((object instanceof ObjectWrapper)) {
/*  46 */       this.objectWrapper = ((ObjectWrapper)object);
/*  47 */     } else if (objectWrapperFactory.hasWrapperFor(object)) {
/*  48 */       this.objectWrapper = objectWrapperFactory.getWrapperFor(this, object);
/*  49 */     } else if ((object instanceof Map)) {
/*  50 */       this.objectWrapper = new MapWrapper(this, (Map)object);
/*  51 */     } else if ((object instanceof Collection)) {
/*  52 */       this.objectWrapper = new CollectionWrapper(this, (Collection)object);
/*     */     } else {
/*  54 */       this.objectWrapper = new BeanWrapper(this, object);
/*     */     }
/*     */   }
/*     */   
/*     */   public static MetaObject forObject(Object object, ObjectFactory objectFactory, ObjectWrapperFactory objectWrapperFactory) {
/*  59 */     if (object == null) {
/*  60 */       return SystemMetaObject.NULL_META_OBJECT;
/*     */     }
/*  62 */     return new MetaObject(object, objectFactory, objectWrapperFactory);
/*     */   }
/*     */   
/*     */   public ObjectFactory getObjectFactory()
/*     */   {
/*  67 */     return this.objectFactory;
/*     */   }
/*     */   
/*     */   public ObjectWrapperFactory getObjectWrapperFactory() {
/*  71 */     return this.objectWrapperFactory;
/*     */   }
/*     */   
/*     */   public Object getOriginalObject() {
/*  75 */     return this.originalObject;
/*     */   }
/*     */   
/*     */   public String findProperty(String propName, boolean useCamelCaseMapping) {
/*  79 */     return this.objectWrapper.findProperty(propName, useCamelCaseMapping);
/*     */   }
/*     */   
/*     */   public String[] getGetterNames() {
/*  83 */     return this.objectWrapper.getGetterNames();
/*     */   }
/*     */   
/*     */   public String[] getSetterNames() {
/*  87 */     return this.objectWrapper.getSetterNames();
/*     */   }
/*     */   
/*     */   public Class<?> getSetterType(String name) {
/*  91 */     return this.objectWrapper.getSetterType(name);
/*     */   }
/*     */   
/*     */   public Class<?> getGetterType(String name) {
/*  95 */     return this.objectWrapper.getGetterType(name);
/*     */   }
/*     */   
/*     */   public boolean hasSetter(String name) {
/*  99 */     return this.objectWrapper.hasSetter(name);
/*     */   }
/*     */   
/*     */   public boolean hasGetter(String name) {
/* 103 */     return this.objectWrapper.hasGetter(name);
/*     */   }
/*     */   
/*     */   public Object getValue(String name) {
/* 107 */     PropertyTokenizer prop = new PropertyTokenizer(name);
/* 108 */     if (prop.hasNext()) {
/* 109 */       MetaObject metaValue = metaObjectForProperty(prop.getIndexedName());
/* 110 */       if (metaValue == SystemMetaObject.NULL_META_OBJECT) {
/* 111 */         return null;
/*     */       }
/* 113 */       return metaValue.getValue(prop.getChildren());
/*     */     }
/*     */     
/* 116 */     return this.objectWrapper.get(prop);
/*     */   }
/*     */   
/*     */   public void setValue(String name, Object value)
/*     */   {
/* 121 */     PropertyTokenizer prop = new PropertyTokenizer(name);
/* 122 */     if (prop.hasNext()) {
/* 123 */       MetaObject metaValue = metaObjectForProperty(prop.getIndexedName());
/* 124 */       if (metaValue == SystemMetaObject.NULL_META_OBJECT) {
/* 125 */         if ((value == null) && (prop.getChildren() != null)) {
/* 126 */           return;
/*     */         }
/* 128 */         metaValue = this.objectWrapper.instantiatePropertyValue(name, prop, this.objectFactory);
/*     */       }
/*     */       
/* 131 */       metaValue.setValue(prop.getChildren(), value);
/*     */     } else {
/* 133 */       this.objectWrapper.set(prop, value);
/*     */     }
/*     */   }
/*     */   
/*     */   public MetaObject metaObjectForProperty(String name) {
/* 138 */     Object value = getValue(name);
/* 139 */     return forObject(value, this.objectFactory, this.objectWrapperFactory);
/*     */   }
/*     */   
/*     */   public ObjectWrapper getObjectWrapper() {
/* 143 */     return this.objectWrapper;
/*     */   }
/*     */   
/*     */   public boolean isCollection() {
/* 147 */     return this.objectWrapper.isCollection();
/*     */   }
/*     */   
/*     */   public void add(Object element) {
/* 151 */     this.objectWrapper.add(element);
/*     */   }
/*     */   
/*     */   public <E> void addAll(List<E> list) {
/* 155 */     this.objectWrapper.addAll(list);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\MetaObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */