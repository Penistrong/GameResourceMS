package org.apache.ibatis.session;

import java.sql.Connection;

public abstract interface SqlSessionFactory
{
  public abstract SqlSession openSession();
  
  public abstract SqlSession openSession(boolean paramBoolean);
  
  public abstract SqlSession openSession(Connection paramConnection);
  
  public abstract SqlSession openSession(TransactionIsolationLevel paramTransactionIsolationLevel);
  
  public abstract SqlSession openSession(ExecutorType paramExecutorType);
  
  public abstract SqlSession openSession(ExecutorType paramExecutorType, boolean paramBoolean);
  
  public abstract SqlSession openSession(ExecutorType paramExecutorType, TransactionIsolationLevel paramTransactionIsolationLevel);
  
  public abstract SqlSession openSession(ExecutorType paramExecutorType, Connection paramConnection);
  
  public abstract Configuration getConfiguration();
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\session\SqlSessionFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */