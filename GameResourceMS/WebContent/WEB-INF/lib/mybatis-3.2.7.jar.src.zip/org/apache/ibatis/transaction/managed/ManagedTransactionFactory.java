/*    */ package org.apache.ibatis.transaction.managed;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.util.Properties;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.ibatis.session.TransactionIsolationLevel;
/*    */ import org.apache.ibatis.transaction.Transaction;
/*    */ import org.apache.ibatis.transaction.TransactionFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ManagedTransactionFactory
/*    */   implements TransactionFactory
/*    */ {
/* 37 */   private boolean closeConnection = true;
/*    */   
/*    */   public void setProperties(Properties props) {
/* 40 */     if (props != null) {
/* 41 */       String closeConnectionProperty = props.getProperty("closeConnection");
/* 42 */       if (closeConnectionProperty != null) {
/* 43 */         this.closeConnection = Boolean.valueOf(closeConnectionProperty).booleanValue();
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public Transaction newTransaction(Connection conn) {
/* 49 */     return new ManagedTransaction(conn, this.closeConnection);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Transaction newTransaction(DataSource ds, TransactionIsolationLevel level, boolean autoCommit)
/*    */   {
/* 56 */     return new ManagedTransaction(ds, level, this.closeConnection);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\transaction\managed\ManagedTransactionFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */