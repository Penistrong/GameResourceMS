/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ 
/*     */ public abstract interface OgnlParserTreeConstants
/*     */ {
/*     */   public static final int JJTVOID = 0;
/*     */   
/*     */   public static final int JJTSEQUENCE = 1;
/*     */   
/*     */   public static final int JJTASSIGN = 2;
/*     */   
/*     */   public static final int JJTTEST = 3;
/*     */   public static final int JJTOR = 4;
/*     */   public static final int JJTAND = 5;
/*     */   public static final int JJTBITOR = 6;
/*     */   public static final int JJTXOR = 7;
/*     */   public static final int JJTBITAND = 8;
/*     */   public static final int JJTEQ = 9;
/*     */   public static final int JJTNOTEQ = 10;
/*     */   public static final int JJTLESS = 11;
/*     */   public static final int JJTGREATER = 12;
/*     */   public static final int JJTLESSEQ = 13;
/*     */   public static final int JJTGREATEREQ = 14;
/*     */   public static final int JJTIN = 15;
/*     */   public static final int JJTNOTIN = 16;
/*     */   public static final int JJTSHIFTLEFT = 17;
/*     */   public static final int JJTSHIFTRIGHT = 18;
/*     */   public static final int JJTUNSIGNEDSHIFTRIGHT = 19;
/*     */   public static final int JJTADD = 20;
/*     */   public static final int JJTSUBTRACT = 21;
/*     */   public static final int JJTMULTIPLY = 22;
/*     */   public static final int JJTDIVIDE = 23;
/*     */   public static final int JJTREMAINDER = 24;
/*     */   public static final int JJTNEGATE = 25;
/*     */   public static final int JJTBITNEGATE = 26;
/*     */   public static final int JJTNOT = 27;
/*     */   public static final int JJTINSTANCEOF = 28;
/*     */   public static final int JJTCHAIN = 29;
/*     */   public static final int JJTEVAL = 30;
/*     */   public static final int JJTCONST = 31;
/*     */   public static final int JJTTHISVARREF = 32;
/*     */   public static final int JJTROOTVARREF = 33;
/*     */   public static final int JJTVARREF = 34;
/*     */   public static final int JJTLIST = 35;
/*     */   public static final int JJTMAP = 36;
/*     */   public static final int JJTKEYVALUE = 37;
/*     */   public static final int JJTSTATICFIELD = 38;
/*     */   public static final int JJTCTOR = 39;
/*     */   public static final int JJTPROPERTY = 40;
/*     */   public static final int JJTSTATICMETHOD = 41;
/*     */   public static final int JJTMETHOD = 42;
/*     */   public static final int JJTPROJECT = 43;
/*     */   public static final int JJTSELECT = 44;
/*     */   public static final int JJTSELECTFIRST = 45;
/*     */   public static final int JJTSELECTLAST = 46;
/*  56 */   public static final String[] jjtNodeName = {
/*  57 */     "void", 
/*  58 */     "Sequence", 
/*  59 */     "Assign", 
/*  60 */     "Test", 
/*  61 */     "Or", 
/*  62 */     "And", 
/*  63 */     "BitOr", 
/*  64 */     "Xor", 
/*  65 */     "BitAnd", 
/*  66 */     "Eq", 
/*  67 */     "NotEq", 
/*  68 */     "Less", 
/*  69 */     "Greater", 
/*  70 */     "LessEq", 
/*  71 */     "GreaterEq", 
/*  72 */     "In", 
/*  73 */     "NotIn", 
/*  74 */     "ShiftLeft", 
/*  75 */     "ShiftRight", 
/*  76 */     "UnsignedShiftRight", 
/*  77 */     "Add", 
/*  78 */     "Subtract", 
/*  79 */     "Multiply", 
/*  80 */     "Divide", 
/*  81 */     "Remainder", 
/*  82 */     "Negate", 
/*  83 */     "BitNegate", 
/*  84 */     "Not", 
/*  85 */     "Instanceof", 
/*  86 */     "Chain", 
/*  87 */     "Eval", 
/*  88 */     "Const", 
/*  89 */     "ThisVarRef", 
/*  90 */     "RootVarRef", 
/*  91 */     "VarRef", 
/*  92 */     "List", 
/*  93 */     "Map", 
/*  94 */     "KeyValue", 
/*  95 */     "StaticField", 
/*  96 */     "Ctor", 
/*  97 */     "Property", 
/*  98 */     "StaticMethod", 
/*  99 */     "Method", 
/* 100 */     "Project", 
/* 101 */     "Select", 
/* 102 */     "SelectFirst", 
/* 103 */     "SelectLast" };
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\OgnlParserTreeConstants.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */