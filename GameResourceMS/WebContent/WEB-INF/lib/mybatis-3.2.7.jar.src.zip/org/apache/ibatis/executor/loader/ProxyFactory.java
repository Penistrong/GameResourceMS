package org.apache.ibatis.executor.loader;

import java.util.List;
import java.util.Properties;
import org.apache.ibatis.reflection.factory.ObjectFactory;
import org.apache.ibatis.session.Configuration;

public abstract interface ProxyFactory
{
  public abstract void setProperties(Properties paramProperties);
  
  public abstract Object createProxy(Object paramObject, ResultLoaderMap paramResultLoaderMap, Configuration paramConfiguration, ObjectFactory paramObjectFactory, List<Class<?>> paramList, List<Object> paramList1);
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\loader\ProxyFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */