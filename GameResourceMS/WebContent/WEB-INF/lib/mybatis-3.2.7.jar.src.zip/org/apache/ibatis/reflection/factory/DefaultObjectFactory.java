/*     */ package org.apache.ibatis.reflection.factory;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.ibatis.reflection.ReflectionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultObjectFactory
/*     */   implements ObjectFactory, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -8855120656740914948L;
/*     */   
/*     */   public <T> T create(Class<T> type)
/*     */   {
/*  41 */     return (T)create(type, null, null);
/*     */   }
/*     */   
/*     */   public <T> T create(Class<T> type, List<Class<?>> constructorArgTypes, List<Object> constructorArgs) {
/*  45 */     Class<?> classToCreate = resolveInterface(type);
/*     */     
/*     */ 
/*  48 */     T created = instantiateClass(classToCreate, constructorArgTypes, constructorArgs);
/*  49 */     return created;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setProperties(Properties properties) {}
/*     */   
/*     */   private <T> T instantiateClass(Class<T> type, List<Class<?>> constructorArgTypes, List<Object> constructorArgs)
/*     */   {
/*     */     try
/*     */     {
/*  59 */       if ((constructorArgTypes == null) || (constructorArgs == null)) {
/*  60 */         Constructor<T> constructor = type.getDeclaredConstructor(new Class[0]);
/*  61 */         if (!constructor.isAccessible()) {
/*  62 */           constructor.setAccessible(true);
/*     */         }
/*  64 */         return (T)constructor.newInstance(new Object[0]);
/*     */       }
/*  66 */       Constructor<T> constructor = type.getDeclaredConstructor((Class[])constructorArgTypes.toArray(new Class[constructorArgTypes.size()]));
/*  67 */       if (!constructor.isAccessible()) {
/*  68 */         constructor.setAccessible(true);
/*     */       }
/*  70 */       return (T)constructor.newInstance(constructorArgs.toArray(new Object[constructorArgs.size()]));
/*     */     } catch (Exception e) {
/*  72 */       StringBuilder argTypes = new StringBuilder();
/*  73 */       if (constructorArgTypes != null) {
/*  74 */         for (Class<?> argType : constructorArgTypes) {
/*  75 */           argTypes.append(argType.getSimpleName());
/*  76 */           argTypes.append(",");
/*     */         }
/*     */       }
/*  79 */       StringBuilder argValues = new StringBuilder();
/*  80 */       if (constructorArgs != null) {
/*  81 */         for (Object argValue : constructorArgs) {
/*  82 */           argValues.append(String.valueOf(argValue));
/*  83 */           argValues.append(",");
/*     */         }
/*     */       }
/*  86 */       throw new ReflectionException("Error instantiating " + type + " with invalid types (" + argTypes + ") or values (" + argValues + "). Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected Class<?> resolveInterface(Class<?> type) { Class<?> classToCreate;
/*     */     Class<?> classToCreate;
/*  92 */     if ((type == List.class) || (type == Collection.class) || (type == Iterable.class)) {
/*  93 */       classToCreate = ArrayList.class; } else { Class<?> classToCreate;
/*  94 */       if (type == Map.class) {
/*  95 */         classToCreate = HashMap.class; } else { Class<?> classToCreate;
/*  96 */         if (type == SortedSet.class) {
/*  97 */           classToCreate = TreeSet.class; } else { Class<?> classToCreate;
/*  98 */           if (type == Set.class) {
/*  99 */             classToCreate = HashSet.class;
/*     */           } else
/* 101 */             classToCreate = type;
/*     */         } } }
/* 103 */     return classToCreate;
/*     */   }
/*     */   
/*     */   public <T> boolean isCollection(Class<T> type) {
/* 107 */     return Collection.class.isAssignableFrom(type);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\factory\DefaultObjectFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */