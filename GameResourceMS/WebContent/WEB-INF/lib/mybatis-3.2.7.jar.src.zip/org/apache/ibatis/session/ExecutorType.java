package org.apache.ibatis.session;

public enum ExecutorType
{
  SIMPLE,  REUSE,  BATCH;
  
  private ExecutorType() {}
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\session\ExecutorType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */