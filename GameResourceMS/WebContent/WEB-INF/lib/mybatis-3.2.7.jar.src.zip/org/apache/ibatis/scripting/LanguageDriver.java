package org.apache.ibatis.scripting;

import org.apache.ibatis.executor.parameter.ParameterHandler;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.SqlSource;
import org.apache.ibatis.parsing.XNode;
import org.apache.ibatis.session.Configuration;

public abstract interface LanguageDriver
{
  public abstract ParameterHandler createParameterHandler(MappedStatement paramMappedStatement, Object paramObject, BoundSql paramBoundSql);
  
  public abstract SqlSource createSqlSource(Configuration paramConfiguration, XNode paramXNode, Class<?> paramClass);
  
  public abstract SqlSource createSqlSource(Configuration paramConfiguration, String paramString, Class<?> paramClass);
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\LanguageDriver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */