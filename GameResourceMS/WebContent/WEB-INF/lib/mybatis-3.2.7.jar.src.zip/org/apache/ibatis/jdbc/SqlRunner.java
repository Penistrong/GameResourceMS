/*     */ package org.apache.ibatis.jdbc;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.ibatis.io.Resources;
/*     */ import org.apache.ibatis.type.TypeHandler;
/*     */ import org.apache.ibatis.type.TypeHandlerRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlRunner
/*     */ {
/*     */   public static final int NO_GENERATED_KEY = -2147482647;
/*     */   private Connection connection;
/*     */   private TypeHandlerRegistry typeHandlerRegistry;
/*     */   private boolean useGeneratedKeySupport;
/*     */   
/*     */   public SqlRunner(Connection connection)
/*     */   {
/*  47 */     this.connection = connection;
/*  48 */     this.typeHandlerRegistry = new TypeHandlerRegistry();
/*     */   }
/*     */   
/*     */   public void setUseGeneratedKeySupport(boolean useGeneratedKeySupport) {
/*  52 */     this.useGeneratedKeySupport = useGeneratedKeySupport;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Object> selectOne(String sql, Object... args)
/*     */     throws SQLException
/*     */   {
/*  64 */     List<Map<String, Object>> results = selectAll(sql, args);
/*  65 */     if (results.size() != 1) {
/*  66 */       throw new SQLException("Statement returned " + results.size() + " results where exactly one (1) was expected.");
/*     */     }
/*  68 */     return (Map)results.get(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Map<String, Object>> selectAll(String sql, Object... args)
/*     */     throws SQLException
/*     */   {
/*  80 */     PreparedStatement ps = this.connection.prepareStatement(sql);
/*     */     try {
/*  82 */       setParameters(ps, args);
/*  83 */       ResultSet rs = ps.executeQuery();
/*  84 */       return getResults(rs);
/*     */     } finally {
/*     */       try {
/*  87 */         ps.close();
/*     */       }
/*     */       catch (SQLException e) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int insert(String sql, Object... args)
/*     */     throws SQLException
/*     */   {
/*     */     PreparedStatement ps;
/*     */     
/*     */ 
/*     */     PreparedStatement ps;
/*     */     
/*     */ 
/* 104 */     if (this.useGeneratedKeySupport) {
/* 105 */       ps = this.connection.prepareStatement(sql, 1);
/*     */     } else {
/* 107 */       ps = this.connection.prepareStatement(sql);
/*     */     }
/*     */     try
/*     */     {
/* 111 */       setParameters(ps, args);
/* 112 */       ps.executeUpdate();
/* 113 */       List<Map<String, Object>> keys; if (this.useGeneratedKeySupport) {
/* 114 */         keys = getResults(ps.getGeneratedKeys());
/* 115 */         if (keys.size() == 1) {
/* 116 */           Map<String, Object> key = (Map)keys.get(0);
/* 117 */           Iterator<Object> i = key.values().iterator();
/* 118 */           if (i.hasNext()) {
/* 119 */             Object genkey = i.next();
/* 120 */             if (genkey != null) {
/*     */               try {
/* 122 */                 return Integer.parseInt(genkey.toString());
/*     */               }
/*     */               catch (NumberFormatException e) {}
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 130 */       return -2147482647;
/*     */     } finally {
/*     */       try {
/* 133 */         ps.close();
/*     */       }
/*     */       catch (SQLException e) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int update(String sql, Object... args)
/*     */     throws SQLException
/*     */   {
/* 149 */     PreparedStatement ps = this.connection.prepareStatement(sql);
/*     */     try {
/* 151 */       setParameters(ps, args);
/* 152 */       return ps.executeUpdate();
/*     */     } finally {
/*     */       try {
/* 155 */         ps.close();
/*     */       }
/*     */       catch (SQLException e) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int delete(String sql, Object... args)
/*     */     throws SQLException
/*     */   {
/* 171 */     return update(sql, args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run(String sql)
/*     */     throws SQLException
/*     */   {
/* 182 */     Statement stmt = this.connection.createStatement();
/*     */     try {
/* 184 */       stmt.execute(sql); return;
/*     */     } finally {
/*     */       try {
/* 187 */         stmt.close();
/*     */       }
/*     */       catch (SQLException e) {}
/*     */     }
/*     */   }
/*     */   
/*     */   public void closeConnection()
/*     */   {
/*     */     try {
/* 196 */       this.connection.close();
/*     */     }
/*     */     catch (SQLException e) {}
/*     */   }
/*     */   
/*     */   private void setParameters(PreparedStatement ps, Object... args) throws SQLException
/*     */   {
/* 203 */     int i = 0; for (int n = args.length; i < n; i++) {
/* 204 */       if (args[i] == null)
/* 205 */         throw new SQLException("SqlRunner requires an instance of Null to represent typed null values for JDBC compatibility");
/* 206 */       if ((args[i] instanceof Null)) {
/* 207 */         ((Null)args[i]).getTypeHandler().setParameter(ps, i + 1, null, ((Null)args[i]).getJdbcType());
/*     */       } else {
/* 209 */         TypeHandler typeHandler = this.typeHandlerRegistry.getTypeHandler(args[i].getClass());
/* 210 */         if (typeHandler == null) {
/* 211 */           throw new SQLException("SqlRunner could not find a TypeHandler instance for " + args[i].getClass());
/*     */         }
/* 213 */         typeHandler.setParameter(ps, i + 1, args[i], null);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private List<Map<String, Object>> getResults(ResultSet rs) throws SQLException
/*     */   {
/*     */     try {
/* 221 */       List<Map<String, Object>> list = new ArrayList();
/* 222 */       List<String> columns = new ArrayList();
/* 223 */       List<TypeHandler<?>> typeHandlers = new ArrayList();
/* 224 */       ResultSetMetaData rsmd = rs.getMetaData();
/* 225 */       int i = 0; for (int n = rsmd.getColumnCount(); i < n; i++) {
/* 226 */         columns.add(rsmd.getColumnLabel(i + 1));
/*     */         try {
/* 228 */           Class<?> type = Resources.classForName(rsmd.getColumnClassName(i + 1));
/* 229 */           TypeHandler<?> typeHandler = this.typeHandlerRegistry.getTypeHandler(type);
/* 230 */           if (typeHandler == null) {
/* 231 */             typeHandler = this.typeHandlerRegistry.getTypeHandler(Object.class);
/*     */           }
/* 233 */           typeHandlers.add(typeHandler);
/*     */         } catch (Exception e) {
/* 235 */           typeHandlers.add(this.typeHandlerRegistry.getTypeHandler(Object.class));
/*     */         } }
/*     */       Map<String, Object> row;
/* 238 */       while (rs.next()) {
/* 239 */         row = new HashMap();
/* 240 */         int i = 0; for (int n = columns.size(); i < n; i++) {
/* 241 */           String name = (String)columns.get(i);
/* 242 */           TypeHandler<?> handler = (TypeHandler)typeHandlers.get(i);
/* 243 */           row.put(name.toUpperCase(Locale.ENGLISH), handler.getResult(rs, name));
/*     */         }
/* 245 */         list.add(row);
/*     */       }
/* 247 */       return list;
/*     */     } finally {
/*     */       try {
/* 250 */         if (rs != null) rs.close();
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\jdbc\SqlRunner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */