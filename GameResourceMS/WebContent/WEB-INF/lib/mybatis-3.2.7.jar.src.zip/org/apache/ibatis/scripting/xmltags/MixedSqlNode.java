/*    */ package org.apache.ibatis.scripting.xmltags;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MixedSqlNode
/*    */   implements SqlNode
/*    */ {
/*    */   private List<SqlNode> contents;
/*    */   
/*    */   public MixedSqlNode(List<SqlNode> contents)
/*    */   {
/* 27 */     this.contents = contents;
/*    */   }
/*    */   
/*    */   public boolean apply(DynamicContext context) {
/* 31 */     for (SqlNode sqlNode : this.contents) {
/* 32 */       sqlNode.apply(context);
/*    */     }
/* 34 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\xmltags\MixedSqlNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */