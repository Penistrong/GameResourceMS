/*    */ package org.apache.ibatis.executor.result;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.ibatis.reflection.MetaObject;
/*    */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*    */ import org.apache.ibatis.reflection.wrapper.ObjectWrapperFactory;
/*    */ import org.apache.ibatis.session.ResultContext;
/*    */ import org.apache.ibatis.session.ResultHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultMapResultHandler<K, V>
/*    */   implements ResultHandler
/*    */ {
/*    */   private final Map<K, V> mappedResults;
/*    */   private final String mapKey;
/*    */   private final ObjectFactory objectFactory;
/*    */   private final ObjectWrapperFactory objectWrapperFactory;
/*    */   
/*    */   public DefaultMapResultHandler(String mapKey, ObjectFactory objectFactory, ObjectWrapperFactory objectWrapperFactory)
/*    */   {
/* 38 */     this.objectFactory = objectFactory;
/* 39 */     this.objectWrapperFactory = objectWrapperFactory;
/* 40 */     this.mappedResults = ((Map)objectFactory.create(Map.class));
/* 41 */     this.mapKey = mapKey;
/*    */   }
/*    */   
/*    */   public void handleResult(ResultContext context)
/*    */   {
/* 46 */     V value = context.getResultObject();
/* 47 */     MetaObject mo = MetaObject.forObject(value, this.objectFactory, this.objectWrapperFactory);
/*    */     
/* 49 */     K key = mo.getValue(this.mapKey);
/* 50 */     this.mappedResults.put(key, value);
/*    */   }
/*    */   
/*    */   public Map<K, V> getMappedResults() {
/* 54 */     return this.mappedResults;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\result\DefaultMapResultHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */