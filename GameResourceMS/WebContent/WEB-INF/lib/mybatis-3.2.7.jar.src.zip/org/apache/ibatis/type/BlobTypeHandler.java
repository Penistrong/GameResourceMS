/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.sql.Blob;
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlobTypeHandler
/*    */   extends BaseTypeHandler<byte[]>
/*    */ {
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, byte[] parameter, JdbcType jdbcType)
/*    */     throws SQLException
/*    */   {
/* 33 */     ByteArrayInputStream bis = new ByteArrayInputStream(parameter);
/* 34 */     ps.setBinaryStream(i, bis, parameter.length);
/*    */   }
/*    */   
/*    */   public byte[] getNullableResult(ResultSet rs, String columnName)
/*    */     throws SQLException
/*    */   {
/* 40 */     Blob blob = rs.getBlob(columnName);
/* 41 */     byte[] returnValue = null;
/* 42 */     if (null != blob) {
/* 43 */       returnValue = blob.getBytes(1L, (int)blob.length());
/*    */     }
/* 45 */     return returnValue;
/*    */   }
/*    */   
/*    */   public byte[] getNullableResult(ResultSet rs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 51 */     Blob blob = rs.getBlob(columnIndex);
/* 52 */     byte[] returnValue = null;
/* 53 */     if (null != blob) {
/* 54 */       returnValue = blob.getBytes(1L, (int)blob.length());
/*    */     }
/* 56 */     return returnValue;
/*    */   }
/*    */   
/*    */   public byte[] getNullableResult(CallableStatement cs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 62 */     Blob blob = cs.getBlob(columnIndex);
/* 63 */     byte[] returnValue = null;
/* 64 */     if (null != blob) {
/* 65 */       returnValue = blob.getBytes(1L, (int)blob.length());
/*    */     }
/* 67 */     return returnValue;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\BlobTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */