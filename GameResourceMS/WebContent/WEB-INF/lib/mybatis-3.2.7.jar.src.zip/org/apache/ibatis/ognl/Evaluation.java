/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Evaluation
/*     */ {
/*     */   private SimpleNode node;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object source;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean setOperation;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object result;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Throwable exception;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Evaluation parent;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Evaluation next;
/*     */   
/*     */ 
/*     */ 
/*     */   private Evaluation previous;
/*     */   
/*     */ 
/*     */ 
/*     */   private Evaluation firstChild;
/*     */   
/*     */ 
/*     */ 
/*     */   private Evaluation lastChild;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Evaluation(SimpleNode node, Object source)
/*     */   {
/*  58 */     this.node = node;
/*  59 */     this.source = source;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Evaluation(SimpleNode node, Object source, boolean setOperation)
/*     */   {
/*  69 */     this(node, source);
/*  70 */     this.setOperation = setOperation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SimpleNode getNode()
/*     */   {
/*  78 */     return this.node;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNode(SimpleNode value)
/*     */   {
/*  89 */     this.node = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getSource()
/*     */   {
/*  97 */     return this.source;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSource(Object value)
/*     */   {
/* 108 */     this.source = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSetOperation()
/*     */   {
/* 116 */     return this.setOperation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSetOperation(boolean value)
/*     */   {
/* 125 */     this.setOperation = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getResult()
/*     */   {
/* 133 */     return this.result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResult(Object value)
/*     */   {
/* 142 */     this.result = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Throwable getException()
/*     */   {
/* 151 */     return this.exception;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setException(Throwable value)
/*     */   {
/* 161 */     this.exception = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Evaluation getParent()
/*     */   {
/* 170 */     return this.parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Evaluation getNext()
/*     */   {
/* 179 */     return this.next;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Evaluation getPrevious()
/*     */   {
/* 188 */     return this.previous;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Evaluation getFirstChild()
/*     */   {
/* 197 */     return this.firstChild;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Evaluation getLastChild()
/*     */   {
/* 206 */     return this.lastChild;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Evaluation getFirstDescendant()
/*     */   {
/* 215 */     if (this.firstChild != null) {
/* 216 */       return this.firstChild.getFirstDescendant();
/*     */     }
/* 218 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Evaluation getLastDescendant()
/*     */   {
/* 227 */     if (this.lastChild != null) {
/* 228 */       return this.lastChild.getLastDescendant();
/*     */     }
/* 230 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addChild(Evaluation child)
/*     */   {
/* 242 */     if (this.firstChild == null) {
/* 243 */       this.firstChild = (this.lastChild = child);
/*     */     }
/* 245 */     else if (this.firstChild == this.lastChild) {
/* 246 */       this.firstChild.next = child;
/* 247 */       this.lastChild = child;
/* 248 */       this.lastChild.previous = this.firstChild;
/*     */     } else {
/* 250 */       child.previous = this.lastChild;
/* 251 */       this.lastChild.next = child;
/* 252 */       this.lastChild = child;
/*     */     }
/*     */     
/* 255 */     child.parent = this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init(SimpleNode node, Object source, boolean setOperation)
/*     */   {
/* 263 */     this.node = node;
/* 264 */     this.source = source;
/* 265 */     this.setOperation = setOperation;
/* 266 */     this.result = null;
/* 267 */     this.exception = null;
/* 268 */     this.parent = null;
/* 269 */     this.next = null;
/* 270 */     this.previous = null;
/* 271 */     this.firstChild = null;
/* 272 */     this.lastChild = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 280 */     init(null, null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString(boolean compact, boolean showChildren, String depth)
/*     */   {
/*     */     String stringResult;
/*     */     
/*     */ 
/*     */ 
/*     */     String stringResult;
/*     */     
/*     */ 
/* 295 */     if (compact) {
/* 296 */       stringResult = depth + "<" + this.node.getClass().getName() + " " + System.identityHashCode(this) + ">";
/*     */     } else {
/* 298 */       String ss = this.source != null ? this.source.getClass().getName() : "null";
/* 299 */       String rs = this.result != null ? this.result.getClass().getName() : "null";
/*     */       
/* 301 */       stringResult = depth + "<" + this.node.getClass().getName() + ": [" + (this.setOperation ? "set" : "get") + "] source = " + ss + ", result = " + this.result + " [" + rs + "]>";
/*     */     }
/* 303 */     if (showChildren) {
/* 304 */       Evaluation child = this.firstChild;
/*     */       
/* 306 */       stringResult = stringResult + "\n";
/* 307 */       while (child != null) {
/* 308 */         stringResult = stringResult + child.toString(compact, new StringBuffer(String.valueOf(depth)).append("  ").toString());
/* 309 */         child = child.next;
/*     */       }
/*     */     }
/* 312 */     return stringResult;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString(boolean compact, String depth)
/*     */   {
/* 324 */     return toString(compact, true, depth);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 332 */     return toString(false, "");
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\Evaluation.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */