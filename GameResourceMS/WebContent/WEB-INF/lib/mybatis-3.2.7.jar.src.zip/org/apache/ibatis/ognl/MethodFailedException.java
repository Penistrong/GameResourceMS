/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodFailedException
/*    */   extends OgnlException
/*    */ {
/*    */   public MethodFailedException(Object source, String name, Throwable reason)
/*    */   {
/* 42 */     super("Method \"" + name + "\" failed for object " + source, reason);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\MethodFailedException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */