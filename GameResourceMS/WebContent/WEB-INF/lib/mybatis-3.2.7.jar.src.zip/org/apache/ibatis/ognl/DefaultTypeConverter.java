/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ import java.lang.reflect.Member;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultTypeConverter
/*    */   implements TypeConverter
/*    */ {
/*    */   public Object convertValue(Map context, Object value, Class toType)
/*    */   {
/* 50 */     return OgnlOps.convertValue(value, toType);
/*    */   }
/*    */   
/*    */   public Object convertValue(Map context, Object target, Member member, String propertyName, Object value, Class toType)
/*    */   {
/* 55 */     return convertValue(context, value, toType);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\DefaultTypeConverter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */