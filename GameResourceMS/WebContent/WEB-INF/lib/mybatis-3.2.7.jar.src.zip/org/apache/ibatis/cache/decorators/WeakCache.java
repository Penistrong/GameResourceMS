/*     */ package org.apache.ibatis.cache.decorators;
/*     */ 
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.LinkedList;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import org.apache.ibatis.cache.Cache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WeakCache
/*     */   implements Cache
/*     */ {
/*     */   private final LinkedList<Object> hardLinksToAvoidGarbageCollection;
/*     */   private final ReferenceQueue<Object> queueOfGarbageCollectedEntries;
/*     */   private final Cache delegate;
/*     */   private int numberOfHardLinks;
/*     */   
/*     */   public WeakCache(Cache delegate)
/*     */   {
/*  38 */     this.delegate = delegate;
/*  39 */     this.numberOfHardLinks = 256;
/*  40 */     this.hardLinksToAvoidGarbageCollection = new LinkedList();
/*  41 */     this.queueOfGarbageCollectedEntries = new ReferenceQueue();
/*     */   }
/*     */   
/*     */   public String getId()
/*     */   {
/*  46 */     return this.delegate.getId();
/*     */   }
/*     */   
/*     */   public int getSize()
/*     */   {
/*  51 */     removeGarbageCollectedItems();
/*  52 */     return this.delegate.getSize();
/*     */   }
/*     */   
/*     */   public void setSize(int size) {
/*  56 */     this.numberOfHardLinks = size;
/*     */   }
/*     */   
/*     */   public void putObject(Object key, Object value)
/*     */   {
/*  61 */     removeGarbageCollectedItems();
/*  62 */     this.delegate.putObject(key, new WeakEntry(key, value, this.queueOfGarbageCollectedEntries, null));
/*     */   }
/*     */   
/*     */   public Object getObject(Object key)
/*     */   {
/*  67 */     Object result = null;
/*     */     
/*  69 */     WeakReference<Object> weakReference = (WeakReference)this.delegate.getObject(key);
/*  70 */     if (weakReference != null) {
/*  71 */       result = weakReference.get();
/*  72 */       if (result == null) {
/*  73 */         this.delegate.removeObject(key);
/*     */       } else {
/*  75 */         this.hardLinksToAvoidGarbageCollection.addFirst(result);
/*  76 */         if (this.hardLinksToAvoidGarbageCollection.size() > this.numberOfHardLinks) {
/*  77 */           this.hardLinksToAvoidGarbageCollection.removeLast();
/*     */         }
/*     */       }
/*     */     }
/*  81 */     return result;
/*     */   }
/*     */   
/*     */   public Object removeObject(Object key)
/*     */   {
/*  86 */     removeGarbageCollectedItems();
/*  87 */     return this.delegate.removeObject(key);
/*     */   }
/*     */   
/*     */   public void clear()
/*     */   {
/*  92 */     this.hardLinksToAvoidGarbageCollection.clear();
/*  93 */     removeGarbageCollectedItems();
/*  94 */     this.delegate.clear();
/*     */   }
/*     */   
/*     */   public ReadWriteLock getReadWriteLock() {
/*  98 */     return null;
/*     */   }
/*     */   
/*     */   private void removeGarbageCollectedItems() {
/*     */     WeakEntry sv;
/* 103 */     while ((sv = (WeakEntry)this.queueOfGarbageCollectedEntries.poll()) != null) {
/* 104 */       this.delegate.removeObject(sv.key);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class WeakEntry extends WeakReference<Object> {
/*     */     private final Object key;
/*     */     
/*     */     private WeakEntry(Object key, Object value, ReferenceQueue<Object> garbageCollectionQueue) {
/* 112 */       super(garbageCollectionQueue);
/* 113 */       this.key = key;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\cache\decorators\WeakCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */