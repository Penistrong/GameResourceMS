/*    */ package org.apache.ibatis.parsing;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenericTokenParser
/*    */ {
/*    */   private final String openToken;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final String closeToken;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final TokenHandler handler;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public GenericTokenParser(String openToken, String closeToken, TokenHandler handler)
/*    */   {
/* 28 */     this.openToken = openToken;
/* 29 */     this.closeToken = closeToken;
/* 30 */     this.handler = handler;
/*    */   }
/*    */   
/*    */   public String parse(String text) {
/* 34 */     StringBuilder builder = new StringBuilder();
/* 35 */     if ((text != null) && (text.length() > 0)) {
/* 36 */       char[] src = text.toCharArray();
/* 37 */       int offset = 0;
/* 38 */       int start = text.indexOf(this.openToken, offset);
/* 39 */       while (start > -1) {
/* 40 */         if ((start > 0) && (src[(start - 1)] == '\\'))
/*    */         {
/* 42 */           builder.append(src, offset, start - 1).append(this.openToken);
/* 43 */           offset = start + this.openToken.length();
/*    */         } else {
/* 45 */           int end = text.indexOf(this.closeToken, start);
/* 46 */           if (end == -1) {
/* 47 */             builder.append(src, offset, src.length - offset);
/* 48 */             offset = src.length;
/*    */           } else {
/* 50 */             builder.append(src, offset, start - offset);
/* 51 */             offset = start + this.openToken.length();
/* 52 */             String content = new String(src, offset, end - offset);
/* 53 */             builder.append(this.handler.handleToken(content));
/* 54 */             offset = end + this.closeToken.length();
/*    */           }
/*    */         }
/* 57 */         start = text.indexOf(this.openToken, offset);
/*    */       }
/* 59 */       if (offset < src.length) {
/* 60 */         builder.append(src, offset, src.length - offset);
/*    */       }
/*    */     }
/* 63 */     return builder.toString();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\parsing\GenericTokenParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */