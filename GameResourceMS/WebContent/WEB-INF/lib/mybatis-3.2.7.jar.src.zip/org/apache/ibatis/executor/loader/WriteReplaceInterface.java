package org.apache.ibatis.executor.loader;

import java.io.ObjectStreamException;

public abstract interface WriteReplaceInterface
{
  public abstract Object writeReplace()
    throws ObjectStreamException;
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\loader\WriteReplaceInterface.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */