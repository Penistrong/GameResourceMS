/*    */ package org.apache.ibatis.session;
/*    */ 
/*    */ import org.apache.ibatis.exceptions.PersistenceException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SqlSessionException
/*    */   extends PersistenceException
/*    */ {
/*    */   private static final long serialVersionUID = 3833184690240265047L;
/*    */   
/*    */   public SqlSessionException() {}
/*    */   
/*    */   public SqlSessionException(String message)
/*    */   {
/* 32 */     super(message);
/*    */   }
/*    */   
/*    */   public SqlSessionException(String message, Throwable cause) {
/* 36 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public SqlSessionException(Throwable cause) {
/* 40 */     super(cause);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\session\SqlSessionException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */