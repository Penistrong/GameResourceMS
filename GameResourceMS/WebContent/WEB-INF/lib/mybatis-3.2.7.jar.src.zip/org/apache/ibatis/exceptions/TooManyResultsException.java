/*    */ package org.apache.ibatis.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TooManyResultsException
/*    */   extends PersistenceException
/*    */ {
/*    */   private static final long serialVersionUID = 8935197089745865786L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TooManyResultsException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TooManyResultsException(String message)
/*    */   {
/* 30 */     super(message);
/*    */   }
/*    */   
/*    */   public TooManyResultsException(String message, Throwable cause) {
/* 34 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public TooManyResultsException(Throwable cause) {
/* 38 */     super(cause);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\exceptions\TooManyResultsException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */