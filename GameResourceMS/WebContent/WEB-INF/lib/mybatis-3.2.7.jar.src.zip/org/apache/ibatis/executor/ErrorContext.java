/*     */ package org.apache.ibatis.executor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ErrorContext
/*     */ {
/*  23 */   private static final String LINE_SEPARATOR = System.getProperty("line.separator", "\n");
/*  24 */   private static final ThreadLocal<ErrorContext> LOCAL = new ThreadLocal();
/*     */   
/*     */   private ErrorContext stored;
/*     */   
/*     */   private String resource;
/*     */   
/*     */   private String activity;
/*     */   private String object;
/*     */   private String message;
/*     */   private String sql;
/*     */   private Throwable cause;
/*     */   
/*     */   public static ErrorContext instance()
/*     */   {
/*  38 */     ErrorContext context = (ErrorContext)LOCAL.get();
/*  39 */     if (context == null) {
/*  40 */       context = new ErrorContext();
/*  41 */       LOCAL.set(context);
/*     */     }
/*  43 */     return context;
/*     */   }
/*     */   
/*     */   public ErrorContext store() {
/*  47 */     this.stored = this;
/*  48 */     LOCAL.set(new ErrorContext());
/*  49 */     return (ErrorContext)LOCAL.get();
/*     */   }
/*     */   
/*     */   public ErrorContext recall() {
/*  53 */     if (this.stored != null) {
/*  54 */       LOCAL.set(this.stored);
/*  55 */       this.stored = null;
/*     */     }
/*  57 */     return (ErrorContext)LOCAL.get();
/*     */   }
/*     */   
/*     */   public ErrorContext resource(String resource) {
/*  61 */     this.resource = resource;
/*  62 */     return this;
/*     */   }
/*     */   
/*     */   public ErrorContext activity(String activity) {
/*  66 */     this.activity = activity;
/*  67 */     return this;
/*     */   }
/*     */   
/*     */   public ErrorContext object(String object) {
/*  71 */     this.object = object;
/*  72 */     return this;
/*     */   }
/*     */   
/*     */   public ErrorContext message(String message) {
/*  76 */     this.message = message;
/*  77 */     return this;
/*     */   }
/*     */   
/*     */   public ErrorContext sql(String sql) {
/*  81 */     this.sql = sql;
/*  82 */     return this;
/*     */   }
/*     */   
/*     */   public ErrorContext cause(Throwable cause) {
/*  86 */     this.cause = cause;
/*  87 */     return this;
/*     */   }
/*     */   
/*     */   public ErrorContext reset() {
/*  91 */     this.resource = null;
/*  92 */     this.activity = null;
/*  93 */     this.object = null;
/*  94 */     this.message = null;
/*  95 */     this.sql = null;
/*  96 */     this.cause = null;
/*  97 */     LOCAL.remove();
/*  98 */     return this;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 102 */     StringBuffer description = new StringBuffer();
/*     */     
/*     */ 
/* 105 */     if (this.message != null) {
/* 106 */       description.append(LINE_SEPARATOR);
/* 107 */       description.append("### ");
/* 108 */       description.append(this.message);
/*     */     }
/*     */     
/*     */ 
/* 112 */     if (this.resource != null) {
/* 113 */       description.append(LINE_SEPARATOR);
/* 114 */       description.append("### The error may exist in ");
/* 115 */       description.append(this.resource);
/*     */     }
/*     */     
/*     */ 
/* 119 */     if (this.object != null) {
/* 120 */       description.append(LINE_SEPARATOR);
/* 121 */       description.append("### The error may involve ");
/* 122 */       description.append(this.object);
/*     */     }
/*     */     
/*     */ 
/* 126 */     if (this.activity != null) {
/* 127 */       description.append(LINE_SEPARATOR);
/* 128 */       description.append("### The error occurred while ");
/* 129 */       description.append(this.activity);
/*     */     }
/*     */     
/*     */ 
/* 133 */     if (this.sql != null) {
/* 134 */       description.append(LINE_SEPARATOR);
/* 135 */       description.append("### SQL: ");
/* 136 */       description.append(this.sql.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ').trim());
/*     */     }
/*     */     
/*     */ 
/* 140 */     if (this.cause != null) {
/* 141 */       description.append(LINE_SEPARATOR);
/* 142 */       description.append("### Cause: ");
/* 143 */       description.append(this.cause.toString());
/*     */     }
/*     */     
/* 146 */     return description.toString();
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\ErrorContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */