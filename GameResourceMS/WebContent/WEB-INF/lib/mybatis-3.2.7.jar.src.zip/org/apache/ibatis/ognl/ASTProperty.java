/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ASTProperty
/*     */   extends SimpleNode
/*     */ {
/*  39 */   private boolean indexedAccess = false;
/*     */   
/*     */   public ASTProperty(int id)
/*     */   {
/*  43 */     super(id);
/*     */   }
/*     */   
/*     */   public ASTProperty(OgnlParser p, int id)
/*     */   {
/*  48 */     super(p, id);
/*     */   }
/*     */   
/*     */   public void setIndexedAccess(boolean value)
/*     */   {
/*  53 */     this.indexedAccess = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isIndexedAccess()
/*     */   {
/*  61 */     return this.indexedAccess;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getIndexedPropertyType(OgnlContext context, Object source)
/*     */     throws OgnlException
/*     */   {
/*  71 */     if (!isIndexedAccess()) {
/*  72 */       Object property = getProperty(context, source);
/*     */       
/*  74 */       if ((property instanceof String)) {
/*  75 */         return OgnlRuntime.getIndexedPropertyType(context, source == null ? null : source.getClass(), (String)property);
/*     */       }
/*     */     }
/*  78 */     return OgnlRuntime.INDEXED_PROPERTY_NONE;
/*     */   }
/*     */   
/*     */   public Object getProperty(OgnlContext context, Object source) throws OgnlException
/*     */   {
/*  83 */     return this.children[0].getValue(context, context.getRoot());
/*     */   }
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source)
/*     */     throws OgnlException
/*     */   {
/*  89 */     Object property = getProperty(context, source);
/*     */     
/*     */ 
/*  92 */     Object result = OgnlRuntime.getProperty(context, source, property);
/*  93 */     if (result == null) {
/*  94 */       result = OgnlRuntime.getNullHandler(OgnlRuntime.getTargetClass(source)).nullPropertyValue(context, source, property);
/*     */     }
/*  96 */     return result;
/*     */   }
/*     */   
/*     */   protected void setValueBody(OgnlContext context, Object target, Object value) throws OgnlException
/*     */   {
/* 101 */     OgnlRuntime.setProperty(context, target, getProperty(context, target), value);
/*     */   }
/*     */   
/*     */   public boolean isNodeSimpleProperty(OgnlContext context) throws OgnlException
/*     */   {
/* 106 */     return (this.children != null) && (this.children.length == 1) && (((SimpleNode)this.children[0]).isConstant(context));
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*     */     String result;
/*     */     String result;
/* 113 */     if (isIndexedAccess()) {
/* 114 */       result = "[" + this.children[0] + "]";
/*     */     } else {
/* 116 */       result = ((ASTConst)this.children[0]).getValue().toString();
/*     */     }
/* 118 */     return result;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */