/*     */ package org.apache.ibatis.executor.loader;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.InvalidClassException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutput;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.StreamCorruptedException;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSerialStateHolder
/*     */   implements Externalizable
/*     */ {
/*     */   private static final long serialVersionUID = 8940388717901644661L;
/*  43 */   private static final ThreadLocal<ObjectOutputStream> stream = new ThreadLocal();
/*  44 */   private byte[] userBeanBytes = new byte[0];
/*     */   
/*     */   private Object userBean;
/*     */   
/*     */   private Map<String, ResultLoaderMap.LoadPair> unloadedProperties;
/*     */   
/*     */   private ObjectFactory objectFactory;
/*     */   
/*     */   private Class<?>[] constructorArgTypes;
/*     */   
/*     */   private Object[] constructorArgs;
/*     */   
/*     */   public AbstractSerialStateHolder() {}
/*     */   
/*     */   public AbstractSerialStateHolder(Object userBean, Map<String, ResultLoaderMap.LoadPair> unloadedProperties, ObjectFactory objectFactory, List<Class<?>> constructorArgTypes, List<Object> constructorArgs)
/*     */   {
/*  60 */     this.userBean = userBean;
/*  61 */     this.unloadedProperties = new HashMap(unloadedProperties);
/*  62 */     this.objectFactory = objectFactory;
/*  63 */     this.constructorArgTypes = ((Class[])constructorArgTypes.toArray(new Class[constructorArgTypes.size()]));
/*  64 */     this.constructorArgs = constructorArgs.toArray(new Object[constructorArgs.size()]);
/*     */   }
/*     */   
/*     */   public final void writeExternal(ObjectOutput out) throws IOException
/*     */   {
/*  69 */     boolean firstRound = false;
/*  70 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  71 */     ObjectOutputStream os = (ObjectOutputStream)stream.get();
/*  72 */     if (os == null) {
/*  73 */       os = new ObjectOutputStream(baos);
/*  74 */       firstRound = true;
/*  75 */       stream.set(os);
/*     */     }
/*     */     
/*  78 */     os.writeObject(this.userBean);
/*  79 */     os.writeObject(this.unloadedProperties);
/*  80 */     os.writeObject(this.objectFactory);
/*  81 */     os.writeObject(this.constructorArgTypes);
/*  82 */     os.writeObject(this.constructorArgs);
/*     */     
/*  84 */     byte[] bytes = baos.toByteArray();
/*  85 */     out.writeObject(bytes);
/*     */     
/*  87 */     if (firstRound) {
/*  88 */       stream.remove();
/*     */     }
/*     */   }
/*     */   
/*     */   public final void readExternal(ObjectInput in) throws IOException, ClassNotFoundException
/*     */   {
/*  94 */     Object data = in.readObject();
/*  95 */     if (data.getClass().isArray()) {
/*  96 */       this.userBeanBytes = ((byte[])data);
/*     */     } else {
/*  98 */       this.userBean = data;
/*     */     }
/*     */   }
/*     */   
/*     */   protected final Object readResolve()
/*     */     throws ObjectStreamException
/*     */   {
/* 105 */     if ((this.userBean != null) && (this.userBeanBytes.length == 0)) {
/* 106 */       return this.userBean;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 111 */       ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(this.userBeanBytes));
/* 112 */       this.userBean = in.readObject();
/* 113 */       this.unloadedProperties = ((Map)in.readObject());
/* 114 */       this.objectFactory = ((ObjectFactory)in.readObject());
/* 115 */       this.constructorArgTypes = ((Class[])in.readObject());
/* 116 */       this.constructorArgs = ((Object[])in.readObject());
/*     */     } catch (IOException ex) {
/* 118 */       throw ((ObjectStreamException)new StreamCorruptedException().initCause(ex));
/*     */     } catch (ClassNotFoundException ex) {
/* 120 */       throw ((ObjectStreamException)new InvalidClassException(ex.getLocalizedMessage()).initCause(ex));
/*     */     }
/*     */     
/* 123 */     Map<String, ResultLoaderMap.LoadPair> arrayProps = new HashMap(this.unloadedProperties);
/* 124 */     List<Class<?>> arrayTypes = Arrays.asList(this.constructorArgTypes);
/* 125 */     List<Object> arrayValues = Arrays.asList(this.constructorArgs);
/*     */     
/* 127 */     return createDeserializationProxy(this.userBean, arrayProps, this.objectFactory, arrayTypes, arrayValues);
/*     */   }
/*     */   
/*     */   protected abstract Object createDeserializationProxy(Object paramObject, Map<String, ResultLoaderMap.LoadPair> paramMap, ObjectFactory paramObjectFactory, List<Class<?>> paramList, List<Object> paramList1);
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\loader\AbstractSerialStateHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */