/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ import java.io.StringReader;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Ognl
/*     */ {
/*     */   public static Object parseExpression(String expression)
/*     */     throws OgnlException
/*     */   {
/*     */     try
/*     */     {
/* 112 */       OgnlParser parser = new OgnlParser(new StringReader(expression));
/* 113 */       return parser.topLevelExpression();
/*     */     }
/*     */     catch (ParseException e) {
/* 116 */       throw new ExpressionSyntaxException(expression, e);
/*     */     }
/*     */     catch (TokenMgrError e) {
/* 119 */       throw new ExpressionSyntaxException(expression, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map createDefaultContext(Object root)
/*     */   {
/* 133 */     return addDefaultContext(root, null, null, null, new OgnlContext());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map createDefaultContext(Object root, ClassResolver classResolver)
/*     */   {
/* 146 */     return addDefaultContext(root, classResolver, null, null, new OgnlContext());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map createDefaultContext(Object root, ClassResolver classResolver, TypeConverter converter)
/*     */   {
/* 159 */     return addDefaultContext(root, classResolver, converter, null, new OgnlContext());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map createDefaultContext(Object root, ClassResolver classResolver, TypeConverter converter, MemberAccess memberAccess)
/*     */   {
/* 172 */     return addDefaultContext(root, classResolver, converter, memberAccess, new OgnlContext());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map addDefaultContext(Object root, Map context)
/*     */   {
/* 186 */     return addDefaultContext(root, null, null, null, context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map addDefaultContext(Object root, ClassResolver classResolver, Map context)
/*     */   {
/* 200 */     return addDefaultContext(root, classResolver, null, null, context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map addDefaultContext(Object root, ClassResolver classResolver, TypeConverter converter, Map context)
/*     */   {
/* 214 */     return addDefaultContext(root, classResolver, converter, null, context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map addDefaultContext(Object root, ClassResolver classResolver, TypeConverter converter, MemberAccess memberAccess, Map context)
/*     */   {
/*     */     OgnlContext result;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 230 */     if (!(context instanceof OgnlContext)) {
/* 231 */       OgnlContext result = new OgnlContext();
/* 232 */       result.setValues(context);
/*     */     } else {
/* 234 */       result = (OgnlContext)context;
/*     */     }
/* 236 */     if (classResolver != null) {
/* 237 */       result.setClassResolver(classResolver);
/*     */     }
/* 239 */     if (converter != null) {
/* 240 */       result.setTypeConverter(converter);
/*     */     }
/* 242 */     if (memberAccess != null) {
/* 243 */       result.setMemberAccess(memberAccess);
/*     */     }
/* 245 */     result.setRoot(root);
/* 246 */     return result;
/*     */   }
/*     */   
/*     */   public static void setClassResolver(Map context, ClassResolver classResolver)
/*     */   {
/* 251 */     context.put("_classResolver", classResolver);
/*     */   }
/*     */   
/*     */   public static ClassResolver getClassResolver(Map context)
/*     */   {
/* 256 */     return (ClassResolver)context.get("_classResolver");
/*     */   }
/*     */   
/*     */   public static void setTypeConverter(Map context, TypeConverter converter)
/*     */   {
/* 261 */     context.put("_typeConverter", converter);
/*     */   }
/*     */   
/*     */   public static TypeConverter getTypeConverter(Map context)
/*     */   {
/* 266 */     return (TypeConverter)context.get("_typeConverter");
/*     */   }
/*     */   
/*     */   public static void setMemberAccess(Map context, MemberAccess memberAccess)
/*     */   {
/* 271 */     context.put("_memberAccess", memberAccess);
/*     */   }
/*     */   
/*     */   public static MemberAccess getMemberAccess(Map context)
/*     */   {
/* 276 */     return (MemberAccess)context.get("_memberAccess");
/*     */   }
/*     */   
/*     */   public static void setRoot(Map context, Object root)
/*     */   {
/* 281 */     context.put("root", root);
/*     */   }
/*     */   
/*     */   public static Object getRoot(Map context)
/*     */   {
/* 286 */     return context.get("root");
/*     */   }
/*     */   
/*     */   public static Evaluation getLastEvaluation(Map context)
/*     */   {
/* 291 */     return (Evaluation)context.get("_lastEvaluation");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getValue(Object tree, Map context, Object root)
/*     */     throws OgnlException
/*     */   {
/* 310 */     return getValue(tree, context, root, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getValue(Object tree, Map context, Object root, Class resultType)
/*     */     throws OgnlException
/*     */   {
/* 331 */     OgnlContext ognlContext = (OgnlContext)addDefaultContext(root, context);
/*     */     
/* 333 */     Object result = ((Node)tree).getValue(ognlContext, root);
/* 334 */     if (resultType != null) {
/* 335 */       result = getTypeConverter(context).convertValue(context, root, null, null, result, resultType);
/*     */     }
/* 337 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getValue(String expression, Map context, Object root)
/*     */     throws OgnlException
/*     */   {
/* 357 */     return getValue(expression, context, root, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getValue(String expression, Map context, Object root, Class resultType)
/*     */     throws OgnlException
/*     */   {
/* 378 */     return getValue(parseExpression(expression), context, root, resultType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getValue(Object tree, Object root)
/*     */     throws OgnlException
/*     */   {
/* 395 */     return getValue(tree, root, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getValue(Object tree, Object root, Class resultType)
/*     */     throws OgnlException
/*     */   {
/* 413 */     return getValue(tree, createDefaultContext(root), root, resultType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getValue(String expression, Object root)
/*     */     throws OgnlException
/*     */   {
/* 433 */     return getValue(expression, root, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getValue(String expression, Object root, Class resultType)
/*     */     throws OgnlException
/*     */   {
/* 454 */     return getValue(parseExpression(expression), root, resultType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setValue(Object tree, Map context, Object root, Object value)
/*     */     throws OgnlException
/*     */   {
/* 473 */     OgnlContext ognlContext = (OgnlContext)addDefaultContext(root, context);
/* 474 */     Node n = (Node)tree;
/*     */     
/* 476 */     n.setValue(ognlContext, root, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setValue(String expression, Map context, Object root, Object value)
/*     */     throws OgnlException
/*     */   {
/* 494 */     setValue(parseExpression(expression), context, root, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setValue(Object tree, Object root, Object value)
/*     */     throws OgnlException
/*     */   {
/* 511 */     setValue(tree, createDefaultContext(root), root, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setValue(String expression, Object root, Object value)
/*     */     throws OgnlException
/*     */   {
/* 531 */     setValue(parseExpression(expression), root, value);
/*     */   }
/*     */   
/*     */   public static boolean isConstant(Object tree, Map context) throws OgnlException
/*     */   {
/* 536 */     return ((SimpleNode)tree).isConstant((OgnlContext)addDefaultContext(null, context));
/*     */   }
/*     */   
/*     */   public static boolean isConstant(String expression, Map context) throws OgnlException
/*     */   {
/* 541 */     return isConstant(parseExpression(expression), context);
/*     */   }
/*     */   
/*     */   public static boolean isConstant(Object tree) throws OgnlException
/*     */   {
/* 546 */     return isConstant(tree, createDefaultContext(null));
/*     */   }
/*     */   
/*     */   public static boolean isConstant(String expression) throws OgnlException
/*     */   {
/* 551 */     return isConstant(parseExpression(expression), createDefaultContext(null));
/*     */   }
/*     */   
/*     */   public static boolean isSimpleProperty(Object tree, Map context) throws OgnlException
/*     */   {
/* 556 */     return ((SimpleNode)tree).isSimpleProperty((OgnlContext)addDefaultContext(null, context));
/*     */   }
/*     */   
/*     */   public static boolean isSimpleProperty(String expression, Map context) throws OgnlException
/*     */   {
/* 561 */     return isSimpleProperty(parseExpression(expression), context);
/*     */   }
/*     */   
/*     */   public static boolean isSimpleProperty(Object tree) throws OgnlException
/*     */   {
/* 566 */     return isSimpleProperty(tree, createDefaultContext(null));
/*     */   }
/*     */   
/*     */   public static boolean isSimpleProperty(String expression) throws OgnlException
/*     */   {
/* 571 */     return isSimpleProperty(parseExpression(expression), createDefaultContext(null));
/*     */   }
/*     */   
/*     */   public static boolean isSimpleNavigationChain(Object tree, Map context) throws OgnlException
/*     */   {
/* 576 */     return ((SimpleNode)tree).isSimpleNavigationChain((OgnlContext)addDefaultContext(null, context));
/*     */   }
/*     */   
/*     */   public static boolean isSimpleNavigationChain(String expression, Map context) throws OgnlException
/*     */   {
/* 581 */     return isSimpleNavigationChain(parseExpression(expression), context);
/*     */   }
/*     */   
/*     */   public static boolean isSimpleNavigationChain(Object tree) throws OgnlException
/*     */   {
/* 586 */     return isSimpleNavigationChain(tree, createDefaultContext(null));
/*     */   }
/*     */   
/*     */   public static boolean isSimpleNavigationChain(String expression) throws OgnlException
/*     */   {
/* 591 */     return isSimpleNavigationChain(parseExpression(expression), createDefaultContext(null));
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\Ognl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */