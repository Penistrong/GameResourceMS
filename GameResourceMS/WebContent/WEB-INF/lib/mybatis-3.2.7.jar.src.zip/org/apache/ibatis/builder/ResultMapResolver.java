/*    */ package org.apache.ibatis.builder;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.apache.ibatis.mapping.Discriminator;
/*    */ import org.apache.ibatis.mapping.ResultMap;
/*    */ import org.apache.ibatis.mapping.ResultMapping;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResultMapResolver
/*    */ {
/*    */   private final MapperBuilderAssistant assistant;
/*    */   private String id;
/*    */   private Class<?> type;
/*    */   private String extend;
/*    */   private Discriminator discriminator;
/*    */   private List<ResultMapping> resultMappings;
/*    */   private Boolean autoMapping;
/*    */   
/*    */   public ResultMapResolver(MapperBuilderAssistant assistant, String id, Class<?> type, String extend, Discriminator discriminator, List<ResultMapping> resultMappings, Boolean autoMapping)
/*    */   {
/* 37 */     this.assistant = assistant;
/* 38 */     this.id = id;
/* 39 */     this.type = type;
/* 40 */     this.extend = extend;
/* 41 */     this.discriminator = discriminator;
/* 42 */     this.resultMappings = resultMappings;
/* 43 */     this.autoMapping = autoMapping;
/*    */   }
/*    */   
/*    */   public ResultMap resolve() {
/* 47 */     return this.assistant.addResultMap(this.id, this.type, this.extend, this.discriminator, this.resultMappings, this.autoMapping);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\builder\ResultMapResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */