/*    */ package org.apache.ibatis.scripting.xmltags;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VarDeclSqlNode
/*    */   implements SqlNode
/*    */ {
/*    */   private final String name;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final String expression;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public VarDeclSqlNode(String var, String exp)
/*    */   {
/* 27 */     this.name = var;
/* 28 */     this.expression = exp;
/*    */   }
/*    */   
/*    */   public boolean apply(DynamicContext context) {
/* 32 */     Object value = OgnlCache.getValue(this.expression, context.getBindings());
/* 33 */     context.bind(this.name, value);
/* 34 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\xmltags\VarDeclSqlNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */