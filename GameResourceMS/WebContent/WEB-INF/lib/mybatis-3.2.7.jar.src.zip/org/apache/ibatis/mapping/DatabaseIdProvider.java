package org.apache.ibatis.mapping;

import java.sql.SQLException;
import java.util.Properties;
import javax.sql.DataSource;

public abstract interface DatabaseIdProvider
{
  public abstract void setProperties(Properties paramProperties);
  
  public abstract String getDatabaseId(DataSource paramDataSource)
    throws SQLException;
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\mapping\DatabaseIdProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */