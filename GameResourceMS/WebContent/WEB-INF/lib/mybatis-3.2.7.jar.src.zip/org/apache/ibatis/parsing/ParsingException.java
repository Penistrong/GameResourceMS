/*    */ package org.apache.ibatis.parsing;
/*    */ 
/*    */ import org.apache.ibatis.exceptions.PersistenceException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParsingException
/*    */   extends PersistenceException
/*    */ {
/*    */   private static final long serialVersionUID = -176685891441325943L;
/*    */   
/*    */   public ParsingException() {}
/*    */   
/*    */   public ParsingException(String message)
/*    */   {
/* 31 */     super(message);
/*    */   }
/*    */   
/*    */   public ParsingException(String message, Throwable cause) {
/* 35 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public ParsingException(Throwable cause) {
/* 39 */     super(cause);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\parsing\ParsingException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */