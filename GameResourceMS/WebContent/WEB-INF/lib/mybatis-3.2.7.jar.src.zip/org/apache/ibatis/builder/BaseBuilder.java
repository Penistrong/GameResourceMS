/*     */ package org.apache.ibatis.builder;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.ibatis.mapping.ParameterMode;
/*     */ import org.apache.ibatis.mapping.ResultSetType;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.type.JdbcType;
/*     */ import org.apache.ibatis.type.TypeAliasRegistry;
/*     */ import org.apache.ibatis.type.TypeHandler;
/*     */ import org.apache.ibatis.type.TypeHandlerRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseBuilder
/*     */ {
/*     */   protected final Configuration configuration;
/*     */   protected final TypeAliasRegistry typeAliasRegistry;
/*     */   protected final TypeHandlerRegistry typeHandlerRegistry;
/*     */   
/*     */   public BaseBuilder(Configuration configuration)
/*     */   {
/*  39 */     this.configuration = configuration;
/*  40 */     this.typeAliasRegistry = this.configuration.getTypeAliasRegistry();
/*  41 */     this.typeHandlerRegistry = this.configuration.getTypeHandlerRegistry();
/*     */   }
/*     */   
/*     */   public Configuration getConfiguration() {
/*  45 */     return this.configuration;
/*     */   }
/*     */   
/*     */   protected Boolean booleanValueOf(String value, Boolean defaultValue) {
/*  49 */     return value == null ? defaultValue : Boolean.valueOf(value);
/*     */   }
/*     */   
/*     */   protected Integer integerValueOf(String value, Integer defaultValue) {
/*  53 */     return value == null ? defaultValue : Integer.valueOf(value);
/*     */   }
/*     */   
/*     */   protected Set<String> stringSetValueOf(String value, String defaultValue) {
/*  57 */     value = value == null ? defaultValue : value;
/*  58 */     return new HashSet(Arrays.asList(value.split(",")));
/*     */   }
/*     */   
/*     */   protected JdbcType resolveJdbcType(String alias) {
/*  62 */     if (alias == null) return null;
/*     */     try {
/*  64 */       return JdbcType.valueOf(alias);
/*     */     } catch (IllegalArgumentException e) {
/*  66 */       throw new BuilderException("Error resolving JdbcType. Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected ResultSetType resolveResultSetType(String alias) {
/*  71 */     if (alias == null) return null;
/*     */     try {
/*  73 */       return ResultSetType.valueOf(alias);
/*     */     } catch (IllegalArgumentException e) {
/*  75 */       throw new BuilderException("Error resolving ResultSetType. Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected ParameterMode resolveParameterMode(String alias) {
/*  80 */     if (alias == null) return null;
/*     */     try {
/*  82 */       return ParameterMode.valueOf(alias);
/*     */     } catch (IllegalArgumentException e) {
/*  84 */       throw new BuilderException("Error resolving ParameterMode. Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected Object createInstance(String alias) {
/*  89 */     Class<?> clazz = resolveClass(alias);
/*  90 */     if (clazz == null) return null;
/*     */     try {
/*  92 */       return resolveClass(alias).newInstance();
/*     */     } catch (Exception e) {
/*  94 */       throw new BuilderException("Error creating instance. Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected Class<?> resolveClass(String alias) {
/*  99 */     if (alias == null) return null;
/*     */     try {
/* 101 */       return resolveAlias(alias);
/*     */     } catch (Exception e) {
/* 103 */       throw new BuilderException("Error resolving class. Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected TypeHandler<?> resolveTypeHandler(Class<?> javaType, String typeHandlerAlias) {
/* 108 */     if (typeHandlerAlias == null) return null;
/* 109 */     Class<?> type = resolveClass(typeHandlerAlias);
/* 110 */     if ((type != null) && (!TypeHandler.class.isAssignableFrom(type))) {
/* 111 */       throw new BuilderException("Type " + type.getName() + " is not a valid TypeHandler because it does not implement TypeHandler interface");
/*     */     }
/*     */     
/* 114 */     Class<? extends TypeHandler<?>> typeHandlerType = type;
/* 115 */     return resolveTypeHandler(javaType, typeHandlerType);
/*     */   }
/*     */   
/*     */   protected TypeHandler<?> resolveTypeHandler(Class<?> javaType, Class<? extends TypeHandler<?>> typeHandlerType) {
/* 119 */     if (typeHandlerType == null) { return null;
/*     */     }
/* 121 */     TypeHandler<?> handler = this.typeHandlerRegistry.getMappingTypeHandler(typeHandlerType);
/* 122 */     if (handler == null)
/*     */     {
/* 124 */       handler = this.typeHandlerRegistry.getInstance(javaType, typeHandlerType);
/*     */     }
/* 126 */     return handler;
/*     */   }
/*     */   
/*     */   protected Class<?> resolveAlias(String alias) {
/* 130 */     return this.typeAliasRegistry.resolveAlias(alias);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\builder\BaseBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */