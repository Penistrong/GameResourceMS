/*     */ package org.apache.ibatis.mapping;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import org.apache.ibatis.cache.Cache;
/*     */ import org.apache.ibatis.cache.CacheException;
/*     */ import org.apache.ibatis.cache.decorators.LoggingCache;
/*     */ import org.apache.ibatis.cache.decorators.LruCache;
/*     */ import org.apache.ibatis.cache.decorators.ScheduledCache;
/*     */ import org.apache.ibatis.cache.decorators.SerializedCache;
/*     */ import org.apache.ibatis.cache.decorators.SynchronizedCache;
/*     */ import org.apache.ibatis.cache.impl.PerpetualCache;
/*     */ import org.apache.ibatis.reflection.MetaObject;
/*     */ import org.apache.ibatis.reflection.SystemMetaObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CacheBuilder
/*     */ {
/*     */   private String id;
/*     */   private Class<? extends Cache> implementation;
/*     */   private List<Class<? extends Cache>> decorators;
/*     */   private Integer size;
/*     */   private Long clearInterval;
/*     */   private boolean readWrite;
/*     */   private Properties properties;
/*     */   
/*     */   public CacheBuilder(String id)
/*     */   {
/*  48 */     this.id = id;
/*  49 */     this.decorators = new ArrayList();
/*     */   }
/*     */   
/*     */   public CacheBuilder implementation(Class<? extends Cache> implementation) {
/*  53 */     this.implementation = implementation;
/*  54 */     return this;
/*     */   }
/*     */   
/*     */   public CacheBuilder addDecorator(Class<? extends Cache> decorator) {
/*  58 */     if (decorator != null) {
/*  59 */       this.decorators.add(decorator);
/*     */     }
/*  61 */     return this;
/*     */   }
/*     */   
/*     */   public CacheBuilder size(Integer size) {
/*  65 */     this.size = size;
/*  66 */     return this;
/*     */   }
/*     */   
/*     */   public CacheBuilder clearInterval(Long clearInterval) {
/*  70 */     this.clearInterval = clearInterval;
/*  71 */     return this;
/*     */   }
/*     */   
/*     */   public CacheBuilder readWrite(boolean readWrite) {
/*  75 */     this.readWrite = readWrite;
/*  76 */     return this;
/*     */   }
/*     */   
/*     */   public CacheBuilder properties(Properties properties) {
/*  80 */     this.properties = properties;
/*  81 */     return this;
/*     */   }
/*     */   
/*     */   public Cache build() {
/*  85 */     setDefaultImplementations();
/*  86 */     Cache cache = newBaseCacheInstance(this.implementation, this.id);
/*  87 */     setCacheProperties(cache);
/*  88 */     if (PerpetualCache.class.equals(cache.getClass())) {
/*  89 */       for (Class<? extends Cache> decorator : this.decorators) {
/*  90 */         cache = newCacheDecoratorInstance(decorator, cache);
/*  91 */         setCacheProperties(cache);
/*     */       }
/*  93 */       cache = setStandardDecorators(cache);
/*  94 */     } else if (!LoggingCache.class.isAssignableFrom(cache.getClass())) {
/*  95 */       cache = new LoggingCache(cache);
/*     */     }
/*  97 */     return cache;
/*     */   }
/*     */   
/*     */   private void setDefaultImplementations() {
/* 101 */     if (this.implementation == null) {
/* 102 */       this.implementation = PerpetualCache.class;
/* 103 */       if (this.decorators.size() == 0) {
/* 104 */         this.decorators.add(LruCache.class);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Cache setStandardDecorators(Cache cache) {
/*     */     try {
/* 111 */       MetaObject metaCache = SystemMetaObject.forObject(cache);
/* 112 */       if ((this.size != null) && (metaCache.hasSetter("size"))) {
/* 113 */         metaCache.setValue("size", this.size);
/*     */       }
/* 115 */       if (this.clearInterval != null) {
/* 116 */         cache = new ScheduledCache(cache);
/* 117 */         ((ScheduledCache)cache).setClearInterval(this.clearInterval.longValue());
/*     */       }
/* 119 */       if (this.readWrite) {
/* 120 */         cache = new SerializedCache(cache);
/*     */       }
/* 122 */       cache = new LoggingCache(cache);
/* 123 */       return new SynchronizedCache(cache);
/*     */     }
/*     */     catch (Exception e) {
/* 126 */       throw new CacheException("Error building standard cache decorators.  Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setCacheProperties(Cache cache) { MetaObject metaCache;
/* 131 */     if (this.properties != null) {
/* 132 */       metaCache = SystemMetaObject.forObject(cache);
/* 133 */       for (Map.Entry<Object, Object> entry : this.properties.entrySet()) {
/* 134 */         String name = (String)entry.getKey();
/* 135 */         String value = (String)entry.getValue();
/* 136 */         if (metaCache.hasSetter(name)) {
/* 137 */           Class<?> type = metaCache.getSetterType(name);
/* 138 */           if (String.class == type) {
/* 139 */             metaCache.setValue(name, value);
/* 140 */           } else if ((Integer.TYPE == type) || (Integer.class == type))
/*     */           {
/* 142 */             metaCache.setValue(name, Integer.valueOf(value));
/* 143 */           } else if ((Long.TYPE == type) || (Long.class == type))
/*     */           {
/* 145 */             metaCache.setValue(name, Long.valueOf(value));
/* 146 */           } else if ((Short.TYPE == type) || (Short.class == type))
/*     */           {
/* 148 */             metaCache.setValue(name, Short.valueOf(value));
/* 149 */           } else if ((Byte.TYPE == type) || (Byte.class == type))
/*     */           {
/* 151 */             metaCache.setValue(name, Byte.valueOf(value));
/* 152 */           } else if ((Float.TYPE == type) || (Float.class == type))
/*     */           {
/* 154 */             metaCache.setValue(name, Float.valueOf(value));
/* 155 */           } else if ((Boolean.TYPE == type) || (Boolean.class == type))
/*     */           {
/* 157 */             metaCache.setValue(name, Boolean.valueOf(value));
/* 158 */           } else if ((Double.TYPE == type) || (Double.class == type))
/*     */           {
/* 160 */             metaCache.setValue(name, Double.valueOf(value));
/*     */           } else {
/* 162 */             throw new CacheException("Unsupported property type for cache: '" + name + "' of type " + type);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Cache newBaseCacheInstance(Class<? extends Cache> cacheClass, String id) {
/* 170 */     Constructor<? extends Cache> cacheConstructor = getBaseCacheConstructor(cacheClass);
/*     */     try {
/* 172 */       return (Cache)cacheConstructor.newInstance(new Object[] { id });
/*     */     } catch (Exception e) {
/* 174 */       throw new CacheException("Could not instantiate cache implementation (" + cacheClass + "). Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   private Constructor<? extends Cache> getBaseCacheConstructor(Class<? extends Cache> cacheClass) {
/*     */     try {
/* 180 */       return cacheClass.getConstructor(new Class[] { String.class });
/*     */     } catch (Exception e) {
/* 182 */       throw new CacheException("Invalid base cache implementation (" + cacheClass + ").  " + "Base cache implementations must have a constructor that takes a String id as a parameter.  Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   private Cache newCacheDecoratorInstance(Class<? extends Cache> cacheClass, Cache base)
/*     */   {
/* 188 */     Constructor<? extends Cache> cacheConstructor = getCacheDecoratorConstructor(cacheClass);
/*     */     try {
/* 190 */       return (Cache)cacheConstructor.newInstance(new Object[] { base });
/*     */     } catch (Exception e) {
/* 192 */       throw new CacheException("Could not instantiate cache decorator (" + cacheClass + "). Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   private Constructor<? extends Cache> getCacheDecoratorConstructor(Class<? extends Cache> cacheClass) {
/*     */     try {
/* 198 */       return cacheClass.getConstructor(new Class[] { Cache.class });
/*     */     } catch (Exception e) {
/* 200 */       throw new CacheException("Invalid cache decorator (" + cacheClass + ").  " + "Cache decorators must have a constructor that takes a Cache instance as a parameter.  Cause: " + e, e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\mapping\CacheBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */