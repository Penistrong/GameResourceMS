/*    */ package org.apache.ibatis.mapping;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.ibatis.transaction.TransactionFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Environment
/*    */ {
/*    */   private final String id;
/*    */   private final TransactionFactory transactionFactory;
/*    */   private final DataSource dataSource;
/*    */   
/*    */   public Environment(String id, TransactionFactory transactionFactory, DataSource dataSource)
/*    */   {
/* 31 */     if (id == null) {
/* 32 */       throw new IllegalArgumentException("Parameter 'id' must not be null");
/*    */     }
/* 34 */     if (transactionFactory == null) {
/* 35 */       throw new IllegalArgumentException("Parameter 'transactionFactory' must not be null");
/*    */     }
/* 37 */     this.id = id;
/* 38 */     if (dataSource == null) {
/* 39 */       throw new IllegalArgumentException("Parameter 'dataSource' must not be null");
/*    */     }
/* 41 */     this.transactionFactory = transactionFactory;
/* 42 */     this.dataSource = dataSource;
/*    */   }
/*    */   
/*    */   public static class Builder {
/*    */     private String id;
/*    */     private TransactionFactory transactionFactory;
/*    */     private DataSource dataSource;
/*    */     
/*    */     public Builder(String id) {
/* 51 */       this.id = id;
/*    */     }
/*    */     
/*    */     public Builder transactionFactory(TransactionFactory transactionFactory) {
/* 55 */       this.transactionFactory = transactionFactory;
/* 56 */       return this;
/*    */     }
/*    */     
/*    */     public Builder dataSource(DataSource dataSource) {
/* 60 */       this.dataSource = dataSource;
/* 61 */       return this;
/*    */     }
/*    */     
/*    */     public String id() {
/* 65 */       return this.id;
/*    */     }
/*    */     
/*    */     public Environment build() {
/* 69 */       return new Environment(this.id, this.transactionFactory, this.dataSource);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getId()
/*    */   {
/* 75 */     return this.id;
/*    */   }
/*    */   
/*    */   public TransactionFactory getTransactionFactory() {
/* 79 */     return this.transactionFactory;
/*    */   }
/*    */   
/*    */   public DataSource getDataSource() {
/* 83 */     return this.dataSource;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\mapping\Environment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */