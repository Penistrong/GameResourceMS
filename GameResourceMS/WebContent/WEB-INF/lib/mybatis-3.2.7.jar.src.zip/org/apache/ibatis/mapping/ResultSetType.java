/*    */ package org.apache.ibatis.mapping;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ResultSetType
/*    */ {
/* 24 */   FORWARD_ONLY(1003), 
/* 25 */   SCROLL_INSENSITIVE(1004), 
/* 26 */   SCROLL_SENSITIVE(1005);
/*    */   
/*    */   private int value;
/*    */   
/*    */   private ResultSetType(int value) {
/* 31 */     this.value = value;
/*    */   }
/*    */   
/*    */   public int getValue() {
/* 35 */     return this.value;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\mapping\ResultSetType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */