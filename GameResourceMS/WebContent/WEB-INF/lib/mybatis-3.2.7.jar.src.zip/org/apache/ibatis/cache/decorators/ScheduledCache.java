/*    */ package org.apache.ibatis.cache.decorators;
/*    */ 
/*    */ import java.util.concurrent.locks.ReadWriteLock;
/*    */ import org.apache.ibatis.cache.Cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScheduledCache
/*    */   implements Cache
/*    */ {
/*    */   private Cache delegate;
/*    */   protected long clearInterval;
/*    */   protected long lastClear;
/*    */   
/*    */   public ScheduledCache(Cache delegate)
/*    */   {
/* 32 */     this.delegate = delegate;
/* 33 */     this.clearInterval = 3600000L;
/* 34 */     this.lastClear = System.currentTimeMillis();
/*    */   }
/*    */   
/*    */   public void setClearInterval(long clearInterval) {
/* 38 */     this.clearInterval = clearInterval;
/*    */   }
/*    */   
/*    */   public String getId()
/*    */   {
/* 43 */     return this.delegate.getId();
/*    */   }
/*    */   
/*    */   public int getSize()
/*    */   {
/* 48 */     clearWhenStale();
/* 49 */     return this.delegate.getSize();
/*    */   }
/*    */   
/*    */   public void putObject(Object key, Object object)
/*    */   {
/* 54 */     clearWhenStale();
/* 55 */     this.delegate.putObject(key, object);
/*    */   }
/*    */   
/*    */   public Object getObject(Object key)
/*    */   {
/* 60 */     if (clearWhenStale()) {
/* 61 */       return null;
/*    */     }
/* 63 */     return this.delegate.getObject(key);
/*    */   }
/*    */   
/*    */ 
/*    */   public Object removeObject(Object key)
/*    */   {
/* 69 */     clearWhenStale();
/* 70 */     return this.delegate.removeObject(key);
/*    */   }
/*    */   
/*    */   public void clear()
/*    */   {
/* 75 */     this.lastClear = System.currentTimeMillis();
/* 76 */     this.delegate.clear();
/*    */   }
/*    */   
/*    */   public ReadWriteLock getReadWriteLock()
/*    */   {
/* 81 */     return null;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 86 */     return this.delegate.hashCode();
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 91 */     return this.delegate.equals(obj);
/*    */   }
/*    */   
/*    */   private boolean clearWhenStale() {
/* 95 */     if (System.currentTimeMillis() - this.lastClear > this.clearInterval) {
/* 96 */       clear();
/* 97 */       return true;
/*    */     }
/* 99 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\cache\decorators\ScheduledCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */