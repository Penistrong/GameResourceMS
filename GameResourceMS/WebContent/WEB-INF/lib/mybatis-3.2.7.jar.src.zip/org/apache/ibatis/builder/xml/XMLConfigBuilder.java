/*     */ package org.apache.ibatis.builder.xml;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.util.Properties;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.ibatis.builder.BaseBuilder;
/*     */ import org.apache.ibatis.builder.BuilderException;
/*     */ import org.apache.ibatis.datasource.DataSourceFactory;
/*     */ import org.apache.ibatis.executor.ErrorContext;
/*     */ import org.apache.ibatis.executor.loader.ProxyFactory;
/*     */ import org.apache.ibatis.io.Resources;
/*     */ import org.apache.ibatis.mapping.DatabaseIdProvider;
/*     */ import org.apache.ibatis.mapping.Environment;
/*     */ import org.apache.ibatis.mapping.Environment.Builder;
/*     */ import org.apache.ibatis.parsing.XNode;
/*     */ import org.apache.ibatis.parsing.XPathParser;
/*     */ import org.apache.ibatis.plugin.Interceptor;
/*     */ import org.apache.ibatis.reflection.MetaClass;
/*     */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*     */ import org.apache.ibatis.reflection.wrapper.ObjectWrapperFactory;
/*     */ import org.apache.ibatis.session.AutoMappingBehavior;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.session.ExecutorType;
/*     */ import org.apache.ibatis.session.LocalCacheScope;
/*     */ import org.apache.ibatis.transaction.TransactionFactory;
/*     */ import org.apache.ibatis.type.JdbcType;
/*     */ import org.apache.ibatis.type.TypeAliasRegistry;
/*     */ import org.apache.ibatis.type.TypeHandlerRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLConfigBuilder
/*     */   extends BaseBuilder
/*     */ {
/*     */   private boolean parsed;
/*     */   private XPathParser parser;
/*     */   private String environment;
/*     */   
/*     */   public XMLConfigBuilder(Reader reader)
/*     */   {
/*  55 */     this(reader, null, null);
/*     */   }
/*     */   
/*     */   public XMLConfigBuilder(Reader reader, String environment) {
/*  59 */     this(reader, environment, null);
/*     */   }
/*     */   
/*     */   public XMLConfigBuilder(Reader reader, String environment, Properties props) {
/*  63 */     this(new XPathParser(reader, true, props, new XMLMapperEntityResolver()), environment, props);
/*     */   }
/*     */   
/*     */   public XMLConfigBuilder(InputStream inputStream) {
/*  67 */     this(inputStream, null, null);
/*     */   }
/*     */   
/*     */   public XMLConfigBuilder(InputStream inputStream, String environment) {
/*  71 */     this(inputStream, environment, null);
/*     */   }
/*     */   
/*     */   public XMLConfigBuilder(InputStream inputStream, String environment, Properties props) {
/*  75 */     this(new XPathParser(inputStream, true, props, new XMLMapperEntityResolver()), environment, props);
/*     */   }
/*     */   
/*     */   private XMLConfigBuilder(XPathParser parser, String environment, Properties props) {
/*  79 */     super(new Configuration());
/*  80 */     ErrorContext.instance().resource("SQL Mapper Configuration");
/*  81 */     this.configuration.setVariables(props);
/*  82 */     this.parsed = false;
/*  83 */     this.environment = environment;
/*  84 */     this.parser = parser;
/*     */   }
/*     */   
/*     */   public Configuration parse() {
/*  88 */     if (this.parsed) {
/*  89 */       throw new BuilderException("Each XMLConfigBuilder can only be used once.");
/*     */     }
/*  91 */     this.parsed = true;
/*  92 */     parseConfiguration(this.parser.evalNode("/configuration"));
/*  93 */     return this.configuration;
/*     */   }
/*     */   
/*     */   private void parseConfiguration(XNode root) {
/*     */     try {
/*  98 */       propertiesElement(root.evalNode("properties"));
/*  99 */       typeAliasesElement(root.evalNode("typeAliases"));
/* 100 */       pluginElement(root.evalNode("plugins"));
/* 101 */       objectFactoryElement(root.evalNode("objectFactory"));
/* 102 */       objectWrapperFactoryElement(root.evalNode("objectWrapperFactory"));
/* 103 */       settingsElement(root.evalNode("settings"));
/* 104 */       environmentsElement(root.evalNode("environments"));
/* 105 */       databaseIdProviderElement(root.evalNode("databaseIdProvider"));
/* 106 */       typeHandlerElement(root.evalNode("typeHandlers"));
/* 107 */       mapperElement(root.evalNode("mappers"));
/*     */     } catch (Exception e) {
/* 109 */       throw new BuilderException("Error parsing SQL Mapper Configuration. Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   private void typeAliasesElement(XNode parent) {
/* 114 */     if (parent != null) {
/* 115 */       for (XNode child : parent.getChildren()) {
/* 116 */         if ("package".equals(child.getName())) {
/* 117 */           String typeAliasPackage = child.getStringAttribute("name");
/* 118 */           this.configuration.getTypeAliasRegistry().registerAliases(typeAliasPackage);
/*     */         } else {
/* 120 */           String alias = child.getStringAttribute("alias");
/* 121 */           String type = child.getStringAttribute("type");
/*     */           try {
/* 123 */             Class<?> clazz = Resources.classForName(type);
/* 124 */             if (alias == null) {
/* 125 */               this.typeAliasRegistry.registerAlias(clazz);
/*     */             } else {
/* 127 */               this.typeAliasRegistry.registerAlias(alias, clazz);
/*     */             }
/*     */           } catch (ClassNotFoundException e) {
/* 130 */             throw new BuilderException("Error registering typeAlias for '" + alias + "'. Cause: " + e, e);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void pluginElement(XNode parent) throws Exception {
/* 138 */     if (parent != null) {
/* 139 */       for (XNode child : parent.getChildren()) {
/* 140 */         String interceptor = child.getStringAttribute("interceptor");
/* 141 */         Properties properties = child.getChildrenAsProperties();
/* 142 */         Interceptor interceptorInstance = (Interceptor)resolveClass(interceptor).newInstance();
/* 143 */         interceptorInstance.setProperties(properties);
/* 144 */         this.configuration.addInterceptor(interceptorInstance);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void objectFactoryElement(XNode context) throws Exception {
/* 150 */     if (context != null) {
/* 151 */       String type = context.getStringAttribute("type");
/* 152 */       Properties properties = context.getChildrenAsProperties();
/* 153 */       ObjectFactory factory = (ObjectFactory)resolveClass(type).newInstance();
/* 154 */       factory.setProperties(properties);
/* 155 */       this.configuration.setObjectFactory(factory);
/*     */     }
/*     */   }
/*     */   
/*     */   private void objectWrapperFactoryElement(XNode context) throws Exception {
/* 160 */     if (context != null) {
/* 161 */       String type = context.getStringAttribute("type");
/* 162 */       ObjectWrapperFactory factory = (ObjectWrapperFactory)resolveClass(type).newInstance();
/* 163 */       this.configuration.setObjectWrapperFactory(factory);
/*     */     }
/*     */   }
/*     */   
/*     */   private void propertiesElement(XNode context) throws Exception {
/* 168 */     if (context != null) {
/* 169 */       Properties defaults = context.getChildrenAsProperties();
/* 170 */       String resource = context.getStringAttribute("resource");
/* 171 */       String url = context.getStringAttribute("url");
/* 172 */       if ((resource != null) && (url != null)) {
/* 173 */         throw new BuilderException("The properties element cannot specify both a URL and a resource based property file reference.  Please specify one or the other.");
/*     */       }
/* 175 */       if (resource != null) {
/* 176 */         defaults.putAll(Resources.getResourceAsProperties(resource));
/* 177 */       } else if (url != null) {
/* 178 */         defaults.putAll(Resources.getUrlAsProperties(url));
/*     */       }
/* 180 */       Properties vars = this.configuration.getVariables();
/* 181 */       if (vars != null) {
/* 182 */         defaults.putAll(vars);
/*     */       }
/* 184 */       this.parser.setVariables(defaults);
/* 185 */       this.configuration.setVariables(defaults);
/*     */     }
/*     */   }
/*     */   
/*     */   private void settingsElement(XNode context) throws Exception {
/* 190 */     if (context != null) {
/* 191 */       Properties props = context.getChildrenAsProperties();
/*     */       
/* 193 */       MetaClass metaConfig = MetaClass.forClass(Configuration.class);
/* 194 */       for (Object key : props.keySet()) {
/* 195 */         if (!metaConfig.hasSetter(String.valueOf(key))) {
/* 196 */           throw new BuilderException("The setting " + key + " is not known.  Make sure you spelled it correctly (case sensitive).");
/*     */         }
/*     */       }
/* 199 */       this.configuration.setAutoMappingBehavior(AutoMappingBehavior.valueOf(props.getProperty("autoMappingBehavior", "PARTIAL")));
/* 200 */       this.configuration.setCacheEnabled(booleanValueOf(props.getProperty("cacheEnabled"), Boolean.valueOf(true)).booleanValue());
/* 201 */       this.configuration.setProxyFactory((ProxyFactory)createInstance(props.getProperty("proxyFactory")));
/* 202 */       this.configuration.setLazyLoadingEnabled(booleanValueOf(props.getProperty("lazyLoadingEnabled"), Boolean.valueOf(false)).booleanValue());
/* 203 */       this.configuration.setAggressiveLazyLoading(booleanValueOf(props.getProperty("aggressiveLazyLoading"), Boolean.valueOf(true)).booleanValue());
/* 204 */       this.configuration.setMultipleResultSetsEnabled(booleanValueOf(props.getProperty("multipleResultSetsEnabled"), Boolean.valueOf(true)).booleanValue());
/* 205 */       this.configuration.setUseColumnLabel(booleanValueOf(props.getProperty("useColumnLabel"), Boolean.valueOf(true)).booleanValue());
/* 206 */       this.configuration.setUseGeneratedKeys(booleanValueOf(props.getProperty("useGeneratedKeys"), Boolean.valueOf(false)).booleanValue());
/* 207 */       this.configuration.setDefaultExecutorType(ExecutorType.valueOf(props.getProperty("defaultExecutorType", "SIMPLE")));
/* 208 */       this.configuration.setDefaultStatementTimeout(integerValueOf(props.getProperty("defaultStatementTimeout"), null));
/* 209 */       this.configuration.setMapUnderscoreToCamelCase(booleanValueOf(props.getProperty("mapUnderscoreToCamelCase"), Boolean.valueOf(false)).booleanValue());
/* 210 */       this.configuration.setSafeRowBoundsEnabled(booleanValueOf(props.getProperty("safeRowBoundsEnabled"), Boolean.valueOf(false)).booleanValue());
/* 211 */       this.configuration.setLocalCacheScope(LocalCacheScope.valueOf(props.getProperty("localCacheScope", "SESSION")));
/* 212 */       this.configuration.setJdbcTypeForNull(JdbcType.valueOf(props.getProperty("jdbcTypeForNull", "OTHER")));
/* 213 */       this.configuration.setLazyLoadTriggerMethods(stringSetValueOf(props.getProperty("lazyLoadTriggerMethods"), "equals,clone,hashCode,toString"));
/* 214 */       this.configuration.setSafeResultHandlerEnabled(booleanValueOf(props.getProperty("safeResultHandlerEnabled"), Boolean.valueOf(true)).booleanValue());
/* 215 */       this.configuration.setDefaultScriptingLanguage(resolveClass(props.getProperty("defaultScriptingLanguage")));
/* 216 */       this.configuration.setCallSettersOnNulls(booleanValueOf(props.getProperty("callSettersOnNulls"), Boolean.valueOf(false)).booleanValue());
/* 217 */       this.configuration.setLogPrefix(props.getProperty("logPrefix"));
/* 218 */       this.configuration.setLogImpl(resolveClass(props.getProperty("logImpl")));
/* 219 */       this.configuration.setConfigurationFactory(resolveClass(props.getProperty("configurationFactory")));
/*     */     }
/*     */   }
/*     */   
/*     */   private void environmentsElement(XNode context) throws Exception {
/* 224 */     if (context != null) {
/* 225 */       if (this.environment == null) {
/* 226 */         this.environment = context.getStringAttribute("default");
/*     */       }
/* 228 */       for (XNode child : context.getChildren()) {
/* 229 */         String id = child.getStringAttribute("id");
/* 230 */         if (isSpecifiedEnvironment(id)) {
/* 231 */           TransactionFactory txFactory = transactionManagerElement(child.evalNode("transactionManager"));
/* 232 */           DataSourceFactory dsFactory = dataSourceElement(child.evalNode("dataSource"));
/* 233 */           DataSource dataSource = dsFactory.getDataSource();
/* 234 */           Environment.Builder environmentBuilder = new Environment.Builder(id).transactionFactory(txFactory).dataSource(dataSource);
/*     */           
/*     */ 
/* 237 */           this.configuration.setEnvironment(environmentBuilder.build());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void databaseIdProviderElement(XNode context) throws Exception {
/* 244 */     DatabaseIdProvider databaseIdProvider = null;
/* 245 */     if (context != null) {
/* 246 */       String type = context.getStringAttribute("type");
/* 247 */       if ("VENDOR".equals(type)) type = "DB_VENDOR";
/* 248 */       Properties properties = context.getChildrenAsProperties();
/* 249 */       databaseIdProvider = (DatabaseIdProvider)resolveClass(type).newInstance();
/* 250 */       databaseIdProvider.setProperties(properties);
/*     */     }
/* 252 */     Environment environment = this.configuration.getEnvironment();
/* 253 */     if ((environment != null) && (databaseIdProvider != null)) {
/* 254 */       String databaseId = databaseIdProvider.getDatabaseId(environment.getDataSource());
/* 255 */       this.configuration.setDatabaseId(databaseId);
/*     */     }
/*     */   }
/*     */   
/*     */   private TransactionFactory transactionManagerElement(XNode context) throws Exception {
/* 260 */     if (context != null) {
/* 261 */       String type = context.getStringAttribute("type");
/* 262 */       Properties props = context.getChildrenAsProperties();
/* 263 */       TransactionFactory factory = (TransactionFactory)resolveClass(type).newInstance();
/* 264 */       factory.setProperties(props);
/* 265 */       return factory;
/*     */     }
/* 267 */     throw new BuilderException("Environment declaration requires a TransactionFactory.");
/*     */   }
/*     */   
/*     */   private DataSourceFactory dataSourceElement(XNode context) throws Exception {
/* 271 */     if (context != null) {
/* 272 */       String type = context.getStringAttribute("type");
/* 273 */       Properties props = context.getChildrenAsProperties();
/* 274 */       DataSourceFactory factory = (DataSourceFactory)resolveClass(type).newInstance();
/* 275 */       factory.setProperties(props);
/* 276 */       return factory;
/*     */     }
/* 278 */     throw new BuilderException("Environment declaration requires a DataSourceFactory.");
/*     */   }
/*     */   
/*     */   private void typeHandlerElement(XNode parent) throws Exception {
/* 282 */     if (parent != null) {
/* 283 */       for (XNode child : parent.getChildren()) {
/* 284 */         if ("package".equals(child.getName())) {
/* 285 */           String typeHandlerPackage = child.getStringAttribute("name");
/* 286 */           this.typeHandlerRegistry.register(typeHandlerPackage);
/*     */         } else {
/* 288 */           String javaTypeName = child.getStringAttribute("javaType");
/* 289 */           String jdbcTypeName = child.getStringAttribute("jdbcType");
/* 290 */           String handlerTypeName = child.getStringAttribute("handler");
/* 291 */           Class<?> javaTypeClass = resolveClass(javaTypeName);
/* 292 */           JdbcType jdbcType = resolveJdbcType(jdbcTypeName);
/* 293 */           Class<?> typeHandlerClass = resolveClass(handlerTypeName);
/* 294 */           if (javaTypeClass != null) {
/* 295 */             if (jdbcType == null) {
/* 296 */               this.typeHandlerRegistry.register(javaTypeClass, typeHandlerClass);
/*     */             } else {
/* 298 */               this.typeHandlerRegistry.register(javaTypeClass, jdbcType, typeHandlerClass);
/*     */             }
/*     */           } else {
/* 301 */             this.typeHandlerRegistry.register(typeHandlerClass);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void mapperElement(XNode parent) throws Exception {
/* 309 */     if (parent != null) {
/* 310 */       for (XNode child : parent.getChildren()) {
/* 311 */         if ("package".equals(child.getName())) {
/* 312 */           String mapperPackage = child.getStringAttribute("name");
/* 313 */           this.configuration.addMappers(mapperPackage);
/*     */         } else {
/* 315 */           String resource = child.getStringAttribute("resource");
/* 316 */           String url = child.getStringAttribute("url");
/* 317 */           String mapperClass = child.getStringAttribute("class");
/* 318 */           if ((resource != null) && (url == null) && (mapperClass == null)) {
/* 319 */             ErrorContext.instance().resource(resource);
/* 320 */             InputStream inputStream = Resources.getResourceAsStream(resource);
/* 321 */             XMLMapperBuilder mapperParser = new XMLMapperBuilder(inputStream, this.configuration, resource, this.configuration.getSqlFragments());
/* 322 */             mapperParser.parse();
/* 323 */           } else if ((resource == null) && (url != null) && (mapperClass == null)) {
/* 324 */             ErrorContext.instance().resource(url);
/* 325 */             InputStream inputStream = Resources.getUrlAsStream(url);
/* 326 */             XMLMapperBuilder mapperParser = new XMLMapperBuilder(inputStream, this.configuration, url, this.configuration.getSqlFragments());
/* 327 */             mapperParser.parse();
/* 328 */           } else if ((resource == null) && (url == null) && (mapperClass != null)) {
/* 329 */             Class<?> mapperInterface = Resources.classForName(mapperClass);
/* 330 */             this.configuration.addMapper(mapperInterface);
/*     */           } else {
/* 332 */             throw new BuilderException("A mapper element may only specify a url, resource or class, but not more than one.");
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isSpecifiedEnvironment(String id) {
/* 340 */     if (this.environment == null)
/* 341 */       throw new BuilderException("No environment specified.");
/* 342 */     if (id == null)
/* 343 */       throw new BuilderException("Environment requires an id attribute.");
/* 344 */     if (this.environment.equals(id)) {
/* 345 */       return true;
/*     */     }
/* 347 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\builder\xml\XMLConfigBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */