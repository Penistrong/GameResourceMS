/*    */ package org.apache.ibatis.cache.decorators;
/*    */ 
/*    */ import java.util.concurrent.locks.ReadWriteLock;
/*    */ import org.apache.ibatis.cache.Cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SynchronizedCache
/*    */   implements Cache
/*    */ {
/*    */   private Cache delegate;
/*    */   
/*    */   public SynchronizedCache(Cache delegate)
/*    */   {
/* 30 */     this.delegate = delegate;
/*    */   }
/*    */   
/*    */   public String getId()
/*    */   {
/* 35 */     return this.delegate.getId();
/*    */   }
/*    */   
/*    */   public synchronized int getSize()
/*    */   {
/* 40 */     return this.delegate.getSize();
/*    */   }
/*    */   
/*    */   public synchronized void putObject(Object key, Object object)
/*    */   {
/* 45 */     this.delegate.putObject(key, object);
/*    */   }
/*    */   
/*    */   public synchronized Object getObject(Object key)
/*    */   {
/* 50 */     return this.delegate.getObject(key);
/*    */   }
/*    */   
/*    */   public synchronized Object removeObject(Object key)
/*    */   {
/* 55 */     return this.delegate.removeObject(key);
/*    */   }
/*    */   
/*    */   public synchronized void clear()
/*    */   {
/* 60 */     this.delegate.clear();
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 65 */     return this.delegate.hashCode();
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 70 */     return this.delegate.equals(obj);
/*    */   }
/*    */   
/*    */   public ReadWriteLock getReadWriteLock()
/*    */   {
/* 75 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\cache\decorators\SynchronizedCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */