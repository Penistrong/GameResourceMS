/*     */ package org.apache.ibatis.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.ibatis.cache.Cache;
/*     */ import org.apache.ibatis.executor.keygen.Jdbc3KeyGenerator;
/*     */ import org.apache.ibatis.executor.keygen.KeyGenerator;
/*     */ import org.apache.ibatis.executor.keygen.NoKeyGenerator;
/*     */ import org.apache.ibatis.logging.Log;
/*     */ import org.apache.ibatis.logging.LogFactory;
/*     */ import org.apache.ibatis.scripting.LanguageDriver;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MappedStatement
/*     */ {
/*     */   private String resource;
/*     */   private Configuration configuration;
/*     */   private String id;
/*     */   private Integer fetchSize;
/*     */   private Integer timeout;
/*     */   private StatementType statementType;
/*     */   private ResultSetType resultSetType;
/*     */   private SqlSource sqlSource;
/*     */   private Cache cache;
/*     */   private ParameterMap parameterMap;
/*     */   private List<ResultMap> resultMaps;
/*     */   private boolean flushCacheRequired;
/*     */   private boolean useCache;
/*     */   private boolean resultOrdered;
/*     */   private SqlCommandType sqlCommandType;
/*     */   private KeyGenerator keyGenerator;
/*     */   private String[] keyProperties;
/*     */   private String[] keyColumns;
/*     */   private boolean hasNestedResultMaps;
/*     */   private String databaseId;
/*     */   private Log statementLog;
/*     */   private LanguageDriver lang;
/*     */   private String[] resultSets;
/*     */   
/*     */   public static class Builder
/*     */   {
/*  65 */     private MappedStatement mappedStatement = new MappedStatement(null);
/*     */     
/*     */     public Builder(Configuration configuration, String id, SqlSource sqlSource, SqlCommandType sqlCommandType) {
/*  68 */       this.mappedStatement.configuration = configuration;
/*  69 */       this.mappedStatement.id = id;
/*  70 */       this.mappedStatement.sqlSource = sqlSource;
/*  71 */       this.mappedStatement.statementType = StatementType.PREPARED;
/*  72 */       this.mappedStatement.parameterMap = new ParameterMap.Builder(configuration, "defaultParameterMap", null, new ArrayList()).build();
/*  73 */       this.mappedStatement.resultMaps = new ArrayList();
/*  74 */       this.mappedStatement.timeout = configuration.getDefaultStatementTimeout();
/*  75 */       this.mappedStatement.sqlCommandType = sqlCommandType;
/*  76 */       this.mappedStatement.keyGenerator = ((configuration.isUseGeneratedKeys()) && (SqlCommandType.INSERT.equals(sqlCommandType)) ? new Jdbc3KeyGenerator() : new NoKeyGenerator());
/*  77 */       String logId = id;
/*  78 */       if (configuration.getLogPrefix() != null) logId = configuration.getLogPrefix() + id;
/*  79 */       this.mappedStatement.statementLog = LogFactory.getLog(logId);
/*  80 */       this.mappedStatement.lang = configuration.getDefaultScriptingLanuageInstance();
/*     */     }
/*     */     
/*     */     public Builder resource(String resource) {
/*  84 */       this.mappedStatement.resource = resource;
/*  85 */       return this;
/*     */     }
/*     */     
/*     */     public String id() {
/*  89 */       return this.mappedStatement.id;
/*     */     }
/*     */     
/*     */     public Builder parameterMap(ParameterMap parameterMap) {
/*  93 */       this.mappedStatement.parameterMap = parameterMap;
/*  94 */       return this;
/*     */     }
/*     */     
/*     */     public Builder resultMaps(List<ResultMap> resultMaps) {
/*  98 */       this.mappedStatement.resultMaps = resultMaps;
/*  99 */       for (ResultMap resultMap : resultMaps) {
/* 100 */         this.mappedStatement.hasNestedResultMaps = ((this.mappedStatement.hasNestedResultMaps) || (resultMap.hasNestedResultMaps()));
/*     */       }
/* 102 */       return this;
/*     */     }
/*     */     
/*     */     public Builder fetchSize(Integer fetchSize) {
/* 106 */       this.mappedStatement.fetchSize = fetchSize;
/* 107 */       return this;
/*     */     }
/*     */     
/*     */     public Builder timeout(Integer timeout) {
/* 111 */       this.mappedStatement.timeout = timeout;
/* 112 */       return this;
/*     */     }
/*     */     
/*     */     public Builder statementType(StatementType statementType) {
/* 116 */       this.mappedStatement.statementType = statementType;
/* 117 */       return this;
/*     */     }
/*     */     
/*     */     public Builder resultSetType(ResultSetType resultSetType) {
/* 121 */       this.mappedStatement.resultSetType = resultSetType;
/* 122 */       return this;
/*     */     }
/*     */     
/*     */     public Builder cache(Cache cache) {
/* 126 */       this.mappedStatement.cache = cache;
/* 127 */       return this;
/*     */     }
/*     */     
/*     */     public Builder flushCacheRequired(boolean flushCacheRequired) {
/* 131 */       this.mappedStatement.flushCacheRequired = flushCacheRequired;
/* 132 */       return this;
/*     */     }
/*     */     
/*     */     public Builder useCache(boolean useCache) {
/* 136 */       this.mappedStatement.useCache = useCache;
/* 137 */       return this;
/*     */     }
/*     */     
/*     */     public Builder resultOrdered(boolean resultOrdered) {
/* 141 */       this.mappedStatement.resultOrdered = resultOrdered;
/* 142 */       return this;
/*     */     }
/*     */     
/*     */     public Builder keyGenerator(KeyGenerator keyGenerator) {
/* 146 */       this.mappedStatement.keyGenerator = keyGenerator;
/* 147 */       return this;
/*     */     }
/*     */     
/*     */     public Builder keyProperty(String keyProperty) {
/* 151 */       this.mappedStatement.keyProperties = MappedStatement.delimitedStringtoArray(keyProperty);
/* 152 */       return this;
/*     */     }
/*     */     
/*     */     public Builder keyColumn(String keyColumn) {
/* 156 */       this.mappedStatement.keyColumns = MappedStatement.delimitedStringtoArray(keyColumn);
/* 157 */       return this;
/*     */     }
/*     */     
/*     */     public Builder databaseId(String databaseId) {
/* 161 */       this.mappedStatement.databaseId = databaseId;
/* 162 */       return this;
/*     */     }
/*     */     
/*     */     public Builder lang(LanguageDriver driver) {
/* 166 */       this.mappedStatement.lang = driver;
/* 167 */       return this;
/*     */     }
/*     */     
/*     */     public Builder resulSets(String resultSet) {
/* 171 */       this.mappedStatement.resultSets = MappedStatement.delimitedStringtoArray(resultSet);
/* 172 */       return this;
/*     */     }
/*     */     
/*     */     public MappedStatement build() {
/* 176 */       assert (this.mappedStatement.configuration != null);
/* 177 */       assert (this.mappedStatement.id != null);
/* 178 */       assert (this.mappedStatement.sqlSource != null);
/* 179 */       assert (this.mappedStatement.lang != null);
/* 180 */       this.mappedStatement.resultMaps = Collections.unmodifiableList(this.mappedStatement.resultMaps);
/* 181 */       return this.mappedStatement;
/*     */     }
/*     */   }
/*     */   
/*     */   public KeyGenerator getKeyGenerator() {
/* 186 */     return this.keyGenerator;
/*     */   }
/*     */   
/*     */   public SqlCommandType getSqlCommandType() {
/* 190 */     return this.sqlCommandType;
/*     */   }
/*     */   
/*     */   public String getResource() {
/* 194 */     return this.resource;
/*     */   }
/*     */   
/*     */   public Configuration getConfiguration() {
/* 198 */     return this.configuration;
/*     */   }
/*     */   
/*     */   public String getId() {
/* 202 */     return this.id;
/*     */   }
/*     */   
/*     */   public boolean hasNestedResultMaps() {
/* 206 */     return this.hasNestedResultMaps;
/*     */   }
/*     */   
/*     */   public Integer getFetchSize() {
/* 210 */     return this.fetchSize;
/*     */   }
/*     */   
/*     */   public Integer getTimeout() {
/* 214 */     return this.timeout;
/*     */   }
/*     */   
/*     */   public StatementType getStatementType() {
/* 218 */     return this.statementType;
/*     */   }
/*     */   
/*     */   public ResultSetType getResultSetType() {
/* 222 */     return this.resultSetType;
/*     */   }
/*     */   
/*     */   public SqlSource getSqlSource() {
/* 226 */     return this.sqlSource;
/*     */   }
/*     */   
/*     */   public ParameterMap getParameterMap() {
/* 230 */     return this.parameterMap;
/*     */   }
/*     */   
/*     */   public List<ResultMap> getResultMaps() {
/* 234 */     return this.resultMaps;
/*     */   }
/*     */   
/*     */   public Cache getCache() {
/* 238 */     return this.cache;
/*     */   }
/*     */   
/*     */   public boolean isFlushCacheRequired() {
/* 242 */     return this.flushCacheRequired;
/*     */   }
/*     */   
/*     */   public boolean isUseCache() {
/* 246 */     return this.useCache;
/*     */   }
/*     */   
/*     */   public boolean isResultOrdered() {
/* 250 */     return this.resultOrdered;
/*     */   }
/*     */   
/*     */   public String getDatabaseId() {
/* 254 */     return this.databaseId;
/*     */   }
/*     */   
/*     */   public String[] getKeyProperties() {
/* 258 */     return this.keyProperties;
/*     */   }
/*     */   
/*     */   public String[] getKeyColumns() {
/* 262 */     return this.keyColumns;
/*     */   }
/*     */   
/*     */   public Log getStatementLog() {
/* 266 */     return this.statementLog;
/*     */   }
/*     */   
/*     */   public LanguageDriver getLang() {
/* 270 */     return this.lang;
/*     */   }
/*     */   
/*     */   public String[] getResulSets() {
/* 274 */     return this.resultSets;
/*     */   }
/*     */   
/*     */   public BoundSql getBoundSql(Object parameterObject) {
/* 278 */     BoundSql boundSql = this.sqlSource.getBoundSql(parameterObject);
/* 279 */     List<ParameterMapping> parameterMappings = boundSql.getParameterMappings();
/* 280 */     if ((parameterMappings == null) || (parameterMappings.size() <= 0)) {
/* 281 */       boundSql = new BoundSql(this.configuration, boundSql.getSql(), this.parameterMap.getParameterMappings(), parameterObject);
/*     */     }
/*     */     
/*     */ 
/* 285 */     for (ParameterMapping pm : boundSql.getParameterMappings()) {
/* 286 */       String rmId = pm.getResultMapId();
/* 287 */       if (rmId != null) {
/* 288 */         ResultMap rm = this.configuration.getResultMap(rmId);
/* 289 */         if (rm != null) {
/* 290 */           this.hasNestedResultMaps |= rm.hasNestedResultMaps();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 295 */     return boundSql;
/*     */   }
/*     */   
/*     */   private static String[] delimitedStringtoArray(String in) {
/* 299 */     if ((in == null) || (in.trim().length() == 0)) {
/* 300 */       return null;
/*     */     }
/* 302 */     String[] answer = in.split(",");
/* 303 */     return answer;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\mapping\MappedStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */