/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectElementsAccessor
/*    */   implements ElementsAccessor
/*    */ {
/*    */   public Enumeration getElements(Object target)
/*    */   {
/* 45 */     Object object = target;
/*    */     
/* 47 */     new Enumeration() {
/*    */       private boolean seen;
/*    */       private final Object val$object;
/*    */       
/* 51 */       public boolean hasMoreElements() { return !this.seen; }
/*    */       
/*    */       public Object nextElement()
/*    */       {
/* 55 */         Object result = null;
/*    */         
/* 57 */         if (!this.seen) {
/* 58 */           result = this.val$object;
/* 59 */           this.seen = true;
/*    */         }
/* 61 */         return result;
/*    */       }
/*    */     };
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ObjectElementsAccessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */