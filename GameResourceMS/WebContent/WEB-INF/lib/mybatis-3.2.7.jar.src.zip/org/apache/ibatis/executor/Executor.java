/*    */ package org.apache.ibatis.executor;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import java.util.List;
/*    */ import org.apache.ibatis.cache.CacheKey;
/*    */ import org.apache.ibatis.mapping.BoundSql;
/*    */ import org.apache.ibatis.mapping.MappedStatement;
/*    */ import org.apache.ibatis.reflection.MetaObject;
/*    */ import org.apache.ibatis.session.ResultHandler;
/*    */ import org.apache.ibatis.session.RowBounds;
/*    */ import org.apache.ibatis.transaction.Transaction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface Executor
/*    */ {
/* 34 */   public static final ResultHandler NO_RESULT_HANDLER = null;
/*    */   
/*    */   public abstract int update(MappedStatement paramMappedStatement, Object paramObject)
/*    */     throws SQLException;
/*    */   
/*    */   public abstract <E> List<E> query(MappedStatement paramMappedStatement, Object paramObject, RowBounds paramRowBounds, ResultHandler paramResultHandler, CacheKey paramCacheKey, BoundSql paramBoundSql)
/*    */     throws SQLException;
/*    */   
/*    */   public abstract <E> List<E> query(MappedStatement paramMappedStatement, Object paramObject, RowBounds paramRowBounds, ResultHandler paramResultHandler)
/*    */     throws SQLException;
/*    */   
/*    */   public abstract List<BatchResult> flushStatements()
/*    */     throws SQLException;
/*    */   
/*    */   public abstract void commit(boolean paramBoolean)
/*    */     throws SQLException;
/*    */   
/*    */   public abstract void rollback(boolean paramBoolean)
/*    */     throws SQLException;
/*    */   
/*    */   public abstract CacheKey createCacheKey(MappedStatement paramMappedStatement, Object paramObject, RowBounds paramRowBounds, BoundSql paramBoundSql);
/*    */   
/*    */   public abstract boolean isCached(MappedStatement paramMappedStatement, CacheKey paramCacheKey);
/*    */   
/*    */   public abstract void clearLocalCache();
/*    */   
/*    */   public abstract void deferLoad(MappedStatement paramMappedStatement, MetaObject paramMetaObject, String paramString, CacheKey paramCacheKey, Class<?> paramClass);
/*    */   
/*    */   public abstract Transaction getTransaction();
/*    */   
/*    */   public abstract void close(boolean paramBoolean);
/*    */   
/*    */   public abstract boolean isClosed();
/*    */   
/*    */   public abstract void setExecutorWrapper(Executor paramExecutor);
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\Executor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */