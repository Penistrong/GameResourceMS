/*    */ package org.apache.ibatis.executor;
/*    */ 
/*    */ import org.apache.ibatis.exceptions.PersistenceException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExecutorException
/*    */   extends PersistenceException
/*    */ {
/*    */   private static final long serialVersionUID = 4060977051977364820L;
/*    */   
/*    */   public ExecutorException() {}
/*    */   
/*    */   public ExecutorException(String message)
/*    */   {
/* 32 */     super(message);
/*    */   }
/*    */   
/*    */   public ExecutorException(String message, Throwable cause) {
/* 36 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public ExecutorException(Throwable cause) {
/* 40 */     super(cause);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\ExecutorException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */