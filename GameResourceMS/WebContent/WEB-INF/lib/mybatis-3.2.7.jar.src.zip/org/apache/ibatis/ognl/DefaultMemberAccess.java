/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultMemberAccess
/*     */   implements MemberAccess
/*     */ {
/*  50 */   public boolean allowPrivateAccess = false;
/*  51 */   public boolean allowProtectedAccess = false;
/*  52 */   public boolean allowPackageProtectedAccess = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultMemberAccess(boolean allowAllAccess)
/*     */   {
/*  59 */     this(allowAllAccess, allowAllAccess, allowAllAccess);
/*     */   }
/*     */   
/*     */ 
/*     */   public DefaultMemberAccess(boolean allowPrivateAccess, boolean allowProtectedAccess, boolean allowPackageProtectedAccess)
/*     */   {
/*  65 */     this.allowPrivateAccess = allowPrivateAccess;
/*  66 */     this.allowProtectedAccess = allowProtectedAccess;
/*  67 */     this.allowPackageProtectedAccess = allowPackageProtectedAccess;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getAllowPrivateAccess()
/*     */   {
/*  75 */     return this.allowPrivateAccess;
/*     */   }
/*     */   
/*     */   public void setAllowPrivateAccess(boolean value)
/*     */   {
/*  80 */     this.allowPrivateAccess = value;
/*     */   }
/*     */   
/*     */   public boolean getAllowProtectedAccess()
/*     */   {
/*  85 */     return this.allowProtectedAccess;
/*     */   }
/*     */   
/*     */   public void setAllowProtectedAccess(boolean value)
/*     */   {
/*  90 */     this.allowProtectedAccess = value;
/*     */   }
/*     */   
/*     */   public boolean getAllowPackageProtectedAccess()
/*     */   {
/*  95 */     return this.allowPackageProtectedAccess;
/*     */   }
/*     */   
/*     */   public void setAllowPackageProtectedAccess(boolean value)
/*     */   {
/* 100 */     this.allowPackageProtectedAccess = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object setup(Map context, Object target, Member member, String propertyName)
/*     */   {
/* 108 */     Object result = null;
/*     */     
/* 110 */     if (isAccessible(context, target, member, propertyName)) {
/* 111 */       AccessibleObject accessible = (AccessibleObject)member;
/*     */       
/* 113 */       if (!accessible.isAccessible()) {
/* 114 */         result = Boolean.TRUE;
/* 115 */         accessible.setAccessible(true);
/*     */       }
/*     */     }
/* 118 */     return result;
/*     */   }
/*     */   
/*     */   public void restore(Map context, Object target, Member member, String propertyName, Object state)
/*     */   {
/* 123 */     if (state != null) {
/* 124 */       ((AccessibleObject)member).setAccessible(((Boolean)state).booleanValue());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAccessible(Map context, Object target, Member member, String propertyName)
/*     */   {
/* 134 */     int modifiers = member.getModifiers();
/* 135 */     boolean result = Modifier.isPublic(modifiers);
/*     */     
/* 137 */     if (!result) {
/* 138 */       if (Modifier.isPrivate(modifiers)) {
/* 139 */         result = getAllowPrivateAccess();
/*     */       }
/* 141 */       else if (Modifier.isProtected(modifiers)) {
/* 142 */         result = getAllowProtectedAccess();
/*     */       } else {
/* 144 */         result = getAllowPackageProtectedAccess();
/*     */       }
/*     */     }
/*     */     
/* 148 */     return result;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\DefaultMemberAccess.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */