/*    */ package org.apache.ibatis.executor.keygen;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.ResultSetMetaData;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.ibatis.executor.Executor;
/*    */ import org.apache.ibatis.executor.ExecutorException;
/*    */ import org.apache.ibatis.mapping.MappedStatement;
/*    */ import org.apache.ibatis.reflection.MetaObject;
/*    */ import org.apache.ibatis.session.Configuration;
/*    */ import org.apache.ibatis.type.TypeHandler;
/*    */ import org.apache.ibatis.type.TypeHandlerRegistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Jdbc3KeyGenerator
/*    */   implements KeyGenerator
/*    */ {
/*    */   public void processBefore(Executor executor, MappedStatement ms, Statement stmt, Object parameter) {}
/*    */   
/*    */   public void processAfter(Executor executor, MappedStatement ms, Statement stmt, Object parameter)
/*    */   {
/* 43 */     List<Object> parameters = new ArrayList();
/* 44 */     parameters.add(parameter);
/* 45 */     processBatch(ms, stmt, parameters);
/*    */   }
/*    */   
/*    */   public void processBatch(MappedStatement ms, Statement stmt, List<Object> parameters) {
/* 49 */     ResultSet rs = null;
/*    */     try {
/* 51 */       rs = stmt.getGeneratedKeys();
/* 52 */       Configuration configuration = ms.getConfiguration();
/* 53 */       TypeHandlerRegistry typeHandlerRegistry = configuration.getTypeHandlerRegistry();
/* 54 */       String[] keyProperties = ms.getKeyProperties();
/* 55 */       ResultSetMetaData rsmd = rs.getMetaData();
/* 56 */       TypeHandler<?>[] typeHandlers = null;
/* 57 */       if ((keyProperties != null) && (rsmd.getColumnCount() >= keyProperties.length))
/* 58 */         for (Object parameter : parameters) {
/* 59 */           if (!rs.next()) break;
/* 60 */           MetaObject metaParam = configuration.newMetaObject(parameter);
/* 61 */           if (typeHandlers == null) typeHandlers = getTypeHandlers(typeHandlerRegistry, metaParam, keyProperties);
/* 62 */           populateKeys(rs, metaParam, keyProperties, typeHandlers);
/*    */         }
/*    */       return;
/*    */     } catch (Exception e) {
/* 66 */       throw new ExecutorException("Error getting generated key or setting result to parameter object. Cause: " + e, e);
/*    */     } finally {
/* 68 */       if (rs != null) {
/*    */         try {
/* 70 */           rs.close();
/*    */         }
/*    */         catch (Exception e) {}
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   private TypeHandler<?>[] getTypeHandlers(TypeHandlerRegistry typeHandlerRegistry, MetaObject metaParam, String[] keyProperties)
/*    */   {
/* 79 */     TypeHandler<?>[] typeHandlers = new TypeHandler[keyProperties.length];
/* 80 */     for (int i = 0; i < keyProperties.length; i++) {
/* 81 */       if (metaParam.hasSetter(keyProperties[i])) {
/* 82 */         Class<?> keyPropertyType = metaParam.getSetterType(keyProperties[i]);
/* 83 */         TypeHandler<?> th = typeHandlerRegistry.getTypeHandler(keyPropertyType);
/* 84 */         typeHandlers[i] = th;
/*    */       }
/*    */     }
/* 87 */     return typeHandlers;
/*    */   }
/*    */   
/*    */   private void populateKeys(ResultSet rs, MetaObject metaParam, String[] keyProperties, TypeHandler<?>[] typeHandlers) throws SQLException {
/* 91 */     for (int i = 0; i < keyProperties.length; i++) {
/* 92 */       TypeHandler<?> th = typeHandlers[i];
/* 93 */       if (th != null) {
/* 94 */         Object value = th.getResult(rs, i + 1);
/* 95 */         metaParam.setValue(keyProperties[i], value);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\keygen\Jdbc3KeyGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */