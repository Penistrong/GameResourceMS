/*    */ package org.apache.ibatis.cache.impl;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.locks.ReadWriteLock;
/*    */ import org.apache.ibatis.cache.Cache;
/*    */ import org.apache.ibatis.cache.CacheException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PerpetualCache
/*    */   implements Cache
/*    */ {
/*    */   private String id;
/* 32 */   private Map<Object, Object> cache = new HashMap();
/*    */   
/*    */   public PerpetualCache(String id) {
/* 35 */     this.id = id;
/*    */   }
/*    */   
/*    */   public String getId() {
/* 39 */     return this.id;
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 43 */     return this.cache.size();
/*    */   }
/*    */   
/*    */   public void putObject(Object key, Object value) {
/* 47 */     this.cache.put(key, value);
/*    */   }
/*    */   
/*    */   public Object getObject(Object key) {
/* 51 */     return this.cache.get(key);
/*    */   }
/*    */   
/*    */   public Object removeObject(Object key) {
/* 55 */     return this.cache.remove(key);
/*    */   }
/*    */   
/*    */   public void clear() {
/* 59 */     this.cache.clear();
/*    */   }
/*    */   
/*    */   public ReadWriteLock getReadWriteLock() {
/* 63 */     return null;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o) {
/* 67 */     if (getId() == null) throw new CacheException("Cache instances require an ID.");
/* 68 */     if (this == o) return true;
/* 69 */     if (!(o instanceof Cache)) { return false;
/*    */     }
/* 71 */     Cache otherCache = (Cache)o;
/* 72 */     return getId().equals(otherCache.getId());
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 76 */     if (getId() == null) throw new CacheException("Cache instances require an ID.");
/* 77 */     return getId().hashCode();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\cache\impl\PerpetualCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */