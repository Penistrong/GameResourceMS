/*     */ package org.apache.ibatis.cache.decorators;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.ObjectStreamClass;
/*     */ import java.io.Serializable;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import org.apache.ibatis.cache.Cache;
/*     */ import org.apache.ibatis.cache.CacheException;
/*     */ import org.apache.ibatis.io.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SerializedCache
/*     */   implements Cache
/*     */ {
/*     */   private Cache delegate;
/*     */   
/*     */   public SerializedCache(Cache delegate)
/*     */   {
/*  40 */     this.delegate = delegate;
/*     */   }
/*     */   
/*     */   public String getId()
/*     */   {
/*  45 */     return this.delegate.getId();
/*     */   }
/*     */   
/*     */   public int getSize()
/*     */   {
/*  50 */     return this.delegate.getSize();
/*     */   }
/*     */   
/*     */   public void putObject(Object key, Object object)
/*     */   {
/*  55 */     if ((object == null) || ((object instanceof Serializable))) {
/*  56 */       this.delegate.putObject(key, serialize((Serializable)object));
/*     */     } else {
/*  58 */       throw new CacheException("SharedCache failed to make a copy of a non-serializable object: " + object);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getObject(Object key)
/*     */   {
/*  64 */     Object object = this.delegate.getObject(key);
/*  65 */     return object == null ? null : deserialize((byte[])object);
/*     */   }
/*     */   
/*     */   public Object removeObject(Object key)
/*     */   {
/*  70 */     return this.delegate.removeObject(key);
/*     */   }
/*     */   
/*     */   public void clear()
/*     */   {
/*  75 */     this.delegate.clear();
/*     */   }
/*     */   
/*     */   public ReadWriteLock getReadWriteLock()
/*     */   {
/*  80 */     return null;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  85 */     return this.delegate.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  90 */     return this.delegate.equals(obj);
/*     */   }
/*     */   
/*     */   private byte[] serialize(Serializable value) {
/*     */     try {
/*  95 */       ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  96 */       ObjectOutputStream oos = new ObjectOutputStream(bos);
/*  97 */       oos.writeObject(value);
/*  98 */       oos.flush();
/*  99 */       oos.close();
/* 100 */       return bos.toByteArray();
/*     */     } catch (Exception e) {
/* 102 */       throw new CacheException("Error serializing object.  Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   private Serializable deserialize(byte[] value) {
/*     */     Serializable result;
/*     */     try {
/* 109 */       ByteArrayInputStream bis = new ByteArrayInputStream(value);
/* 110 */       ObjectInputStream ois = new CustomObjectInputStream(bis);
/* 111 */       result = (Serializable)ois.readObject();
/* 112 */       ois.close();
/*     */     } catch (Exception e) {
/* 114 */       throw new CacheException("Error deserializing object.  Cause: " + e, e);
/*     */     }
/* 116 */     return result;
/*     */   }
/*     */   
/*     */   public static class CustomObjectInputStream extends ObjectInputStream
/*     */   {
/*     */     public CustomObjectInputStream(InputStream in) throws IOException {
/* 122 */       super();
/*     */     }
/*     */     
/*     */     protected Class<?> resolveClass(ObjectStreamClass desc) throws IOException, ClassNotFoundException
/*     */     {
/* 127 */       return Resources.classForName(desc.getName());
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\cache\decorators\SerializedCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */