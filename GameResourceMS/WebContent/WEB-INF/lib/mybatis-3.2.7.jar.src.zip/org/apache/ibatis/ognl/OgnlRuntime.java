/*      */ package org.apache.ibatis.ognl;
/*      */ 
/*      */ import [B;
/*      */ import [C;
/*      */ import [D;
/*      */ import [F;
/*      */ import [I;
/*      */ import [J;
/*      */ import [S;
/*      */ import java.beans.BeanInfo;
/*      */ import java.beans.FeatureDescriptor;
/*      */ import java.beans.IndexedPropertyDescriptor;
/*      */ import java.beans.IntrospectionException;
/*      */ import java.beans.Introspector;
/*      */ import java.beans.PropertyDescriptor;
/*      */ import java.lang.reflect.AccessibleObject;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Member;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.security.Permission;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class OgnlRuntime
/*      */ {
/*   67 */   public static final Object NotFound = new Object();
/*   68 */   public static final List NotFoundList = new ArrayList();
/*   69 */   public static final Map NotFoundMap = new HashMap();
/*   70 */   public static final Object[] NoArguments = new Object[0];
/*   71 */   public static final Class[] NoArgumentTypes = new Class[0];
/*      */   
/*      */ 
/*   74 */   public static final Object NoConversionPossible = "org.apache.ibatis.ognl.NoConversionPossible";
/*      */   
/*      */ 
/*   77 */   public static int INDEXED_PROPERTY_NONE = 0;
/*      */   
/*   79 */   public static int INDEXED_PROPERTY_INT = 1;
/*      */   
/*   81 */   public static int INDEXED_PROPERTY_OBJECT = 2;
/*      */   
/*   83 */   public static final String NULL_STRING = null;
/*      */   
/*      */ 
/*      */   private static final String SET_PREFIX = "set";
/*      */   
/*      */   private static final String GET_PREFIX = "get";
/*      */   
/*      */   private static final String IS_PREFIX = "is";
/*      */   
/*   92 */   private static final Map HEX_PADDING = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */   private static final String HEX_PREFIX = "0x";
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int HEX_LENGTH = 8;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final String NULL_OBJECT_STRING = "<null>";
/*      */   
/*      */ 
/*  107 */   private static ClassCache methodAccessors = new ClassCache();
/*  108 */   private static ClassCache propertyAccessors = new ClassCache();
/*  109 */   private static ClassCache elementsAccessors = new ClassCache();
/*  110 */   private static ClassCache nullHandlers = new ClassCache();
/*  111 */   private static ClassCache propertyDescriptorCache = new ClassCache();
/*  112 */   private static ClassCache constructorCache = new ClassCache();
/*  113 */   private static ClassCache staticMethodCache = new ClassCache();
/*  114 */   private static ClassCache instanceMethodCache = new ClassCache();
/*  115 */   private static ClassCache invokePermissionCache = new ClassCache();
/*  116 */   private static ClassCache fieldCache = new ClassCache();
/*  117 */   private static List superclasses = new ArrayList();
/*  118 */   private static ClassCache[] declaredMethods = { new ClassCache(), new ClassCache() };
/*  119 */   private static Map primitiveTypes = new HashMap(101);
/*  120 */   private static ClassCache primitiveDefaults = new ClassCache();
/*  121 */   private static Map methodParameterTypesCache = new HashMap(101);
/*  122 */   private static Map ctorParameterTypesCache = new HashMap(101);
/*  123 */   private static SecurityManager securityManager = System.getSecurityManager();
/*  124 */   private static EvaluationPool evaluationPool = new EvaluationPool();
/*  125 */   private static ObjectArrayPool objectArrayPool = new ObjectArrayPool();
/*      */   
/*      */ 
/*      */ 
/*      */   private static class ClassCache
/*      */   {
/*      */     private static final int TABLE_SIZE = 512;
/*      */     
/*      */     private static final int TABLE_SIZE_MASK = 511;
/*      */     
/*      */     private Entry[] table;
/*      */     
/*      */ 
/*      */     private static class Entry
/*      */     {
/*      */       protected Entry next;
/*      */       
/*      */       protected Class key;
/*      */       
/*      */       protected Object value;
/*      */       
/*      */ 
/*      */       public Entry(Class key, Object value)
/*      */       {
/*  149 */         this.key = key;
/*  150 */         this.value = value;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public ClassCache()
/*      */     {
/*  157 */       this.table = new Entry['Ȁ'];
/*      */     }
/*      */     
/*      */     public final Object get(Class key)
/*      */     {
/*  162 */       Object result = null;
/*  163 */       int i = key.hashCode() & 0x1FF;
/*      */       
/*  165 */       for (Entry entry = this.table[i]; entry != null; entry = entry.next) {
/*  166 */         if (entry.key == key) {
/*  167 */           result = entry.value;
/*  168 */           break;
/*      */         }
/*      */       }
/*  171 */       return result;
/*      */     }
/*      */     
/*      */     public final Object put(Class key, Object value)
/*      */     {
/*  176 */       Object result = null;
/*  177 */       int i = key.hashCode() & 0x1FF;
/*  178 */       Entry entry = this.table[i];
/*      */       
/*  180 */       if (entry == null) {
/*  181 */         this.table[i] = new Entry(key, value);
/*      */       }
/*  183 */       else if (entry.key == key) {
/*  184 */         result = entry.value;
/*  185 */         entry.value = value;
/*      */       } else {
/*      */         for (;;) {
/*  188 */           if (entry.key == key)
/*      */           {
/*  190 */             result = entry.value;
/*  191 */             entry.value = value;
/*  192 */             break;
/*      */           }
/*  194 */           if (entry.next == null)
/*      */           {
/*  196 */             entry.next = new Entry(key, value);
/*  197 */             break;
/*      */           }
/*      */           
/*  200 */           entry = entry.next;
/*      */         }
/*      */       }
/*      */       
/*  204 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */   static
/*      */   {
/*  210 */     PropertyAccessor p = new ArrayPropertyAccessor();
/*  211 */     setPropertyAccessor(Object.class, new ObjectPropertyAccessor());
/*  212 */     setPropertyAccessor(byte[].class, p);
/*  213 */     setPropertyAccessor(short[].class, p);
/*  214 */     setPropertyAccessor(char[].class, p);
/*  215 */     setPropertyAccessor(int[].class, p);
/*  216 */     setPropertyAccessor(long[].class, p);
/*  217 */     setPropertyAccessor(float[].class, p);
/*  218 */     setPropertyAccessor(double[].class, p);
/*  219 */     setPropertyAccessor(Object[].class, p);
/*  220 */     setPropertyAccessor(List.class, new ListPropertyAccessor());
/*  221 */     setPropertyAccessor(Map.class, new MapPropertyAccessor());
/*  222 */     setPropertyAccessor(Set.class, new SetPropertyAccessor());
/*  223 */     setPropertyAccessor(Iterator.class, new IteratorPropertyAccessor());
/*  224 */     setPropertyAccessor(Enumeration.class, new EnumerationPropertyAccessor());
/*      */     
/*  226 */     ElementsAccessor e = new ArrayElementsAccessor();
/*  227 */     setElementsAccessor(Object.class, new ObjectElementsAccessor());
/*  228 */     setElementsAccessor(byte[].class, e);
/*  229 */     setElementsAccessor(short[].class, e);
/*  230 */     setElementsAccessor(char[].class, e);
/*  231 */     setElementsAccessor(int[].class, e);
/*  232 */     setElementsAccessor(long[].class, e);
/*  233 */     setElementsAccessor(float[].class, e);
/*  234 */     setElementsAccessor(double[].class, e);
/*  235 */     setElementsAccessor(Object[].class, e);
/*  236 */     setElementsAccessor(Collection.class, new CollectionElementsAccessor());
/*  237 */     setElementsAccessor(Map.class, new MapElementsAccessor());
/*  238 */     setElementsAccessor(Iterator.class, new IteratorElementsAccessor());
/*  239 */     setElementsAccessor(Enumeration.class, new EnumerationElementsAccessor());
/*  240 */     setElementsAccessor(Number.class, new NumberElementsAccessor());
/*      */     
/*  242 */     NullHandler nh = new ObjectNullHandler();
/*  243 */     setNullHandler(Object.class, nh);
/*  244 */     setNullHandler(byte[].class, nh);
/*  245 */     setNullHandler(short[].class, nh);
/*  246 */     setNullHandler(char[].class, nh);
/*  247 */     setNullHandler(int[].class, nh);
/*  248 */     setNullHandler(long[].class, nh);
/*  249 */     setNullHandler(float[].class, nh);
/*  250 */     setNullHandler(double[].class, nh);
/*  251 */     setNullHandler(Object[].class, nh);
/*      */     
/*  253 */     MethodAccessor ma = new ObjectMethodAccessor();
/*  254 */     setMethodAccessor(Object.class, ma);
/*  255 */     setMethodAccessor(byte[].class, ma);
/*  256 */     setMethodAccessor(short[].class, ma);
/*  257 */     setMethodAccessor(char[].class, ma);
/*  258 */     setMethodAccessor(int[].class, ma);
/*  259 */     setMethodAccessor(long[].class, ma);
/*  260 */     setMethodAccessor(float[].class, ma);
/*  261 */     setMethodAccessor(double[].class, ma);
/*  262 */     setMethodAccessor(Object[].class, ma);
/*      */     
/*  264 */     primitiveTypes.put("boolean", Boolean.TYPE);
/*  265 */     primitiveTypes.put("byte", Byte.TYPE);
/*  266 */     primitiveTypes.put("short", Short.TYPE);
/*  267 */     primitiveTypes.put("char", Character.TYPE);
/*  268 */     primitiveTypes.put("int", Integer.TYPE);
/*  269 */     primitiveTypes.put("long", Long.TYPE);
/*  270 */     primitiveTypes.put("float", Float.TYPE);
/*  271 */     primitiveTypes.put("double", Double.TYPE);
/*      */     
/*  273 */     primitiveDefaults.put(Boolean.TYPE, Boolean.FALSE);
/*  274 */     primitiveDefaults.put(Byte.TYPE, new Byte((byte)0));
/*  275 */     primitiveDefaults.put(Short.TYPE, new Short((short)0));
/*  276 */     primitiveDefaults.put(Character.TYPE, new Character('\000'));
/*  277 */     primitiveDefaults.put(Integer.TYPE, new Integer(0));
/*  278 */     primitiveDefaults.put(Long.TYPE, new Long(0L));
/*  279 */     primitiveDefaults.put(Float.TYPE, new Float(0.0F));
/*  280 */     primitiveDefaults.put(Double.TYPE, new Double(0.0D));
/*  281 */     primitiveDefaults.put(BigInteger.class, new BigInteger("0"));
/*  282 */     primitiveDefaults.put(BigDecimal.class, new BigDecimal(0.0D));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class getTargetClass(Object o)
/*      */   {
/*  293 */     return (o instanceof Class) ? (Class)o : o == null ? null : o.getClass();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getBaseName(Object o)
/*      */   {
/*  302 */     return o == null ? null : getClassBaseName(o.getClass());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getClassBaseName(Class c)
/*      */   {
/*  311 */     String s = c.getName();
/*      */     
/*  313 */     return s.substring(s.lastIndexOf('.') + 1);
/*      */   }
/*      */   
/*      */   public static String getClassName(Object o, boolean fullyQualified)
/*      */   {
/*  318 */     if (!(o instanceof Class)) {
/*  319 */       o = o.getClass();
/*      */     }
/*  321 */     return getClassName((Class)o, fullyQualified);
/*      */   }
/*      */   
/*      */   public static String getClassName(Class c, boolean fullyQualified)
/*      */   {
/*  326 */     return fullyQualified ? c.getName() : getClassBaseName(c);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getPackageName(Object o)
/*      */   {
/*  334 */     return o == null ? null : getClassPackageName(o.getClass());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getClassPackageName(Class c)
/*      */   {
/*  342 */     String s = c.getName();
/*  343 */     int i = s.lastIndexOf('.');
/*      */     
/*  345 */     return i < 0 ? null : s.substring(0, i);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getPointerString(int num)
/*      */   {
/*  354 */     StringBuffer result = new StringBuffer();
/*  355 */     String hex = Integer.toHexString(num);
/*      */     
/*  357 */     Integer l = new Integer(hex.length());
/*      */     
/*      */     String pad;
/*  360 */     if ((pad = (String)HEX_PADDING.get(l)) == null) {
/*  361 */       StringBuffer pb = new StringBuffer();
/*      */       
/*  363 */       for (int i = hex.length(); i < 8; i++) {
/*  364 */         pb.append('0');
/*      */       }
/*  366 */       pad = new String(pb);
/*  367 */       HEX_PADDING.put(l, pad);
/*      */     }
/*  369 */     result.append(pad);
/*  370 */     result.append(hex);
/*  371 */     return new String(result);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getPointerString(Object o)
/*      */   {
/*  381 */     return getPointerString(o == null ? 0 : System.identityHashCode(o));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getUniqueDescriptor(Object object, boolean fullyQualified)
/*      */   {
/*  392 */     StringBuffer result = new StringBuffer();
/*      */     
/*  394 */     if (object != null) {
/*  395 */       if ((object instanceof Proxy)) {
/*  396 */         Class interfaceClass = object.getClass().getInterfaces()[0];
/*      */         
/*  398 */         result.append(getClassName(interfaceClass, fullyQualified));
/*  399 */         result.append('^');
/*  400 */         object = Proxy.getInvocationHandler(object);
/*      */       }
/*  402 */       result.append(getClassName(object, fullyQualified));
/*  403 */       result.append('@');
/*  404 */       result.append(getPointerString(object));
/*      */     } else {
/*  406 */       result.append("<null>");
/*      */     }
/*  408 */     return new String(result);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getUniqueDescriptor(Object object)
/*      */   {
/*  417 */     return getUniqueDescriptor(object, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Object[] toArray(List list)
/*      */   {
/*  428 */     int size = list.size();
/*      */     Object[] result;
/*  430 */     Object[] result; if (size == 0) {
/*  431 */       result = NoArguments;
/*      */     } else {
/*  433 */       result = getObjectArrayPool().create(list.size());
/*  434 */       for (int i = 0; i < size; i++) {
/*  435 */         result[i] = list.get(i);
/*      */       }
/*      */     }
/*  438 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class[] getParameterTypes(Method m)
/*      */   {
/*  446 */     synchronized (methodParameterTypesCache)
/*      */     {
/*      */       Class[] result;
/*  449 */       if ((result = (Class[])methodParameterTypesCache.get(m)) == null) {
/*  450 */         methodParameterTypesCache.put(m, result = m.getParameterTypes());
/*      */       }
/*  452 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class[] getParameterTypes(Constructor c)
/*      */   {
/*  461 */     synchronized (ctorParameterTypesCache)
/*      */     {
/*      */       Class[] result;
/*  464 */       if ((result = (Class[])ctorParameterTypesCache.get(c)) == null) {
/*  465 */         ctorParameterTypesCache.put(c, result = c.getParameterTypes());
/*      */       }
/*  467 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static SecurityManager getSecurityManager()
/*      */   {
/*  479 */     return securityManager;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void setSecurityManager(SecurityManager value)
/*      */   {
/*  490 */     securityManager = value;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Permission getPermission(Method method)
/*      */   {
/*  498 */     Permission result = null;
/*  499 */     Class mc = method.getDeclaringClass();
/*      */     
/*  501 */     synchronized (invokePermissionCache) {
/*  502 */       Map permissions = (Map)invokePermissionCache.get(mc);
/*      */       
/*  504 */       if (permissions == null) {
/*  505 */         invokePermissionCache.put(mc, permissions = new HashMap(101));
/*      */       }
/*  507 */       if ((result = (Permission)permissions.get(method.getName())) == null) {
/*  508 */         result = new OgnlInvokePermission("invoke." + mc.getName() + "." + method.getName());
/*  509 */         permissions.put(method.getName(), result);
/*      */       }
/*      */     }
/*  512 */     return result;
/*      */   }
/*      */   
/*      */   public static Object invokeMethod(Object target, Method method, Object[] argsArray)
/*      */     throws InvocationTargetException, IllegalAccessException
/*      */   {
/*  518 */     boolean wasAccessible = true;
/*      */     
/*  520 */     if (securityManager != null) {
/*      */       try {
/*  522 */         securityManager.checkPermission(getPermission(method));
/*      */       } catch (SecurityException ex) {
/*  524 */         throw new IllegalAccessException("Method [" + method + "] cannot be accessed.");
/*      */       }
/*      */     }
/*  527 */     if (((!Modifier.isPublic(method.getModifiers())) || (!Modifier.isPublic(method.getDeclaringClass().getModifiers()))) && 
/*  528 */       (!(wasAccessible = method.isAccessible()))) {
/*  529 */       method.setAccessible(true);
/*      */     }
/*      */     
/*  532 */     Object result = method.invoke(target, argsArray);
/*  533 */     if (!wasAccessible) {
/*  534 */       method.setAccessible(false);
/*      */     }
/*  536 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final Class getArgClass(Object arg)
/*      */   {
/*  550 */     if (arg == null)
/*  551 */       return null;
/*  552 */     Class c = arg.getClass();
/*  553 */     if (c == Boolean.class)
/*  554 */       return Boolean.TYPE;
/*  555 */     if (c.getSuperclass() == Number.class) {
/*  556 */       if (c == Integer.class)
/*  557 */         return Integer.TYPE;
/*  558 */       if (c == Double.class)
/*  559 */         return Double.TYPE;
/*  560 */       if (c == Byte.class)
/*  561 */         return Byte.TYPE;
/*  562 */       if (c == Long.class)
/*  563 */         return Long.TYPE;
/*  564 */       if (c == Float.class)
/*  565 */         return Float.TYPE;
/*  566 */       if (c == Short.class) {
/*  567 */         return Short.TYPE;
/*      */       }
/*  569 */     } else if (c == Character.class) {
/*  570 */       return Character.TYPE; }
/*  571 */     return c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean isTypeCompatible(Object object, Class c)
/*      */   {
/*  583 */     boolean result = true;
/*      */     
/*  585 */     if (object != null) {
/*  586 */       if (c.isPrimitive()) {
/*  587 */         if (getArgClass(object) != c) {
/*  588 */           result = false;
/*      */         }
/*  590 */       } else if (!c.isInstance(object)) {
/*  591 */         result = false;
/*      */       }
/*      */     }
/*  594 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean areArgsCompatible(Object[] args, Class[] classes)
/*      */   {
/*  604 */     boolean result = true;
/*      */     
/*  606 */     if (args.length != classes.length) {
/*  607 */       result = false;
/*      */     } else {
/*  609 */       int index = 0; for (int count = args.length; (result) && (index < count); index++) {
/*  610 */         result = isTypeCompatible(args[index], classes[index]);
/*      */       }
/*      */     }
/*  613 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean isMoreSpecific(Class[] classes1, Class[] classes2)
/*      */   {
/*  622 */     int index = 0; for (int count = classes1.length; index < count; index++)
/*      */     {
/*  624 */       Class c1 = classes1[index];Class c2 = classes2[index];
/*  625 */       if (c1 != c2)
/*      */       {
/*  627 */         if (c1.isPrimitive())
/*  628 */           return true;
/*  629 */         if (c1.isAssignableFrom(c2))
/*  630 */           return false;
/*  631 */         if (c2.isAssignableFrom(c1)) {
/*  632 */           return true;
/*      */         }
/*      */       }
/*      */     }
/*  636 */     return false;
/*      */   }
/*      */   
/*      */   public static final String getModifierString(int modifiers)
/*      */   {
/*      */     String result;
/*      */     String result;
/*  643 */     if (Modifier.isPublic(modifiers)) {
/*  644 */       result = "public";
/*      */     } else { String result;
/*  646 */       if (Modifier.isProtected(modifiers)) {
/*  647 */         result = "protected";
/*      */       } else { String result;
/*  649 */         if (Modifier.isPrivate(modifiers)) {
/*  650 */           result = "private";
/*      */         } else
/*  652 */           result = ""; } }
/*  653 */     if (Modifier.isStatic(modifiers))
/*  654 */       result = "static " + result;
/*  655 */     if (Modifier.isFinal(modifiers))
/*  656 */       result = "final " + result;
/*  657 */     if (Modifier.isNative(modifiers))
/*  658 */       result = "native " + result;
/*  659 */     if (Modifier.isSynchronized(modifiers))
/*  660 */       result = "synchronized " + result;
/*  661 */     if (Modifier.isTransient(modifiers))
/*  662 */       result = "transient " + result;
/*  663 */     return result;
/*      */   }
/*      */   
/*      */   public static final Class classForName(OgnlContext context, String className) throws ClassNotFoundException
/*      */   {
/*  668 */     Class result = (Class)primitiveTypes.get(className);
/*      */     
/*  670 */     if (result == null) {
/*      */       ClassResolver resolver;
/*      */       ClassResolver resolver;
/*  673 */       if ((context == null) || ((resolver = context.getClassResolver()) == null)) {
/*  674 */         resolver = OgnlContext.DEFAULT_CLASS_RESOLVER;
/*      */       }
/*  676 */       result = resolver.classForName(className, context);
/*      */     }
/*  678 */     return result;
/*      */   }
/*      */   
/*      */   public static final boolean isInstance(OgnlContext context, Object value, String className) throws OgnlException
/*      */   {
/*      */     try
/*      */     {
/*  685 */       Class c = classForName(context, className);
/*  686 */       return c.isInstance(value);
/*      */     }
/*      */     catch (ClassNotFoundException e)
/*      */     {
/*  690 */       throw new OgnlException("No such class: " + className, e);
/*      */     }
/*      */   }
/*      */   
/*      */   public static Object getPrimitiveDefaultValue(Class forClass)
/*      */   {
/*  696 */     return primitiveDefaults.get(forClass);
/*      */   }
/*      */   
/*      */   public static Object getConvertedType(OgnlContext context, Object target, Member member, String propertyName, Object value, Class type)
/*      */   {
/*  701 */     return context.getTypeConverter().convertValue(context, target, member, propertyName, value, type);
/*      */   }
/*      */   
/*      */   public static boolean getConvertedTypes(OgnlContext context, Object target, Member member, String propertyName, Class[] parameterTypes, Object[] args, Object[] newArgs)
/*      */   {
/*  706 */     boolean result = false;
/*      */     
/*  708 */     if (parameterTypes.length == args.length) {
/*  709 */       result = true;
/*  710 */       int i = 0; for (int ilast = parameterTypes.length - 1; (result) && (i <= ilast); i++) {
/*  711 */         Object arg = args[i];
/*  712 */         Class type = parameterTypes[i];
/*      */         
/*  714 */         if (isTypeCompatible(arg, type)) {
/*  715 */           newArgs[i] = arg;
/*      */         } else {
/*  717 */           Object v = getConvertedType(context, target, member, propertyName, arg, type);
/*      */           
/*  719 */           if (v == NoConversionPossible) {
/*  720 */             result = false;
/*      */           } else {
/*  722 */             newArgs[i] = v;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  727 */     return result;
/*      */   }
/*      */   
/*      */   public static Method getConvertedMethodAndArgs(OgnlContext context, Object target, String propertyName, List methods, Object[] args, Object[] newArgs)
/*      */   {
/*  732 */     Method result = null;
/*  733 */     TypeConverter converter = context.getTypeConverter();
/*      */     
/*  735 */     if ((converter != null) && (methods != null)) {
/*  736 */       int i = 0; for (int icount = methods.size(); (result == null) && (i < icount); i++) {
/*  737 */         Method m = (Method)methods.get(i);
/*  738 */         Class[] parameterTypes = getParameterTypes(m);
/*      */         
/*  740 */         if (getConvertedTypes(context, target, m, propertyName, parameterTypes, args, newArgs)) {
/*  741 */           result = m;
/*      */         }
/*      */       }
/*      */     }
/*  745 */     return result;
/*      */   }
/*      */   
/*      */   public static Constructor getConvertedConstructorAndArgs(OgnlContext context, Object target, List constructors, Object[] args, Object[] newArgs)
/*      */   {
/*  750 */     Constructor result = null;
/*  751 */     TypeConverter converter = context.getTypeConverter();
/*      */     
/*  753 */     if ((converter != null) && (constructors != null)) {
/*  754 */       int i = 0; for (int icount = constructors.size(); (result == null) && (i < icount); i++) {
/*  755 */         Constructor ctor = (Constructor)constructors.get(i);
/*  756 */         Class[] parameterTypes = getParameterTypes(ctor);
/*      */         
/*  758 */         if (getConvertedTypes(context, target, ctor, null, parameterTypes, args, newArgs)) {
/*  759 */           result = ctor;
/*      */         }
/*      */       }
/*      */     }
/*  763 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Method getAppropriateMethod(OgnlContext context, Object source, Object target, String methodName, String propertyName, List methods, Object[] args, Object[] actualArgs)
/*      */   {
/*  774 */     Method result = null;
/*  775 */     Class[] resultParameterTypes = (Class[])null;
/*      */     
/*  777 */     if (methods != null) {
/*  778 */       int i = 0; for (int icount = methods.size(); i < icount; i++) {
/*  779 */         Method m = (Method)methods.get(i);
/*  780 */         Class[] mParameterTypes = getParameterTypes(m);
/*      */         
/*  782 */         if ((areArgsCompatible(args, mParameterTypes)) && ((result == null) || (isMoreSpecific(mParameterTypes, resultParameterTypes)))) {
/*  783 */           result = m;
/*  784 */           resultParameterTypes = mParameterTypes;
/*  785 */           System.arraycopy(args, 0, actualArgs, 0, args.length);
/*  786 */           for (int j = 0; j < mParameterTypes.length; j++) {
/*  787 */             Class type = mParameterTypes[j];
/*      */             
/*  789 */             if ((type.isPrimitive()) && (actualArgs[j] == null)) {
/*  790 */               actualArgs[j] = getConvertedType(context, source, result, propertyName, null, type);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  796 */     if (result == null) {
/*  797 */       result = getConvertedMethodAndArgs(context, target, propertyName, methods, args, actualArgs);
/*      */     }
/*  799 */     return result;
/*      */   }
/*      */   
/*      */   public static Object callAppropriateMethod(OgnlContext context, Object source, Object target, String methodName, String propertyName, List methods, Object[] args) throws MethodFailedException
/*      */   {
/*  804 */     Throwable reason = null;
/*  805 */     Object[] actualArgs = objectArrayPool.create(args.length);
/*      */     try {
/*      */       try {
/*  808 */         Method method = getAppropriateMethod(context, source, target, methodName, propertyName, methods, args, actualArgs);
/*      */         
/*  810 */         if ((method == null) || (!isMethodAccessible(context, source, method, propertyName)))
/*      */         {
/*  812 */           StringBuffer buffer = new StringBuffer();
/*      */           
/*  814 */           if (args != null) {
/*  815 */             int i = 0; for (int ilast = args.length - 1; i <= ilast; i++) {
/*  816 */               Object arg = args[i];
/*      */               
/*  818 */               buffer.append(arg == null ? NULL_STRING : arg.getClass().getName());
/*  819 */               if (i < ilast) {
/*  820 */                 buffer.append(", ");
/*      */               }
/*      */             }
/*      */           }
/*  824 */           throw new NoSuchMethodException(methodName + "(" + buffer + ")");
/*      */         }
/*  826 */         return invokeMethod(target, method, actualArgs);
/*      */       }
/*      */       catch (NoSuchMethodException e) {
/*  829 */         reason = e;
/*      */       } catch (IllegalAccessException e) {
/*  831 */         reason = e;
/*      */       } catch (InvocationTargetException e) {
/*  833 */         reason = e.getTargetException();
/*      */       }
/*  835 */     } finally { objectArrayPool.recycle(actualArgs);
/*      */     }
/*  837 */     throw new MethodFailedException(source, methodName, reason);
/*      */   }
/*      */   
/*      */   public static final Object callStaticMethod(OgnlContext context, String className, String methodName, Object[] args) throws OgnlException, MethodFailedException
/*      */   {
/*      */     try
/*      */     {
/*  844 */       Class targetClass = classForName(context, className);
/*  845 */       MethodAccessor ma = getMethodAccessor(targetClass);
/*      */       
/*  847 */       return ma.callStaticMethod(context, targetClass, methodName, args);
/*      */     } catch (ClassNotFoundException ex) {
/*  849 */       throw new MethodFailedException(className, methodName, ex);
/*      */     }
/*      */   }
/*      */   
/*      */   public static final Object callMethod(OgnlContext context, Object target, String methodName, String propertyName, Object[] args)
/*      */     throws OgnlException, MethodFailedException
/*      */   {
/*      */     Object result;
/*  857 */     if (target != null) {
/*  858 */       MethodAccessor ma = getMethodAccessor(target.getClass());
/*      */       
/*  860 */       result = ma.callMethod(context, target, methodName, args);
/*      */     } else {
/*  862 */       throw new NullPointerException("target is null for method " + methodName);
/*      */     }
/*  864 */     return result;
/*      */   }
/*      */   
/*      */   public static final Object callConstructor(OgnlContext context, String className, Object[] args) throws OgnlException
/*      */   {
/*  869 */     Throwable reason = null;
/*  870 */     Object[] actualArgs = args;
/*      */     try
/*      */     {
/*      */       try {
/*  874 */         Constructor ctor = null;
/*  875 */         Class[] ctorParameterTypes = (Class[])null;
/*  876 */         Class target = classForName(context, className);
/*  877 */         List constructors = getConstructors(target);
/*      */         
/*  879 */         int i = 0; for (int icount = constructors.size(); i < icount; i++)
/*      */         {
/*  881 */           Constructor c = (Constructor)constructors.get(i);
/*  882 */           Class[] cParameterTypes = getParameterTypes(c);
/*      */           
/*  884 */           if ((areArgsCompatible(args, cParameterTypes)) && ((ctor == null) || (isMoreSpecific(cParameterTypes, ctorParameterTypes)))) {
/*  885 */             ctor = c;
/*  886 */             ctorParameterTypes = cParameterTypes;
/*      */           }
/*      */         }
/*  889 */         if (ctor == null)
/*      */         {
/*  891 */           actualArgs = objectArrayPool.create(args.length);
/*  892 */           if ((ctor = getConvertedConstructorAndArgs(context, target, constructors, args, actualArgs)) == null) {
/*  893 */             throw new NoSuchMethodException();
/*      */           }
/*      */         }
/*  896 */         if (!context.getMemberAccess().isAccessible(context, target, ctor, null)) {
/*  897 */           throw new IllegalAccessException("access denied to " + target.getName() + "()");
/*      */         }
/*  899 */         return ctor.newInstance(actualArgs);
/*      */       }
/*      */       catch (ClassNotFoundException e) {
/*  902 */         reason = e;
/*      */       } catch (NoSuchMethodException e) {
/*  904 */         reason = e;
/*      */       } catch (IllegalAccessException e) {
/*  906 */         reason = e;
/*      */       } catch (InvocationTargetException e) {
/*  908 */         reason = e.getTargetException();
/*      */       } catch (InstantiationException e) {
/*  910 */         reason = e;
/*      */       }
/*  912 */     } finally { if (actualArgs != args) {
/*  913 */         objectArrayPool.recycle(actualArgs);
/*      */       }
/*      */     }
/*      */     
/*  917 */     throw new MethodFailedException(className, "new", reason);
/*      */   }
/*      */   
/*      */   public static final Object getMethodValue(OgnlContext context, Object target, String propertyName) throws OgnlException, IllegalAccessException, NoSuchMethodException, IntrospectionException
/*      */   {
/*  922 */     return getMethodValue(context, target, propertyName, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final Object getMethodValue(OgnlContext context, Object target, String propertyName, boolean checkAccessAndExistence)
/*      */     throws OgnlException, IllegalAccessException, NoSuchMethodException, IntrospectionException
/*      */   {
/*  932 */     Object result = null;
/*  933 */     Method m = getGetMethod(context, target == null ? null : target.getClass(), propertyName);
/*      */     
/*  935 */     if ((checkAccessAndExistence) && (
/*  936 */       (m == null) || (!context.getMemberAccess().isAccessible(context, target, m, propertyName)))) {
/*  937 */       result = NotFound;
/*      */     }
/*      */     
/*  940 */     if (result == null) {
/*  941 */       if (m != null)
/*      */       {
/*      */         try
/*      */         {
/*  945 */           result = invokeMethod(target, m, NoArguments);
/*      */         }
/*      */         catch (InvocationTargetException ex)
/*      */         {
/*  949 */           throw new OgnlException(propertyName, ex.getTargetException());
/*      */         }
/*      */       } else {
/*  952 */         throw new NoSuchMethodException(propertyName);
/*      */       }
/*      */     }
/*  955 */     return result;
/*      */   }
/*      */   
/*      */   public static final boolean setMethodValue(OgnlContext context, Object target, String propertyName, Object value) throws OgnlException, IllegalAccessException, NoSuchMethodException, MethodFailedException, IntrospectionException
/*      */   {
/*  960 */     return setMethodValue(context, target, propertyName, value, false);
/*      */   }
/*      */   
/*      */   public static final boolean setMethodValue(OgnlContext context, Object target, String propertyName, Object value, boolean checkAccessAndExistence) throws OgnlException, IllegalAccessException, NoSuchMethodException, MethodFailedException, IntrospectionException
/*      */   {
/*  965 */     boolean result = true;
/*  966 */     Method m = getSetMethod(context, target == null ? null : target.getClass(), propertyName);
/*      */     
/*  968 */     if ((checkAccessAndExistence) && (
/*  969 */       (m == null) || (!context.getMemberAccess().isAccessible(context, target, m, propertyName)))) {
/*  970 */       result = false;
/*      */     }
/*      */     
/*  973 */     if (result) {
/*  974 */       if (m != null) {
/*  975 */         Object[] args = objectArrayPool.create(value);
/*      */         try
/*      */         {
/*  978 */           callAppropriateMethod(context, target, target, m.getName(), propertyName, Collections.nCopies(1, m), args);
/*      */         } finally {
/*  980 */           objectArrayPool.recycle(args);
/*      */         }
/*      */       } else {
/*  983 */         result = false;
/*      */       }
/*      */     }
/*  986 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   public static final List getConstructors(Class targetClass)
/*      */   {
/*      */     List result;
/*  993 */     synchronized (constructorCache) {
/*  994 */       if ((result = (List)constructorCache.get(targetClass)) == null) {
/*  995 */         constructorCache.put(targetClass, result = Arrays.asList(targetClass.getConstructors()));
/*      */       }
/*      */     }
/*  998 */     return result;
/*      */   }
/*      */   
/*      */   public static final Map getMethods(Class targetClass, boolean staticMethods)
/*      */   {
/* 1003 */     ClassCache cache = staticMethods ? staticMethodCache : instanceMethodCache;
/*      */     
/*      */     Map result;
/* 1006 */     synchronized (cache) {
/* 1007 */       if ((result = (Map)cache.get(targetClass)) == null)
/*      */       {
/* 1009 */         cache.put(targetClass, result = new HashMap(23));
/* 1010 */         for (Class c = targetClass; c != null; c = c.getSuperclass()) {
/* 1011 */           Method[] ma = c.getDeclaredMethods();
/*      */           
/* 1013 */           int i = 0; for (int icount = ma.length; i < icount; i++)
/*      */           {
/* 1015 */             if (Modifier.isStatic(ma[i].getModifiers()) == staticMethods) {
/* 1016 */               List ml = (List)result.get(ma[i].getName());
/*      */               
/* 1018 */               if (ml == null)
/* 1019 */                 result.put(ma[i].getName(), ml = new ArrayList());
/* 1020 */               ml.add(ma[i]);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1026 */     return result;
/*      */   }
/*      */   
/*      */   public static final List getMethods(Class targetClass, String name, boolean staticMethods)
/*      */   {
/* 1031 */     return (List)getMethods(targetClass, staticMethods).get(name);
/*      */   }
/*      */   
/*      */ 
/*      */   public static final Map getFields(Class targetClass)
/*      */   {
/*      */     Map result;
/* 1038 */     synchronized (fieldCache) {
/* 1039 */       if ((result = (Map)fieldCache.get(targetClass)) == null)
/*      */       {
/*      */ 
/*      */ 
/* 1043 */         result = new HashMap(23);
/* 1044 */         Field[] fa = targetClass.getDeclaredFields();
/* 1045 */         for (int i = 0; i < fa.length; i++) {
/* 1046 */           result.put(fa[i].getName(), fa[i]);
/*      */         }
/* 1048 */         fieldCache.put(targetClass, result);
/*      */       }
/*      */     }
/* 1051 */     return result;
/*      */   }
/*      */   
/*      */   public static final Field getField(Class inClass, String name)
/*      */   {
/* 1056 */     Field result = null;
/*      */     
/* 1058 */     synchronized (fieldCache)
/*      */     {
/* 1060 */       Object o = getFields(inClass).get(name);
/*      */       
/* 1062 */       if (o == null)
/*      */       {
/* 1064 */         superclasses.clear();
/* 1065 */         for (Class sc = inClass; (sc != null) && (result == null); sc = sc.getSuperclass())
/*      */         {
/* 1067 */           if ((o = getFields(sc).get(name)) == NotFound)
/*      */             break;
/* 1069 */           superclasses.add(sc);
/* 1070 */           if ((result = (Field)o) != null) {
/*      */             break;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1077 */         int i = 0; for (int icount = superclasses.size(); i < icount; i++)
/*      */         {
/* 1079 */           getFields((Class)superclasses.get(i)).put(name, result == null ? NotFound : result);
/*      */         }
/*      */         
/*      */ 
/*      */       }
/* 1084 */       else if ((o instanceof Field))
/*      */       {
/* 1086 */         result = (Field)o;
/*      */ 
/*      */ 
/*      */       }
/* 1090 */       else if (result == NotFound) {
/* 1091 */         result = null;
/*      */       }
/*      */     }
/*      */     
/* 1095 */     return result;
/*      */   }
/*      */   
/*      */   public static final Object getFieldValue(OgnlContext context, Object target, String propertyName) throws NoSuchFieldException
/*      */   {
/* 1100 */     return getFieldValue(context, target, propertyName, false);
/*      */   }
/*      */   
/*      */   public static final Object getFieldValue(OgnlContext context, Object target, String propertyName, boolean checkAccessAndExistence) throws NoSuchFieldException
/*      */   {
/* 1105 */     Object result = null;
/* 1106 */     Field f = getField(target == null ? null : target.getClass(), propertyName);
/*      */     
/* 1108 */     if ((checkAccessAndExistence) && (
/* 1109 */       (f == null) || (!context.getMemberAccess().isAccessible(context, target, f, propertyName)))) {
/* 1110 */       result = NotFound;
/*      */     }
/*      */     
/* 1113 */     if (result == null) {
/* 1114 */       if (f == null) {
/* 1115 */         throw new NoSuchFieldException(propertyName);
/*      */       }
/*      */       try
/*      */       {
/* 1119 */         Object state = null;
/*      */         
/* 1121 */         if ((f != null) && (!Modifier.isStatic(f.getModifiers())))
/*      */         {
/* 1123 */           state = context.getMemberAccess().setup(context, target, f, propertyName);
/* 1124 */           result = f.get(target);
/* 1125 */           context.getMemberAccess().restore(context, target, f, propertyName, state);
/*      */         }
/*      */         else {
/* 1128 */           throw new NoSuchFieldException(propertyName);
/*      */         }
/*      */       }
/*      */       catch (IllegalAccessException ex) {
/* 1132 */         throw new NoSuchFieldException(propertyName);
/*      */       }
/*      */     }
/*      */     
/* 1136 */     return result;
/*      */   }
/*      */   
/*      */   public static final boolean setFieldValue(OgnlContext context, Object target, String propertyName, Object value) throws OgnlException
/*      */   {
/* 1141 */     boolean result = false;
/*      */     
/*      */     try
/*      */     {
/* 1145 */       Field f = getField(target == null ? null : target.getClass(), propertyName);
/*      */       
/*      */ 
/* 1148 */       if ((f != null) && (!Modifier.isStatic(f.getModifiers())))
/*      */       {
/* 1150 */         Object state = context.getMemberAccess().setup(context, target, f, propertyName);
/*      */         try
/*      */         {
/* 1153 */           if ((isTypeCompatible(value, f.getType())) || ((value = getConvertedType(context, target, f, propertyName, value, f.getType())) != null)) {
/* 1154 */             f.set(target, value);
/* 1155 */             result = true;
/*      */           }
/*      */         }
/*      */         finally
/*      */         {
/* 1160 */           context.getMemberAccess().restore(context, target, f, propertyName, state);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (IllegalAccessException ex)
/*      */     {
/* 1166 */       throw new NoSuchPropertyException(target, propertyName, ex);
/*      */     }
/* 1168 */     return result;
/*      */   }
/*      */   
/*      */   public static final boolean isFieldAccessible(OgnlContext context, Object target, Class inClass, String propertyName)
/*      */   {
/* 1173 */     return isFieldAccessible(context, target, getField(inClass, propertyName), propertyName);
/*      */   }
/*      */   
/*      */   public static final boolean isFieldAccessible(OgnlContext context, Object target, Field field, String propertyName)
/*      */   {
/* 1178 */     return context.getMemberAccess().isAccessible(context, target, field, propertyName);
/*      */   }
/*      */   
/*      */   public static final boolean hasField(OgnlContext context, Object target, Class inClass, String propertyName)
/*      */   {
/* 1183 */     Field f = getField(inClass, propertyName);
/*      */     
/* 1185 */     return (f != null) && (isFieldAccessible(context, target, f, propertyName));
/*      */   }
/*      */   
/*      */   public static final Object getStaticField(OgnlContext context, String className, String fieldName) throws OgnlException
/*      */   {
/* 1190 */     Exception reason = null;
/*      */     try
/*      */     {
/* 1193 */       Class c = classForName(context, className);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1199 */       if (fieldName.equals("class"))
/*      */       {
/* 1201 */         return c;
/*      */       }
/*      */       
/*      */ 
/* 1205 */       Field f = c.getField(fieldName);
/* 1206 */       if (!Modifier.isStatic(f.getModifiers()))
/* 1207 */         throw new OgnlException("Field " + fieldName + " of class " + className + " is not static");
/* 1208 */       return f.get(null);
/*      */     }
/*      */     catch (ClassNotFoundException e)
/*      */     {
/* 1212 */       reason = e;
/*      */     } catch (NoSuchFieldException e) {
/* 1214 */       reason = e;
/*      */     } catch (SecurityException e) {
/* 1216 */       reason = e;
/*      */     } catch (IllegalAccessException e) {
/* 1218 */       reason = e;
/*      */     }
/* 1220 */     throw new OgnlException("Could not get static field " + fieldName + " from class " + className, reason);
/*      */   }
/*      */   
/*      */   public static final List getDeclaredMethods(Class targetClass, String propertyName, boolean findSets)
/*      */   {
/* 1225 */     List result = null;
/* 1226 */     ClassCache cache = declaredMethods[1];
/*      */     
/* 1228 */     synchronized (cache) {
/* 1229 */       Map propertyCache = (Map)cache.get(targetClass);
/*      */       
/* 1231 */       if ((propertyCache == null) || ((result = (List)propertyCache.get(propertyName)) == null)) {
/* 1232 */         String baseName = Character.toUpperCase(propertyName.charAt(0)) + propertyName.substring(1);
/* 1233 */         int len = baseName.length();
/*      */         
/* 1235 */         for (Class c = targetClass; c != null; c = c.getSuperclass()) {
/* 1236 */           Method[] methods = c.getDeclaredMethods();
/*      */           
/* 1238 */           for (int i = 0; i < methods.length; i++) {
/* 1239 */             String ms = methods[i].getName();
/*      */             
/* 1241 */             if (ms.endsWith(baseName)) {
/* 1242 */               boolean isSet = false;
/* 1243 */               boolean isGet = false;
/* 1244 */               boolean isIs = false;
/*      */               
/* 1246 */               if (((isSet = ms.startsWith("set"))) || ((isGet = ms.startsWith("get"))) || ((isIs = ms.startsWith("is")))) {
/* 1247 */                 int prefixLength = isIs ? 2 : 3;
/*      */                 
/* 1249 */                 if ((isSet == findSets) && 
/* 1250 */                   (baseName.length() == ms.length() - prefixLength)) {
/* 1251 */                   if (result == null) {
/* 1252 */                     result = new ArrayList();
/*      */                   }
/* 1254 */                   result.add(methods[i]);
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 1261 */         if (propertyCache == null) {
/* 1262 */           cache.put(targetClass, propertyCache = new HashMap(101));
/*      */         }
/* 1264 */         propertyCache.put(propertyName, result == null ? NotFoundList : result);
/*      */       }
/* 1266 */       return result == NotFoundList ? null : result;
/*      */     }
/*      */   }
/*      */   
/*      */   public static final Method getGetMethod(OgnlContext context, Class targetClass, String propertyName) throws IntrospectionException, OgnlException
/*      */   {
/* 1272 */     Method result = null;
/* 1273 */     PropertyDescriptor pd = getPropertyDescriptor(targetClass, propertyName);
/*      */     
/* 1275 */     if (pd == null) {
/* 1276 */       List methods = getDeclaredMethods(targetClass, propertyName, false);
/*      */       
/* 1278 */       if (methods != null) {
/* 1279 */         int i = 0; for (int icount = methods.size(); i < icount; i++) {
/* 1280 */           Method m = (Method)methods.get(i);
/* 1281 */           Class[] mParameterTypes = getParameterTypes(m);
/*      */           
/* 1283 */           if (mParameterTypes.length == 0) {
/* 1284 */             result = m;
/* 1285 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     } else {
/* 1290 */       result = pd.getReadMethod();
/*      */     }
/* 1292 */     return result;
/*      */   }
/*      */   
/*      */   public static final boolean isMethodAccessible(OgnlContext context, Object target, Method method, String propertyName)
/*      */   {
/* 1297 */     return method == null ? false : context.getMemberAccess().isAccessible(context, target, method, propertyName);
/*      */   }
/*      */   
/*      */   public static final boolean hasGetMethod(OgnlContext context, Object target, Class targetClass, String propertyName) throws IntrospectionException, OgnlException
/*      */   {
/* 1302 */     return isMethodAccessible(context, target, getGetMethod(context, targetClass, propertyName), propertyName);
/*      */   }
/*      */   
/*      */   public static final Method getSetMethod(OgnlContext context, Class targetClass, String propertyName) throws IntrospectionException, OgnlException
/*      */   {
/* 1307 */     Method result = null;
/* 1308 */     PropertyDescriptor pd = getPropertyDescriptor(targetClass, propertyName);
/*      */     
/* 1310 */     if (pd == null) {
/* 1311 */       List methods = getDeclaredMethods(targetClass, propertyName, true);
/*      */       
/* 1313 */       if (methods != null) {
/* 1314 */         int i = 0; for (int icount = methods.size(); i < icount; i++) {
/* 1315 */           Method m = (Method)methods.get(i);
/* 1316 */           Class[] mParameterTypes = getParameterTypes(m);
/*      */           
/* 1318 */           if (mParameterTypes.length == 1) {
/* 1319 */             result = m;
/* 1320 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     } else {
/* 1325 */       result = pd.getWriteMethod();
/*      */     }
/* 1327 */     return result;
/*      */   }
/*      */   
/*      */   public static final boolean hasSetMethod(OgnlContext context, Object target, Class targetClass, String propertyName) throws IntrospectionException, OgnlException
/*      */   {
/* 1332 */     return isMethodAccessible(context, target, getSetMethod(context, targetClass, propertyName), propertyName);
/*      */   }
/*      */   
/*      */   public static final boolean hasGetProperty(OgnlContext context, Object target, Object oname) throws IntrospectionException, OgnlException
/*      */   {
/* 1337 */     Class targetClass = target == null ? null : target.getClass();
/* 1338 */     String name = oname.toString();
/*      */     
/* 1340 */     return (hasGetMethod(context, target, targetClass, name)) || (hasField(context, target, targetClass, name));
/*      */   }
/*      */   
/*      */   public static final boolean hasSetProperty(OgnlContext context, Object target, Object oname) throws IntrospectionException, OgnlException
/*      */   {
/* 1345 */     Class targetClass = target == null ? null : target.getClass();
/* 1346 */     String name = oname.toString();
/*      */     
/* 1348 */     return (hasSetMethod(context, target, targetClass, name)) || (hasField(context, target, targetClass, name));
/*      */   }
/*      */   
/*      */   private static final boolean indexMethodCheck(List methods)
/*      */   {
/* 1353 */     boolean result = false;
/*      */     
/* 1355 */     if (methods.size() > 0) {
/* 1356 */       Method fm = (Method)methods.get(0);
/* 1357 */       Class[] fmpt = getParameterTypes(fm);
/* 1358 */       int fmpc = fmpt.length;
/* 1359 */       Class lastMethodClass = fm.getDeclaringClass();
/*      */       
/* 1361 */       result = true;
/* 1362 */       for (int i = 1; (result) && (i < methods.size()); i++) {
/* 1363 */         Method m = (Method)methods.get(i);
/* 1364 */         Class c = m.getDeclaringClass();
/*      */         
/*      */ 
/* 1367 */         if (lastMethodClass == c) {
/* 1368 */           result = false;
/*      */         } else {
/* 1370 */           Class[] mpt = getParameterTypes(fm);
/* 1371 */           int mpc = fmpt.length;
/*      */           
/* 1373 */           if (fmpc != mpc) {
/* 1374 */             result = false;
/*      */           }
/* 1376 */           for (int j = 0; j < fmpc; j++) {
/* 1377 */             if (fmpt[j] != mpt[j]) {
/* 1378 */               result = false;
/* 1379 */               break;
/*      */             }
/*      */           }
/*      */         }
/* 1383 */         lastMethodClass = c;
/*      */       }
/*      */     }
/* 1386 */     return result;
/*      */   }
/*      */   
/*      */   private static final void findObjectIndexedPropertyDescriptors(Class targetClass, Map intoMap) throws OgnlException
/*      */   {
/* 1391 */     Map allMethods = getMethods(targetClass, false);
/* 1392 */     Map pairs = new HashMap(101);
/*      */     
/* 1394 */     for (Iterator it = allMethods.keySet().iterator(); it.hasNext();) {
/* 1395 */       String methodName = (String)it.next();
/* 1396 */       List methods = (List)allMethods.get(methodName);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1403 */       if (indexMethodCheck(methods)) {
/* 1404 */         boolean isGet = false;
/* 1405 */         boolean isSet = false;
/* 1406 */         Method m = (Method)methods.get(0);
/*      */         
/* 1408 */         if ((((isSet = methodName.startsWith("set"))) || ((isGet = methodName.startsWith("get")))) && (methodName.length() > 3)) {
/* 1409 */           String propertyName = Introspector.decapitalize(methodName.substring(3));
/* 1410 */           Class[] parameterTypes = getParameterTypes(m);
/* 1411 */           int parameterCount = parameterTypes.length;
/*      */           
/* 1413 */           if ((isGet) && (parameterCount == 1) && (m.getReturnType() != Void.TYPE)) {
/* 1414 */             List pair = (List)pairs.get(propertyName);
/*      */             
/* 1416 */             if (pair == null) {
/* 1417 */               pairs.put(propertyName, pair = new ArrayList());
/*      */             }
/* 1419 */             pair.add(m);
/*      */           }
/* 1421 */           if ((isSet) && (parameterCount == 2) && (m.getReturnType() == Void.TYPE)) {
/* 1422 */             List pair = (List)pairs.get(propertyName);
/*      */             
/* 1424 */             if (pair == null) {
/* 1425 */               pairs.put(propertyName, pair = new ArrayList());
/*      */             }
/* 1427 */             pair.add(m);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1432 */     for (Iterator it = pairs.keySet().iterator(); it.hasNext();) {
/* 1433 */       String propertyName = (String)it.next();
/* 1434 */       List methods = (List)pairs.get(propertyName);
/*      */       
/* 1436 */       if (methods.size() == 2) {
/* 1437 */         Method method1 = (Method)methods.get(0);
/* 1438 */         Method method2 = (Method)methods.get(1);
/* 1439 */         Method setMethod = method1.getParameterTypes().length == 2 ? method1 : method2;
/* 1440 */         Method getMethod = setMethod == method1 ? method2 : method1;
/* 1441 */         Class keyType = getMethod.getParameterTypes()[0];
/* 1442 */         Class propertyType = getMethod.getReturnType();
/*      */         
/* 1444 */         if ((keyType == setMethod.getParameterTypes()[0]) && 
/* 1445 */           (propertyType == setMethod.getParameterTypes()[1]))
/*      */         {
/*      */           try
/*      */           {
/* 1449 */             propertyDescriptor = new ObjectIndexedPropertyDescriptor(propertyName, propertyType, getMethod, setMethod);
/*      */           } catch (Exception ex) { ObjectIndexedPropertyDescriptor propertyDescriptor;
/* 1451 */             throw new OgnlException("creating object indexed property descriptor for '" + propertyName + "' in " + targetClass, ex); }
/*      */           ObjectIndexedPropertyDescriptor propertyDescriptor;
/* 1453 */           intoMap.put(propertyName, propertyDescriptor);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final Map getPropertyDescriptors(Class targetClass)
/*      */     throws IntrospectionException, OgnlException
/*      */   {
/*      */     Map result;
/*      */     
/*      */ 
/* 1468 */     synchronized (propertyDescriptorCache) {
/* 1469 */       if ((result = (Map)propertyDescriptorCache.get(targetClass)) == null) {
/* 1470 */         PropertyDescriptor[] pda = Introspector.getBeanInfo(targetClass).getPropertyDescriptors();
/*      */         
/* 1472 */         result = new HashMap(101);
/* 1473 */         int i = 0; for (int icount = pda.length; i < icount; i++) {
/* 1474 */           result.put(pda[i].getName(), pda[i]);
/*      */         }
/* 1476 */         findObjectIndexedPropertyDescriptors(targetClass, result);
/* 1477 */         propertyDescriptorCache.put(targetClass, result);
/*      */       }
/*      */     }
/* 1480 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final PropertyDescriptor getPropertyDescriptor(Class targetClass, String propertyName)
/*      */     throws IntrospectionException, OgnlException
/*      */   {
/* 1489 */     return targetClass == null ? null : (PropertyDescriptor)getPropertyDescriptors(targetClass).get(propertyName);
/*      */   }
/*      */   
/*      */   public static final PropertyDescriptor[] getPropertyDescriptorsArray(Class targetClass) throws IntrospectionException
/*      */   {
/* 1494 */     PropertyDescriptor[] result = (PropertyDescriptor[])null;
/*      */     
/* 1496 */     if (targetClass != null) {
/* 1497 */       synchronized (propertyDescriptorCache) {
/* 1498 */         if ((result = (PropertyDescriptor[])propertyDescriptorCache.get(targetClass)) == null) {
/* 1499 */           propertyDescriptorCache.put(targetClass, result = Introspector.getBeanInfo(targetClass).getPropertyDescriptors());
/*      */         }
/*      */       }
/*      */     }
/* 1503 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final PropertyDescriptor getPropertyDescriptorFromArray(Class targetClass, String name)
/*      */     throws IntrospectionException
/*      */   {
/* 1515 */     PropertyDescriptor result = null;
/* 1516 */     PropertyDescriptor[] pda = getPropertyDescriptorsArray(targetClass);
/*      */     
/* 1518 */     int i = 0; for (int icount = pda.length; (result == null) && (i < icount); i++) {
/* 1519 */       if (pda[i].getName().compareTo(name) == 0) {
/* 1520 */         result = pda[i];
/*      */       }
/*      */     }
/* 1523 */     return result;
/*      */   }
/*      */   
/*      */   public static final void setMethodAccessor(Class cls, MethodAccessor accessor)
/*      */   {
/* 1528 */     synchronized (methodAccessors) {
/* 1529 */       methodAccessors.put(cls, accessor);
/*      */     }
/*      */   }
/*      */   
/*      */   public static final MethodAccessor getMethodAccessor(Class cls) throws OgnlException
/*      */   {
/* 1535 */     MethodAccessor answer = (MethodAccessor)getHandler(cls, methodAccessors);
/* 1536 */     if (answer != null)
/* 1537 */       return answer;
/* 1538 */     throw new OgnlException("No method accessor for " + cls);
/*      */   }
/*      */   
/*      */   public static final void setPropertyAccessor(Class cls, PropertyAccessor accessor)
/*      */   {
/* 1543 */     synchronized (propertyAccessors) {
/* 1544 */       propertyAccessors.put(cls, accessor);
/*      */     }
/*      */   }
/*      */   
/*      */   public static final PropertyAccessor getPropertyAccessor(Class cls) throws OgnlException
/*      */   {
/* 1550 */     PropertyAccessor answer = (PropertyAccessor)getHandler(cls, propertyAccessors);
/* 1551 */     if (answer != null) {
/* 1552 */       return answer;
/*      */     }
/* 1554 */     throw new OgnlException("No property accessor for class " + cls);
/*      */   }
/*      */   
/*      */   public static final ElementsAccessor getElementsAccessor(Class cls) throws OgnlException
/*      */   {
/* 1559 */     ElementsAccessor answer = (ElementsAccessor)getHandler(cls, elementsAccessors);
/* 1560 */     if (answer != null)
/* 1561 */       return answer;
/* 1562 */     throw new OgnlException("No elements accessor for class " + cls);
/*      */   }
/*      */   
/*      */   public static final void setElementsAccessor(Class cls, ElementsAccessor accessor)
/*      */   {
/* 1567 */     synchronized (elementsAccessors) {
/* 1568 */       elementsAccessors.put(cls, accessor);
/*      */     }
/*      */   }
/*      */   
/*      */   public static final NullHandler getNullHandler(Class cls) throws OgnlException
/*      */   {
/* 1574 */     NullHandler answer = (NullHandler)getHandler(cls, nullHandlers);
/* 1575 */     if (answer != null)
/* 1576 */       return answer;
/* 1577 */     throw new OgnlException("No null handler for class " + cls);
/*      */   }
/*      */   
/*      */   public static final void setNullHandler(Class cls, NullHandler handler)
/*      */   {
/* 1582 */     synchronized (nullHandlers) {
/* 1583 */       nullHandlers.put(cls, handler);
/*      */     }
/*      */   }
/*      */   
/*      */   private static final Object getHandler(Class forClass, ClassCache handlers)
/*      */   {
/* 1589 */     Object answer = null;
/*      */     
/* 1591 */     synchronized (handlers) {
/* 1592 */       if ((answer = handlers.get(forClass)) == null)
/*      */       {
/*      */         Class keyFound;
/*      */         Class keyFound;
/* 1596 */         if (forClass.isArray())
/*      */         {
/* 1598 */           answer = handlers.get(Object[].class);
/* 1599 */           keyFound = null;
/*      */         }
/*      */         else
/*      */         {
/* 1603 */           keyFound = forClass;
/*      */           
/* 1605 */           for (Class c = forClass; c != null; c = c.getSuperclass())
/*      */           {
/* 1607 */             answer = handlers.get(c);
/* 1608 */             if (answer == null)
/*      */             {
/* 1610 */               Class[] interfaces = c.getInterfaces();
/* 1611 */               int index = 0; for (int count = interfaces.length; index < count; index++)
/*      */               {
/* 1613 */                 Class iface = interfaces[index];
/*      */                 
/* 1615 */                 answer = handlers.get(iface);
/* 1616 */                 if (answer == null)
/*      */                 {
/*      */ 
/* 1619 */                   answer = getHandler(iface, handlers);
/*      */                 }
/* 1621 */                 if (answer != null)
/*      */                 {
/* 1623 */                   keyFound = iface;
/* 1624 */                   break;
/*      */                 }
/*      */               }
/*      */             }
/*      */             else
/*      */             {
/* 1630 */               keyFound = c;
/* 1631 */               break;
/*      */             }
/*      */           }
/*      */         }
/* 1635 */         if (answer != null)
/*      */         {
/* 1637 */           if (keyFound != forClass)
/*      */           {
/* 1639 */             handlers.put(forClass, answer);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1644 */     return answer;
/*      */   }
/*      */   
/*      */ 
/*      */   public static final Object getProperty(OgnlContext context, Object source, Object name)
/*      */     throws OgnlException
/*      */   {
/* 1651 */     if (source == null)
/* 1652 */       throw new OgnlException("source is null for getProperty(null, \"" + name + "\")");
/*      */     PropertyAccessor accessor;
/* 1654 */     if ((accessor = getPropertyAccessor(getTargetClass(source))) == null) {
/* 1655 */       throw new OgnlException("No property accessor for " + getTargetClass(source).getName());
/*      */     }
/* 1657 */     return accessor.getProperty(context, source, name);
/*      */   }
/*      */   
/*      */ 
/*      */   public static final void setProperty(OgnlContext context, Object target, Object name, Object value)
/*      */     throws OgnlException
/*      */   {
/* 1664 */     if (target == null)
/* 1665 */       throw new OgnlException("target is null for setProperty(null, \"" + name + "\", " + value + ")");
/*      */     PropertyAccessor accessor;
/* 1667 */     if ((accessor = getPropertyAccessor(getTargetClass(target))) == null) {
/* 1668 */       throw new OgnlException("No property accessor for " + getTargetClass(target).getName());
/*      */     }
/* 1670 */     accessor.setProperty(context, target, name, value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int getIndexedPropertyType(OgnlContext context, Class sourceClass, String name)
/*      */     throws OgnlException
/*      */   {
/* 1682 */     int result = INDEXED_PROPERTY_NONE;
/*      */     try
/*      */     {
/* 1685 */       PropertyDescriptor pd = getPropertyDescriptor(sourceClass, name);
/*      */       
/* 1687 */       if (pd != null) {
/* 1688 */         if ((pd instanceof IndexedPropertyDescriptor)) {
/* 1689 */           result = INDEXED_PROPERTY_INT;
/*      */         }
/* 1691 */         else if ((pd instanceof ObjectIndexedPropertyDescriptor)) {
/* 1692 */           result = INDEXED_PROPERTY_OBJECT;
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception ex) {
/* 1697 */       throw new OgnlException("problem determining if '" + name + "' is an indexed property", ex);
/*      */     }
/* 1699 */     return result;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public static final Object getIndexedProperty(OgnlContext context, Object source, String name, Object index)
/*      */     throws OgnlException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aconst_null
/*      */     //   1: astore 4
/*      */     //   3: getstatic 198	org/apache/ibatis/ognl/OgnlRuntime:objectArrayPool	Lorg/apache/ibatis/ognl/ObjectArrayPool;
/*      */     //   6: aload_3
/*      */     //   7: invokevirtual 963	org/apache/ibatis/ognl/ObjectArrayPool:create	(Ljava/lang/Object;)[Ljava/lang/Object;
/*      */     //   10: astore 5
/*      */     //   12: aload_1
/*      */     //   13: ifnonnull +7 -> 20
/*      */     //   16: aconst_null
/*      */     //   17: goto +7 -> 24
/*      */     //   20: aload_1
/*      */     //   21: invokevirtual 446	java/lang/Object:getClass	()Ljava/lang/Class;
/*      */     //   24: aload_2
/*      */     //   25: invokestatic 1112	org/apache/ibatis/ognl/OgnlRuntime:getPropertyDescriptor	(Ljava/lang/Class;Ljava/lang/String;)Ljava/beans/PropertyDescriptor;
/*      */     //   28: astore 6
/*      */     //   30: aload 6
/*      */     //   32: instanceof 1299
/*      */     //   35: ifeq +16 -> 51
/*      */     //   38: aload 6
/*      */     //   40: checkcast 1299	java/beans/IndexedPropertyDescriptor
/*      */     //   43: invokevirtual 1309	java/beans/IndexedPropertyDescriptor:getIndexedReadMethod	()Ljava/lang/reflect/Method;
/*      */     //   46: astore 7
/*      */     //   48: goto +55 -> 103
/*      */     //   51: aload 6
/*      */     //   53: instanceof 1185
/*      */     //   56: ifeq +16 -> 72
/*      */     //   59: aload 6
/*      */     //   61: checkcast 1185	org/apache/ibatis/ognl/ObjectIndexedPropertyDescriptor
/*      */     //   64: invokevirtual 1310	org/apache/ibatis/ognl/ObjectIndexedPropertyDescriptor:getIndexedReadMethod	()Ljava/lang/reflect/Method;
/*      */     //   67: astore 7
/*      */     //   69: goto +34 -> 103
/*      */     //   72: new 776	org/apache/ibatis/ognl/OgnlException
/*      */     //   75: dup
/*      */     //   76: new 131	java/lang/StringBuffer
/*      */     //   79: dup
/*      */     //   80: ldc_w 1312
/*      */     //   83: invokespecial 588	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
/*      */     //   86: aload_2
/*      */     //   87: invokevirtual 503	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   90: ldc_w 1314
/*      */     //   93: invokevirtual 503	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   96: invokevirtual 140	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   99: invokespecial 1074	org/apache/ibatis/ognl/OgnlException:<init>	(Ljava/lang/String;)V
/*      */     //   102: athrow
/*      */     //   103: aload_0
/*      */     //   104: aload_1
/*      */     //   105: aload 7
/*      */     //   107: invokevirtual 581	java/lang/reflect/Method:getName	()Ljava/lang/String;
/*      */     //   110: aload_2
/*      */     //   111: aload 5
/*      */     //   113: invokestatic 1316	org/apache/ibatis/ognl/OgnlRuntime:callMethod	(Lorg/apache/ibatis/ognl/OgnlContext;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   116: astore 8
/*      */     //   118: jsr +54 -> 172
/*      */     //   121: aload 8
/*      */     //   123: areturn
/*      */     //   124: astore 6
/*      */     //   126: aload 6
/*      */     //   128: athrow
/*      */     //   129: astore 6
/*      */     //   131: new 776	org/apache/ibatis/ognl/OgnlException
/*      */     //   134: dup
/*      */     //   135: new 131	java/lang/StringBuffer
/*      */     //   138: dup
/*      */     //   139: ldc_w 1318
/*      */     //   142: invokespecial 588	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
/*      */     //   145: aload_2
/*      */     //   146: invokevirtual 503	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   149: ldc_w 1320
/*      */     //   152: invokevirtual 503	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   155: invokevirtual 140	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   158: aload 6
/*      */     //   160: invokespecial 783	org/apache/ibatis/ognl/OgnlException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*      */     //   163: athrow
/*      */     //   164: astore 9
/*      */     //   166: jsr +6 -> 172
/*      */     //   169: aload 9
/*      */     //   171: athrow
/*      */     //   172: astore 10
/*      */     //   174: getstatic 198	org/apache/ibatis/ognl/OgnlRuntime:objectArrayPool	Lorg/apache/ibatis/ognl/ObjectArrayPool;
/*      */     //   177: aload 5
/*      */     //   179: invokevirtual 876	org/apache/ibatis/ognl/ObjectArrayPool:recycle	([Ljava/lang/Object;)V
/*      */     //   182: ret 10
/*      */     // Line number table:
/*      */     //   Java source line #1704	-> byte code offset #0
/*      */     //   Java source line #1705	-> byte code offset #3
/*      */     //   Java source line #1708	-> byte code offset #12
/*      */     //   Java source line #1711	-> byte code offset #30
/*      */     //   Java source line #1712	-> byte code offset #38
/*      */     //   Java source line #1714	-> byte code offset #51
/*      */     //   Java source line #1715	-> byte code offset #59
/*      */     //   Java source line #1717	-> byte code offset #72
/*      */     //   Java source line #1720	-> byte code offset #103
/*      */     //   Java source line #1721	-> byte code offset #124
/*      */     //   Java source line #1722	-> byte code offset #126
/*      */     //   Java source line #1723	-> byte code offset #129
/*      */     //   Java source line #1724	-> byte code offset #131
/*      */     //   Java source line #1725	-> byte code offset #164
/*      */     //   Java source line #1727	-> byte code offset #169
/*      */     //   Java source line #1725	-> byte code offset #172
/*      */     //   Java source line #1726	-> byte code offset #174
/*      */     //   Java source line #1727	-> byte code offset #182
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	184	0	context	OgnlContext
/*      */     //   0	184	1	source	Object
/*      */     //   0	184	2	name	String
/*      */     //   0	184	3	index	Object
/*      */     //   1	3	4	reason	Throwable
/*      */     //   10	168	5	args	Object[]
/*      */     //   28	32	6	pd	PropertyDescriptor
/*      */     //   124	3	6	ex	OgnlException
/*      */     //   129	30	6	ex	Exception
/*      */     //   46	3	7	m	Method
/*      */     //   67	39	7	m	Method
/*      */     //   164	6	9	localObject2	Object
/*      */     //   172	1	10	localObject3	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	124	124	org/apache/ibatis/ognl/OgnlException
/*      */     //   12	124	129	java/lang/Exception
/*      */     //   12	121	164	finally
/*      */     //   124	164	164	finally
/*      */   }
/*      */   
/*      */   public static final void setIndexedProperty(OgnlContext context, Object source, String name, Object index, Object value)
/*      */     throws OgnlException
/*      */   {
/* 1732 */     Throwable reason = null;
/* 1733 */     Object[] args = objectArrayPool.create(index, value);
/*      */     try
/*      */     {
/* 1736 */       PropertyDescriptor pd = getPropertyDescriptor(source == null ? null : source.getClass(), name);
/*      */       Method m;
/*      */       Method m;
/* 1739 */       if ((pd instanceof IndexedPropertyDescriptor)) {
/* 1740 */         m = ((IndexedPropertyDescriptor)pd).getIndexedWriteMethod();
/*      */       }
/* 1742 */       else if ((pd instanceof ObjectIndexedPropertyDescriptor)) {
/* 1743 */         m = ((ObjectIndexedPropertyDescriptor)pd).getIndexedWriteMethod();
/*      */       } else {
/* 1745 */         throw new OgnlException("property '" + name + "' is not an indexed property");
/*      */       }
/*      */       
/* 1748 */       callMethod(context, source, m.getName(), name, args);
/*      */     } catch (OgnlException ex) {
/* 1750 */       throw ex;
/*      */     } catch (Exception ex) {
/* 1752 */       throw new OgnlException("getting indexed property descriptor for '" + name + "'", ex);
/*      */     } finally {
/* 1754 */       objectArrayPool.recycle(args);
/*      */     }
/*      */   }
/*      */   
/*      */   public static EvaluationPool getEvaluationPool()
/*      */   {
/* 1760 */     return evaluationPool;
/*      */   }
/*      */   
/*      */   public static ObjectArrayPool getObjectArrayPool()
/*      */   {
/* 1765 */     return objectArrayPool;
/*      */   }
/*      */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\OgnlRuntime.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */