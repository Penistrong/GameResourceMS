/*     */ package org.apache.ibatis.io;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarInputStream;
/*     */ import org.apache.ibatis.logging.Log;
/*     */ import org.apache.ibatis.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultVFS
/*     */   extends VFS
/*     */ {
/*  43 */   private static final Log log = LogFactory.getLog(ResolverUtil.class);
/*     */   
/*     */ 
/*  46 */   private static final byte[] JAR_MAGIC = { 80, 75, 3, 4 };
/*     */   
/*     */   public boolean isValid()
/*     */   {
/*  50 */     return true;
/*     */   }
/*     */   
/*     */   public List<String> list(URL url, String path) throws IOException
/*     */   {
/*  55 */     InputStream is = null;
/*     */     try {
/*  57 */       List<String> resources = new ArrayList();
/*     */       
/*     */ 
/*     */ 
/*  61 */       URL jarUrl = findJarForResource(url);
/*  62 */       List<String> children; String prefix; if (jarUrl != null) {
/*  63 */         is = jarUrl.openStream();
/*  64 */         log.debug("Listing " + url);
/*  65 */         resources = listResources(new JarInputStream(is), path);
/*     */       }
/*     */       else {
/*  68 */         children = new ArrayList();
/*     */         try {
/*  70 */           if (isJar(url))
/*     */           {
/*     */ 
/*  73 */             is = url.openStream();
/*  74 */             JarInputStream jarInput = new JarInputStream(is);
/*  75 */             log.debug("Listing " + url);
/*  76 */             JarEntry entry; while ((entry = jarInput.getNextJarEntry()) != null) {
/*  77 */               log.debug("Jar entry: " + entry.getName());
/*  78 */               children.add(entry.getName());
/*     */ 
/*     */ 
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/*     */ 
/*  90 */             is = url.openStream();
/*  91 */             BufferedReader reader = new BufferedReader(new InputStreamReader(is));
/*  92 */             List<String> lines = new ArrayList();
/*  93 */             String line; while ((line = reader.readLine()) != null) {
/*  94 */               log.debug("Reader entry: " + line);
/*  95 */               lines.add(line);
/*  96 */               if (getResources(path + "/" + line).isEmpty()) {
/*  97 */                 lines.clear();
/*     */               }
/*     */             }
/*     */             
/*     */ 
/* 102 */             if (!lines.isEmpty()) {
/* 103 */               log.debug("Listing " + url);
/* 104 */               children.addAll(lines);
/*     */             }
/*     */             
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         catch (FileNotFoundException e)
/*     */         {
/* 113 */           if ("file".equals(url.getProtocol())) {
/* 114 */             File file = new File(url.getFile());
/* 115 */             log.debug("Listing directory " + file.getAbsolutePath());
/* 116 */             if (file.isDirectory()) {
/* 117 */               log.debug("Listing " + url);
/* 118 */               children = Arrays.asList(file.list());
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 123 */             throw e;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 128 */         prefix = url.toExternalForm();
/* 129 */         if (!prefix.endsWith("/")) {
/* 130 */           prefix = prefix + "/";
/*     */         }
/*     */         
/* 133 */         for (String child : children) {
/* 134 */           String resourcePath = path + "/" + child;
/* 135 */           resources.add(resourcePath);
/* 136 */           URL childUrl = new URL(prefix + child);
/* 137 */           resources.addAll(list(childUrl, resourcePath));
/*     */         }
/*     */       }
/*     */       
/* 141 */       return resources;
/*     */     } finally {
/*     */       try {
/* 144 */         if (is != null) {
/* 145 */           is.close();
/*     */         }
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<String> listResources(JarInputStream jar, String path)
/*     */     throws IOException
/*     */   {
/* 162 */     if (!path.startsWith("/"))
/* 163 */       path = "/" + path;
/* 164 */     if (!path.endsWith("/")) {
/* 165 */       path = path + "/";
/*     */     }
/*     */     
/* 168 */     List<String> resources = new ArrayList();
/* 169 */     JarEntry entry; while ((entry = jar.getNextJarEntry()) != null) {
/* 170 */       if (!entry.isDirectory())
/*     */       {
/* 172 */         String name = entry.getName();
/* 173 */         if (!name.startsWith("/")) {
/* 174 */           name = "/" + name;
/*     */         }
/*     */         
/* 177 */         if (name.startsWith(path)) {
/* 178 */           log.debug("Found resource: " + name);
/* 179 */           resources.add(name.substring(1));
/*     */         }
/*     */       }
/*     */     }
/* 183 */     return resources;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected URL findJarForResource(URL url)
/*     */     throws MalformedURLException
/*     */   {
/* 197 */     log.debug("Find JAR URL: " + url);
/*     */     StringBuilder jarUrl;
/*     */     try
/*     */     {
/*     */       for (;;) {
/* 202 */         url = new URL(url.getFile());
/* 203 */         log.debug("Inner URL: " + url);
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     catch (MalformedURLException e)
/*     */     {
/* 210 */       jarUrl = new StringBuilder(url.toExternalForm());
/* 211 */       int index = jarUrl.lastIndexOf(".jar");
/* 212 */       if (index >= 0) {
/* 213 */         jarUrl.setLength(index + 4);
/* 214 */         log.debug("Extracted JAR URL: " + jarUrl);
/*     */       }
/*     */       else {
/* 217 */         log.debug("Not a JAR: " + jarUrl);
/* 218 */         return null;
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 223 */       URL testUrl = new URL(jarUrl.toString());
/* 224 */       if (isJar(testUrl)) {
/* 225 */         return testUrl;
/*     */       }
/*     */       
/*     */ 
/* 229 */       log.debug("Not a JAR: " + jarUrl);
/* 230 */       jarUrl.replace(0, jarUrl.length(), testUrl.getFile());
/* 231 */       File file = new File(jarUrl.toString());
/*     */       
/*     */ 
/* 234 */       if (!file.exists()) {
/*     */         try {
/* 236 */           file = new File(URLEncoder.encode(jarUrl.toString(), "UTF-8"));
/*     */         } catch (UnsupportedEncodingException e) {
/* 238 */           throw new RuntimeException("Unsupported encoding?  UTF-8?  That's unpossible.");
/*     */         }
/*     */       }
/*     */       
/* 242 */       if (file.exists()) {
/* 243 */         log.debug("Trying real file: " + file.getAbsolutePath());
/* 244 */         testUrl = file.toURI().toURL();
/* 245 */         if (isJar(testUrl)) {
/* 246 */           return testUrl;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (MalformedURLException e) {
/* 251 */       log.warn("Invalid JAR URL: " + jarUrl);
/*     */     }
/*     */     
/* 254 */     log.debug("Not a JAR: " + jarUrl);
/* 255 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getPackagePath(String packageName)
/*     */   {
/* 265 */     return packageName == null ? null : packageName.replace('.', '/');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isJar(URL url)
/*     */   {
/* 274 */     return isJar(url, new byte[JAR_MAGIC.length]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isJar(URL url, byte[] buffer)
/*     */   {
/* 286 */     InputStream is = null;
/*     */     try {
/* 288 */       is = url.openStream();
/* 289 */       is.read(buffer, 0, JAR_MAGIC.length);
/* 290 */       if (Arrays.equals(buffer, JAR_MAGIC)) {
/* 291 */         log.debug("Found JAR: " + url);
/* 292 */         return true;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 303 */       return false;
/*     */     }
/*     */     catch (Exception e) {}finally
/*     */     {
/*     */       try
/*     */       {
/* 298 */         is.close();
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\io\DefaultVFS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */