package org.apache.ibatis.reflection.factory;

import java.util.List;
import java.util.Properties;

public abstract interface ObjectFactory
{
  public abstract void setProperties(Properties paramProperties);
  
  public abstract <T> T create(Class<T> paramClass);
  
  public abstract <T> T create(Class<T> paramClass, List<Class<?>> paramList, List<Object> paramList1);
  
  public abstract <T> boolean isCollection(Class<T> paramClass);
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\factory\ObjectFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */