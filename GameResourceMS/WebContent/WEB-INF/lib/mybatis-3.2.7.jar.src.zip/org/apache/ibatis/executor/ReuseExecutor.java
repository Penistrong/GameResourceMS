/*    */ package org.apache.ibatis.executor;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.apache.ibatis.executor.statement.StatementHandler;
/*    */ import org.apache.ibatis.logging.Log;
/*    */ import org.apache.ibatis.mapping.BoundSql;
/*    */ import org.apache.ibatis.mapping.MappedStatement;
/*    */ import org.apache.ibatis.session.Configuration;
/*    */ import org.apache.ibatis.session.ResultHandler;
/*    */ import org.apache.ibatis.session.RowBounds;
/*    */ import org.apache.ibatis.transaction.Transaction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReuseExecutor
/*    */   extends BaseExecutor
/*    */ {
/* 40 */   private final Map<String, Statement> statementMap = new HashMap();
/*    */   
/*    */   public ReuseExecutor(Configuration configuration, Transaction transaction) {
/* 43 */     super(configuration, transaction);
/*    */   }
/*    */   
/*    */   public int doUpdate(MappedStatement ms, Object parameter) throws SQLException {
/* 47 */     Configuration configuration = ms.getConfiguration();
/* 48 */     StatementHandler handler = configuration.newStatementHandler(this, ms, parameter, RowBounds.DEFAULT, null, null);
/* 49 */     Statement stmt = prepareStatement(handler, ms.getStatementLog());
/* 50 */     return handler.update(stmt);
/*    */   }
/*    */   
/*    */   public <E> List<E> doQuery(MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler, BoundSql boundSql) throws SQLException {
/* 54 */     Configuration configuration = ms.getConfiguration();
/* 55 */     StatementHandler handler = configuration.newStatementHandler(this.wrapper, ms, parameter, rowBounds, resultHandler, boundSql);
/* 56 */     Statement stmt = prepareStatement(handler, ms.getStatementLog());
/* 57 */     return handler.query(stmt, resultHandler);
/*    */   }
/*    */   
/*    */   public List<BatchResult> doFlushStatements(boolean isRollback) throws SQLException {
/* 61 */     for (Statement stmt : this.statementMap.values()) {
/* 62 */       closeStatement(stmt);
/*    */     }
/* 64 */     this.statementMap.clear();
/* 65 */     return Collections.emptyList();
/*    */   }
/*    */   
/*    */   private Statement prepareStatement(StatementHandler handler, Log statementLog) throws SQLException
/*    */   {
/* 70 */     BoundSql boundSql = handler.getBoundSql();
/* 71 */     String sql = boundSql.getSql();
/* 72 */     Statement stmt; Statement stmt; if (hasStatementFor(sql)) {
/* 73 */       stmt = getStatement(sql);
/*    */     } else {
/* 75 */       Connection connection = getConnection(statementLog);
/* 76 */       stmt = handler.prepare(connection);
/* 77 */       putStatement(sql, stmt);
/*    */     }
/* 79 */     handler.parameterize(stmt);
/* 80 */     return stmt;
/*    */   }
/*    */   
/*    */   private boolean hasStatementFor(String sql) {
/*    */     try {
/* 85 */       return (this.statementMap.keySet().contains(sql)) && (!((Statement)this.statementMap.get(sql)).getConnection().isClosed());
/*    */     } catch (SQLException e) {}
/* 87 */     return false;
/*    */   }
/*    */   
/*    */   private Statement getStatement(String s)
/*    */   {
/* 92 */     return (Statement)this.statementMap.get(s);
/*    */   }
/*    */   
/*    */   private void putStatement(String sql, Statement stmt) {
/* 96 */     this.statementMap.put(sql, stmt);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\ReuseExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */