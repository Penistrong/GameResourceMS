/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTBitAnd
/*    */   extends ExpressionNode
/*    */ {
/*    */   public ASTBitAnd(int id)
/*    */   {
/* 40 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTBitAnd(OgnlParser p, int id) {
/* 44 */     super(p, id);
/*    */   }
/*    */   
/*    */   public void jjtClose() {
/* 48 */     flattenTree();
/*    */   }
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException
/*    */   {
/* 53 */     Object result = this.children[0].getValue(context, source);
/* 54 */     for (int i = 1; i < this.children.length; i++)
/* 55 */       result = OgnlOps.binaryAnd(result, this.children[i].getValue(context, source));
/* 56 */     return result;
/*    */   }
/*    */   
/*    */   public String getExpressionOperator(int index)
/*    */   {
/* 61 */     return "&";
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTBitAnd.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */