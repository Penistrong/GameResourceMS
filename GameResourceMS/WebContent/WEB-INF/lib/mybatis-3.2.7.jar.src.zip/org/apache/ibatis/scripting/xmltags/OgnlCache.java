/*    */ package org.apache.ibatis.scripting.xmltags;
/*    */ 
/*    */ import java.io.StringReader;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import org.apache.ibatis.builder.BuilderException;
/*    */ import org.apache.ibatis.ognl.ExpressionSyntaxException;
/*    */ import org.apache.ibatis.ognl.Node;
/*    */ import org.apache.ibatis.ognl.Ognl;
/*    */ import org.apache.ibatis.ognl.OgnlException;
/*    */ import org.apache.ibatis.ognl.OgnlParser;
/*    */ import org.apache.ibatis.ognl.ParseException;
/*    */ import org.apache.ibatis.ognl.TokenMgrError;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OgnlCache
/*    */ {
/* 44 */   private static final Map<String, Node> expressionCache = new ConcurrentHashMap();
/*    */   
/*    */   public static Object getValue(String expression, Object root) {
/*    */     try {
/* 48 */       return Ognl.getValue(parseExpression(expression), root);
/*    */     } catch (OgnlException e) {
/* 50 */       throw new BuilderException("Error evaluating expression '" + expression + "'. Cause: " + e, e);
/*    */     }
/*    */   }
/*    */   
/*    */   private static Object parseExpression(String expression) throws OgnlException {
/*    */     try {
/* 56 */       Node node = (Node)expressionCache.get(expression);
/* 57 */       if (node == null) {
/* 58 */         node = new OgnlParser(new StringReader(expression)).topLevelExpression();
/* 59 */         expressionCache.put(expression, node);
/*    */       }
/* 61 */       return node;
/*    */     } catch (ParseException e) {
/* 63 */       throw new ExpressionSyntaxException(expression, e);
/*    */     } catch (TokenMgrError e) {
/* 65 */       throw new ExpressionSyntaxException(expression, e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\xmltags\OgnlCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */