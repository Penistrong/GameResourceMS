/*    */ package org.apache.ibatis.reflection;
/*    */ 
/*    */ import org.apache.ibatis.reflection.factory.DefaultObjectFactory;
/*    */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*    */ import org.apache.ibatis.reflection.wrapper.DefaultObjectWrapperFactory;
/*    */ import org.apache.ibatis.reflection.wrapper.ObjectWrapperFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SystemMetaObject
/*    */ {
/* 29 */   public static final ObjectFactory DEFAULT_OBJECT_FACTORY = new DefaultObjectFactory();
/* 30 */   public static final ObjectWrapperFactory DEFAULT_OBJECT_WRAPPER_FACTORY = new DefaultObjectWrapperFactory();
/* 31 */   public static final MetaObject NULL_META_OBJECT = MetaObject.forObject(NullObject.class, DEFAULT_OBJECT_FACTORY, DEFAULT_OBJECT_WRAPPER_FACTORY);
/*    */   
/*    */ 
/*    */ 
/*    */   public static MetaObject forObject(Object object)
/*    */   {
/* 37 */     return MetaObject.forObject(object, DEFAULT_OBJECT_FACTORY, DEFAULT_OBJECT_WRAPPER_FACTORY);
/*    */   }
/*    */   
/*    */   private static class NullObject {}
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\SystemMetaObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */