/*     */ package org.apache.ibatis.reflection;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.ReflectPermission;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.ibatis.reflection.invoker.GetFieldInvoker;
/*     */ import org.apache.ibatis.reflection.invoker.Invoker;
/*     */ import org.apache.ibatis.reflection.invoker.MethodInvoker;
/*     */ import org.apache.ibatis.reflection.invoker.SetFieldInvoker;
/*     */ import org.apache.ibatis.reflection.property.PropertyNamer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Reflector
/*     */ {
/*  47 */   private static boolean classCacheEnabled = true;
/*  48 */   private static final String[] EMPTY_STRING_ARRAY = new String[0];
/*  49 */   private static final Map<Class<?>, Reflector> REFLECTOR_MAP = new ConcurrentHashMap();
/*     */   
/*     */   private Class<?> type;
/*  52 */   private String[] readablePropertyNames = EMPTY_STRING_ARRAY;
/*  53 */   private String[] writeablePropertyNames = EMPTY_STRING_ARRAY;
/*  54 */   private Map<String, Invoker> setMethods = new HashMap();
/*  55 */   private Map<String, Invoker> getMethods = new HashMap();
/*  56 */   private Map<String, Class<?>> setTypes = new HashMap();
/*  57 */   private Map<String, Class<?>> getTypes = new HashMap();
/*     */   
/*     */   private Constructor<?> defaultConstructor;
/*  60 */   private Map<String, String> caseInsensitivePropertyMap = new HashMap();
/*     */   
/*     */   private Reflector(Class<?> clazz) {
/*  63 */     this.type = clazz;
/*  64 */     addDefaultConstructor(clazz);
/*  65 */     addGetMethods(clazz);
/*  66 */     addSetMethods(clazz);
/*  67 */     addFields(clazz);
/*  68 */     this.readablePropertyNames = ((String[])this.getMethods.keySet().toArray(new String[this.getMethods.keySet().size()]));
/*  69 */     this.writeablePropertyNames = ((String[])this.setMethods.keySet().toArray(new String[this.setMethods.keySet().size()]));
/*  70 */     for (String propName : this.readablePropertyNames) {
/*  71 */       this.caseInsensitivePropertyMap.put(propName.toUpperCase(Locale.ENGLISH), propName);
/*     */     }
/*  73 */     for (String propName : this.writeablePropertyNames) {
/*  74 */       this.caseInsensitivePropertyMap.put(propName.toUpperCase(Locale.ENGLISH), propName);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addDefaultConstructor(Class<?> clazz) {
/*  79 */     Constructor<?>[] consts = clazz.getDeclaredConstructors();
/*  80 */     for (Constructor<?> constructor : consts) {
/*  81 */       if (constructor.getParameterTypes().length == 0) {
/*  82 */         if (canAccessPrivateMethods()) {
/*     */           try {
/*  84 */             constructor.setAccessible(true);
/*     */           }
/*     */           catch (Exception e) {}
/*     */         }
/*     */         
/*  89 */         if (constructor.isAccessible()) {
/*  90 */           this.defaultConstructor = constructor;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addGetMethods(Class<?> cls) {
/*  97 */     Map<String, List<Method>> conflictingGetters = new HashMap();
/*  98 */     Method[] methods = getClassMethods(cls);
/*  99 */     for (Method method : methods) {
/* 100 */       String name = method.getName();
/* 101 */       if ((name.startsWith("get")) && (name.length() > 3)) {
/* 102 */         if (method.getParameterTypes().length == 0) {
/* 103 */           name = PropertyNamer.methodToProperty(name);
/* 104 */           addMethodConflict(conflictingGetters, name, method);
/*     */         }
/* 106 */       } else if ((name.startsWith("is")) && (name.length() > 2) && 
/* 107 */         (method.getParameterTypes().length == 0)) {
/* 108 */         name = PropertyNamer.methodToProperty(name);
/* 109 */         addMethodConflict(conflictingGetters, name, method);
/*     */       }
/*     */     }
/*     */     
/* 113 */     resolveGetterConflicts(conflictingGetters);
/*     */   }
/*     */   
/*     */   private void resolveGetterConflicts(Map<String, List<Method>> conflictingGetters) {
/* 117 */     for (String propName : conflictingGetters.keySet()) {
/* 118 */       List<Method> getters = (List)conflictingGetters.get(propName);
/* 119 */       Iterator<Method> iterator = getters.iterator();
/* 120 */       Method firstMethod = (Method)iterator.next();
/* 121 */       if (getters.size() == 1) {
/* 122 */         addGetMethod(propName, firstMethod);
/*     */       } else {
/* 124 */         Method getter = firstMethod;
/* 125 */         Class<?> getterType = firstMethod.getReturnType();
/* 126 */         while (iterator.hasNext()) {
/* 127 */           Method method = (Method)iterator.next();
/* 128 */           Class<?> methodType = method.getReturnType();
/* 129 */           if (methodType.equals(getterType)) {
/* 130 */             throw new ReflectionException("Illegal overloaded getter method with ambiguous type for property " + propName + " in class " + firstMethod.getDeclaringClass() + ".  This breaks the JavaBeans " + "specification and can cause unpredicatble results.");
/*     */           }
/*     */           
/* 133 */           if (!methodType.isAssignableFrom(getterType))
/*     */           {
/* 135 */             if (getterType.isAssignableFrom(methodType)) {
/* 136 */               getter = method;
/* 137 */               getterType = methodType;
/*     */             } else {
/* 139 */               throw new ReflectionException("Illegal overloaded getter method with ambiguous type for property " + propName + " in class " + firstMethod.getDeclaringClass() + ".  This breaks the JavaBeans " + "specification and can cause unpredicatble results.");
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 144 */         addGetMethod(propName, getter);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addGetMethod(String name, Method method) {
/* 150 */     if (isValidPropertyName(name)) {
/* 151 */       this.getMethods.put(name, new MethodInvoker(method));
/* 152 */       this.getTypes.put(name, method.getReturnType());
/*     */     }
/*     */   }
/*     */   
/*     */   private void addSetMethods(Class<?> cls) {
/* 157 */     Map<String, List<Method>> conflictingSetters = new HashMap();
/* 158 */     Method[] methods = getClassMethods(cls);
/* 159 */     for (Method method : methods) {
/* 160 */       String name = method.getName();
/* 161 */       if ((name.startsWith("set")) && (name.length() > 3) && 
/* 162 */         (method.getParameterTypes().length == 1)) {
/* 163 */         name = PropertyNamer.methodToProperty(name);
/* 164 */         addMethodConflict(conflictingSetters, name, method);
/*     */       }
/*     */     }
/*     */     
/* 168 */     resolveSetterConflicts(conflictingSetters);
/*     */   }
/*     */   
/*     */   private void addMethodConflict(Map<String, List<Method>> conflictingMethods, String name, Method method) {
/* 172 */     List<Method> list = (List)conflictingMethods.get(name);
/* 173 */     if (list == null) {
/* 174 */       list = new ArrayList();
/* 175 */       conflictingMethods.put(name, list);
/*     */     }
/* 177 */     list.add(method);
/*     */   }
/*     */   
/*     */   private void resolveSetterConflicts(Map<String, List<Method>> conflictingSetters) {
/* 181 */     for (String propName : conflictingSetters.keySet()) {
/* 182 */       List<Method> setters = (List)conflictingSetters.get(propName);
/* 183 */       Method firstMethod = (Method)setters.get(0);
/* 184 */       if (setters.size() == 1) {
/* 185 */         addSetMethod(propName, firstMethod);
/*     */       } else {
/* 187 */         Class<?> expectedType = (Class)this.getTypes.get(propName);
/* 188 */         if (expectedType == null) {
/* 189 */           throw new ReflectionException("Illegal overloaded setter method with ambiguous type for property " + propName + " in class " + firstMethod.getDeclaringClass() + ".  This breaks the JavaBeans " + "specification and can cause unpredicatble results.");
/*     */         }
/*     */         
/*     */ 
/* 193 */         Iterator<Method> methods = setters.iterator();
/* 194 */         Method setter = null;
/* 195 */         while (methods.hasNext()) {
/* 196 */           Method method = (Method)methods.next();
/* 197 */           if ((method.getParameterTypes().length == 1) && (expectedType.equals(method.getParameterTypes()[0])))
/*     */           {
/* 199 */             setter = method;
/* 200 */             break;
/*     */           }
/*     */         }
/* 203 */         if (setter == null) {
/* 204 */           throw new ReflectionException("Illegal overloaded setter method with ambiguous type for property " + propName + " in class " + firstMethod.getDeclaringClass() + ".  This breaks the JavaBeans " + "specification and can cause unpredicatble results.");
/*     */         }
/*     */         
/*     */ 
/* 208 */         addSetMethod(propName, setter);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addSetMethod(String name, Method method)
/*     */   {
/* 215 */     if (isValidPropertyName(name)) {
/* 216 */       this.setMethods.put(name, new MethodInvoker(method));
/* 217 */       this.setTypes.put(name, method.getParameterTypes()[0]);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addFields(Class<?> clazz) {
/* 222 */     Field[] fields = clazz.getDeclaredFields();
/* 223 */     for (Field field : fields) {
/* 224 */       if (canAccessPrivateMethods()) {
/*     */         try {
/* 226 */           field.setAccessible(true);
/*     */         }
/*     */         catch (Exception e) {}
/*     */       }
/*     */       
/* 231 */       if (field.isAccessible()) {
/* 232 */         if (!this.setMethods.containsKey(field.getName()))
/*     */         {
/*     */ 
/*     */ 
/* 236 */           int modifiers = field.getModifiers();
/* 237 */           if ((!Modifier.isFinal(modifiers)) || (!Modifier.isStatic(modifiers))) {
/* 238 */             addSetField(field);
/*     */           }
/*     */         }
/* 241 */         if (!this.getMethods.containsKey(field.getName())) {
/* 242 */           addGetField(field);
/*     */         }
/*     */       }
/*     */     }
/* 246 */     if (clazz.getSuperclass() != null) {
/* 247 */       addFields(clazz.getSuperclass());
/*     */     }
/*     */   }
/*     */   
/*     */   private void addSetField(Field field) {
/* 252 */     if (isValidPropertyName(field.getName())) {
/* 253 */       this.setMethods.put(field.getName(), new SetFieldInvoker(field));
/* 254 */       this.setTypes.put(field.getName(), field.getType());
/*     */     }
/*     */   }
/*     */   
/*     */   private void addGetField(Field field) {
/* 259 */     if (isValidPropertyName(field.getName())) {
/* 260 */       this.getMethods.put(field.getName(), new GetFieldInvoker(field));
/* 261 */       this.getTypes.put(field.getName(), field.getType());
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isValidPropertyName(String name) {
/* 266 */     return (!name.startsWith("$")) && (!"serialVersionUID".equals(name)) && (!"class".equals(name));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Method[] getClassMethods(Class<?> cls)
/*     */   {
/* 279 */     HashMap<String, Method> uniqueMethods = new HashMap();
/* 280 */     Class<?> currentClass = cls;
/* 281 */     while (currentClass != null) {
/* 282 */       addUniqueMethods(uniqueMethods, currentClass.getDeclaredMethods());
/*     */       
/*     */ 
/*     */ 
/* 286 */       Class<?>[] interfaces = currentClass.getInterfaces();
/* 287 */       for (Class<?> anInterface : interfaces) {
/* 288 */         addUniqueMethods(uniqueMethods, anInterface.getMethods());
/*     */       }
/*     */       
/* 291 */       currentClass = currentClass.getSuperclass();
/*     */     }
/*     */     
/* 294 */     Collection<Method> methods = uniqueMethods.values();
/*     */     
/* 296 */     return (Method[])methods.toArray(new Method[methods.size()]);
/*     */   }
/*     */   
/*     */   private void addUniqueMethods(HashMap<String, Method> uniqueMethods, Method[] methods) {
/* 300 */     for (Method currentMethod : methods) {
/* 301 */       if (!currentMethod.isBridge()) {
/* 302 */         String signature = getSignature(currentMethod);
/*     */         
/*     */ 
/*     */ 
/* 306 */         if (!uniqueMethods.containsKey(signature)) {
/* 307 */           if (canAccessPrivateMethods()) {
/*     */             try {
/* 309 */               currentMethod.setAccessible(true);
/*     */             }
/*     */             catch (Exception e) {}
/*     */           }
/*     */           
/*     */ 
/* 315 */           uniqueMethods.put(signature, currentMethod);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private String getSignature(Method method) {
/* 322 */     StringBuilder sb = new StringBuilder();
/* 323 */     Class<?> returnType = method.getReturnType();
/* 324 */     if (returnType != null) {
/* 325 */       sb.append(returnType.getName()).append('#');
/*     */     }
/* 327 */     sb.append(method.getName());
/* 328 */     Class<?>[] parameters = method.getParameterTypes();
/* 329 */     for (int i = 0; i < parameters.length; i++) {
/* 330 */       if (i == 0) {
/* 331 */         sb.append(':');
/*     */       } else {
/* 333 */         sb.append(',');
/*     */       }
/* 335 */       sb.append(parameters[i].getName());
/*     */     }
/* 337 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static boolean canAccessPrivateMethods() {
/*     */     try {
/* 342 */       SecurityManager securityManager = System.getSecurityManager();
/* 343 */       if (null != securityManager) {
/* 344 */         securityManager.checkPermission(new ReflectPermission("suppressAccessChecks"));
/*     */       }
/*     */     } catch (SecurityException e) {
/* 347 */       return false;
/*     */     }
/* 349 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getType()
/*     */   {
/* 358 */     return this.type;
/*     */   }
/*     */   
/*     */   public Constructor<?> getDefaultConstructor() {
/* 362 */     if (this.defaultConstructor != null) {
/* 363 */       return this.defaultConstructor;
/*     */     }
/* 365 */     throw new ReflectionException("There is no default constructor for " + this.type);
/*     */   }
/*     */   
/*     */   public Invoker getSetInvoker(String propertyName)
/*     */   {
/* 370 */     Invoker method = (Invoker)this.setMethods.get(propertyName);
/* 371 */     if (method == null) {
/* 372 */       throw new ReflectionException("There is no setter for property named '" + propertyName + "' in '" + this.type + "'");
/*     */     }
/* 374 */     return method;
/*     */   }
/*     */   
/*     */   public Invoker getGetInvoker(String propertyName) {
/* 378 */     Invoker method = (Invoker)this.getMethods.get(propertyName);
/* 379 */     if (method == null) {
/* 380 */       throw new ReflectionException("There is no getter for property named '" + propertyName + "' in '" + this.type + "'");
/*     */     }
/* 382 */     return method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getSetterType(String propertyName)
/*     */   {
/* 392 */     Class<?> clazz = (Class)this.setTypes.get(propertyName);
/* 393 */     if (clazz == null) {
/* 394 */       throw new ReflectionException("There is no setter for property named '" + propertyName + "' in '" + this.type + "'");
/*     */     }
/* 396 */     return clazz;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getGetterType(String propertyName)
/*     */   {
/* 406 */     Class<?> clazz = (Class)this.getTypes.get(propertyName);
/* 407 */     if (clazz == null) {
/* 408 */       throw new ReflectionException("There is no getter for property named '" + propertyName + "' in '" + this.type + "'");
/*     */     }
/* 410 */     return clazz;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getGetablePropertyNames()
/*     */   {
/* 419 */     return this.readablePropertyNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getSetablePropertyNames()
/*     */   {
/* 428 */     return this.writeablePropertyNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasSetter(String propertyName)
/*     */   {
/* 438 */     return this.setMethods.keySet().contains(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasGetter(String propertyName)
/*     */   {
/* 448 */     return this.getMethods.keySet().contains(propertyName);
/*     */   }
/*     */   
/*     */   public String findPropertyName(String name) {
/* 452 */     return (String)this.caseInsensitivePropertyMap.get(name.toUpperCase(Locale.ENGLISH));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Reflector forClass(Class<?> clazz)
/*     */   {
/* 462 */     if (classCacheEnabled)
/*     */     {
/* 464 */       Reflector cached = (Reflector)REFLECTOR_MAP.get(clazz);
/* 465 */       if (cached == null) {
/* 466 */         cached = new Reflector(clazz);
/* 467 */         REFLECTOR_MAP.put(clazz, cached);
/*     */       }
/* 469 */       return cached;
/*     */     }
/* 471 */     return new Reflector(clazz);
/*     */   }
/*     */   
/*     */   public static void setClassCacheEnabled(boolean classCacheEnabled)
/*     */   {
/* 476 */     classCacheEnabled = classCacheEnabled;
/*     */   }
/*     */   
/*     */   public static boolean isClassCacheEnabled() {
/* 480 */     return classCacheEnabled;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\Reflector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */