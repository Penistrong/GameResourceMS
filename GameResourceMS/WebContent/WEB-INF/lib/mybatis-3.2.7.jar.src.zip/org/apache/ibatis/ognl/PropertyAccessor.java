package org.apache.ibatis.ognl;

import java.util.Map;

public abstract interface PropertyAccessor
{
  public abstract Object getProperty(Map paramMap, Object paramObject1, Object paramObject2)
    throws OgnlException;
  
  public abstract void setProperty(Map paramMap, Object paramObject1, Object paramObject2, Object paramObject3)
    throws OgnlException;
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\PropertyAccessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */