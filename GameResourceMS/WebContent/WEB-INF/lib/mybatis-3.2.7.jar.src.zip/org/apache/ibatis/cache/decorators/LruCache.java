/*    */ package org.apache.ibatis.cache.decorators;
/*    */ 
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.concurrent.locks.ReadWriteLock;
/*    */ import org.apache.ibatis.cache.Cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LruCache
/*    */   implements Cache
/*    */ {
/*    */   private final Cache delegate;
/*    */   private Map<Object, Object> keyMap;
/*    */   private Object eldestKey;
/*    */   
/*    */   public LruCache(Cache delegate)
/*    */   {
/* 36 */     this.delegate = delegate;
/* 37 */     setSize(1024);
/*    */   }
/*    */   
/*    */   public String getId()
/*    */   {
/* 42 */     return this.delegate.getId();
/*    */   }
/*    */   
/*    */   public int getSize()
/*    */   {
/* 47 */     return this.delegate.getSize();
/*    */   }
/*    */   
/*    */   public void setSize(final int size) {
/* 51 */     this.keyMap = new LinkedHashMap(size, 0.75F, true) {
/*    */       private static final long serialVersionUID = 4267176411845948333L;
/*    */       
/*    */       protected boolean removeEldestEntry(Map.Entry<Object, Object> eldest) {
/* 55 */         boolean tooBig = size() > size;
/* 56 */         if (tooBig) {
/* 57 */           LruCache.this.eldestKey = eldest.getKey();
/*    */         }
/* 59 */         return tooBig;
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */   public void putObject(Object key, Object value)
/*    */   {
/* 66 */     this.delegate.putObject(key, value);
/* 67 */     cycleKeyList(key);
/*    */   }
/*    */   
/*    */   public Object getObject(Object key)
/*    */   {
/* 72 */     this.keyMap.get(key);
/* 73 */     return this.delegate.getObject(key);
/*    */   }
/*    */   
/*    */   public Object removeObject(Object key)
/*    */   {
/* 78 */     return this.delegate.removeObject(key);
/*    */   }
/*    */   
/*    */   public void clear()
/*    */   {
/* 83 */     this.delegate.clear();
/* 84 */     this.keyMap.clear();
/*    */   }
/*    */   
/*    */   public ReadWriteLock getReadWriteLock() {
/* 88 */     return null;
/*    */   }
/*    */   
/*    */   private void cycleKeyList(Object key) {
/* 92 */     this.keyMap.put(key, key);
/* 93 */     if (this.eldestKey != null) {
/* 94 */       this.delegate.removeObject(this.eldestKey);
/* 95 */       this.eldestKey = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\cache\decorators\LruCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */