/*    */ package org.apache.ibatis.executor.result;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*    */ import org.apache.ibatis.session.ResultContext;
/*    */ import org.apache.ibatis.session.ResultHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultResultHandler
/*    */   implements ResultHandler
/*    */ {
/*    */   private final List<Object> list;
/*    */   
/*    */   public DefaultResultHandler()
/*    */   {
/* 33 */     this.list = new ArrayList();
/*    */   }
/*    */   
/*    */   public DefaultResultHandler(ObjectFactory objectFactory)
/*    */   {
/* 38 */     this.list = ((List)objectFactory.create(List.class));
/*    */   }
/*    */   
/*    */   public void handleResult(ResultContext context) {
/* 42 */     this.list.add(context.getResultObject());
/*    */   }
/*    */   
/*    */   public List<Object> getResultList() {
/* 46 */     return this.list;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\result\DefaultResultHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */