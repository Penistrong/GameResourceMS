/*    */ package org.apache.ibatis.scripting;
/*    */ 
/*    */ import org.apache.ibatis.exceptions.PersistenceException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScriptingException
/*    */   extends PersistenceException
/*    */ {
/*    */   private static final long serialVersionUID = 7642570221267566591L;
/*    */   
/*    */   public ScriptingException() {}
/*    */   
/*    */   public ScriptingException(String message)
/*    */   {
/* 32 */     super(message);
/*    */   }
/*    */   
/*    */   public ScriptingException(String message, Throwable cause) {
/* 36 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public ScriptingException(Throwable cause) {
/* 40 */     super(cause);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\ScriptingException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */