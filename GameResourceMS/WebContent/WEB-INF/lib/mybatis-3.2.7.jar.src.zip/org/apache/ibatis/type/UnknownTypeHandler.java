/*     */ package org.apache.ibatis.type;
/*     */ 
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.ibatis.io.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnknownTypeHandler
/*     */   extends BaseTypeHandler<Object>
/*     */ {
/*  33 */   private static final ObjectTypeHandler OBJECT_TYPE_HANDLER = new ObjectTypeHandler();
/*     */   private TypeHandlerRegistry typeHandlerRegistry;
/*     */   
/*     */   public UnknownTypeHandler(TypeHandlerRegistry typeHandlerRegistry)
/*     */   {
/*  38 */     this.typeHandlerRegistry = typeHandlerRegistry;
/*     */   }
/*     */   
/*     */   public void setNonNullParameter(PreparedStatement ps, int i, Object parameter, JdbcType jdbcType)
/*     */     throws SQLException
/*     */   {
/*  44 */     TypeHandler handler = resolveTypeHandler(parameter, jdbcType);
/*  45 */     handler.setParameter(ps, i, parameter, jdbcType);
/*     */   }
/*     */   
/*     */   public Object getNullableResult(ResultSet rs, String columnName)
/*     */     throws SQLException
/*     */   {
/*  51 */     TypeHandler<?> handler = resolveTypeHandler(rs, columnName);
/*  52 */     return handler.getResult(rs, columnName);
/*     */   }
/*     */   
/*     */   public Object getNullableResult(ResultSet rs, int columnIndex)
/*     */     throws SQLException
/*     */   {
/*  58 */     TypeHandler<?> handler = resolveTypeHandler(rs.getMetaData(), Integer.valueOf(columnIndex));
/*  59 */     if ((handler == null) || ((handler instanceof UnknownTypeHandler))) {
/*  60 */       handler = OBJECT_TYPE_HANDLER;
/*     */     }
/*  62 */     return handler.getResult(rs, columnIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  68 */   public Object getNullableResult(CallableStatement cs, int columnIndex)
/*  68 */     throws SQLException { return cs.getObject(columnIndex); }
/*     */   
/*     */   private TypeHandler<? extends Object> resolveTypeHandler(Object parameter, JdbcType jdbcType) {
/*     */     TypeHandler<? extends Object> handler;
/*     */     TypeHandler<? extends Object> handler;
/*  73 */     if (parameter == null) {
/*  74 */       handler = OBJECT_TYPE_HANDLER;
/*     */     } else {
/*  76 */       handler = this.typeHandlerRegistry.getTypeHandler(parameter.getClass(), jdbcType);
/*     */       
/*  78 */       if ((handler == null) || ((handler instanceof UnknownTypeHandler))) {
/*  79 */         handler = OBJECT_TYPE_HANDLER;
/*     */       }
/*     */     }
/*  82 */     return handler;
/*     */   }
/*     */   
/*     */   private TypeHandler<?> resolveTypeHandler(ResultSet rs, String column)
/*     */   {
/*     */     try {
/*  88 */       Map<String, Integer> columnIndexLookup = new HashMap();
/*  89 */       ResultSetMetaData rsmd = rs.getMetaData();
/*  90 */       int count = rsmd.getColumnCount();
/*  91 */       for (int i = 1; i <= count; i++) {
/*  92 */         String name = rsmd.getColumnName(i);
/*  93 */         columnIndexLookup.put(name, Integer.valueOf(i));
/*     */       }
/*  95 */       Integer columnIndex = (Integer)columnIndexLookup.get(column);
/*  96 */       TypeHandler<?> handler = null;
/*  97 */       if (columnIndex != null) {
/*  98 */         handler = resolveTypeHandler(rsmd, columnIndex);
/*     */       }
/* 100 */       if ((handler == null) || ((handler instanceof UnknownTypeHandler))) {}
/* 101 */       return OBJECT_TYPE_HANDLER;
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/* 105 */       throw new TypeException("Error determining JDBC type for column " + column + ".  Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   private TypeHandler<?> resolveTypeHandler(ResultSetMetaData rsmd, Integer columnIndex) throws SQLException {
/* 110 */     TypeHandler<?> handler = null;
/* 111 */     JdbcType jdbcType = safeGetJdbcTypeForColumn(rsmd, columnIndex);
/* 112 */     Class<?> javaType = safeGetClassForColumn(rsmd, columnIndex);
/* 113 */     if ((javaType != null) && (jdbcType != null)) {
/* 114 */       handler = this.typeHandlerRegistry.getTypeHandler(javaType, jdbcType);
/* 115 */     } else if (javaType != null) {
/* 116 */       handler = this.typeHandlerRegistry.getTypeHandler(javaType);
/* 117 */     } else if (jdbcType != null) {
/* 118 */       handler = this.typeHandlerRegistry.getTypeHandler(jdbcType);
/*     */     }
/* 120 */     return handler;
/*     */   }
/*     */   
/*     */   private JdbcType safeGetJdbcTypeForColumn(ResultSetMetaData rsmd, Integer columnIndex) {
/*     */     try {
/* 125 */       return JdbcType.forCode(rsmd.getColumnType(columnIndex.intValue()));
/*     */     } catch (Exception e) {}
/* 127 */     return null;
/*     */   }
/*     */   
/*     */   private Class<?> safeGetClassForColumn(ResultSetMetaData rsmd, Integer columnIndex)
/*     */   {
/*     */     try {
/* 133 */       return Resources.classForName(rsmd.getColumnClassName(columnIndex.intValue()));
/*     */     } catch (Exception e) {}
/* 135 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\UnknownTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */