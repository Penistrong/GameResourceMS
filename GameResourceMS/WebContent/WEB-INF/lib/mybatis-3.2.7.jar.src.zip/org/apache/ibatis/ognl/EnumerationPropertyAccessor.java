/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnumerationPropertyAccessor
/*    */   extends ObjectPropertyAccessor
/*    */   implements PropertyAccessor
/*    */ {
/*    */   public Object getProperty(Map context, Object target, Object name)
/*    */     throws OgnlException
/*    */   {
/* 48 */     Enumeration e = (Enumeration)target;
/*    */     Object result;
/* 50 */     Object result; if ((name instanceof String)) { Object result;
/* 51 */       if ((name.equals("next")) || (name.equals("nextElement"))) {
/* 52 */         result = e.nextElement();
/*    */       } else { Object result;
/* 54 */         if ((name.equals("hasNext")) || (name.equals("hasMoreElements"))) {
/* 55 */           result = e.hasMoreElements() ? Boolean.TRUE : Boolean.FALSE;
/*    */         } else {
/* 57 */           result = super.getProperty(context, target, name);
/*    */         }
/*    */       }
/*    */     } else {
/* 61 */       result = super.getProperty(context, target, name);
/*    */     }
/* 63 */     return result;
/*    */   }
/*    */   
/*    */   public void setProperty(Map context, Object target, Object name, Object value) throws OgnlException
/*    */   {
/* 68 */     throw new IllegalArgumentException("can't set property " + name + " on Enumeration");
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\EnumerationPropertyAccessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */