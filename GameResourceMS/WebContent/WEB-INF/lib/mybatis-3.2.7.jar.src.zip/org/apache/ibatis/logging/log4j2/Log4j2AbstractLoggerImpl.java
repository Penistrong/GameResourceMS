/*    */ package org.apache.ibatis.logging.log4j2;
/*    */ 
/*    */ import org.apache.ibatis.logging.Log;
/*    */ import org.apache.logging.log4j.Level;
/*    */ import org.apache.logging.log4j.Marker;
/*    */ import org.apache.logging.log4j.MarkerManager;
/*    */ import org.apache.logging.log4j.message.SimpleMessage;
/*    */ import org.apache.logging.log4j.spi.AbstractLogger;
/*    */ import org.apache.logging.log4j.spi.AbstractLoggerWrapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Log4j2AbstractLoggerImpl
/*    */   implements Log
/*    */ {
/* 32 */   private static Marker MARKER = MarkerManager.getMarker("MYBATIS");
/*    */   
/* 34 */   private static final String FQCN = Log4j2Impl.class.getName();
/*    */   private AbstractLoggerWrapper log;
/*    */   
/*    */   public Log4j2AbstractLoggerImpl(AbstractLogger abstractLogger)
/*    */   {
/* 39 */     this.log = new AbstractLoggerWrapper(abstractLogger, abstractLogger.getName(), abstractLogger.getMessageFactory());
/*    */   }
/*    */   
/*    */   public boolean isDebugEnabled() {
/* 43 */     return this.log.isDebugEnabled();
/*    */   }
/*    */   
/*    */   public boolean isTraceEnabled() {
/* 47 */     return this.log.isTraceEnabled();
/*    */   }
/*    */   
/*    */   public void error(String s, Throwable e) {
/* 51 */     this.log.log(MARKER, FQCN, Level.ERROR, new SimpleMessage(s), e);
/*    */   }
/*    */   
/*    */   public void error(String s) {
/* 55 */     this.log.log(MARKER, FQCN, Level.ERROR, new SimpleMessage(s), null);
/*    */   }
/*    */   
/*    */   public void debug(String s) {
/* 59 */     this.log.log(MARKER, FQCN, Level.DEBUG, new SimpleMessage(s), null);
/*    */   }
/*    */   
/*    */   public void trace(String s) {
/* 63 */     this.log.log(MARKER, FQCN, Level.TRACE, new SimpleMessage(s), null);
/*    */   }
/*    */   
/*    */   public void warn(String s) {
/* 67 */     this.log.log(MARKER, FQCN, Level.WARN, new SimpleMessage(s), null);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\logging\log4j2\Log4j2AbstractLoggerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */