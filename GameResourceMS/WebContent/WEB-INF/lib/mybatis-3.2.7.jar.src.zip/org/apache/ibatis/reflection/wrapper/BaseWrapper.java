/*     */ package org.apache.ibatis.reflection.wrapper;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.ibatis.reflection.MetaObject;
/*     */ import org.apache.ibatis.reflection.ReflectionException;
/*     */ import org.apache.ibatis.reflection.property.PropertyTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseWrapper
/*     */   implements ObjectWrapper
/*     */ {
/*  30 */   protected static final Object[] NO_ARGUMENTS = new Object[0];
/*     */   protected MetaObject metaObject;
/*     */   
/*     */   protected BaseWrapper(MetaObject metaObject) {
/*  34 */     this.metaObject = metaObject;
/*     */   }
/*     */   
/*     */   protected Object resolveCollection(PropertyTokenizer prop, Object object) {
/*  38 */     if ("".equals(prop.getName())) {
/*  39 */       return object;
/*     */     }
/*  41 */     return this.metaObject.getValue(prop.getName());
/*     */   }
/*     */   
/*     */   protected Object getCollectionValue(PropertyTokenizer prop, Object collection)
/*     */   {
/*  46 */     if ((collection instanceof Map)) {
/*  47 */       return ((Map)collection).get(prop.getIndex());
/*     */     }
/*  49 */     int i = Integer.parseInt(prop.getIndex());
/*  50 */     if ((collection instanceof List))
/*  51 */       return ((List)collection).get(i);
/*  52 */     if ((collection instanceof Object[]))
/*  53 */       return ((Object[])(Object[])collection)[i];
/*  54 */     if ((collection instanceof char[]))
/*  55 */       return Character.valueOf(((char[])(char[])collection)[i]);
/*  56 */     if ((collection instanceof boolean[]))
/*  57 */       return Boolean.valueOf(((boolean[])(boolean[])collection)[i]);
/*  58 */     if ((collection instanceof byte[]))
/*  59 */       return Byte.valueOf(((byte[])(byte[])collection)[i]);
/*  60 */     if ((collection instanceof double[]))
/*  61 */       return Double.valueOf(((double[])(double[])collection)[i]);
/*  62 */     if ((collection instanceof float[]))
/*  63 */       return Float.valueOf(((float[])(float[])collection)[i]);
/*  64 */     if ((collection instanceof int[]))
/*  65 */       return Integer.valueOf(((int[])(int[])collection)[i]);
/*  66 */     if ((collection instanceof long[]))
/*  67 */       return Long.valueOf(((long[])(long[])collection)[i]);
/*  68 */     if ((collection instanceof short[])) {
/*  69 */       return Short.valueOf(((short[])(short[])collection)[i]);
/*     */     }
/*  71 */     throw new ReflectionException("The '" + prop.getName() + "' property of " + collection + " is not a List or Array.");
/*     */   }
/*     */   
/*     */ 
/*     */   protected void setCollectionValue(PropertyTokenizer prop, Object collection, Object value)
/*     */   {
/*  77 */     if ((collection instanceof Map)) {
/*  78 */       ((Map)collection).put(prop.getIndex(), value);
/*     */     } else {
/*  80 */       int i = Integer.parseInt(prop.getIndex());
/*  81 */       if ((collection instanceof List)) {
/*  82 */         ((List)collection).set(i, value);
/*  83 */       } else if ((collection instanceof Object[])) {
/*  84 */         ((Object[])collection)[i] = value;
/*  85 */       } else if ((collection instanceof char[])) {
/*  86 */         ((char[])collection)[i] = ((Character)value).charValue();
/*  87 */       } else if ((collection instanceof boolean[])) {
/*  88 */         ((boolean[])collection)[i] = ((Boolean)value).booleanValue();
/*  89 */       } else if ((collection instanceof byte[])) {
/*  90 */         ((byte[])collection)[i] = ((Byte)value).byteValue();
/*  91 */       } else if ((collection instanceof double[])) {
/*  92 */         ((double[])collection)[i] = ((Double)value).doubleValue();
/*  93 */       } else if ((collection instanceof float[])) {
/*  94 */         ((float[])collection)[i] = ((Float)value).floatValue();
/*  95 */       } else if ((collection instanceof int[])) {
/*  96 */         ((int[])collection)[i] = ((Integer)value).intValue();
/*  97 */       } else if ((collection instanceof long[])) {
/*  98 */         ((long[])collection)[i] = ((Long)value).longValue();
/*  99 */       } else if ((collection instanceof short[])) {
/* 100 */         ((short[])collection)[i] = ((Short)value).shortValue();
/*     */       } else {
/* 102 */         throw new ReflectionException("The '" + prop.getName() + "' property of " + collection + " is not a List or Array.");
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\wrapper\BaseWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */