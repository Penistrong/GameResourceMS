/*    */ package org.apache.ibatis.scripting;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LanguageDriverRegistry
/*    */ {
/* 26 */   private final Map<Class<?>, LanguageDriver> LANGUAGE_DRIVER_MAP = new HashMap();
/*    */   
/* 28 */   private Class<?> defaultDriverClass = null;
/*    */   
/*    */   public void register(Class<?> cls) {
/* 31 */     if (cls == null) {
/* 32 */       throw new IllegalArgumentException("null is not a valid Language Driver");
/*    */     }
/* 34 */     if (!LanguageDriver.class.isAssignableFrom(cls)) {
/* 35 */       throw new ScriptingException(cls.getName() + " does not implements " + LanguageDriver.class.getName());
/*    */     }
/* 37 */     LanguageDriver driver = (LanguageDriver)this.LANGUAGE_DRIVER_MAP.get(cls);
/* 38 */     if (driver == null) {
/*    */       try {
/* 40 */         driver = (LanguageDriver)cls.newInstance();
/* 41 */         this.LANGUAGE_DRIVER_MAP.put(cls, driver);
/*    */       } catch (Exception ex) {
/* 43 */         throw new ScriptingException("Failed to load language driver for " + cls.getName(), ex);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public LanguageDriver getDriver(Class<?> cls) {
/* 49 */     return (LanguageDriver)this.LANGUAGE_DRIVER_MAP.get(cls);
/*    */   }
/*    */   
/*    */   public LanguageDriver getDefaultDriver() {
/* 53 */     return getDriver(getDefaultDriverClass());
/*    */   }
/*    */   
/*    */   public Class<?> getDefaultDriverClass() {
/* 57 */     return this.defaultDriverClass;
/*    */   }
/*    */   
/*    */   public void setDefaultDriverClass(Class<?> defaultDriverClass) {
/* 61 */     register(defaultDriverClass);
/* 62 */     this.defaultDriverClass = defaultDriverClass;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\LanguageDriverRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */