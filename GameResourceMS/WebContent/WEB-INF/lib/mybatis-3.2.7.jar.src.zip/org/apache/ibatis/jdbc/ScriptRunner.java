/*     */ package org.apache.ibatis.jdbc;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScriptRunner
/*     */ {
/*  33 */   private static final String LINE_SEPARATOR = System.getProperty("line.separator", "\n");
/*     */   
/*     */   private static final String DEFAULT_DELIMITER = ";";
/*     */   
/*     */   private Connection connection;
/*     */   
/*     */   private boolean stopOnError;
/*     */   private boolean autoCommit;
/*     */   private boolean sendFullScript;
/*     */   private boolean removeCRs;
/*  43 */   private boolean escapeProcessing = true;
/*     */   
/*  45 */   private PrintWriter logWriter = new PrintWriter(System.out);
/*  46 */   private PrintWriter errorLogWriter = new PrintWriter(System.err);
/*     */   
/*  48 */   private String delimiter = ";";
/*  49 */   private boolean fullLineDelimiter = false;
/*     */   
/*     */   public ScriptRunner(Connection connection) {
/*  52 */     this.connection = connection;
/*     */   }
/*     */   
/*     */   public void setStopOnError(boolean stopOnError) {
/*  56 */     this.stopOnError = stopOnError;
/*     */   }
/*     */   
/*     */   public void setAutoCommit(boolean autoCommit) {
/*  60 */     this.autoCommit = autoCommit;
/*     */   }
/*     */   
/*     */   public void setSendFullScript(boolean sendFullScript) {
/*  64 */     this.sendFullScript = sendFullScript;
/*     */   }
/*     */   
/*     */   public void setRemoveCRs(boolean removeCRs) {
/*  68 */     this.removeCRs = removeCRs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setEscapeProcessing(boolean escapeProcessing)
/*     */   {
/*  75 */     this.escapeProcessing = escapeProcessing;
/*     */   }
/*     */   
/*     */   public void setLogWriter(PrintWriter logWriter) {
/*  79 */     this.logWriter = logWriter;
/*     */   }
/*     */   
/*     */   public void setErrorLogWriter(PrintWriter errorLogWriter) {
/*  83 */     this.errorLogWriter = errorLogWriter;
/*     */   }
/*     */   
/*     */   public void setDelimiter(String delimiter) {
/*  87 */     this.delimiter = delimiter;
/*     */   }
/*     */   
/*     */   public void setFullLineDelimiter(boolean fullLineDelimiter) {
/*  91 */     this.fullLineDelimiter = fullLineDelimiter;
/*     */   }
/*     */   
/*     */   public void runScript(Reader reader) {
/*  95 */     setAutoCommit();
/*     */     try
/*     */     {
/*  98 */       if (this.sendFullScript) {
/*  99 */         executeFullScript(reader);
/*     */       } else {
/* 101 */         executeLineByLine(reader);
/*     */       }
/*     */     } finally {
/* 104 */       rollbackConnection();
/*     */     }
/*     */   }
/*     */   
/*     */   private void executeFullScript(Reader reader) {
/* 109 */     StringBuilder script = new StringBuilder();
/*     */     try {
/* 111 */       BufferedReader lineReader = new BufferedReader(reader);
/*     */       String line;
/* 113 */       while ((line = lineReader.readLine()) != null) {
/* 114 */         script.append(line);
/* 115 */         script.append(LINE_SEPARATOR);
/*     */       }
/* 117 */       executeStatement(script.toString());
/* 118 */       commitConnection();
/*     */     } catch (Exception e) {
/* 120 */       String message = "Error executing: " + script + ".  Cause: " + e;
/* 121 */       printlnError(message);
/* 122 */       throw new RuntimeSqlException(message, e);
/*     */     }
/*     */   }
/*     */   
/*     */   private void executeLineByLine(Reader reader) {
/* 127 */     StringBuilder command = new StringBuilder();
/*     */     try {
/* 129 */       BufferedReader lineReader = new BufferedReader(reader);
/*     */       String line;
/* 131 */       while ((line = lineReader.readLine()) != null) {
/* 132 */         command = handleLine(command, line);
/*     */       }
/* 134 */       commitConnection();
/* 135 */       checkForMissingLineTerminator(command);
/*     */     } catch (Exception e) {
/* 137 */       String message = "Error executing: " + command + ".  Cause: " + e;
/* 138 */       printlnError(message);
/* 139 */       throw new RuntimeSqlException(message, e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void closeConnection() {
/*     */     try {
/* 145 */       this.connection.close();
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */   private void setAutoCommit()
/*     */   {
/*     */     try {
/* 153 */       if (this.autoCommit != this.connection.getAutoCommit()) {
/* 154 */         this.connection.setAutoCommit(this.autoCommit);
/*     */       }
/*     */     } catch (Throwable t) {
/* 157 */       throw new RuntimeSqlException("Could not set AutoCommit to " + this.autoCommit + ". Cause: " + t, t);
/*     */     }
/*     */   }
/*     */   
/*     */   private void commitConnection() {
/*     */     try {
/* 163 */       if (!this.connection.getAutoCommit()) {
/* 164 */         this.connection.commit();
/*     */       }
/*     */     } catch (Throwable t) {
/* 167 */       throw new RuntimeSqlException("Could not commit transaction. Cause: " + t, t);
/*     */     }
/*     */   }
/*     */   
/*     */   private void rollbackConnection() {
/*     */     try {
/* 173 */       if (!this.connection.getAutoCommit()) {
/* 174 */         this.connection.rollback();
/*     */       }
/*     */     }
/*     */     catch (Throwable t) {}
/*     */   }
/*     */   
/*     */   private void checkForMissingLineTerminator(StringBuilder command)
/*     */   {
/* 182 */     if ((command != null) && (command.toString().trim().length() > 0)) {
/* 183 */       throw new RuntimeSqlException("Line missing end-of-line terminator (" + this.delimiter + ") => " + command);
/*     */     }
/*     */   }
/*     */   
/*     */   private StringBuilder handleLine(StringBuilder command, String line) throws SQLException, UnsupportedEncodingException {
/* 188 */     String trimmedLine = line.trim();
/* 189 */     if (lineIsComment(trimmedLine)) {
/* 190 */       println(trimmedLine);
/* 191 */     } else if (commandReadyToExecute(trimmedLine)) {
/* 192 */       command.append(line.substring(0, line.lastIndexOf(this.delimiter)));
/* 193 */       command.append(LINE_SEPARATOR);
/* 194 */       println(command);
/* 195 */       executeStatement(command.toString());
/* 196 */       command.setLength(0);
/* 197 */     } else if (trimmedLine.length() > 0) {
/* 198 */       command.append(line);
/* 199 */       command.append(LINE_SEPARATOR);
/*     */     }
/* 201 */     return command;
/*     */   }
/*     */   
/*     */   private boolean lineIsComment(String trimmedLine) {
/* 205 */     return (trimmedLine.startsWith("//")) || (trimmedLine.startsWith("--"));
/*     */   }
/*     */   
/*     */   private boolean commandReadyToExecute(String trimmedLine)
/*     */   {
/* 210 */     return ((!this.fullLineDelimiter) && (trimmedLine.contains(this.delimiter))) || ((this.fullLineDelimiter) && (trimmedLine.equals(this.delimiter)));
/*     */   }
/*     */   
/*     */   private void executeStatement(String command) throws SQLException, UnsupportedEncodingException {
/* 214 */     boolean hasResults = false;
/* 215 */     Statement statement = this.connection.createStatement();
/* 216 */     statement.setEscapeProcessing(this.escapeProcessing);
/* 217 */     String sql = command;
/* 218 */     if (this.removeCRs)
/* 219 */       sql = sql.replaceAll("\r\n", "\n");
/* 220 */     if (this.stopOnError) {
/* 221 */       hasResults = statement.execute(sql);
/*     */     } else {
/*     */       try {
/* 224 */         hasResults = statement.execute(sql);
/*     */       } catch (SQLException e) {
/* 226 */         String message = "Error executing: " + command + ".  Cause: " + e;
/* 227 */         printlnError(message);
/*     */       }
/*     */     }
/* 230 */     printResults(statement, hasResults);
/*     */     try {
/* 232 */       statement.close();
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */   private void printResults(Statement statement, boolean hasResults)
/*     */   {
/*     */     try {
/* 240 */       if (hasResults) {
/* 241 */         ResultSet rs = statement.getResultSet();
/* 242 */         if (rs != null) {
/* 243 */           ResultSetMetaData md = rs.getMetaData();
/* 244 */           int cols = md.getColumnCount();
/* 245 */           for (int i = 0; i < cols; i++) {
/* 246 */             String name = md.getColumnLabel(i + 1);
/* 247 */             print(name + "\t");
/*     */           }
/* 249 */           println("");
/* 250 */           while (rs.next()) {
/* 251 */             for (int i = 0; i < cols; i++) {
/* 252 */               String value = rs.getString(i + 1);
/* 253 */               print(value + "\t");
/*     */             }
/* 255 */             println("");
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (SQLException e) {
/* 260 */       printlnError("Error printing results: " + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */   private void print(Object o) {
/* 265 */     if (this.logWriter != null) {
/* 266 */       this.logWriter.print(o);
/* 267 */       this.logWriter.flush();
/*     */     }
/*     */   }
/*     */   
/*     */   private void println(Object o) {
/* 272 */     if (this.logWriter != null) {
/* 273 */       this.logWriter.println(o);
/* 274 */       this.logWriter.flush();
/*     */     }
/*     */   }
/*     */   
/*     */   private void printlnError(Object o) {
/* 279 */     if (this.errorLogWriter != null) {
/* 280 */       this.errorLogWriter.println(o);
/* 281 */       this.errorLogWriter.flush();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\jdbc\ScriptRunner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */