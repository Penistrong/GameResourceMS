/*     */ package org.apache.ibatis.cache;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CacheKey
/*     */   implements Cloneable, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1146682552656046210L;
/*  30 */   public static final CacheKey NULL_CACHE_KEY = new NullCacheKey();
/*     */   
/*     */   private static final int DEFAULT_MULTIPLYER = 37;
/*     */   private static final int DEFAULT_HASHCODE = 17;
/*     */   private int multiplier;
/*     */   private int hashcode;
/*     */   private long checksum;
/*     */   private int count;
/*     */   private List<Object> updateList;
/*     */   
/*     */   public CacheKey()
/*     */   {
/*  42 */     this.hashcode = 17;
/*  43 */     this.multiplier = 37;
/*  44 */     this.count = 0;
/*  45 */     this.updateList = new ArrayList();
/*     */   }
/*     */   
/*     */   public CacheKey(Object[] objects) {
/*  49 */     this();
/*  50 */     updateAll(objects);
/*     */   }
/*     */   
/*     */   public int getUpdateCount() {
/*  54 */     return this.updateList.size();
/*     */   }
/*     */   
/*     */   public void update(Object object) {
/*  58 */     if ((object != null) && (object.getClass().isArray())) {
/*  59 */       int length = Array.getLength(object);
/*  60 */       for (int i = 0; i < length; i++) {
/*  61 */         Object element = Array.get(object, i);
/*  62 */         doUpdate(element);
/*     */       }
/*     */     } else {
/*  65 */       doUpdate(object);
/*     */     }
/*     */   }
/*     */   
/*     */   private void doUpdate(Object object) {
/*  70 */     int baseHashCode = object == null ? 1 : object.hashCode();
/*     */     
/*  72 */     this.count += 1;
/*  73 */     this.checksum += baseHashCode;
/*  74 */     baseHashCode *= this.count;
/*     */     
/*  76 */     this.hashcode = (this.multiplier * this.hashcode + baseHashCode);
/*     */     
/*  78 */     this.updateList.add(object);
/*     */   }
/*     */   
/*     */   public void updateAll(Object[] objects) {
/*  82 */     for (Object o : objects) {
/*  83 */       update(o);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/*  88 */     if (this == object)
/*  89 */       return true;
/*  90 */     if (!(object instanceof CacheKey)) {
/*  91 */       return false;
/*     */     }
/*  93 */     CacheKey cacheKey = (CacheKey)object;
/*     */     
/*  95 */     if (this.hashcode != cacheKey.hashcode)
/*  96 */       return false;
/*  97 */     if (this.checksum != cacheKey.checksum)
/*  98 */       return false;
/*  99 */     if (this.count != cacheKey.count) {
/* 100 */       return false;
/*     */     }
/* 102 */     for (int i = 0; i < this.updateList.size(); i++) {
/* 103 */       Object thisObject = this.updateList.get(i);
/* 104 */       Object thatObject = cacheKey.updateList.get(i);
/* 105 */       if (thisObject == null) {
/* 106 */         if (thatObject != null) {
/* 107 */           return false;
/*     */         }
/* 109 */       } else if (!thisObject.equals(thatObject)) {
/* 110 */         return false;
/*     */       }
/*     */     }
/* 113 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 117 */     return this.hashcode;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 121 */     StringBuilder returnValue = new StringBuilder().append(this.hashcode).append(':').append(this.checksum);
/* 122 */     for (int i = 0; i < this.updateList.size(); i++) {
/* 123 */       returnValue.append(':').append(this.updateList.get(i));
/*     */     }
/*     */     
/* 126 */     return returnValue.toString();
/*     */   }
/*     */   
/*     */   public CacheKey clone() throws CloneNotSupportedException
/*     */   {
/* 131 */     CacheKey clonedCacheKey = (CacheKey)super.clone();
/* 132 */     clonedCacheKey.updateList = new ArrayList(this.updateList);
/* 133 */     return clonedCacheKey;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\cache\CacheKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */