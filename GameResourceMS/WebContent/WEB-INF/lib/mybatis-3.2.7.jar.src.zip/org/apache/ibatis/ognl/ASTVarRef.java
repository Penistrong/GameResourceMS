/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTVarRef
/*    */   extends SimpleNode
/*    */ {
/*    */   private String name;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ASTVarRef(int id)
/*    */   {
/* 42 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTVarRef(OgnlParser p, int id) {
/* 46 */     super(p, id);
/*    */   }
/*    */   
/*    */   void setName(String name) {
/* 50 */     this.name = name;
/*    */   }
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/* 54 */     return context.get(this.name);
/*    */   }
/*    */   
/*    */   protected void setValueBody(OgnlContext context, Object target, Object value) throws OgnlException {
/* 58 */     context.put(this.name, value);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 62 */     return "#" + this.name;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTVarRef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */