/*    */ package org.apache.ibatis.mapping;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.apache.ibatis.reflection.MetaObject;
/*    */ import org.apache.ibatis.session.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BoundSql
/*    */ {
/*    */   private String sql;
/*    */   private List<ParameterMapping> parameterMappings;
/*    */   private Object parameterObject;
/*    */   private Map<String, Object> additionalParameters;
/*    */   private MetaObject metaParameters;
/*    */   
/*    */   public BoundSql(Configuration configuration, String sql, List<ParameterMapping> parameterMappings, Object parameterObject)
/*    */   {
/* 45 */     this.sql = sql;
/* 46 */     this.parameterMappings = parameterMappings;
/* 47 */     this.parameterObject = parameterObject;
/* 48 */     this.additionalParameters = new HashMap();
/* 49 */     this.metaParameters = configuration.newMetaObject(this.additionalParameters);
/*    */   }
/*    */   
/*    */   public String getSql() {
/* 53 */     return this.sql;
/*    */   }
/*    */   
/*    */   public List<ParameterMapping> getParameterMappings() {
/* 57 */     return this.parameterMappings;
/*    */   }
/*    */   
/*    */   public Object getParameterObject() {
/* 61 */     return this.parameterObject;
/*    */   }
/*    */   
/*    */   public boolean hasAdditionalParameter(String name) {
/* 65 */     return this.metaParameters.hasGetter(name);
/*    */   }
/*    */   
/*    */   public void setAdditionalParameter(String name, Object value) {
/* 69 */     this.metaParameters.setValue(name, value);
/*    */   }
/*    */   
/*    */   public Object getAdditionalParameter(String name) {
/* 73 */     return this.metaParameters.getValue(name);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\mapping\BoundSql.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */