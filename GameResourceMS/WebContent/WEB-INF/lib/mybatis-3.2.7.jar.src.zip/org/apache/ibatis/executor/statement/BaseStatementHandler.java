/*     */ package org.apache.ibatis.executor.statement;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import org.apache.ibatis.executor.ErrorContext;
/*     */ import org.apache.ibatis.executor.Executor;
/*     */ import org.apache.ibatis.executor.ExecutorException;
/*     */ import org.apache.ibatis.executor.keygen.KeyGenerator;
/*     */ import org.apache.ibatis.executor.parameter.ParameterHandler;
/*     */ import org.apache.ibatis.executor.resultset.ResultSetHandler;
/*     */ import org.apache.ibatis.mapping.BoundSql;
/*     */ import org.apache.ibatis.mapping.MappedStatement;
/*     */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.session.ResultHandler;
/*     */ import org.apache.ibatis.session.RowBounds;
/*     */ import org.apache.ibatis.type.TypeHandlerRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseStatementHandler
/*     */   implements StatementHandler
/*     */ {
/*     */   protected final Configuration configuration;
/*     */   protected final ObjectFactory objectFactory;
/*     */   protected final TypeHandlerRegistry typeHandlerRegistry;
/*     */   protected final ResultSetHandler resultSetHandler;
/*     */   protected final ParameterHandler parameterHandler;
/*     */   protected final Executor executor;
/*     */   protected final MappedStatement mappedStatement;
/*     */   protected final RowBounds rowBounds;
/*     */   protected BoundSql boundSql;
/*     */   
/*     */   protected BaseStatementHandler(Executor executor, MappedStatement mappedStatement, Object parameterObject, RowBounds rowBounds, ResultHandler resultHandler, BoundSql boundSql)
/*     */   {
/*  54 */     this.configuration = mappedStatement.getConfiguration();
/*  55 */     this.executor = executor;
/*  56 */     this.mappedStatement = mappedStatement;
/*  57 */     this.rowBounds = rowBounds;
/*     */     
/*  59 */     this.typeHandlerRegistry = this.configuration.getTypeHandlerRegistry();
/*  60 */     this.objectFactory = this.configuration.getObjectFactory();
/*     */     
/*  62 */     if (boundSql == null) {
/*  63 */       generateKeys(parameterObject);
/*  64 */       boundSql = mappedStatement.getBoundSql(parameterObject);
/*     */     }
/*     */     
/*  67 */     this.boundSql = boundSql;
/*     */     
/*  69 */     this.parameterHandler = this.configuration.newParameterHandler(mappedStatement, parameterObject, boundSql);
/*  70 */     this.resultSetHandler = this.configuration.newResultSetHandler(executor, mappedStatement, rowBounds, this.parameterHandler, resultHandler, boundSql);
/*     */   }
/*     */   
/*     */   public BoundSql getBoundSql() {
/*  74 */     return this.boundSql;
/*     */   }
/*     */   
/*     */   public ParameterHandler getParameterHandler() {
/*  78 */     return this.parameterHandler;
/*     */   }
/*     */   
/*     */   public Statement prepare(Connection connection) throws SQLException {
/*  82 */     ErrorContext.instance().sql(this.boundSql.getSql());
/*  83 */     Statement statement = null;
/*     */     try {
/*  85 */       statement = instantiateStatement(connection);
/*  86 */       setStatementTimeout(statement);
/*  87 */       setFetchSize(statement);
/*  88 */       return statement;
/*     */     } catch (SQLException e) {
/*  90 */       closeStatement(statement);
/*  91 */       throw e;
/*     */     } catch (Exception e) {
/*  93 */       closeStatement(statement);
/*  94 */       throw new ExecutorException("Error preparing statement.  Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract Statement instantiateStatement(Connection paramConnection) throws SQLException;
/*     */   
/*     */   protected void setStatementTimeout(Statement stmt) throws SQLException {
/* 101 */     Integer timeout = this.mappedStatement.getTimeout();
/* 102 */     Integer defaultTimeout = this.configuration.getDefaultStatementTimeout();
/* 103 */     if (timeout != null) {
/* 104 */       stmt.setQueryTimeout(timeout.intValue());
/* 105 */     } else if (defaultTimeout != null) {
/* 106 */       stmt.setQueryTimeout(defaultTimeout.intValue());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void setFetchSize(Statement stmt) throws SQLException {
/* 111 */     Integer fetchSize = this.mappedStatement.getFetchSize();
/* 112 */     if (fetchSize != null) {
/* 113 */       stmt.setFetchSize(fetchSize.intValue());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void closeStatement(Statement statement) {
/*     */     try {
/* 119 */       if (statement != null) {
/* 120 */         statement.close();
/*     */       }
/*     */     }
/*     */     catch (SQLException e) {}
/*     */   }
/*     */   
/*     */   protected void generateKeys(Object parameter)
/*     */   {
/* 128 */     KeyGenerator keyGenerator = this.mappedStatement.getKeyGenerator();
/* 129 */     ErrorContext.instance().store();
/* 130 */     keyGenerator.processBefore(this.executor, this.mappedStatement, null, parameter);
/* 131 */     ErrorContext.instance().recall();
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\statement\BaseStatementHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */