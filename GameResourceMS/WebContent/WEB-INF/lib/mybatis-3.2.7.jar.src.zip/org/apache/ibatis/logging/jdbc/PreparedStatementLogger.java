/*     */ package org.apache.ibatis.logging.jdbc;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.util.Set;
/*     */ import org.apache.ibatis.logging.Log;
/*     */ import org.apache.ibatis.reflection.ExceptionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PreparedStatementLogger
/*     */   extends BaseJdbcLogger
/*     */   implements InvocationHandler
/*     */ {
/*     */   private PreparedStatement statement;
/*     */   
/*     */   private PreparedStatementLogger(PreparedStatement stmt, Log statementLog, int queryStack)
/*     */   {
/*  40 */     super(statementLog, queryStack);
/*  41 */     this.statement = stmt;
/*     */   }
/*     */   
/*     */   public Object invoke(Object proxy, Method method, Object[] params) throws Throwable {
/*     */     try {
/*  46 */       if (Object.class.equals(method.getDeclaringClass())) {
/*  47 */         return method.invoke(this, params);
/*     */       }
/*  49 */       if (EXECUTE_METHODS.contains(method.getName())) {
/*  50 */         if (isDebugEnabled()) {
/*  51 */           debug("Parameters: " + getParameterValueString(), true);
/*     */         }
/*  53 */         clearColumnInfo();
/*  54 */         if ("executeQuery".equals(method.getName())) {
/*  55 */           ResultSet rs = (ResultSet)method.invoke(this.statement, params);
/*  56 */           if (rs != null) {
/*  57 */             return ResultSetLogger.newInstance(rs, this.statementLog, this.queryStack);
/*     */           }
/*  59 */           return null;
/*     */         }
/*     */         
/*  62 */         return method.invoke(this.statement, params);
/*     */       }
/*  64 */       if (SET_METHODS.contains(method.getName())) {
/*  65 */         if ("setNull".equals(method.getName())) {
/*  66 */           setColumn(params[0], null);
/*     */         } else {
/*  68 */           setColumn(params[0], params[1]);
/*     */         }
/*  70 */         return method.invoke(this.statement, params); }
/*  71 */       if ("getResultSet".equals(method.getName())) {
/*  72 */         ResultSet rs = (ResultSet)method.invoke(this.statement, params);
/*  73 */         if (rs != null) {
/*  74 */           return ResultSetLogger.newInstance(rs, this.statementLog, this.queryStack);
/*     */         }
/*  76 */         return null;
/*     */       }
/*  78 */       if ("getUpdateCount".equals(method.getName())) {
/*  79 */         int updateCount = ((Integer)method.invoke(this.statement, params)).intValue();
/*  80 */         if (updateCount != -1) {
/*  81 */           debug("   Updates: " + updateCount, false);
/*     */         }
/*  83 */         return Integer.valueOf(updateCount);
/*     */       }
/*  85 */       return method.invoke(this.statement, params);
/*     */     }
/*     */     catch (Throwable t) {
/*  88 */       throw ExceptionUtil.unwrapThrowable(t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PreparedStatement newInstance(PreparedStatement stmt, Log statementLog, int queryStack)
/*     */   {
/* 100 */     InvocationHandler handler = new PreparedStatementLogger(stmt, statementLog, queryStack);
/* 101 */     ClassLoader cl = PreparedStatement.class.getClassLoader();
/* 102 */     return (PreparedStatement)Proxy.newProxyInstance(cl, new Class[] { PreparedStatement.class, CallableStatement.class }, handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PreparedStatement getPreparedStatement()
/*     */   {
/* 111 */     return this.statement;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\logging\jdbc\PreparedStatementLogger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */