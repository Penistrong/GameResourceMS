/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnumOrdinalTypeHandler<E extends Enum<E>>
/*    */   extends BaseTypeHandler<E>
/*    */ {
/*    */   private Class<E> type;
/*    */   private final E[] enums;
/*    */   
/*    */   public EnumOrdinalTypeHandler(Class<E> type)
/*    */   {
/* 32 */     if (type == null) throw new IllegalArgumentException("Type argument cannot be null");
/* 33 */     this.type = type;
/* 34 */     this.enums = ((Enum[])type.getEnumConstants());
/* 35 */     if (this.enums == null) throw new IllegalArgumentException(type.getSimpleName() + " does not represent an enum type.");
/*    */   }
/*    */   
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, E parameter, JdbcType jdbcType) throws SQLException
/*    */   {
/* 40 */     ps.setInt(i, parameter.ordinal());
/*    */   }
/*    */   
/*    */   public E getNullableResult(ResultSet rs, String columnName) throws SQLException
/*    */   {
/* 45 */     int i = rs.getInt(columnName);
/* 46 */     if (rs.wasNull()) {
/* 47 */       return null;
/*    */     }
/*    */     try {
/* 50 */       return this.enums[i];
/*    */     } catch (Exception ex) {
/* 52 */       throw new IllegalArgumentException("Cannot convert " + i + " to " + this.type.getSimpleName() + " by ordinal value.", ex);
/*    */     }
/*    */   }
/*    */   
/*    */   public E getNullableResult(ResultSet rs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 59 */     int i = rs.getInt(columnIndex);
/* 60 */     if (rs.wasNull()) {
/* 61 */       return null;
/*    */     }
/*    */     try {
/* 64 */       return this.enums[i];
/*    */     } catch (Exception ex) {
/* 66 */       throw new IllegalArgumentException("Cannot convert " + i + " to " + this.type.getSimpleName() + " by ordinal value.", ex);
/*    */     }
/*    */   }
/*    */   
/*    */   public E getNullableResult(CallableStatement cs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 73 */     int i = cs.getInt(columnIndex);
/* 74 */     if (cs.wasNull()) {
/* 75 */       return null;
/*    */     }
/*    */     try {
/* 78 */       return this.enums[i];
/*    */     } catch (Exception ex) {
/* 80 */       throw new IllegalArgumentException("Cannot convert " + i + " to " + this.type.getSimpleName() + " by ordinal value.", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\EnumOrdinalTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */