package org.apache.ibatis.executor.keygen;

import java.sql.Statement;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.MappedStatement;

public class NoKeyGenerator
  implements KeyGenerator
{
  public void processBefore(Executor executor, MappedStatement ms, Statement stmt, Object parameter) {}
  
  public void processAfter(Executor executor, MappedStatement ms, Statement stmt, Object parameter) {}
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\keygen\NoKeyGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */