/*    */ package org.apache.ibatis.scripting.xmltags;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import java.math.BigDecimal;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.apache.ibatis.builder.BuilderException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExpressionEvaluator
/*    */ {
/*    */   public boolean evaluateBoolean(String expression, Object parameterObject)
/*    */   {
/* 32 */     Object value = OgnlCache.getValue(expression, parameterObject);
/* 33 */     if ((value instanceof Boolean)) return ((Boolean)value).booleanValue();
/* 34 */     if ((value instanceof Number)) return !new BigDecimal(String.valueOf(value)).equals(BigDecimal.ZERO);
/* 35 */     return value != null;
/*    */   }
/*    */   
/*    */   public Iterable<?> evaluateIterable(String expression, Object parameterObject) {
/* 39 */     Object value = OgnlCache.getValue(expression, parameterObject);
/* 40 */     if (value == null) throw new BuilderException("The expression '" + expression + "' evaluated to a null value.");
/* 41 */     if ((value instanceof Iterable)) return (Iterable)value;
/* 42 */     if (value.getClass().isArray())
/*    */     {
/*    */ 
/*    */ 
/* 46 */       int size = Array.getLength(value);
/* 47 */       List<Object> answer = new ArrayList();
/* 48 */       for (int i = 0; i < size; i++) {
/* 49 */         Object o = Array.get(value, i);
/* 50 */         answer.add(o);
/*    */       }
/* 52 */       return answer;
/*    */     }
/* 54 */     if ((value instanceof Map)) {
/* 55 */       return ((Map)value).entrySet();
/*    */     }
/* 57 */     throw new BuilderException("Error evaluating expression '" + expression + "'.  Return value (" + value + ") was not iterable.");
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\xmltags\ExpressionEvaluator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */