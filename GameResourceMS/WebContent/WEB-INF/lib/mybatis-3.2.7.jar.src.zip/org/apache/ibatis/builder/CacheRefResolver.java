/*    */ package org.apache.ibatis.builder;
/*    */ 
/*    */ import org.apache.ibatis.cache.Cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheRefResolver
/*    */ {
/*    */   private final MapperBuilderAssistant assistant;
/*    */   private final String cacheRefNamespace;
/*    */   
/*    */   public CacheRefResolver(MapperBuilderAssistant assistant, String cacheRefNamespace)
/*    */   {
/* 27 */     this.assistant = assistant;
/* 28 */     this.cacheRefNamespace = cacheRefNamespace;
/*    */   }
/*    */   
/* 31 */   public Cache resolveCacheRef() { return this.assistant.useCacheRef(this.cacheRefNamespace); }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\builder\CacheRefResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */