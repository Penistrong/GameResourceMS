/*     */ package org.apache.ibatis.scripting.xmltags;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.ibatis.parsing.GenericTokenParser;
/*     */ import org.apache.ibatis.parsing.TokenHandler;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForEachSqlNode
/*     */   implements SqlNode
/*     */ {
/*     */   public static final String ITEM_PREFIX = "__frch_";
/*     */   private ExpressionEvaluator evaluator;
/*     */   private String collectionExpression;
/*     */   private SqlNode contents;
/*     */   private String open;
/*     */   private String close;
/*     */   private String separator;
/*     */   private String item;
/*     */   private String index;
/*     */   private Configuration configuration;
/*     */   
/*     */   public ForEachSqlNode(Configuration configuration, SqlNode contents, String collectionExpression, String index, String item, String open, String close, String separator)
/*     */   {
/*  41 */     this.evaluator = new ExpressionEvaluator();
/*  42 */     this.collectionExpression = collectionExpression;
/*  43 */     this.contents = contents;
/*  44 */     this.open = open;
/*  45 */     this.close = close;
/*  46 */     this.separator = separator;
/*  47 */     this.index = index;
/*  48 */     this.item = item;
/*  49 */     this.configuration = configuration;
/*     */   }
/*     */   
/*     */   public boolean apply(DynamicContext context) {
/*  53 */     Map<String, Object> bindings = context.getBindings();
/*  54 */     Iterable<?> iterable = this.evaluator.evaluateIterable(this.collectionExpression, bindings);
/*  55 */     boolean first = true;
/*  56 */     applyOpen(context);
/*  57 */     int i = 0;
/*  58 */     for (Object o : iterable) {
/*  59 */       DynamicContext oldContext = context;
/*  60 */       if (first) {
/*  61 */         context = new PrefixedContext(context, "");
/*     */       }
/*  63 */       else if (this.separator != null) {
/*  64 */         context = new PrefixedContext(context, this.separator);
/*     */       } else {
/*  66 */         context = new PrefixedContext(context, "");
/*     */       }
/*     */       
/*  69 */       int uniqueNumber = context.getUniqueNumber();
/*  70 */       if ((o instanceof Map.Entry))
/*     */       {
/*  72 */         Map.Entry<Object, Object> mapEntry = (Map.Entry)o;
/*  73 */         applyIndex(context, mapEntry.getKey(), uniqueNumber);
/*  74 */         applyItem(context, mapEntry.getValue(), uniqueNumber);
/*     */       } else {
/*  76 */         applyIndex(context, Integer.valueOf(i), uniqueNumber);
/*  77 */         applyItem(context, o, uniqueNumber);
/*     */       }
/*  79 */       this.contents.apply(new FilteredDynamicContext(this.configuration, context, this.index, this.item, uniqueNumber));
/*  80 */       if (first) first = !((PrefixedContext)context).isPrefixApplied();
/*  81 */       context = oldContext;
/*  82 */       i++;
/*     */     }
/*  84 */     applyClose(context);
/*  85 */     return true;
/*     */   }
/*     */   
/*     */   private void applyIndex(DynamicContext context, Object o, int i) {
/*  89 */     if (this.index != null) {
/*  90 */       context.bind(this.index, o);
/*  91 */       context.bind(itemizeItem(this.index, i), o);
/*     */     }
/*     */   }
/*     */   
/*     */   private void applyItem(DynamicContext context, Object o, int i) {
/*  96 */     if (this.item != null) {
/*  97 */       context.bind(this.item, o);
/*  98 */       context.bind(itemizeItem(this.item, i), o);
/*     */     }
/*     */   }
/*     */   
/*     */   private void applyOpen(DynamicContext context) {
/* 103 */     if (this.open != null) {
/* 104 */       context.appendSql(this.open);
/*     */     }
/*     */   }
/*     */   
/*     */   private void applyClose(DynamicContext context) {
/* 109 */     if (this.close != null) {
/* 110 */       context.appendSql(this.close);
/*     */     }
/*     */   }
/*     */   
/*     */   private static String itemizeItem(String item, int i) {
/* 115 */     return "__frch_" + item + "_" + i;
/*     */   }
/*     */   
/*     */   private static class FilteredDynamicContext extends DynamicContext {
/*     */     private DynamicContext delegate;
/*     */     private int index;
/*     */     private String itemIndex;
/*     */     private String item;
/*     */     
/*     */     public FilteredDynamicContext(Configuration configuration, DynamicContext delegate, String itemIndex, String item, int i) {
/* 125 */       super(null);
/* 126 */       this.delegate = delegate;
/* 127 */       this.index = i;
/* 128 */       this.itemIndex = itemIndex;
/* 129 */       this.item = item;
/*     */     }
/*     */     
/*     */     public Map<String, Object> getBindings()
/*     */     {
/* 134 */       return this.delegate.getBindings();
/*     */     }
/*     */     
/*     */     public void bind(String name, Object value)
/*     */     {
/* 139 */       this.delegate.bind(name, value);
/*     */     }
/*     */     
/*     */     public String getSql()
/*     */     {
/* 144 */       return this.delegate.getSql();
/*     */     }
/*     */     
/*     */     public void appendSql(String sql)
/*     */     {
/* 149 */       GenericTokenParser parser = new GenericTokenParser("#{", "}", new TokenHandler() {
/*     */         public String handleToken(String content) {
/* 151 */           String newContent = content.replaceFirst("^\\s*" + ForEachSqlNode.FilteredDynamicContext.this.item + "(?![^.,:\\s])", ForEachSqlNode.itemizeItem(ForEachSqlNode.FilteredDynamicContext.this.item, ForEachSqlNode.FilteredDynamicContext.this.index));
/* 152 */           if ((ForEachSqlNode.FilteredDynamicContext.this.itemIndex != null) && (newContent.equals(content))) {
/* 153 */             newContent = content.replaceFirst("^\\s*" + ForEachSqlNode.FilteredDynamicContext.this.itemIndex + "(?![^.,:\\s])", ForEachSqlNode.itemizeItem(ForEachSqlNode.FilteredDynamicContext.this.itemIndex, ForEachSqlNode.FilteredDynamicContext.this.index));
/*     */           }
/* 155 */           return "#{" + newContent + "}";
/*     */         }
/*     */         
/* 158 */       });
/* 159 */       this.delegate.appendSql(parser.parse(sql));
/*     */     }
/*     */     
/*     */     public int getUniqueNumber()
/*     */     {
/* 164 */       return this.delegate.getUniqueNumber();
/*     */     }
/*     */   }
/*     */   
/*     */   private class PrefixedContext extends DynamicContext
/*     */   {
/*     */     private DynamicContext delegate;
/*     */     private String prefix;
/*     */     private boolean prefixApplied;
/*     */     
/*     */     public PrefixedContext(DynamicContext delegate, String prefix)
/*     */     {
/* 176 */       super(null);
/* 177 */       this.delegate = delegate;
/* 178 */       this.prefix = prefix;
/* 179 */       this.prefixApplied = false;
/*     */     }
/*     */     
/*     */     public boolean isPrefixApplied() {
/* 183 */       return this.prefixApplied;
/*     */     }
/*     */     
/*     */     public Map<String, Object> getBindings()
/*     */     {
/* 188 */       return this.delegate.getBindings();
/*     */     }
/*     */     
/*     */     public void bind(String name, Object value)
/*     */     {
/* 193 */       this.delegate.bind(name, value);
/*     */     }
/*     */     
/*     */     public void appendSql(String sql)
/*     */     {
/* 198 */       if ((!this.prefixApplied) && (sql != null) && (sql.trim().length() > 0)) {
/* 199 */         this.delegate.appendSql(this.prefix);
/* 200 */         this.prefixApplied = true;
/*     */       }
/* 202 */       this.delegate.appendSql(sql);
/*     */     }
/*     */     
/*     */     public String getSql()
/*     */     {
/* 207 */       return this.delegate.getSql();
/*     */     }
/*     */     
/*     */     public int getUniqueNumber()
/*     */     {
/* 212 */       return this.delegate.getUniqueNumber();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\xmltags\ForEachSqlNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */