/*     */ package org.apache.ibatis.cache.decorators;
/*     */ 
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.util.LinkedList;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import org.apache.ibatis.cache.Cache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SoftCache
/*     */   implements Cache
/*     */ {
/*     */   private final LinkedList<Object> hardLinksToAvoidGarbageCollection;
/*     */   private final ReferenceQueue<Object> queueOfGarbageCollectedEntries;
/*     */   private final Cache delegate;
/*     */   private int numberOfHardLinks;
/*     */   
/*     */   public SoftCache(Cache delegate)
/*     */   {
/*  38 */     this.delegate = delegate;
/*  39 */     this.numberOfHardLinks = 256;
/*  40 */     this.hardLinksToAvoidGarbageCollection = new LinkedList();
/*  41 */     this.queueOfGarbageCollectedEntries = new ReferenceQueue();
/*     */   }
/*     */   
/*     */   public String getId()
/*     */   {
/*  46 */     return this.delegate.getId();
/*     */   }
/*     */   
/*     */   public int getSize()
/*     */   {
/*  51 */     removeGarbageCollectedItems();
/*  52 */     return this.delegate.getSize();
/*     */   }
/*     */   
/*     */   public void setSize(int size)
/*     */   {
/*  57 */     this.numberOfHardLinks = size;
/*     */   }
/*     */   
/*     */   public void putObject(Object key, Object value)
/*     */   {
/*  62 */     removeGarbageCollectedItems();
/*  63 */     this.delegate.putObject(key, new SoftEntry(key, value, this.queueOfGarbageCollectedEntries, null));
/*     */   }
/*     */   
/*     */   public Object getObject(Object key)
/*     */   {
/*  68 */     Object result = null;
/*     */     
/*  70 */     SoftReference<Object> softReference = (SoftReference)this.delegate.getObject(key);
/*  71 */     if (softReference != null) {
/*  72 */       result = softReference.get();
/*  73 */       if (result == null) {
/*  74 */         this.delegate.removeObject(key);
/*     */       }
/*     */       else {
/*  77 */         synchronized (this.hardLinksToAvoidGarbageCollection) {
/*  78 */           this.hardLinksToAvoidGarbageCollection.addFirst(result);
/*  79 */           if (this.hardLinksToAvoidGarbageCollection.size() > this.numberOfHardLinks) {
/*  80 */             this.hardLinksToAvoidGarbageCollection.removeLast();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  85 */     return result;
/*     */   }
/*     */   
/*     */   public Object removeObject(Object key)
/*     */   {
/*  90 */     removeGarbageCollectedItems();
/*  91 */     return this.delegate.removeObject(key);
/*     */   }
/*     */   
/*     */   public void clear()
/*     */   {
/*  96 */     synchronized (this.hardLinksToAvoidGarbageCollection) {
/*  97 */       this.hardLinksToAvoidGarbageCollection.clear();
/*     */     }
/*  99 */     removeGarbageCollectedItems();
/* 100 */     this.delegate.clear();
/*     */   }
/*     */   
/*     */   public ReadWriteLock getReadWriteLock()
/*     */   {
/* 105 */     return null;
/*     */   }
/*     */   
/*     */   private void removeGarbageCollectedItems() {
/*     */     SoftEntry sv;
/* 110 */     while ((sv = (SoftEntry)this.queueOfGarbageCollectedEntries.poll()) != null) {
/* 111 */       this.delegate.removeObject(sv.key);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SoftEntry extends SoftReference<Object> {
/*     */     private final Object key;
/*     */     
/*     */     private SoftEntry(Object key, Object value, ReferenceQueue<Object> garbageCollectionQueue) {
/* 119 */       super(garbageCollectionQueue);
/* 120 */       this.key = key;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\cache\decorators\SoftCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */