/*    */ package org.apache.ibatis.reflection.invoker;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodInvoker
/*    */   implements Invoker
/*    */ {
/*    */   private Class<?> type;
/*    */   private Method method;
/*    */   
/*    */   public MethodInvoker(Method method)
/*    */   {
/* 30 */     this.method = method;
/*    */     
/* 32 */     if (method.getParameterTypes().length == 1) {
/* 33 */       this.type = method.getParameterTypes()[0];
/*    */     } else {
/* 35 */       this.type = method.getReturnType();
/*    */     }
/*    */   }
/*    */   
/*    */   public Object invoke(Object target, Object[] args) throws IllegalAccessException, InvocationTargetException {
/* 40 */     return this.method.invoke(target, args);
/*    */   }
/*    */   
/*    */   public Class<?> getType() {
/* 44 */     return this.type;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\invoker\MethodInvoker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */