/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteObjectArrayTypeHandler
/*    */   extends BaseTypeHandler<Byte[]>
/*    */ {
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, Byte[] parameter, JdbcType jdbcType)
/*    */     throws SQLException
/*    */   {
/* 30 */     ps.setBytes(i, ByteArrayUtils.convertToPrimitiveArray(parameter));
/*    */   }
/*    */   
/*    */   public Byte[] getNullableResult(ResultSet rs, String columnName) throws SQLException
/*    */   {
/* 35 */     byte[] bytes = rs.getBytes(columnName);
/* 36 */     return getBytes(bytes);
/*    */   }
/*    */   
/*    */   public Byte[] getNullableResult(ResultSet rs, int columnIndex) throws SQLException
/*    */   {
/* 41 */     byte[] bytes = rs.getBytes(columnIndex);
/* 42 */     return getBytes(bytes);
/*    */   }
/*    */   
/*    */   public Byte[] getNullableResult(CallableStatement cs, int columnIndex) throws SQLException
/*    */   {
/* 47 */     byte[] bytes = cs.getBytes(columnIndex);
/* 48 */     return getBytes(bytes);
/*    */   }
/*    */   
/*    */   private Byte[] getBytes(byte[] bytes) {
/* 52 */     Byte[] returnValue = null;
/* 53 */     if (bytes != null) {
/* 54 */       returnValue = ByteArrayUtils.convertToObjectArray(bytes);
/*    */     }
/* 56 */     return returnValue;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\ByteObjectArrayTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */