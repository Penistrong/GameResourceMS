/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EvaluationPool
/*     */ {
/*  37 */   private List evaluations = new ArrayList();
/*  38 */   private int size = 0;
/*  39 */   private int created = 0;
/*  40 */   private int recovered = 0;
/*  41 */   private int recycled = 0;
/*     */   
/*     */   public EvaluationPool()
/*     */   {
/*  45 */     this(0);
/*     */   }
/*     */   
/*     */ 
/*     */   public EvaluationPool(int initialSize)
/*     */   {
/*  51 */     for (int i = 0; i < initialSize; i++) {
/*  52 */       this.evaluations.add(new Evaluation(null, null));
/*     */     }
/*  54 */     this.created = (this.size = initialSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Evaluation create(SimpleNode node, Object source)
/*     */   {
/*  64 */     return create(node, source, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Evaluation create(SimpleNode node, Object source, boolean setOperation)
/*     */   {
/*     */     Evaluation result;
/*     */     
/*     */ 
/*     */ 
/*  76 */     if (this.size > 0) {
/*  77 */       Evaluation result = (Evaluation)this.evaluations.remove(this.size - 1);
/*  78 */       result.init(node, source, setOperation);
/*  79 */       this.size -= 1;
/*  80 */       this.recovered += 1;
/*     */     } else {
/*  82 */       result = new Evaluation(node, source, setOperation);
/*  83 */       this.created += 1;
/*     */     }
/*  85 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void recycle(Evaluation value)
/*     */   {
/*  93 */     if (value != null) {
/*  94 */       value.reset();
/*  95 */       this.evaluations.add(value);
/*  96 */       this.size += 1;
/*  97 */       this.recycled += 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void recycleAll(Evaluation value)
/*     */   {
/* 107 */     if (value != null) {
/* 108 */       recycleAll(value.getNext());
/* 109 */       recycleAll(value.getFirstChild());
/* 110 */       recycle(value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void recycleAll(List value)
/*     */   {
/* 119 */     if (value != null) {
/* 120 */       int i = 0; for (int icount = value.size(); i < icount; i++) {
/* 121 */         recycle((Evaluation)value.get(i));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSize()
/*     */   {
/* 131 */     return this.size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCreatedCount()
/*     */   {
/* 140 */     return this.created;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRecoveredCount()
/*     */   {
/* 149 */     return this.recovered;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRecycledCount()
/*     */   {
/* 158 */     return this.recycled;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\EvaluationPool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */