/*    */ package org.apache.ibatis.io;
/*    */ 
/*    */ import java.io.Closeable;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.nio.channels.FileChannel;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExternalResources
/*    */ {
/*    */   public static void copyExternalResource(File sourceFile, File destFile)
/*    */     throws IOException
/*    */   {
/* 37 */     if (!destFile.exists()) {
/* 38 */       destFile.createNewFile();
/*    */     }
/*    */     
/* 41 */     FileChannel source = null;
/* 42 */     FileChannel destination = null;
/*    */     try {
/* 44 */       source = new FileInputStream(sourceFile).getChannel();
/* 45 */       destination = new FileOutputStream(destFile).getChannel();
/* 46 */       destination.transferFrom(source, 0L, source.size());
/*    */     } finally {
/* 48 */       closeQuietly(source);
/* 49 */       closeQuietly(destination);
/*    */     }
/*    */   }
/*    */   
/*    */   private static void closeQuietly(Closeable closeable)
/*    */   {
/* 55 */     if (closeable != null) {
/*    */       try {
/* 57 */         closeable.close();
/*    */       }
/*    */       catch (IOException e) {}
/*    */     }
/*    */   }
/*    */   
/*    */   public static String getConfiguredTemplate(String templatePath, String templateProperty) throws FileNotFoundException
/*    */   {
/* 65 */     String templateName = "";
/* 66 */     Properties migrationProperties = new Properties();
/*    */     try
/*    */     {
/* 69 */       migrationProperties.load(new FileInputStream(templatePath));
/* 70 */       templateName = migrationProperties.getProperty(templateProperty);
/*    */     } catch (FileNotFoundException e) {
/* 72 */       throw e;
/*    */     } catch (Exception e) {
/* 74 */       e.printStackTrace();
/*    */     }
/*    */     
/* 77 */     return templateName;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\io\ExternalResources.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */