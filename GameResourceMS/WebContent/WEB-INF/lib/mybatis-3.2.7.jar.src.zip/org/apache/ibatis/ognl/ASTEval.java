/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTEval
/*    */   extends SimpleNode
/*    */ {
/*    */   public ASTEval(int id)
/*    */   {
/* 40 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTEval(OgnlParser p, int id) {
/* 44 */     super(p, id);
/*    */   }
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source)
/*    */     throws OgnlException
/*    */   {
/* 50 */     Object expr = this.children[0].getValue(context, source);
/* 51 */     Object previousRoot = context.getRoot();
/*    */     
/*    */ 
/* 54 */     source = this.children[1].getValue(context, source);
/* 55 */     Node node = (expr instanceof Node) ? (Node)expr : (Node)Ognl.parseExpression(expr.toString());
/*    */     try {
/* 57 */       context.setRoot(source);
/* 58 */       result = node.getValue(context, source);
/*    */     } finally { Object result;
/* 60 */       context.setRoot(previousRoot); }
/*    */     Object result;
/* 62 */     return result;
/*    */   }
/*    */   
/*    */   protected void setValueBody(OgnlContext context, Object target, Object value) throws OgnlException
/*    */   {
/* 67 */     Object expr = this.children[0].getValue(context, target);
/* 68 */     Object previousRoot = context.getRoot();
/*    */     
/*    */ 
/* 71 */     target = this.children[1].getValue(context, target);
/* 72 */     Node node = (expr instanceof Node) ? (Node)expr : (Node)Ognl.parseExpression(expr.toString());
/*    */     try {
/* 74 */       context.setRoot(target);
/* 75 */       node.setValue(context, target, value);
/*    */     } finally {
/* 77 */       context.setRoot(previousRoot);
/*    */     }
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 83 */     return "(" + this.children[0] + ")(" + this.children[1] + ")";
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTEval.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */