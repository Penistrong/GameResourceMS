package org.apache.ibatis.reflection.invoker;

import java.lang.reflect.InvocationTargetException;

public abstract interface Invoker
{
  public abstract Object invoke(Object paramObject, Object[] paramArrayOfObject)
    throws IllegalAccessException, InvocationTargetException;
  
  public abstract Class<?> getType();
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\invoker\Invoker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */