/*     */ package org.apache.ibatis.reflection.wrapper;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.apache.ibatis.reflection.ExceptionUtil;
/*     */ import org.apache.ibatis.reflection.MetaClass;
/*     */ import org.apache.ibatis.reflection.MetaObject;
/*     */ import org.apache.ibatis.reflection.ReflectionException;
/*     */ import org.apache.ibatis.reflection.SystemMetaObject;
/*     */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*     */ import org.apache.ibatis.reflection.invoker.Invoker;
/*     */ import org.apache.ibatis.reflection.property.PropertyTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanWrapper
/*     */   extends BaseWrapper
/*     */ {
/*     */   private Object object;
/*     */   private MetaClass metaClass;
/*     */   
/*     */   public BeanWrapper(MetaObject metaObject, Object object)
/*     */   {
/*  38 */     super(metaObject);
/*  39 */     this.object = object;
/*  40 */     this.metaClass = MetaClass.forClass(object.getClass());
/*     */   }
/*     */   
/*     */   public Object get(PropertyTokenizer prop) {
/*  44 */     if (prop.getIndex() != null) {
/*  45 */       Object collection = resolveCollection(prop, this.object);
/*  46 */       return getCollectionValue(prop, collection);
/*     */     }
/*  48 */     return getBeanProperty(prop, this.object);
/*     */   }
/*     */   
/*     */   public void set(PropertyTokenizer prop, Object value)
/*     */   {
/*  53 */     if (prop.getIndex() != null) {
/*  54 */       Object collection = resolveCollection(prop, this.object);
/*  55 */       setCollectionValue(prop, collection, value);
/*     */     } else {
/*  57 */       setBeanProperty(prop, this.object, value);
/*     */     }
/*     */   }
/*     */   
/*     */   public String findProperty(String name, boolean useCamelCaseMapping) {
/*  62 */     return this.metaClass.findProperty(name, useCamelCaseMapping);
/*     */   }
/*     */   
/*     */   public String[] getGetterNames() {
/*  66 */     return this.metaClass.getGetterNames();
/*     */   }
/*     */   
/*     */   public String[] getSetterNames() {
/*  70 */     return this.metaClass.getSetterNames();
/*     */   }
/*     */   
/*     */   public Class<?> getSetterType(String name) {
/*  74 */     PropertyTokenizer prop = new PropertyTokenizer(name);
/*  75 */     if (prop.hasNext()) {
/*  76 */       MetaObject metaValue = this.metaObject.metaObjectForProperty(prop.getIndexedName());
/*  77 */       if (metaValue == SystemMetaObject.NULL_META_OBJECT) {
/*  78 */         return this.metaClass.getSetterType(name);
/*     */       }
/*  80 */       return metaValue.getSetterType(prop.getChildren());
/*     */     }
/*     */     
/*  83 */     return this.metaClass.getSetterType(name);
/*     */   }
/*     */   
/*     */   public Class<?> getGetterType(String name)
/*     */   {
/*  88 */     PropertyTokenizer prop = new PropertyTokenizer(name);
/*  89 */     if (prop.hasNext()) {
/*  90 */       MetaObject metaValue = this.metaObject.metaObjectForProperty(prop.getIndexedName());
/*  91 */       if (metaValue == SystemMetaObject.NULL_META_OBJECT) {
/*  92 */         return this.metaClass.getGetterType(name);
/*     */       }
/*  94 */       return metaValue.getGetterType(prop.getChildren());
/*     */     }
/*     */     
/*  97 */     return this.metaClass.getGetterType(name);
/*     */   }
/*     */   
/*     */   public boolean hasSetter(String name)
/*     */   {
/* 102 */     PropertyTokenizer prop = new PropertyTokenizer(name);
/* 103 */     if (prop.hasNext()) {
/* 104 */       if (this.metaClass.hasSetter(prop.getIndexedName())) {
/* 105 */         MetaObject metaValue = this.metaObject.metaObjectForProperty(prop.getIndexedName());
/* 106 */         if (metaValue == SystemMetaObject.NULL_META_OBJECT) {
/* 107 */           return this.metaClass.hasSetter(name);
/*     */         }
/* 109 */         return metaValue.hasSetter(prop.getChildren());
/*     */       }
/*     */       
/* 112 */       return false;
/*     */     }
/*     */     
/* 115 */     return this.metaClass.hasSetter(name);
/*     */   }
/*     */   
/*     */   public boolean hasGetter(String name)
/*     */   {
/* 120 */     PropertyTokenizer prop = new PropertyTokenizer(name);
/* 121 */     if (prop.hasNext()) {
/* 122 */       if (this.metaClass.hasGetter(prop.getIndexedName())) {
/* 123 */         MetaObject metaValue = this.metaObject.metaObjectForProperty(prop.getIndexedName());
/* 124 */         if (metaValue == SystemMetaObject.NULL_META_OBJECT) {
/* 125 */           return this.metaClass.hasGetter(name);
/*     */         }
/* 127 */         return metaValue.hasGetter(prop.getChildren());
/*     */       }
/*     */       
/* 130 */       return false;
/*     */     }
/*     */     
/* 133 */     return this.metaClass.hasGetter(name);
/*     */   }
/*     */   
/*     */ 
/*     */   public MetaObject instantiatePropertyValue(String name, PropertyTokenizer prop, ObjectFactory objectFactory)
/*     */   {
/* 139 */     Class<?> type = getSetterType(prop.getName());
/*     */     MetaObject metaValue;
/* 141 */     try { Object newObject = objectFactory.create(type);
/* 142 */       metaValue = MetaObject.forObject(newObject, this.metaObject.getObjectFactory(), this.metaObject.getObjectWrapperFactory());
/* 143 */       set(prop, newObject);
/*     */     } catch (Exception e) {
/* 145 */       throw new ReflectionException("Cannot set value of property '" + name + "' because '" + name + "' is null and cannot be instantiated on instance of " + type.getName() + ". Cause:" + e.toString(), e);
/*     */     }
/* 147 */     return metaValue;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private Object getBeanProperty(PropertyTokenizer prop, Object object)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 30	org/apache/ibatis/reflection/wrapper/BeanWrapper:metaClass	Lorg/apache/ibatis/reflection/MetaClass;
/*     */     //   4: aload_1
/*     */     //   5: invokevirtual 132	org/apache/ibatis/reflection/property/PropertyTokenizer:getName	()Ljava/lang/String;
/*     */     //   8: invokevirtual 200	org/apache/ibatis/reflection/MetaClass:getGetInvoker	(Ljava/lang/String;)Lorg/apache/ibatis/reflection/invoker/Invoker;
/*     */     //   11: astore_3
/*     */     //   12: aload_3
/*     */     //   13: aload_2
/*     */     //   14: getstatic 204	org/apache/ibatis/reflection/wrapper/BeanWrapper:NO_ARGUMENTS	[Ljava/lang/Object;
/*     */     //   17: invokeinterface 210 3 0
/*     */     //   22: areturn
/*     */     //   23: astore 4
/*     */     //   25: aload 4
/*     */     //   27: invokestatic 216	org/apache/ibatis/reflection/ExceptionUtil:unwrapThrowable	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
/*     */     //   30: athrow
/*     */     //   31: astore_3
/*     */     //   32: aload_3
/*     */     //   33: athrow
/*     */     //   34: astore_3
/*     */     //   35: new 159	org/apache/ibatis/reflection/ReflectionException
/*     */     //   38: dup
/*     */     //   39: new 161	java/lang/StringBuilder
/*     */     //   42: dup
/*     */     //   43: invokespecial 164	java/lang/StringBuilder:<init>	()V
/*     */     //   46: ldc -38
/*     */     //   48: invokevirtual 170	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   51: aload_1
/*     */     //   52: invokevirtual 132	org/apache/ibatis/reflection/property/PropertyTokenizer:getName	()Ljava/lang/String;
/*     */     //   55: invokevirtual 170	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   58: ldc -36
/*     */     //   60: invokevirtual 170	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   63: aload_2
/*     */     //   64: invokevirtual 22	java/lang/Object:getClass	()Ljava/lang/Class;
/*     */     //   67: invokevirtual 223	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   70: ldc -31
/*     */     //   72: invokevirtual 170	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   75: aload_3
/*     */     //   76: invokevirtual 226	java/lang/Throwable:toString	()Ljava/lang/String;
/*     */     //   79: invokevirtual 170	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   82: invokevirtual 181	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   85: aload_3
/*     */     //   86: invokespecial 184	org/apache/ibatis/reflection/ReflectionException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   89: athrow
/*     */     // Line number table:
/*     */     //   Java source line #152	-> byte code offset #0
/*     */     //   Java source line #154	-> byte code offset #12
/*     */     //   Java source line #155	-> byte code offset #23
/*     */     //   Java source line #156	-> byte code offset #25
/*     */     //   Java source line #158	-> byte code offset #31
/*     */     //   Java source line #159	-> byte code offset #32
/*     */     //   Java source line #160	-> byte code offset #34
/*     */     //   Java source line #161	-> byte code offset #35
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	90	0	this	BeanWrapper
/*     */     //   0	90	1	prop	PropertyTokenizer
/*     */     //   0	90	2	object	Object
/*     */     //   11	2	3	method	Invoker
/*     */     //   31	2	3	e	RuntimeException
/*     */     //   34	52	3	t	Throwable
/*     */     //   23	3	4	t	Throwable
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   12	22	23	java/lang/Throwable
/*     */     //   0	22	31	java/lang/RuntimeException
/*     */     //   23	31	31	java/lang/RuntimeException
/*     */     //   0	22	34	java/lang/Throwable
/*     */     //   23	31	34	java/lang/Throwable
/*     */   }
/*     */   
/*     */   private void setBeanProperty(PropertyTokenizer prop, Object object, Object value)
/*     */   {
/*     */     try
/*     */     {
/* 167 */       Invoker method = this.metaClass.getSetInvoker(prop.getName());
/* 168 */       Object[] params = { value };
/*     */       try {
/* 170 */         method.invoke(object, params);
/*     */       } catch (Throwable t) {
/* 172 */         throw ExceptionUtil.unwrapThrowable(t);
/*     */       }
/*     */     } catch (Throwable t) {
/* 175 */       throw new ReflectionException("Could not set property '" + prop.getName() + "' of '" + object.getClass() + "' with value '" + value + "' Cause: " + t.toString(), t);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isCollection() {
/* 180 */     return false;
/*     */   }
/*     */   
/*     */   public void add(Object element) {
/* 184 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public <E> void addAll(List<E> list) {
/* 188 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\wrapper\BeanWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */