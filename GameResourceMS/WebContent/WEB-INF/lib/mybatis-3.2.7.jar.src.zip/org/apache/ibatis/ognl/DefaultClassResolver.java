/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultClassResolver
/*    */   implements ClassResolver
/*    */ {
/* 44 */   private Map classes = new HashMap(101);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Class classForName(String className, Map context)
/*    */     throws ClassNotFoundException
/*    */   {
/* 53 */     Class result = null;
/*    */     
/* 55 */     if ((result = (Class)this.classes.get(className)) == null) {
/*    */       try {
/* 57 */         result = Class.forName(className);
/*    */       } catch (ClassNotFoundException ex) {
/* 59 */         if (className.indexOf('.') == -1) {
/* 60 */           result = Class.forName("java.lang." + className);
/* 61 */           this.classes.put("java.lang." + className, result);
/*    */         }
/*    */       }
/* 64 */       this.classes.put(className, result);
/*    */     }
/* 66 */     return result;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\DefaultClassResolver.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */