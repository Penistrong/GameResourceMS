/*     */ package org.apache.ibatis.builder;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.ibatis.cache.Cache;
/*     */ import org.apache.ibatis.cache.decorators.LruCache;
/*     */ import org.apache.ibatis.cache.impl.PerpetualCache;
/*     */ import org.apache.ibatis.executor.ErrorContext;
/*     */ import org.apache.ibatis.executor.keygen.KeyGenerator;
/*     */ import org.apache.ibatis.mapping.CacheBuilder;
/*     */ import org.apache.ibatis.mapping.Discriminator;
/*     */ import org.apache.ibatis.mapping.Discriminator.Builder;
/*     */ import org.apache.ibatis.mapping.MappedStatement;
/*     */ import org.apache.ibatis.mapping.MappedStatement.Builder;
/*     */ import org.apache.ibatis.mapping.ParameterMap;
/*     */ import org.apache.ibatis.mapping.ParameterMap.Builder;
/*     */ import org.apache.ibatis.mapping.ParameterMapping;
/*     */ import org.apache.ibatis.mapping.ParameterMapping.Builder;
/*     */ import org.apache.ibatis.mapping.ParameterMode;
/*     */ import org.apache.ibatis.mapping.ResultFlag;
/*     */ import org.apache.ibatis.mapping.ResultMap;
/*     */ import org.apache.ibatis.mapping.ResultMap.Builder;
/*     */ import org.apache.ibatis.mapping.ResultMapping;
/*     */ import org.apache.ibatis.mapping.ResultMapping.Builder;
/*     */ import org.apache.ibatis.mapping.ResultSetType;
/*     */ import org.apache.ibatis.mapping.SqlCommandType;
/*     */ import org.apache.ibatis.mapping.SqlSource;
/*     */ import org.apache.ibatis.mapping.StatementType;
/*     */ import org.apache.ibatis.reflection.MetaClass;
/*     */ import org.apache.ibatis.scripting.LanguageDriver;
/*     */ import org.apache.ibatis.scripting.LanguageDriverRegistry;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.type.JdbcType;
/*     */ import org.apache.ibatis.type.TypeHandler;
/*     */ import org.apache.ibatis.type.TypeHandlerRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapperBuilderAssistant
/*     */   extends BaseBuilder
/*     */ {
/*     */   private String currentNamespace;
/*     */   private String resource;
/*     */   private Cache currentCache;
/*     */   private boolean unresolvedCacheRef;
/*     */   
/*     */   public MapperBuilderAssistant(Configuration configuration, String resource)
/*     */   {
/*  63 */     super(configuration);
/*  64 */     ErrorContext.instance().resource(resource);
/*  65 */     this.resource = resource;
/*     */   }
/*     */   
/*     */   public String getCurrentNamespace() {
/*  69 */     return this.currentNamespace;
/*     */   }
/*     */   
/*     */   public void setCurrentNamespace(String currentNamespace) {
/*  73 */     if (currentNamespace == null) {
/*  74 */       throw new BuilderException("The mapper element requires a namespace attribute to be specified.");
/*     */     }
/*     */     
/*  77 */     if ((this.currentNamespace != null) && (!this.currentNamespace.equals(currentNamespace))) {
/*  78 */       throw new BuilderException("Wrong namespace. Expected '" + this.currentNamespace + "' but found '" + currentNamespace + "'.");
/*     */     }
/*     */     
/*     */ 
/*  82 */     this.currentNamespace = currentNamespace;
/*     */   }
/*     */   
/*     */   public String applyCurrentNamespace(String base, boolean isReference) {
/*  86 */     if (base == null) return null;
/*  87 */     if (isReference)
/*     */     {
/*  89 */       if (base.contains(".")) return base;
/*     */     }
/*     */     else {
/*  92 */       if (base.startsWith(this.currentNamespace + ".")) return base;
/*  93 */       if (base.contains(".")) throw new BuilderException("Dots are not allowed in element names, please remove it from " + base);
/*     */     }
/*  95 */     return this.currentNamespace + "." + base;
/*     */   }
/*     */   
/*     */   public Cache useCacheRef(String namespace) {
/*  99 */     if (namespace == null) {
/* 100 */       throw new BuilderException("cache-ref element requires a namespace attribute.");
/*     */     }
/*     */     try {
/* 103 */       this.unresolvedCacheRef = true;
/* 104 */       Cache cache = this.configuration.getCache(namespace);
/* 105 */       if (cache == null) {
/* 106 */         throw new IncompleteElementException("No cache for namespace '" + namespace + "' could be found.");
/*     */       }
/* 108 */       this.currentCache = cache;
/* 109 */       this.unresolvedCacheRef = false;
/* 110 */       return cache;
/*     */     } catch (IllegalArgumentException e) {
/* 112 */       throw new IncompleteElementException("No cache for namespace '" + namespace + "' could be found.", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cache useNewCache(Class<? extends Cache> typeClass, Class<? extends Cache> evictionClass, Long flushInterval, Integer size, boolean readWrite, Properties props)
/*     */   {
/* 122 */     typeClass = (Class)valueOrDefault(typeClass, PerpetualCache.class);
/* 123 */     evictionClass = (Class)valueOrDefault(evictionClass, LruCache.class);
/* 124 */     Cache cache = new CacheBuilder(this.currentNamespace).implementation(typeClass).addDecorator(evictionClass).clearInterval(flushInterval).size(size).readWrite(readWrite).properties(props).build();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 132 */     this.configuration.addCache(cache);
/* 133 */     this.currentCache = cache;
/* 134 */     return cache;
/*     */   }
/*     */   
/*     */   public ParameterMap addParameterMap(String id, Class<?> parameterClass, List<ParameterMapping> parameterMappings) {
/* 138 */     id = applyCurrentNamespace(id, false);
/* 139 */     ParameterMap.Builder parameterMapBuilder = new ParameterMap.Builder(this.configuration, id, parameterClass, parameterMappings);
/* 140 */     ParameterMap parameterMap = parameterMapBuilder.build();
/* 141 */     this.configuration.addParameterMap(parameterMap);
/* 142 */     return parameterMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParameterMapping buildParameterMapping(Class<?> parameterType, String property, Class<?> javaType, JdbcType jdbcType, String resultMap, ParameterMode parameterMode, Class<? extends TypeHandler<?>> typeHandler, Integer numericScale)
/*     */   {
/* 154 */     resultMap = applyCurrentNamespace(resultMap, true);
/*     */     
/*     */ 
/* 157 */     Class<?> javaTypeClass = resolveParameterJavaType(parameterType, property, javaType, jdbcType);
/* 158 */     TypeHandler<?> typeHandlerInstance = resolveTypeHandler(javaTypeClass, typeHandler);
/*     */     
/* 160 */     ParameterMapping.Builder builder = new ParameterMapping.Builder(this.configuration, property, javaTypeClass);
/* 161 */     builder.jdbcType(jdbcType);
/* 162 */     builder.resultMapId(resultMap);
/* 163 */     builder.mode(parameterMode);
/* 164 */     builder.numericScale(numericScale);
/* 165 */     builder.typeHandler(typeHandlerInstance);
/* 166 */     return builder.build();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResultMap addResultMap(String id, Class<?> type, String extend, Discriminator discriminator, List<ResultMapping> resultMappings, Boolean autoMapping)
/*     */   {
/* 176 */     id = applyCurrentNamespace(id, false);
/* 177 */     extend = applyCurrentNamespace(extend, true);
/*     */     
/* 179 */     ResultMap.Builder resultMapBuilder = new ResultMap.Builder(this.configuration, id, type, resultMappings, autoMapping);
/* 180 */     if (extend != null) {
/* 181 */       if (!this.configuration.hasResultMap(extend)) {
/* 182 */         throw new IncompleteElementException("Could not find a parent resultmap with id '" + extend + "'");
/*     */       }
/* 184 */       ResultMap resultMap = this.configuration.getResultMap(extend);
/* 185 */       List<ResultMapping> extendedResultMappings = new ArrayList(resultMap.getResultMappings());
/* 186 */       extendedResultMappings.removeAll(resultMappings);
/*     */       
/* 188 */       boolean declaresConstructor = false;
/* 189 */       for (ResultMapping resultMapping : resultMappings) {
/* 190 */         if (resultMapping.getFlags().contains(ResultFlag.CONSTRUCTOR)) {
/* 191 */           declaresConstructor = true;
/* 192 */           break;
/*     */         }
/*     */       }
/* 195 */       if (declaresConstructor) {
/* 196 */         Iterator<ResultMapping> extendedResultMappingsIter = extendedResultMappings.iterator();
/* 197 */         while (extendedResultMappingsIter.hasNext()) {
/* 198 */           if (((ResultMapping)extendedResultMappingsIter.next()).getFlags().contains(ResultFlag.CONSTRUCTOR)) {
/* 199 */             extendedResultMappingsIter.remove();
/*     */           }
/*     */         }
/*     */       }
/* 203 */       resultMappings.addAll(extendedResultMappings);
/*     */     }
/* 205 */     resultMapBuilder.discriminator(discriminator);
/* 206 */     ResultMap resultMap = resultMapBuilder.build();
/* 207 */     this.configuration.addResultMap(resultMap);
/* 208 */     return resultMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Discriminator buildDiscriminator(Class<?> resultType, String column, Class<?> javaType, JdbcType jdbcType, Class<? extends TypeHandler<?>> typeHandler, Map<String, String> discriminatorMap)
/*     */   {
/* 218 */     ResultMapping resultMapping = buildResultMapping(resultType, null, column, javaType, jdbcType, null, null, null, null, typeHandler, new ArrayList(), null, null, false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 233 */     Map<String, String> namespaceDiscriminatorMap = new HashMap();
/* 234 */     for (Map.Entry<String, String> e : discriminatorMap.entrySet()) {
/* 235 */       String resultMap = (String)e.getValue();
/* 236 */       resultMap = applyCurrentNamespace(resultMap, true);
/* 237 */       namespaceDiscriminatorMap.put(e.getKey(), resultMap);
/*     */     }
/* 239 */     Discriminator.Builder discriminatorBuilder = new Discriminator.Builder(this.configuration, resultMapping, namespaceDiscriminatorMap);
/* 240 */     return discriminatorBuilder.build();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MappedStatement addMappedStatement(String id, SqlSource sqlSource, StatementType statementType, SqlCommandType sqlCommandType, Integer fetchSize, Integer timeout, String parameterMap, Class<?> parameterType, String resultMap, Class<?> resultType, ResultSetType resultSetType, boolean flushCache, boolean useCache, boolean resultOrdered, KeyGenerator keyGenerator, String keyProperty, String keyColumn, String databaseId, LanguageDriver lang, String resultSets)
/*     */   {
/* 265 */     if (this.unresolvedCacheRef) { throw new IncompleteElementException("Cache-ref not yet resolved");
/*     */     }
/* 267 */     id = applyCurrentNamespace(id, false);
/* 268 */     boolean isSelect = sqlCommandType == SqlCommandType.SELECT;
/*     */     
/* 270 */     MappedStatement.Builder statementBuilder = new MappedStatement.Builder(this.configuration, id, sqlSource, sqlCommandType);
/* 271 */     statementBuilder.resource(this.resource);
/* 272 */     statementBuilder.fetchSize(fetchSize);
/* 273 */     statementBuilder.statementType(statementType);
/* 274 */     statementBuilder.keyGenerator(keyGenerator);
/* 275 */     statementBuilder.keyProperty(keyProperty);
/* 276 */     statementBuilder.keyColumn(keyColumn);
/* 277 */     statementBuilder.databaseId(databaseId);
/* 278 */     statementBuilder.lang(lang);
/* 279 */     statementBuilder.resultOrdered(resultOrdered);
/* 280 */     statementBuilder.resulSets(resultSets);
/* 281 */     setStatementTimeout(timeout, statementBuilder);
/*     */     
/* 283 */     setStatementParameterMap(parameterMap, parameterType, statementBuilder);
/* 284 */     setStatementResultMap(resultMap, resultType, resultSetType, statementBuilder);
/* 285 */     setStatementCache(isSelect, flushCache, useCache, this.currentCache, statementBuilder);
/*     */     
/* 287 */     MappedStatement statement = statementBuilder.build();
/* 288 */     this.configuration.addMappedStatement(statement);
/* 289 */     return statement;
/*     */   }
/*     */   
/*     */   private <T> T valueOrDefault(T value, T defaultValue) {
/* 293 */     return value == null ? defaultValue : value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setStatementCache(boolean isSelect, boolean flushCache, boolean useCache, Cache cache, MappedStatement.Builder statementBuilder)
/*     */   {
/* 302 */     flushCache = ((Boolean)valueOrDefault(Boolean.valueOf(flushCache), Boolean.valueOf(!isSelect))).booleanValue();
/* 303 */     useCache = ((Boolean)valueOrDefault(Boolean.valueOf(useCache), Boolean.valueOf(isSelect))).booleanValue();
/* 304 */     statementBuilder.flushCacheRequired(flushCache);
/* 305 */     statementBuilder.useCache(useCache);
/* 306 */     statementBuilder.cache(cache);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void setStatementParameterMap(String parameterMap, Class<?> parameterTypeClass, MappedStatement.Builder statementBuilder)
/*     */   {
/* 313 */     parameterMap = applyCurrentNamespace(parameterMap, true);
/*     */     
/* 315 */     if (parameterMap != null) {
/*     */       try {
/* 317 */         statementBuilder.parameterMap(this.configuration.getParameterMap(parameterMap));
/*     */       } catch (IllegalArgumentException e) {
/* 319 */         throw new IncompleteElementException("Could not find parameter map " + parameterMap, e);
/*     */       }
/* 321 */     } else if (parameterTypeClass != null) {
/* 322 */       List<ParameterMapping> parameterMappings = new ArrayList();
/* 323 */       ParameterMap.Builder inlineParameterMapBuilder = new ParameterMap.Builder(this.configuration, statementBuilder.id() + "-Inline", parameterTypeClass, parameterMappings);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 328 */       statementBuilder.parameterMap(inlineParameterMapBuilder.build());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setStatementResultMap(String resultMap, Class<?> resultType, ResultSetType resultSetType, MappedStatement.Builder statementBuilder)
/*     */   {
/* 337 */     resultMap = applyCurrentNamespace(resultMap, true);
/*     */     
/* 339 */     List<ResultMap> resultMaps = new ArrayList();
/* 340 */     if (resultMap != null) {
/* 341 */       String[] resultMapNames = resultMap.split(",");
/* 342 */       for (String resultMapName : resultMapNames) {
/*     */         try {
/* 344 */           resultMaps.add(this.configuration.getResultMap(resultMapName.trim()));
/*     */         } catch (IllegalArgumentException e) {
/* 346 */           throw new IncompleteElementException("Could not find result map " + resultMapName, e);
/*     */         }
/*     */       }
/* 349 */     } else if (resultType != null) {
/* 350 */       ResultMap.Builder inlineResultMapBuilder = new ResultMap.Builder(this.configuration, statementBuilder.id() + "-Inline", resultType, new ArrayList(), null);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 356 */       resultMaps.add(inlineResultMapBuilder.build());
/*     */     }
/* 358 */     statementBuilder.resultMaps(resultMaps);
/*     */     
/* 360 */     statementBuilder.resultSetType(resultSetType);
/*     */   }
/*     */   
/*     */   private void setStatementTimeout(Integer timeout, MappedStatement.Builder statementBuilder) {
/* 364 */     if (timeout == null) {
/* 365 */       timeout = this.configuration.getDefaultStatementTimeout();
/*     */     }
/* 367 */     statementBuilder.timeout(timeout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResultMapping buildResultMapping(Class<?> resultType, String property, String column, Class<?> javaType, JdbcType jdbcType, String nestedSelect, String nestedResultMap, String notNullColumn, String columnPrefix, Class<? extends TypeHandler<?>> typeHandler, List<ResultFlag> flags, String resultSet, String foreignColumn, boolean lazy)
/*     */   {
/* 385 */     Class<?> javaTypeClass = resolveResultJavaType(resultType, property, javaType);
/* 386 */     TypeHandler<?> typeHandlerInstance = resolveTypeHandler(javaTypeClass, typeHandler);
/* 387 */     List<ResultMapping> composites = parseCompositeColumnName(column);
/* 388 */     if (composites.size() > 0) column = null;
/* 389 */     ResultMapping.Builder builder = new ResultMapping.Builder(this.configuration, property, column, javaTypeClass);
/* 390 */     builder.jdbcType(jdbcType);
/* 391 */     builder.nestedQueryId(applyCurrentNamespace(nestedSelect, true));
/* 392 */     builder.nestedResultMapId(applyCurrentNamespace(nestedResultMap, true));
/* 393 */     builder.resultSet(resultSet);
/* 394 */     builder.typeHandler(typeHandlerInstance);
/* 395 */     builder.flags(flags == null ? new ArrayList() : flags);
/* 396 */     builder.composites(composites);
/* 397 */     builder.notNullColumns(parseMultipleColumnNames(notNullColumn));
/* 398 */     builder.columnPrefix(columnPrefix);
/* 399 */     builder.foreignColumn(foreignColumn);
/* 400 */     builder.lazy(lazy);
/* 401 */     return builder.build();
/*     */   }
/*     */   
/*     */   private Set<String> parseMultipleColumnNames(String columnName) {
/* 405 */     Set<String> columns = new HashSet();
/* 406 */     if (columnName != null) {
/* 407 */       if (columnName.indexOf(',') > -1) {
/* 408 */         StringTokenizer parser = new StringTokenizer(columnName, "{}, ", false);
/* 409 */         while (parser.hasMoreTokens()) {
/* 410 */           String column = parser.nextToken();
/* 411 */           columns.add(column);
/*     */         }
/*     */       } else {
/* 414 */         columns.add(columnName);
/*     */       }
/*     */     }
/* 417 */     return columns;
/*     */   }
/*     */   
/*     */   private List<ResultMapping> parseCompositeColumnName(String columnName) {
/* 421 */     List<ResultMapping> composites = new ArrayList();
/* 422 */     if ((columnName != null) && ((columnName.indexOf('=') > -1) || (columnName.indexOf(',') > -1))) {
/* 423 */       StringTokenizer parser = new StringTokenizer(columnName, "{}=, ", false);
/* 424 */       while (parser.hasMoreTokens()) {
/* 425 */         String property = parser.nextToken();
/* 426 */         String column = parser.nextToken();
/* 427 */         ResultMapping.Builder complexBuilder = new ResultMapping.Builder(this.configuration, property, column, this.configuration.getTypeHandlerRegistry().getUnknownTypeHandler());
/* 428 */         composites.add(complexBuilder.build());
/*     */       }
/*     */     }
/* 431 */     return composites;
/*     */   }
/*     */   
/*     */   private Class<?> resolveResultJavaType(Class<?> resultType, String property, Class<?> javaType) {
/* 435 */     if ((javaType == null) && (property != null)) {
/*     */       try {
/* 437 */         MetaClass metaResultType = MetaClass.forClass(resultType);
/* 438 */         javaType = metaResultType.getSetterType(property);
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/* 443 */     if (javaType == null) {
/* 444 */       javaType = Object.class;
/*     */     }
/* 446 */     return javaType;
/*     */   }
/*     */   
/*     */   private Class<?> resolveParameterJavaType(Class<?> resultType, String property, Class<?> javaType, JdbcType jdbcType) {
/* 450 */     if (javaType == null) {
/* 451 */       if (JdbcType.CURSOR.equals(jdbcType)) {
/* 452 */         javaType = ResultSet.class;
/* 453 */       } else if (Map.class.isAssignableFrom(resultType)) {
/* 454 */         javaType = Object.class;
/*     */       } else {
/* 456 */         MetaClass metaResultType = MetaClass.forClass(resultType);
/* 457 */         javaType = metaResultType.getGetterType(property);
/*     */       }
/*     */     }
/* 460 */     if (javaType == null) {
/* 461 */       javaType = Object.class;
/*     */     }
/* 463 */     return javaType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResultMapping buildResultMapping(Class<?> resultType, String property, String column, Class<?> javaType, JdbcType jdbcType, String nestedSelect, String nestedResultMap, String notNullColumn, String columnPrefix, Class<? extends TypeHandler<?>> typeHandler, List<ResultFlag> flags)
/*     */   {
/* 479 */     return buildResultMapping(resultType, property, column, javaType, jdbcType, nestedSelect, nestedResultMap, notNullColumn, columnPrefix, typeHandler, flags, null, null, this.configuration.isLazyLoadingEnabled());
/*     */   }
/*     */   
/*     */ 
/*     */   public LanguageDriver getLanguageDriver(Class<?> langClass)
/*     */   {
/* 485 */     if (langClass != null) {
/* 486 */       this.configuration.getLanguageRegistry().register(langClass);
/*     */     } else {
/* 488 */       langClass = this.configuration.getLanguageRegistry().getDefaultDriverClass();
/*     */     }
/* 490 */     return this.configuration.getLanguageRegistry().getDriver(langClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MappedStatement addMappedStatement(String id, SqlSource sqlSource, StatementType statementType, SqlCommandType sqlCommandType, Integer fetchSize, Integer timeout, String parameterMap, Class<?> parameterType, String resultMap, Class<?> resultType, ResultSetType resultSetType, boolean flushCache, boolean useCache, boolean resultOrdered, KeyGenerator keyGenerator, String keyProperty, String keyColumn, String databaseId, LanguageDriver lang)
/*     */   {
/* 514 */     return addMappedStatement(id, sqlSource, statementType, sqlCommandType, fetchSize, timeout, parameterMap, parameterType, resultMap, resultType, resultSetType, flushCache, useCache, resultOrdered, keyGenerator, keyProperty, keyColumn, databaseId, lang, null);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\builder\MapperBuilderAssistant.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */