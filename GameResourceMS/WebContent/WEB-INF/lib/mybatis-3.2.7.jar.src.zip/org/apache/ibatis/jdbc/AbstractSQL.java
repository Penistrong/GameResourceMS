/*     */ package org.apache.ibatis.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSQL<T>
/*     */ {
/*     */   private static final String AND = ") \nAND (";
/*     */   private static final String OR = ") \nOR (";
/*     */   private SQLStatement sql;
/*     */   
/*     */   public T UPDATE(String table)
/*     */   {
/*  35 */     sql().statementType = AbstractSQL.SQLStatement.StatementType.UPDATE;
/*  36 */     sql().tables.add(table);
/*  37 */     return (T)getSelf();
/*     */   }
/*     */   
/*     */   public T SET(String sets) {
/*  41 */     sql().sets.add(sets);
/*  42 */     return (T)getSelf();
/*     */   }
/*     */   
/*     */   public T INSERT_INTO(String tableName) {
/*  46 */     sql().statementType = AbstractSQL.SQLStatement.StatementType.INSERT;
/*  47 */     sql().tables.add(tableName);
/*  48 */     return (T)getSelf();
/*     */   }
/*     */   
/*     */   public T VALUES(String columns, String values) {
/*  52 */     sql().columns.add(columns);
/*  53 */     sql().values.add(values);
/*  54 */     return (T)getSelf();
/*     */   }
/*     */   
/*     */   public T SELECT(String columns) {
/*  58 */     sql().statementType = AbstractSQL.SQLStatement.StatementType.SELECT;
/*  59 */     sql().select.add(columns);
/*  60 */     return (T)getSelf();
/*     */   }
/*     */   
/*     */   public T SELECT_DISTINCT(String columns) {
/*  64 */     sql().distinct = true;
/*  65 */     SELECT(columns);
/*  66 */     return (T)getSelf();
/*     */   }
/*     */   
/*     */   public T DELETE_FROM(String table) {
/*  70 */     sql().statementType = AbstractSQL.SQLStatement.StatementType.DELETE;
/*  71 */     sql().tables.add(table);
/*  72 */     return (T)getSelf();
/*     */   }
/*     */   
/*     */   public T FROM(String table) {
/*  76 */     sql().tables.add(table);
/*  77 */     return (T)getSelf();
/*     */   }
/*     */   
/*     */   public T JOIN(String join) {
/*  81 */     sql().join.add(join);
/*  82 */     return (T)getSelf();
/*     */   }
/*     */   
/*     */   public T INNER_JOIN(String join) {
/*  86 */     sql().innerJoin.add(join);
/*  87 */     return (T)getSelf();
/*     */   }
/*     */   
/*     */   public T LEFT_OUTER_JOIN(String join) {
/*  91 */     sql().leftOuterJoin.add(join);
/*  92 */     return (T)getSelf();
/*     */   }
/*     */   
/*     */   public T RIGHT_OUTER_JOIN(String join) {
/*  96 */     sql().rightOuterJoin.add(join);
/*  97 */     return (T)getSelf();
/*     */   }
/*     */   
/*     */   public T OUTER_JOIN(String join) {
/* 101 */     sql().outerJoin.add(join);
/* 102 */     return (T)getSelf();
/*     */   }
/*     */   
/*     */   public T WHERE(String conditions) {
/* 106 */     sql().where.add(conditions);
/* 107 */     sql().lastList = sql().where;
/* 108 */     return (T)getSelf();
/*     */   }
/*     */   
/*     */   public T OR() {
/* 112 */     sql().lastList.add(") \nOR (");
/* 113 */     return (T)getSelf();
/*     */   }
/*     */   
/*     */   public T AND() {
/* 117 */     sql().lastList.add(") \nAND (");
/* 118 */     return (T)getSelf();
/*     */   }
/*     */   
/*     */   public T GROUP_BY(String columns) {
/* 122 */     sql().groupBy.add(columns);
/* 123 */     return (T)getSelf();
/*     */   }
/*     */   
/*     */   public T HAVING(String conditions) {
/* 127 */     sql().having.add(conditions);
/* 128 */     sql().lastList = sql().having;
/* 129 */     return (T)getSelf();
/*     */   }
/*     */   
/*     */   public T ORDER_BY(String columns) {
/* 133 */     sql().orderBy.add(columns);
/* 134 */     return (T)getSelf();
/*     */   }
/*     */   
/* 137 */   public AbstractSQL() { this.sql = new SQLStatement(null); }
/*     */   
/*     */   private SQLStatement sql() {
/* 140 */     return this.sql;
/*     */   }
/*     */   
/*     */   public <A extends Appendable> A usingAppender(A a) {
/* 144 */     sql().sql(a);
/* 145 */     return a;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 150 */     StringBuilder sb = new StringBuilder();
/* 151 */     sql().sql(sb);
/* 152 */     return sb.toString(); }
/*     */   
/*     */   public abstract T getSelf();
/*     */   
/*     */   private static class SafeAppendable { private final Appendable a;
/* 157 */     private boolean empty = true;
/*     */     
/*     */     public SafeAppendable(Appendable a)
/*     */     {
/* 161 */       this.a = a;
/*     */     }
/*     */     
/*     */     public SafeAppendable append(CharSequence s) {
/*     */       try {
/* 166 */         if ((this.empty) && (s.length() > 0)) this.empty = false;
/* 167 */         this.a.append(s);
/*     */       } catch (IOException e) {
/* 169 */         throw new RuntimeException(e);
/*     */       }
/* 171 */       return this;
/*     */     }
/*     */     
/*     */     public boolean isEmpty() {
/* 175 */       return this.empty;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SQLStatement {
/*     */     StatementType statementType;
/*     */     
/*     */     public static enum StatementType {
/* 183 */       DELETE,  INSERT,  SELECT,  UPDATE;
/*     */       
/*     */       private StatementType() {} }
/*     */     
/* 187 */     List<String> sets = new ArrayList();
/* 188 */     List<String> select = new ArrayList();
/* 189 */     List<String> tables = new ArrayList();
/* 190 */     List<String> join = new ArrayList();
/* 191 */     List<String> innerJoin = new ArrayList();
/* 192 */     List<String> outerJoin = new ArrayList();
/* 193 */     List<String> leftOuterJoin = new ArrayList();
/* 194 */     List<String> rightOuterJoin = new ArrayList();
/* 195 */     List<String> where = new ArrayList();
/* 196 */     List<String> having = new ArrayList();
/* 197 */     List<String> groupBy = new ArrayList();
/* 198 */     List<String> orderBy = new ArrayList();
/* 199 */     List<String> lastList = new ArrayList();
/* 200 */     List<String> columns = new ArrayList();
/* 201 */     List<String> values = new ArrayList();
/*     */     boolean distinct;
/*     */     
/*     */     private void sqlClause(AbstractSQL.SafeAppendable builder, String keyword, List<String> parts, String open, String close, String conjunction)
/*     */     {
/* 206 */       if (!parts.isEmpty()) {
/* 207 */         if (!builder.isEmpty())
/* 208 */           builder.append("\n");
/* 209 */         builder.append(keyword);
/* 210 */         builder.append(" ");
/* 211 */         builder.append(open);
/* 212 */         String last = "________";
/* 213 */         int i = 0; for (int n = parts.size(); i < n; i++) {
/* 214 */           String part = (String)parts.get(i);
/* 215 */           if ((i > 0) && (!part.equals(") \nAND (")) && (!part.equals(") \nOR (")) && (!last.equals(") \nAND (")) && (!last.equals(") \nOR ("))) {
/* 216 */             builder.append(conjunction);
/*     */           }
/* 218 */           builder.append(part);
/* 219 */           last = part;
/*     */         }
/* 221 */         builder.append(close);
/*     */       }
/*     */     }
/*     */     
/*     */     private String selectSQL(AbstractSQL.SafeAppendable builder) {
/* 226 */       if (this.distinct) {
/* 227 */         sqlClause(builder, "SELECT DISTINCT", this.select, "", "", ", ");
/*     */       } else {
/* 229 */         sqlClause(builder, "SELECT", this.select, "", "", ", ");
/*     */       }
/*     */       
/* 232 */       sqlClause(builder, "FROM", this.tables, "", "", ", ");
/* 233 */       sqlClause(builder, "JOIN", this.join, "", "", "\nJOIN ");
/* 234 */       sqlClause(builder, "INNER JOIN", this.innerJoin, "", "", "\nINNER JOIN ");
/* 235 */       sqlClause(builder, "OUTER JOIN", this.outerJoin, "", "", "\nOUTER JOIN ");
/* 236 */       sqlClause(builder, "LEFT OUTER JOIN", this.leftOuterJoin, "", "", "\nLEFT OUTER JOIN ");
/* 237 */       sqlClause(builder, "RIGHT OUTER JOIN", this.rightOuterJoin, "", "", "\nRIGHT OUTER JOIN ");
/* 238 */       sqlClause(builder, "WHERE", this.where, "(", ")", " AND ");
/* 239 */       sqlClause(builder, "GROUP BY", this.groupBy, "", "", ", ");
/* 240 */       sqlClause(builder, "HAVING", this.having, "(", ")", " AND ");
/* 241 */       sqlClause(builder, "ORDER BY", this.orderBy, "", "", ", ");
/* 242 */       return builder.toString();
/*     */     }
/*     */     
/*     */     private String insertSQL(AbstractSQL.SafeAppendable builder) {
/* 246 */       sqlClause(builder, "INSERT INTO", this.tables, "", "", "");
/* 247 */       sqlClause(builder, "", this.columns, "(", ")", ", ");
/* 248 */       sqlClause(builder, "VALUES", this.values, "(", ")", ", ");
/* 249 */       return builder.toString();
/*     */     }
/*     */     
/*     */     private String deleteSQL(AbstractSQL.SafeAppendable builder) {
/* 253 */       sqlClause(builder, "DELETE FROM", this.tables, "", "", "");
/* 254 */       sqlClause(builder, "WHERE", this.where, "(", ")", " AND ");
/* 255 */       return builder.toString();
/*     */     }
/*     */     
/*     */     private String updateSQL(AbstractSQL.SafeAppendable builder)
/*     */     {
/* 260 */       sqlClause(builder, "UPDATE", this.tables, "", "", "");
/* 261 */       sqlClause(builder, "SET", this.sets, "", "", ", ");
/* 262 */       sqlClause(builder, "WHERE", this.where, "(", ")", " AND ");
/* 263 */       return builder.toString();
/*     */     }
/*     */     
/*     */     public String sql(Appendable a) {
/* 267 */       AbstractSQL.SafeAppendable builder = new AbstractSQL.SafeAppendable(a);
/* 268 */       if (this.statementType == null) {
/* 269 */         return null;
/*     */       }
/*     */       
/*     */       String answer;
/*     */       
/* 274 */       switch (AbstractSQL.1.$SwitchMap$org$apache$ibatis$jdbc$AbstractSQL$SQLStatement$StatementType[this.statementType.ordinal()]) {
/*     */       case 1: 
/* 276 */         answer = deleteSQL(builder);
/* 277 */         break;
/*     */       
/*     */       case 2: 
/* 280 */         answer = insertSQL(builder);
/* 281 */         break;
/*     */       
/*     */       case 3: 
/* 284 */         answer = selectSQL(builder);
/* 285 */         break;
/*     */       
/*     */       case 4: 
/* 288 */         answer = updateSQL(builder);
/* 289 */         break;
/*     */       
/*     */       default: 
/* 292 */         answer = null;
/*     */       }
/*     */       
/* 295 */       return answer;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\jdbc\AbstractSQL.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */