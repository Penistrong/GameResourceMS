/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OgnlException
/*     */   extends Exception
/*     */ {
/*     */   private Evaluation evaluation;
/*     */   private Throwable reason;
/*     */   
/*     */   public OgnlException()
/*     */   {
/*  55 */     this(null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OgnlException(String msg)
/*     */   {
/*  64 */     this(msg, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OgnlException(String msg, Throwable reason)
/*     */   {
/*  74 */     super(msg);
/*  75 */     this.reason = reason;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Throwable getReason()
/*     */   {
/*  84 */     return this.reason;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Evaluation getEvaluation()
/*     */   {
/*  93 */     return this.evaluation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEvaluation(Evaluation value)
/*     */   {
/* 101 */     this.evaluation = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 110 */     if (this.reason == null)
/* 111 */       return super.toString();
/* 112 */     return super.toString() + " [" + this.reason + "]";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace()
/*     */   {
/* 122 */     printStackTrace(System.err);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace(PrintStream s)
/*     */   {
/* 131 */     synchronized (s)
/*     */     {
/* 133 */       super.printStackTrace(s);
/* 134 */       if (this.reason != null) {
/* 135 */         s.println("/-- Encapsulated exception ------------\\");
/* 136 */         this.reason.printStackTrace(s);
/* 137 */         s.println("\\--------------------------------------/");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace(PrintWriter s)
/*     */   {
/* 148 */     synchronized (s)
/*     */     {
/* 150 */       super.printStackTrace(s);
/* 151 */       if (this.reason != null) {
/* 152 */         s.println("/-- Encapsulated exception ------------\\");
/* 153 */         this.reason.printStackTrace(s);
/* 154 */         s.println("\\--------------------------------------/");
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\OgnlException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */