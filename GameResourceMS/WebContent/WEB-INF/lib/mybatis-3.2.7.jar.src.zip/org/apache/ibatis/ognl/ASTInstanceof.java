/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTInstanceof
/*    */   extends SimpleNode
/*    */ {
/*    */   private String targetType;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ASTInstanceof(int id)
/*    */   {
/* 42 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTInstanceof(OgnlParser p, int id) {
/* 46 */     super(p, id);
/*    */   }
/*    */   
/*    */   void setTargetType(String targetType) {
/* 50 */     this.targetType = targetType;
/*    */   }
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException
/*    */   {
/* 55 */     Object value = this.children[0].getValue(context, source);
/* 56 */     return OgnlRuntime.isInstance(context, value, this.targetType) ? Boolean.TRUE : Boolean.FALSE;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 61 */     return this.children[0] + " instanceof " + this.targetType;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTInstanceof.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */