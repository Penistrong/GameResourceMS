/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Enumeration;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTSelect
/*    */   extends SimpleNode
/*    */ {
/*    */   public ASTSelect(int id)
/*    */   {
/* 42 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTSelect(OgnlParser p, int id) {
/* 46 */     super(p, id);
/*    */   }
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException
/*    */   {
/* 51 */     Node expr = this.children[0];
/* 52 */     List answer = new ArrayList();
/* 53 */     ElementsAccessor elementsAccessor = OgnlRuntime.getElementsAccessor(OgnlRuntime.getTargetClass(source));
/*    */     
/* 55 */     for (Enumeration e = elementsAccessor.getElements(source); e.hasMoreElements();) {
/* 56 */       Object next = e.nextElement();
/*    */       
/* 58 */       if (OgnlOps.booleanValue(expr.getValue(context, next)))
/* 59 */         answer.add(next);
/*    */     }
/* 61 */     return answer;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 66 */     return "{? " + this.children[0] + " }";
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTSelect.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */