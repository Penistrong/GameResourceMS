/*    */ package org.apache.ibatis.mapping;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Properties;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.ibatis.executor.BaseExecutor;
/*    */ import org.apache.ibatis.logging.Log;
/*    */ import org.apache.ibatis.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VendorDatabaseIdProvider
/*    */   implements DatabaseIdProvider
/*    */ {
/* 43 */   private static final Log log = LogFactory.getLog(BaseExecutor.class);
/*    */   private Properties properties;
/*    */   
/*    */   public String getDatabaseId(DataSource dataSource)
/*    */   {
/* 48 */     if (dataSource == null) throw new NullPointerException("dataSource cannot be null");
/*    */     try {
/* 50 */       return getDatabaseName(dataSource);
/*    */     } catch (Exception e) {
/* 52 */       log.error("Could not get a databaseId from dataSource", e);
/*    */     }
/* 54 */     return null;
/*    */   }
/*    */   
/*    */   public void setProperties(Properties p) {
/* 58 */     this.properties = p;
/*    */   }
/*    */   
/*    */   private String getDatabaseName(DataSource dataSource) throws SQLException {
/* 62 */     String productName = getDatabaseProductName(dataSource);
/* 63 */     if (this.properties != null) {
/* 64 */       for (Map.Entry<Object, Object> property : this.properties.entrySet()) {
/* 65 */         if (productName.contains((String)property.getKey())) {
/* 66 */           return (String)property.getValue();
/*    */         }
/*    */       }
/* 69 */       return null;
/*    */     }
/* 71 */     return productName;
/*    */   }
/*    */   
/*    */   private String getDatabaseProductName(DataSource dataSource) throws SQLException {
/* 75 */     Connection con = null;
/*    */     try {
/* 77 */       con = dataSource.getConnection();
/* 78 */       DatabaseMetaData metaData = con.getMetaData();
/* 79 */       return metaData.getDatabaseProductName();
/*    */     } finally {
/* 81 */       if (con != null) {
/*    */         try {
/* 83 */           con.close();
/*    */         }
/*    */         catch (SQLException e) {}
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\mapping\VendorDatabaseIdProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */