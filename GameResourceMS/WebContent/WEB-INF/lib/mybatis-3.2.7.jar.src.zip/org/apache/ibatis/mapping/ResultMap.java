/*     */ package org.apache.ibatis.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResultMap
/*     */ {
/*     */   private String id;
/*     */   private Class<?> type;
/*     */   private List<ResultMapping> resultMappings;
/*     */   private List<ResultMapping> idResultMappings;
/*     */   private List<ResultMapping> constructorResultMappings;
/*     */   private List<ResultMapping> propertyResultMappings;
/*     */   private Set<String> mappedColumns;
/*     */   private Discriminator discriminator;
/*     */   private boolean hasNestedResultMaps;
/*     */   private boolean hasNestedQueries;
/*     */   private Boolean autoMapping;
/*     */   
/*     */   public static class Builder
/*     */   {
/*  47 */     private ResultMap resultMap = new ResultMap(null);
/*     */     
/*     */     public Builder(Configuration configuration, String id, Class<?> type, List<ResultMapping> resultMappings) {
/*  50 */       this(configuration, id, type, resultMappings, null);
/*     */     }
/*     */     
/*     */     public Builder(Configuration configuration, String id, Class<?> type, List<ResultMapping> resultMappings, Boolean autoMapping) {
/*  54 */       this.resultMap.id = id;
/*  55 */       this.resultMap.type = type;
/*  56 */       this.resultMap.resultMappings = resultMappings;
/*  57 */       this.resultMap.autoMapping = autoMapping;
/*     */     }
/*     */     
/*     */     public Builder discriminator(Discriminator discriminator) {
/*  61 */       this.resultMap.discriminator = discriminator;
/*  62 */       return this;
/*     */     }
/*     */     
/*     */     public Class<?> type() {
/*  66 */       return this.resultMap.type;
/*     */     }
/*     */     
/*     */     public ResultMap build() {
/*  70 */       if (this.resultMap.id == null) {
/*  71 */         throw new IllegalArgumentException("ResultMaps must have an id");
/*     */       }
/*  73 */       this.resultMap.mappedColumns = new HashSet();
/*  74 */       this.resultMap.idResultMappings = new ArrayList();
/*  75 */       this.resultMap.constructorResultMappings = new ArrayList();
/*  76 */       this.resultMap.propertyResultMappings = new ArrayList();
/*  77 */       for (ResultMapping resultMapping : this.resultMap.resultMappings) {
/*  78 */         this.resultMap.hasNestedQueries = ((this.resultMap.hasNestedQueries) || (resultMapping.getNestedQueryId() != null));
/*  79 */         this.resultMap.hasNestedResultMaps = ((this.resultMap.hasNestedResultMaps) || ((resultMapping.getNestedResultMapId() != null) && (resultMapping.getResultSet() == null)));
/*  80 */         String column = resultMapping.getColumn();
/*  81 */         if (column != null) {
/*  82 */           this.resultMap.mappedColumns.add(column.toUpperCase(Locale.ENGLISH));
/*  83 */         } else if (resultMapping.isCompositeResult()) {
/*  84 */           for (ResultMapping compositeResultMapping : resultMapping.getComposites()) {
/*  85 */             String compositeColumn = compositeResultMapping.getColumn();
/*  86 */             if (compositeColumn != null) {
/*  87 */               this.resultMap.mappedColumns.add(compositeColumn.toUpperCase(Locale.ENGLISH));
/*     */             }
/*     */           }
/*     */         }
/*  91 */         if (resultMapping.getFlags().contains(ResultFlag.CONSTRUCTOR)) {
/*  92 */           this.resultMap.constructorResultMappings.add(resultMapping);
/*     */         } else {
/*  94 */           this.resultMap.propertyResultMappings.add(resultMapping);
/*     */         }
/*  96 */         if (resultMapping.getFlags().contains(ResultFlag.ID)) {
/*  97 */           this.resultMap.idResultMappings.add(resultMapping);
/*     */         }
/*     */       }
/* 100 */       if (this.resultMap.idResultMappings.isEmpty()) {
/* 101 */         this.resultMap.idResultMappings.addAll(this.resultMap.resultMappings);
/*     */       }
/*     */       
/* 104 */       this.resultMap.resultMappings = Collections.unmodifiableList(this.resultMap.resultMappings);
/* 105 */       this.resultMap.idResultMappings = Collections.unmodifiableList(this.resultMap.idResultMappings);
/* 106 */       this.resultMap.constructorResultMappings = Collections.unmodifiableList(this.resultMap.constructorResultMappings);
/* 107 */       this.resultMap.propertyResultMappings = Collections.unmodifiableList(this.resultMap.propertyResultMappings);
/* 108 */       this.resultMap.mappedColumns = Collections.unmodifiableSet(this.resultMap.mappedColumns);
/* 109 */       return this.resultMap;
/*     */     }
/*     */   }
/*     */   
/*     */   public String getId() {
/* 114 */     return this.id;
/*     */   }
/*     */   
/*     */   public boolean hasNestedResultMaps() {
/* 118 */     return this.hasNestedResultMaps;
/*     */   }
/*     */   
/*     */   public boolean hasNestedQueries() {
/* 122 */     return this.hasNestedQueries;
/*     */   }
/*     */   
/*     */   public Class<?> getType() {
/* 126 */     return this.type;
/*     */   }
/*     */   
/*     */   public List<ResultMapping> getResultMappings() {
/* 130 */     return this.resultMappings;
/*     */   }
/*     */   
/*     */   public List<ResultMapping> getConstructorResultMappings() {
/* 134 */     return this.constructorResultMappings;
/*     */   }
/*     */   
/*     */   public List<ResultMapping> getPropertyResultMappings() {
/* 138 */     return this.propertyResultMappings;
/*     */   }
/*     */   
/*     */   public List<ResultMapping> getIdResultMappings() {
/* 142 */     return this.idResultMappings;
/*     */   }
/*     */   
/*     */   public Set<String> getMappedColumns() {
/* 146 */     return this.mappedColumns;
/*     */   }
/*     */   
/*     */   public Discriminator getDiscriminator() {
/* 150 */     return this.discriminator;
/*     */   }
/*     */   
/*     */   public void forceNestedResultMaps() {
/* 154 */     this.hasNestedResultMaps = true;
/*     */   }
/*     */   
/*     */   public Boolean getAutoMapping() {
/* 158 */     return this.autoMapping;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\mapping\ResultMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */