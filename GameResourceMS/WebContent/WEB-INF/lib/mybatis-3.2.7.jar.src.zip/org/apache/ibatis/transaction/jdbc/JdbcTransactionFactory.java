/*    */ package org.apache.ibatis.transaction.jdbc;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.util.Properties;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.ibatis.session.TransactionIsolationLevel;
/*    */ import org.apache.ibatis.transaction.Transaction;
/*    */ import org.apache.ibatis.transaction.TransactionFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JdbcTransactionFactory
/*    */   implements TransactionFactory
/*    */ {
/*    */   public void setProperties(Properties props) {}
/*    */   
/*    */   public Transaction newTransaction(Connection conn)
/*    */   {
/* 41 */     return new JdbcTransaction(conn);
/*    */   }
/*    */   
/*    */   public Transaction newTransaction(DataSource ds, TransactionIsolationLevel level, boolean autoCommit) {
/* 45 */     return new JdbcTransaction(ds, level, autoCommit);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\transaction\jdbc\JdbcTransactionFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */