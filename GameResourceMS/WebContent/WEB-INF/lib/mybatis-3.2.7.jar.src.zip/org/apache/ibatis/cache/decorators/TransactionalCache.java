/*     */ package org.apache.ibatis.cache.decorators;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import org.apache.ibatis.cache.Cache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransactionalCache
/*     */   implements Cache
/*     */ {
/*     */   private Cache delegate;
/*     */   private boolean clearOnCommit;
/*     */   private Map<Object, AddEntry> entriesToAddOnCommit;
/*     */   private Map<Object, RemoveEntry> entriesToRemoveOnCommit;
/*     */   
/*     */   public TransactionalCache(Cache delegate)
/*     */   {
/*  35 */     this.delegate = delegate;
/*  36 */     this.clearOnCommit = false;
/*  37 */     this.entriesToAddOnCommit = new HashMap();
/*  38 */     this.entriesToRemoveOnCommit = new HashMap();
/*     */   }
/*     */   
/*     */   public String getId()
/*     */   {
/*  43 */     return this.delegate.getId();
/*     */   }
/*     */   
/*     */   public int getSize()
/*     */   {
/*  48 */     return this.delegate.getSize();
/*     */   }
/*     */   
/*     */   public Object getObject(Object key)
/*     */   {
/*  53 */     if (this.clearOnCommit) return null;
/*  54 */     return this.delegate.getObject(key);
/*     */   }
/*     */   
/*     */   public ReadWriteLock getReadWriteLock()
/*     */   {
/*  59 */     return null;
/*     */   }
/*     */   
/*     */   public void putObject(Object key, Object object)
/*     */   {
/*  64 */     this.entriesToRemoveOnCommit.remove(key);
/*  65 */     this.entriesToAddOnCommit.put(key, new AddEntry(this.delegate, key, object));
/*     */   }
/*     */   
/*     */   public Object removeObject(Object key)
/*     */   {
/*  70 */     this.entriesToAddOnCommit.remove(key);
/*  71 */     this.entriesToRemoveOnCommit.put(key, new RemoveEntry(this.delegate, key));
/*  72 */     return this.delegate.getObject(key);
/*     */   }
/*     */   
/*     */   public void clear()
/*     */   {
/*  77 */     reset();
/*  78 */     this.clearOnCommit = true;
/*     */   }
/*     */   
/*     */   public void commit() {
/*  82 */     if (this.clearOnCommit) {
/*  83 */       this.delegate.clear();
/*     */     } else {
/*  85 */       for (RemoveEntry entry : this.entriesToRemoveOnCommit.values()) {
/*  86 */         entry.commit();
/*     */       }
/*     */     }
/*  89 */     for (AddEntry entry : this.entriesToAddOnCommit.values()) {
/*  90 */       entry.commit();
/*     */     }
/*  92 */     reset();
/*     */   }
/*     */   
/*     */   public void rollback() {
/*  96 */     reset();
/*     */   }
/*     */   
/*     */   private void reset() {
/* 100 */     this.clearOnCommit = false;
/* 101 */     this.entriesToRemoveOnCommit.clear();
/* 102 */     this.entriesToAddOnCommit.clear();
/*     */   }
/*     */   
/*     */   private static class AddEntry {
/*     */     private Cache cache;
/*     */     private Object key;
/*     */     private Object value;
/*     */     
/*     */     public AddEntry(Cache cache, Object key, Object value) {
/* 111 */       this.cache = cache;
/* 112 */       this.key = key;
/* 113 */       this.value = value;
/*     */     }
/*     */     
/*     */     public void commit() {
/* 117 */       this.cache.putObject(this.key, this.value);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class RemoveEntry {
/*     */     private Cache cache;
/*     */     private Object key;
/*     */     
/*     */     public RemoveEntry(Cache cache, Object key) {
/* 126 */       this.cache = cache;
/* 127 */       this.key = key;
/*     */     }
/*     */     
/*     */     public void commit() {
/* 131 */       this.cache.removeObject(this.key);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\cache\decorators\TransactionalCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */