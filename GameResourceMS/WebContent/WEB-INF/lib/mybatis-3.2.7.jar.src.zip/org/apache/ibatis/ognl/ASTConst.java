/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ASTConst
/*     */   extends SimpleNode
/*     */ {
/*     */   private Object value;
/*     */   
/*     */   public ASTConst(int id)
/*     */   {
/*  44 */     super(id);
/*     */   }
/*     */   
/*     */   public ASTConst(OgnlParser p, int id) {
/*  48 */     super(p, id);
/*     */   }
/*     */   
/*     */   void setValue(Object value)
/*     */   {
/*  53 */     this.value = value;
/*     */   }
/*     */   
/*     */   public Object getValue() {
/*  57 */     return this.value;
/*     */   }
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/*  61 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  66 */   public boolean isNodeConstant(OgnlContext context) throws OgnlException { return true; }
/*     */   
/*     */   public String getEscapedChar(char ch) { String result;
/*     */     String result;
/*     */     String result;
/*     */     String result;
/*     */     String result;
/*  73 */     String result; String result; String result; String result; switch (ch) {
/*     */     case '\b': 
/*  75 */       result = "\b";
/*  76 */       break;
/*     */     case '\t': 
/*  78 */       result = "\\t";
/*  79 */       break;
/*     */     case '\n': 
/*  81 */       result = "\\n";
/*  82 */       break;
/*     */     case '\f': 
/*  84 */       result = "\\f";
/*  85 */       break;
/*     */     case '\r': 
/*  87 */       result = "\\r";
/*  88 */       break;
/*     */     case '"': 
/*  90 */       result = "\\\"";
/*  91 */       break;
/*     */     case '\'': 
/*  93 */       result = "\\'";
/*  94 */       break;
/*     */     case '\\': 
/*  96 */       result = "\\\\";
/*  97 */       break;
/*     */     default: 
/*  99 */       if ((Character.isISOControl(ch)) || (ch > 'ÿ')) {
/* 100 */         String hc = Integer.toString(ch, 16);
/* 101 */         int hcl = hc.length();
/*     */         
/* 103 */         String result = "\\u";
/* 104 */         if (hcl < 4) {
/* 105 */           if (hcl == 3) {
/* 106 */             result = result + "0";
/*     */           }
/* 108 */           else if (hcl == 2) {
/* 109 */             result = result + "00";
/*     */           } else {
/* 111 */             result = result + "000";
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 116 */         result = result + hc;
/*     */       } else {
/* 118 */         result = new String(ch);
/*     */       }
/*     */       break;
/*     */     }
/* 122 */     return result;
/*     */   }
/*     */   
/*     */   public String getEscapedString(String value)
/*     */   {
/* 127 */     StringBuffer result = new StringBuffer();
/*     */     
/* 129 */     int i = 0; for (int icount = value.length(); i < icount; i++) {
/* 130 */       result.append(getEscapedChar(value.charAt(i)));
/*     */     }
/* 132 */     return new String(result);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*     */     String result;
/*     */     String result;
/* 139 */     if (this.value == null) {
/* 140 */       result = "null";
/*     */     } else { String result;
/* 142 */       if ((this.value instanceof String)) {
/* 143 */         result = '"' + getEscapedString(this.value.toString()) + '"';
/*     */       } else { String result;
/* 145 */         if ((this.value instanceof Character)) {
/* 146 */           result = '\'' + getEscapedChar(((Character)this.value).charValue()) + '\'';
/*     */         } else {
/* 148 */           result = this.value.toString();
/* 149 */           if ((this.value instanceof Long)) {
/* 150 */             result = result + "L";
/*     */           }
/* 152 */           else if ((this.value instanceof BigDecimal)) {
/* 153 */             result = result + "B";
/*     */           }
/* 155 */           else if ((this.value instanceof BigInteger)) {
/* 156 */             result = result + "H";
/*     */           }
/* 158 */           else if ((this.value instanceof Node)) {
/* 159 */             result = ":[ " + result + " ]";
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 167 */     return result;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTConst.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */