/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ASTChain
/*     */   extends SimpleNode
/*     */ {
/*     */   public ASTChain(int id)
/*     */   {
/*  42 */     super(id);
/*     */   }
/*     */   
/*     */   public ASTChain(OgnlParser p, int id) {
/*  46 */     super(p, id);
/*     */   }
/*     */   
/*     */   public void jjtClose() {
/*  50 */     flattenTree();
/*     */   }
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException
/*     */   {
/*  55 */     Object result = source;
/*     */     
/*  57 */     int i = 0; for (int ilast = this.children.length - 1; i <= ilast; i++) {
/*  58 */       boolean handled = false;
/*     */       
/*  60 */       if ((i < ilast) && 
/*  61 */         ((this.children[i] instanceof ASTProperty))) {
/*  62 */         ASTProperty propertyNode = (ASTProperty)this.children[i];
/*  63 */         int indexType = propertyNode.getIndexedPropertyType(context, result);
/*     */         
/*  65 */         if ((indexType != OgnlRuntime.INDEXED_PROPERTY_NONE) && ((this.children[(i + 1)] instanceof ASTProperty))) {
/*  66 */           ASTProperty indexNode = (ASTProperty)this.children[(i + 1)];
/*     */           
/*  68 */           if (indexNode.isIndexedAccess()) {
/*  69 */             Object index = indexNode.getProperty(context, result);
/*     */             
/*  71 */             if ((index instanceof DynamicSubscript)) {
/*  72 */               if (indexType == OgnlRuntime.INDEXED_PROPERTY_INT) {
/*  73 */                 Object array = propertyNode.getValue(context, result);
/*  74 */                 int len = Array.getLength(array);
/*     */                 
/*  76 */                 switch (((DynamicSubscript)index).getFlag()) {
/*     */                 case 3: 
/*  78 */                   result = Array.newInstance(array.getClass().getComponentType(), len);
/*  79 */                   System.arraycopy(array, 0, result, 0, len);
/*  80 */                   handled = true;
/*  81 */                   i++;
/*  82 */                   break;
/*     */                 case 0: 
/*  84 */                   index = new Integer(len > 0 ? 0 : -1);
/*  85 */                   break;
/*     */                 case 1: 
/*  87 */                   index = new Integer(len > 0 ? len / 2 : -1);
/*  88 */                   break;
/*     */                 case 2: 
/*  90 */                   index = new Integer(len > 0 ? len - 1 : -1);
/*     */                 }
/*     */                 
/*     */               }
/*  94 */               else if (indexType == OgnlRuntime.INDEXED_PROPERTY_OBJECT) {
/*  95 */                 throw new OgnlException("DynamicSubscript '" + indexNode + "' not allowed for object indexed property '" + propertyNode + "'");
/*     */               }
/*     */             }
/*     */             
/*  99 */             if (!handled) {
/* 100 */               result = OgnlRuntime.getIndexedProperty(context, result, propertyNode.getProperty(context, result).toString(), index);
/* 101 */               handled = true;
/* 102 */               i++;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 108 */       if (!handled) {
/* 109 */         result = this.children[i].getValue(context, result);
/*     */       }
/*     */     }
/* 112 */     return result;
/*     */   }
/*     */   
/*     */   protected void setValueBody(OgnlContext context, Object target, Object value) throws OgnlException
/*     */   {
/* 117 */     boolean handled = false;
/*     */     
/* 119 */     int i = 0; for (int ilast = this.children.length - 2; i <= ilast; i++) {
/* 120 */       if ((i == ilast) && 
/* 121 */         ((this.children[i] instanceof ASTProperty))) {
/* 122 */         ASTProperty propertyNode = (ASTProperty)this.children[i];
/* 123 */         int indexType = propertyNode.getIndexedPropertyType(context, target);
/*     */         
/* 125 */         if ((indexType != OgnlRuntime.INDEXED_PROPERTY_NONE) && ((this.children[(i + 1)] instanceof ASTProperty))) {
/* 126 */           ASTProperty indexNode = (ASTProperty)this.children[(i + 1)];
/*     */           
/* 128 */           if (indexNode.isIndexedAccess()) {
/* 129 */             Object index = indexNode.getProperty(context, target);
/*     */             
/* 131 */             if ((index instanceof DynamicSubscript)) {
/* 132 */               if (indexType == OgnlRuntime.INDEXED_PROPERTY_INT) {
/* 133 */                 Object array = propertyNode.getValue(context, target);
/* 134 */                 int len = Array.getLength(array);
/*     */                 
/* 136 */                 switch (((DynamicSubscript)index).getFlag()) {
/*     */                 case 3: 
/* 138 */                   System.arraycopy(target, 0, value, 0, len);
/* 139 */                   handled = true;
/* 140 */                   i++;
/* 141 */                   break;
/*     */                 case 0: 
/* 143 */                   index = new Integer(len > 0 ? 0 : -1);
/* 144 */                   break;
/*     */                 case 1: 
/* 146 */                   index = new Integer(len > 0 ? len / 2 : -1);
/* 147 */                   break;
/*     */                 case 2: 
/* 149 */                   index = new Integer(len > 0 ? len - 1 : -1);
/*     */                 }
/*     */                 
/*     */               }
/* 153 */               else if (indexType == OgnlRuntime.INDEXED_PROPERTY_OBJECT) {
/* 154 */                 throw new OgnlException("DynamicSubscript '" + indexNode + "' not allowed for object indexed property '" + propertyNode + "'");
/*     */               }
/*     */             }
/*     */             
/* 158 */             if (!handled) {
/* 159 */               OgnlRuntime.setIndexedProperty(context, target, propertyNode.getProperty(context, target).toString(), index, value);
/* 160 */               handled = true;
/* 161 */               i++;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 167 */       if (!handled) {
/* 168 */         target = this.children[i].getValue(context, target);
/*     */       }
/*     */     }
/* 171 */     if (!handled) {
/* 172 */       this.children[(this.children.length - 1)].setValue(context, target, value);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isSimpleNavigationChain(OgnlContext context) throws OgnlException
/*     */   {
/* 178 */     boolean result = false;
/*     */     
/* 180 */     if ((this.children != null) && (this.children.length > 0)) {
/* 181 */       result = true;
/* 182 */       for (int i = 0; (result) && (i < this.children.length); i++) {
/* 183 */         if ((this.children[i] instanceof SimpleNode)) {
/* 184 */           result = ((SimpleNode)this.children[i]).isSimpleProperty(context);
/*     */         } else {
/* 186 */           result = false;
/*     */         }
/*     */       }
/*     */     }
/* 190 */     return result;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 195 */     String result = "";
/*     */     
/* 197 */     if ((this.children != null) && (this.children.length > 0)) {
/* 198 */       for (int i = 0; i < this.children.length; i++) {
/* 199 */         if ((i > 0) && (
/* 200 */           (!(this.children[i] instanceof ASTProperty)) || (!((ASTProperty)this.children[i]).isIndexedAccess()))) {
/* 201 */           result = result + ".";
/*     */         }
/*     */         
/* 204 */         result = result + this.children[i].toString();
/*     */       }
/*     */     }
/* 207 */     return result;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTChain.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */