/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ import java.beans.IntrospectionException;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectPropertyAccessor
/*     */   implements PropertyAccessor
/*     */ {
/*     */   public Object getPossibleProperty(Map context, Object target, String name)
/*     */     throws OgnlException
/*     */   {
/*  50 */     OgnlContext ognlContext = (OgnlContext)context;
/*     */     try {
/*     */       Object result;
/*  53 */       if ((result = OgnlRuntime.getMethodValue(ognlContext, target, name, true)) == OgnlRuntime.NotFound) {
/*  54 */         result = OgnlRuntime.getFieldValue(ognlContext, target, name, true);
/*     */       }
/*     */     } catch (IntrospectionException ex) {
/*  57 */       throw new OgnlException(name, ex);
/*     */     } catch (OgnlException ex) {
/*  59 */       throw ex;
/*     */     } catch (Exception ex) {
/*  61 */       throw new OgnlException(name, ex); }
/*     */     Object result;
/*  63 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object setPossibleProperty(Map context, Object target, String name, Object value)
/*     */     throws OgnlException
/*     */   {
/*  71 */     Object result = null;
/*  72 */     OgnlContext ognlContext = (OgnlContext)context;
/*     */     try
/*     */     {
/*  75 */       if (!OgnlRuntime.setMethodValue(ognlContext, target, name, value, true)) {
/*  76 */         result = OgnlRuntime.setFieldValue(ognlContext, target, name, value) ? null : OgnlRuntime.NotFound;
/*     */       }
/*     */     } catch (IntrospectionException ex) {
/*  79 */       throw new OgnlException(name, ex);
/*     */     } catch (OgnlException ex) {
/*  81 */       throw ex;
/*     */     } catch (Exception ex) {
/*  83 */       throw new OgnlException(name, ex);
/*     */     }
/*  85 */     return result;
/*     */   }
/*     */   
/*     */   public boolean hasGetProperty(OgnlContext context, Object target, Object oname) throws OgnlException
/*     */   {
/*     */     try {
/*  91 */       return OgnlRuntime.hasGetProperty(context, target, oname);
/*     */     } catch (IntrospectionException ex) {
/*  93 */       throw new OgnlException("checking if " + target + " has gettable property " + oname, ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasGetProperty(Map context, Object target, Object oname) throws OgnlException
/*     */   {
/*  99 */     return hasGetProperty((OgnlContext)context, target, oname);
/*     */   }
/*     */   
/*     */   public boolean hasSetProperty(OgnlContext context, Object target, Object oname) throws OgnlException
/*     */   {
/*     */     try {
/* 105 */       return OgnlRuntime.hasSetProperty(context, target, oname);
/*     */     } catch (IntrospectionException ex) {
/* 107 */       throw new OgnlException("checking if " + target + " has settable property " + oname, ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasSetProperty(Map context, Object target, Object oname) throws OgnlException
/*     */   {
/* 113 */     return hasSetProperty((OgnlContext)context, target, oname);
/*     */   }
/*     */   
/*     */   public Object getProperty(Map context, Object target, Object oname) throws OgnlException
/*     */   {
/* 118 */     Object result = null;
/* 119 */     String name = oname.toString();
/*     */     
/* 121 */     if ((result = getPossibleProperty(context, target, name)) == OgnlRuntime.NotFound) {
/* 122 */       throw new NoSuchPropertyException(target, name);
/*     */     }
/* 124 */     return result;
/*     */   }
/*     */   
/*     */   public void setProperty(Map context, Object target, Object oname, Object value) throws OgnlException
/*     */   {
/* 129 */     String name = oname.toString();
/*     */     
/* 131 */     if (setPossibleProperty(context, target, name, value) == OgnlRuntime.NotFound) {
/* 132 */       throw new NoSuchPropertyException(target, name);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ObjectPropertyAccessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */