/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OgnlContext
/*     */   implements Map
/*     */ {
/*     */   public static final String CONTEXT_CONTEXT_KEY = "context";
/*     */   public static final String ROOT_CONTEXT_KEY = "root";
/*     */   public static final String THIS_CONTEXT_KEY = "this";
/*     */   public static final String TRACE_EVALUATIONS_CONTEXT_KEY = "_traceEvaluations";
/*     */   public static final String LAST_EVALUATION_CONTEXT_KEY = "_lastEvaluation";
/*     */   public static final String KEEP_LAST_EVALUATION_CONTEXT_KEY = "_keepLastEvaluation";
/*     */   public static final String CLASS_RESOLVER_CONTEXT_KEY = "_classResolver";
/*     */   public static final String TYPE_CONVERTER_CONTEXT_KEY = "_typeConverter";
/*     */   public static final String MEMBER_ACCESS_CONTEXT_KEY = "_memberAccess";
/*     */   private static final String PROPERTY_KEY_PREFIX = "ognl";
/*  53 */   private static boolean DEFAULT_TRACE_EVALUATIONS = false;
/*  54 */   private static boolean DEFAULT_KEEP_LAST_EVALUATION = false;
/*     */   
/*  56 */   public static final ClassResolver DEFAULT_CLASS_RESOLVER = new DefaultClassResolver();
/*  57 */   public static final TypeConverter DEFAULT_TYPE_CONVERTER = new DefaultTypeConverter();
/*  58 */   public static final MemberAccess DEFAULT_MEMBER_ACCESS = new DefaultMemberAccess(false);
/*     */   
/*  60 */   private static Map RESERVED_KEYS = new HashMap(11);
/*     */   
/*     */   private Object root;
/*     */   private Object currentObject;
/*     */   private Node currentNode;
/*  65 */   private boolean traceEvaluations = DEFAULT_TRACE_EVALUATIONS;
/*     */   private Evaluation rootEvaluation;
/*     */   private Evaluation currentEvaluation;
/*     */   private Evaluation lastEvaluation;
/*  69 */   private boolean keepLastEvaluation = DEFAULT_KEEP_LAST_EVALUATION;
/*  70 */   private Map values = new HashMap(23);
/*  71 */   private ClassResolver classResolver = DEFAULT_CLASS_RESOLVER;
/*  72 */   private TypeConverter typeConverter = DEFAULT_TYPE_CONVERTER;
/*  73 */   private MemberAccess memberAccess = DEFAULT_MEMBER_ACCESS;
/*     */   
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  79 */     RESERVED_KEYS.put("context", null);
/*  80 */     RESERVED_KEYS.put("root", null);
/*  81 */     RESERVED_KEYS.put("this", null);
/*  82 */     RESERVED_KEYS.put("_traceEvaluations", null);
/*  83 */     RESERVED_KEYS.put("_lastEvaluation", null);
/*  84 */     RESERVED_KEYS.put("_keepLastEvaluation", null);
/*  85 */     RESERVED_KEYS.put("_classResolver", null);
/*  86 */     RESERVED_KEYS.put("_typeConverter", null);
/*  87 */     RESERVED_KEYS.put("_memberAccess", null);
/*     */     try {
/*     */       String s;
/*  90 */       if ((s = System.getProperty("org.apache.ibatis.ognl.traceEvaluations")) != null) {
/*  91 */         DEFAULT_TRACE_EVALUATIONS = Boolean.valueOf(s.trim()).booleanValue();
/*     */       }
/*  93 */       if ((s = System.getProperty("org.apache.ibatis.ognl.keepLastEvaluation")) != null) {
/*  94 */         DEFAULT_KEEP_LAST_EVALUATION = Boolean.valueOf(s.trim()).booleanValue();
/*     */       }
/*     */     }
/*     */     catch (SecurityException localSecurityException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OgnlContext() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OgnlContext(ClassResolver classResolver, TypeConverter typeConverter, MemberAccess memberAccess)
/*     */   {
/* 116 */     this();
/* 117 */     if (classResolver != null) {
/* 118 */       this.classResolver = classResolver;
/*     */     }
/* 120 */     if (typeConverter != null) {
/* 121 */       this.typeConverter = typeConverter;
/*     */     }
/* 123 */     if (memberAccess != null) {
/* 124 */       this.memberAccess = memberAccess;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public OgnlContext(Map values)
/*     */   {
/* 131 */     this.values = values;
/*     */   }
/*     */   
/*     */   public OgnlContext(ClassResolver classResolver, TypeConverter typeConverter, MemberAccess memberAccess, Map values)
/*     */   {
/* 136 */     this(classResolver, typeConverter, memberAccess);
/* 137 */     this.values = values;
/*     */   }
/*     */   
/*     */   public void setValues(Map value)
/*     */   {
/* 142 */     for (Iterator it = value.keySet().iterator(); it.hasNext();) {
/* 143 */       Object k = it.next();
/*     */       
/* 145 */       this.values.put(k, value.get(k));
/*     */     }
/*     */   }
/*     */   
/*     */   public Map getValues()
/*     */   {
/* 151 */     return this.values;
/*     */   }
/*     */   
/*     */   public void setClassResolver(ClassResolver value)
/*     */   {
/* 156 */     if (value == null) {
/* 157 */       throw new IllegalArgumentException("cannot set ClassResolver to null");
/*     */     }
/* 159 */     this.classResolver = value;
/*     */   }
/*     */   
/*     */   public ClassResolver getClassResolver()
/*     */   {
/* 164 */     return this.classResolver;
/*     */   }
/*     */   
/*     */   public void setTypeConverter(TypeConverter value)
/*     */   {
/* 169 */     if (value == null) {
/* 170 */       throw new IllegalArgumentException("cannot set TypeConverter to null");
/*     */     }
/* 172 */     this.typeConverter = value;
/*     */   }
/*     */   
/*     */   public TypeConverter getTypeConverter()
/*     */   {
/* 177 */     return this.typeConverter;
/*     */   }
/*     */   
/*     */   public void setMemberAccess(MemberAccess value)
/*     */   {
/* 182 */     if (value == null) {
/* 183 */       throw new IllegalArgumentException("cannot set MemberAccess to null");
/*     */     }
/* 185 */     this.memberAccess = value;
/*     */   }
/*     */   
/*     */   public MemberAccess getMemberAccess()
/*     */   {
/* 190 */     return this.memberAccess;
/*     */   }
/*     */   
/*     */   public void setRoot(Object value)
/*     */   {
/* 195 */     this.root = value;
/*     */   }
/*     */   
/*     */   public Object getRoot()
/*     */   {
/* 200 */     return this.root;
/*     */   }
/*     */   
/*     */   public boolean getTraceEvaluations()
/*     */   {
/* 205 */     return this.traceEvaluations;
/*     */   }
/*     */   
/*     */   public void setTraceEvaluations(boolean value)
/*     */   {
/* 210 */     this.traceEvaluations = value;
/*     */   }
/*     */   
/*     */   public Evaluation getLastEvaluation()
/*     */   {
/* 215 */     return this.lastEvaluation;
/*     */   }
/*     */   
/*     */   public void setLastEvaluation(Evaluation value)
/*     */   {
/* 220 */     this.lastEvaluation = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void recycleLastEvaluation()
/*     */   {
/* 232 */     OgnlRuntime.getEvaluationPool().recycleAll(this.lastEvaluation);
/* 233 */     this.lastEvaluation = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getKeepLastEvaluation()
/*     */   {
/* 243 */     return this.keepLastEvaluation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setKeepLastEvaluation(boolean value)
/*     */   {
/* 253 */     this.keepLastEvaluation = value;
/*     */   }
/*     */   
/*     */   public void setCurrentObject(Object value)
/*     */   {
/* 258 */     this.currentObject = value;
/*     */   }
/*     */   
/*     */   public Object getCurrentObject()
/*     */   {
/* 263 */     return this.currentObject;
/*     */   }
/*     */   
/*     */   public void setCurrentNode(Node value)
/*     */   {
/* 268 */     this.currentNode = value;
/*     */   }
/*     */   
/*     */   public Node getCurrentNode()
/*     */   {
/* 273 */     return this.currentNode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Evaluation getCurrentEvaluation()
/*     */   {
/* 282 */     return this.currentEvaluation;
/*     */   }
/*     */   
/*     */   public void setCurrentEvaluation(Evaluation value)
/*     */   {
/* 287 */     this.currentEvaluation = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Evaluation getRootEvaluation()
/*     */   {
/* 298 */     return this.rootEvaluation;
/*     */   }
/*     */   
/*     */   public void setRootEvaluation(Evaluation value)
/*     */   {
/* 303 */     this.rootEvaluation = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Evaluation getEvaluation(int relativeIndex)
/*     */   {
/* 313 */     Evaluation result = null;
/*     */     
/* 315 */     if (relativeIndex <= 0) {
/* 316 */       result = this.currentEvaluation;
/*     */       do {
/* 318 */         result = result.getParent();relativeIndex++;
/* 317 */       } while ((relativeIndex < 0) && (result != null));
/*     */     }
/*     */     
/*     */ 
/* 321 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void pushEvaluation(Evaluation value)
/*     */   {
/* 331 */     if (this.currentEvaluation != null) {
/* 332 */       this.currentEvaluation.addChild(value);
/*     */     } else {
/* 334 */       setRootEvaluation(value);
/*     */     }
/* 336 */     setCurrentEvaluation(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Evaluation popEvaluation()
/*     */   {
/* 347 */     Evaluation result = this.currentEvaluation;
/* 348 */     setCurrentEvaluation(result.getParent());
/* 349 */     if (this.currentEvaluation == null) {
/* 350 */       setLastEvaluation(getKeepLastEvaluation() ? result : null);
/* 351 */       setRootEvaluation(null);
/* 352 */       setCurrentNode(null);
/*     */     }
/* 354 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public int size()
/*     */   {
/* 360 */     return this.values.size();
/*     */   }
/*     */   
/*     */   public boolean isEmpty()
/*     */   {
/* 365 */     return this.values.isEmpty();
/*     */   }
/*     */   
/*     */   public boolean containsKey(Object key)
/*     */   {
/* 370 */     return this.values.containsKey(key);
/*     */   }
/*     */   
/*     */   public boolean containsValue(Object value)
/*     */   {
/* 375 */     return this.values.containsValue(value);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object get(Object key)
/*     */   {
/*     */     Object result;
/* 382 */     if (RESERVED_KEYS.containsKey(key)) { Object result;
/* 383 */       if (key.equals("this")) {
/* 384 */         result = getCurrentObject();
/*     */       } else { Object result;
/* 386 */         if (key.equals("root")) {
/* 387 */           result = getRoot();
/*     */         } else { Object result;
/* 389 */           if (key.equals("context")) {
/* 390 */             result = this;
/*     */           } else { Object result;
/* 392 */             if (key.equals("_traceEvaluations")) {
/* 393 */               result = getTraceEvaluations() ? Boolean.TRUE : Boolean.FALSE;
/*     */             } else { Object result;
/* 395 */               if (key.equals("_lastEvaluation")) {
/* 396 */                 result = getLastEvaluation();
/*     */               } else { Object result;
/* 398 */                 if (key.equals("_keepLastEvaluation")) {
/* 399 */                   result = getKeepLastEvaluation() ? Boolean.TRUE : Boolean.FALSE;
/*     */                 } else { Object result;
/* 401 */                   if (key.equals("_classResolver")) {
/* 402 */                     result = getClassResolver();
/*     */                   } else { Object result;
/* 404 */                     if (key.equals("_typeConverter")) {
/* 405 */                       result = getTypeConverter();
/*     */                     } else { Object result;
/* 407 */                       if (key.equals("_memberAccess")) {
/* 408 */                         result = getMemberAccess();
/*     */                       } else {
/* 410 */                         throw new IllegalArgumentException("unknown reserved key '" + key + "'");
/*     */                       }
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     } else {
/* 421 */       result = this.values.get(key);
/*     */     }
/* 423 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public Object put(Object key, Object value)
/*     */   {
/*     */     Object result;
/* 430 */     if (RESERVED_KEYS.containsKey(key)) {
/* 431 */       if (key.equals("this")) {
/* 432 */         Object result = getCurrentObject();
/* 433 */         setCurrentObject(value);
/*     */       }
/* 435 */       else if (key.equals("root")) {
/* 436 */         Object result = getRoot();
/* 437 */         setRoot(value);
/*     */       } else {
/* 439 */         if (key.equals("context")) {
/* 440 */           throw new IllegalArgumentException("can't change context in context");
/*     */         }
/* 442 */         if (key.equals("_traceEvaluations")) {
/* 443 */           Object result = getTraceEvaluations() ? Boolean.TRUE : Boolean.FALSE;
/* 444 */           setTraceEvaluations(OgnlOps.booleanValue(value));
/*     */         }
/* 446 */         else if (key.equals("_lastEvaluation")) {
/* 447 */           Object result = getLastEvaluation();
/* 448 */           this.lastEvaluation = ((Evaluation)value);
/*     */         }
/* 450 */         else if (key.equals("_keepLastEvaluation")) {
/* 451 */           Object result = getKeepLastEvaluation() ? Boolean.TRUE : Boolean.FALSE;
/* 452 */           setKeepLastEvaluation(OgnlOps.booleanValue(value));
/*     */         }
/* 454 */         else if (key.equals("_classResolver")) {
/* 455 */           Object result = getClassResolver();
/* 456 */           setClassResolver((ClassResolver)value);
/*     */         }
/* 458 */         else if (key.equals("_typeConverter")) {
/* 459 */           Object result = getTypeConverter();
/* 460 */           setTypeConverter((TypeConverter)value);
/*     */         }
/* 462 */         else if (key.equals("_memberAccess")) {
/* 463 */           Object result = getMemberAccess();
/* 464 */           setMemberAccess((MemberAccess)value);
/*     */         } else {
/* 466 */           throw new IllegalArgumentException("unknown reserved key '" + key + "'");
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 477 */       result = this.values.put(key, value);
/*     */     }
/* 479 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public Object remove(Object key)
/*     */   {
/*     */     Object result;
/* 486 */     if (RESERVED_KEYS.containsKey(key)) {
/* 487 */       if (key.equals("this")) {
/* 488 */         Object result = getCurrentObject();
/* 489 */         setCurrentObject(null);
/*     */       }
/* 491 */       else if (key.equals("root")) {
/* 492 */         Object result = getRoot();
/* 493 */         setRoot(null);
/*     */       } else {
/* 495 */         if (key.equals("context")) {
/* 496 */           throw new IllegalArgumentException("can't remove context from context");
/*     */         }
/* 498 */         if (key.equals("_traceEvaluations")) {
/* 499 */           throw new IllegalArgumentException("can't remove _traceEvaluations from context");
/*     */         }
/* 501 */         if (key.equals("_lastEvaluation")) {
/* 502 */           Object result = this.lastEvaluation;
/* 503 */           setLastEvaluation(null);
/*     */         } else {
/* 505 */           if (key.equals("_keepLastEvaluation")) {
/* 506 */             throw new IllegalArgumentException("can't remove _keepLastEvaluation from context");
/*     */           }
/* 508 */           if (key.equals("_classResolver")) {
/* 509 */             Object result = getClassResolver();
/* 510 */             setClassResolver(null);
/*     */           }
/* 512 */           else if (key.equals("_typeConverter")) {
/* 513 */             Object result = getTypeConverter();
/* 514 */             setTypeConverter(null);
/*     */           }
/* 516 */           else if (key.equals("_memberAccess")) {
/* 517 */             Object result = getMemberAccess();
/* 518 */             setMemberAccess(null);
/*     */           } else {
/* 520 */             throw new IllegalArgumentException("unknown reserved key '" + key + "'");
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 531 */       result = this.values.remove(key);
/*     */     }
/* 533 */     return result;
/*     */   }
/*     */   
/*     */   public void putAll(Map t)
/*     */   {
/* 538 */     for (Iterator it = t.keySet().iterator(); it.hasNext();) {
/* 539 */       Object k = it.next();
/*     */       
/* 541 */       put(k, t.get(k));
/*     */     }
/*     */   }
/*     */   
/*     */   public void clear()
/*     */   {
/* 547 */     this.values.clear();
/* 548 */     setRoot(null);
/* 549 */     setCurrentObject(null);
/* 550 */     setRootEvaluation(null);
/* 551 */     setCurrentEvaluation(null);
/* 552 */     setLastEvaluation(null);
/* 553 */     setCurrentNode(null);
/* 554 */     setClassResolver(DEFAULT_CLASS_RESOLVER);
/* 555 */     setTypeConverter(DEFAULT_TYPE_CONVERTER);
/* 556 */     setMemberAccess(DEFAULT_MEMBER_ACCESS);
/*     */   }
/*     */   
/*     */ 
/*     */   public Set keySet()
/*     */   {
/* 562 */     return this.values.keySet();
/*     */   }
/*     */   
/*     */ 
/*     */   public Collection values()
/*     */   {
/* 568 */     return this.values.values();
/*     */   }
/*     */   
/*     */ 
/*     */   public Set entrySet()
/*     */   {
/* 574 */     return this.values.entrySet();
/*     */   }
/*     */   
/*     */   public boolean equals(Object o)
/*     */   {
/* 579 */     return this.values.equals(o);
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 584 */     return this.values.hashCode();
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\OgnlContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */