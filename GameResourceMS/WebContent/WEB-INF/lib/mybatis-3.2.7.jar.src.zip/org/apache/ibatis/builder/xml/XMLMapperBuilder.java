/*     */ package org.apache.ibatis.builder.xml;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.ibatis.builder.BaseBuilder;
/*     */ import org.apache.ibatis.builder.BuilderException;
/*     */ import org.apache.ibatis.builder.CacheRefResolver;
/*     */ import org.apache.ibatis.builder.IncompleteElementException;
/*     */ import org.apache.ibatis.builder.MapperBuilderAssistant;
/*     */ import org.apache.ibatis.builder.ResultMapResolver;
/*     */ import org.apache.ibatis.cache.Cache;
/*     */ import org.apache.ibatis.executor.ErrorContext;
/*     */ import org.apache.ibatis.io.Resources;
/*     */ import org.apache.ibatis.mapping.Discriminator;
/*     */ import org.apache.ibatis.mapping.ParameterMapping;
/*     */ import org.apache.ibatis.mapping.ParameterMode;
/*     */ import org.apache.ibatis.mapping.ResultFlag;
/*     */ import org.apache.ibatis.mapping.ResultMap;
/*     */ import org.apache.ibatis.mapping.ResultMapping;
/*     */ import org.apache.ibatis.parsing.XNode;
/*     */ import org.apache.ibatis.parsing.XPathParser;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.type.JdbcType;
/*     */ import org.apache.ibatis.type.TypeAliasRegistry;
/*     */ import org.apache.ibatis.type.TypeHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLMapperBuilder
/*     */   extends BaseBuilder
/*     */ {
/*     */   private XPathParser parser;
/*     */   private MapperBuilderAssistant builderAssistant;
/*     */   private Map<String, XNode> sqlFragments;
/*     */   private String resource;
/*     */   
/*     */   @Deprecated
/*     */   public XMLMapperBuilder(Reader reader, Configuration configuration, String resource, Map<String, XNode> sqlFragments, String namespace)
/*     */   {
/*  62 */     this(reader, configuration, resource, sqlFragments);
/*  63 */     this.builderAssistant.setCurrentNamespace(namespace);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public XMLMapperBuilder(Reader reader, Configuration configuration, String resource, Map<String, XNode> sqlFragments) {
/*  68 */     this(new XPathParser(reader, true, configuration.getVariables(), new XMLMapperEntityResolver()), configuration, resource, sqlFragments);
/*     */   }
/*     */   
/*     */   public XMLMapperBuilder(InputStream inputStream, Configuration configuration, String resource, Map<String, XNode> sqlFragments, String namespace)
/*     */   {
/*  73 */     this(inputStream, configuration, resource, sqlFragments);
/*  74 */     this.builderAssistant.setCurrentNamespace(namespace);
/*     */   }
/*     */   
/*     */   public XMLMapperBuilder(InputStream inputStream, Configuration configuration, String resource, Map<String, XNode> sqlFragments) {
/*  78 */     this(new XPathParser(inputStream, true, configuration.getVariables(), new XMLMapperEntityResolver()), configuration, resource, sqlFragments);
/*     */   }
/*     */   
/*     */   private XMLMapperBuilder(XPathParser parser, Configuration configuration, String resource, Map<String, XNode> sqlFragments)
/*     */   {
/*  83 */     super(configuration);
/*  84 */     this.builderAssistant = new MapperBuilderAssistant(configuration, resource);
/*  85 */     this.parser = parser;
/*  86 */     this.sqlFragments = sqlFragments;
/*  87 */     this.resource = resource;
/*     */   }
/*     */   
/*     */   public void parse() {
/*  91 */     if (!this.configuration.isResourceLoaded(this.resource)) {
/*  92 */       configurationElement(this.parser.evalNode("/mapper"));
/*  93 */       this.configuration.addLoadedResource(this.resource);
/*  94 */       bindMapperForNamespace();
/*     */     }
/*     */     
/*  97 */     parsePendingResultMaps();
/*  98 */     parsePendingChacheRefs();
/*  99 */     parsePendingStatements();
/*     */   }
/*     */   
/*     */   public XNode getSqlFragment(String refid) {
/* 103 */     return (XNode)this.sqlFragments.get(refid);
/*     */   }
/*     */   
/*     */   private void configurationElement(XNode context) {
/*     */     try {
/* 108 */       String namespace = context.getStringAttribute("namespace");
/* 109 */       if (namespace.equals("")) {
/* 110 */         throw new BuilderException("Mapper's namespace cannot be empty");
/*     */       }
/* 112 */       this.builderAssistant.setCurrentNamespace(namespace);
/* 113 */       cacheRefElement(context.evalNode("cache-ref"));
/* 114 */       cacheElement(context.evalNode("cache"));
/* 115 */       parameterMapElement(context.evalNodes("/mapper/parameterMap"));
/* 116 */       resultMapElements(context.evalNodes("/mapper/resultMap"));
/* 117 */       sqlElement(context.evalNodes("/mapper/sql"));
/* 118 */       buildStatementFromContext(context.evalNodes("select|insert|update|delete"));
/*     */     } catch (Exception e) {
/* 120 */       throw new BuilderException("Error parsing Mapper XML. Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   private void buildStatementFromContext(List<XNode> list) {
/* 125 */     if (this.configuration.getDatabaseId() != null) {
/* 126 */       buildStatementFromContext(list, this.configuration.getDatabaseId());
/*     */     }
/* 128 */     buildStatementFromContext(list, null);
/*     */   }
/*     */   
/*     */   private void buildStatementFromContext(List<XNode> list, String requiredDatabaseId) {
/* 132 */     for (XNode context : list) {
/* 133 */       XMLStatementBuilder statementParser = new XMLStatementBuilder(this.configuration, this.builderAssistant, context, requiredDatabaseId);
/*     */       try {
/* 135 */         statementParser.parseStatementNode();
/*     */       } catch (IncompleteElementException e) {
/* 137 */         this.configuration.addIncompleteStatement(statementParser);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void parsePendingResultMaps() {
/* 143 */     Collection<ResultMapResolver> incompleteResultMaps = this.configuration.getIncompleteResultMaps();
/* 144 */     synchronized (incompleteResultMaps) {
/* 145 */       Iterator<ResultMapResolver> iter = incompleteResultMaps.iterator();
/* 146 */       while (iter.hasNext()) {
/*     */         try {
/* 148 */           ((ResultMapResolver)iter.next()).resolve();
/* 149 */           iter.remove();
/*     */         }
/*     */         catch (IncompleteElementException e) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void parsePendingChacheRefs()
/*     */   {
/* 158 */     Collection<CacheRefResolver> incompleteCacheRefs = this.configuration.getIncompleteCacheRefs();
/* 159 */     synchronized (incompleteCacheRefs) {
/* 160 */       Iterator<CacheRefResolver> iter = incompleteCacheRefs.iterator();
/* 161 */       while (iter.hasNext()) {
/*     */         try {
/* 163 */           ((CacheRefResolver)iter.next()).resolveCacheRef();
/* 164 */           iter.remove();
/*     */         }
/*     */         catch (IncompleteElementException e) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void parsePendingStatements()
/*     */   {
/* 173 */     Collection<XMLStatementBuilder> incompleteStatements = this.configuration.getIncompleteStatements();
/* 174 */     synchronized (incompleteStatements) {
/* 175 */       Iterator<XMLStatementBuilder> iter = incompleteStatements.iterator();
/* 176 */       while (iter.hasNext()) {
/*     */         try {
/* 178 */           ((XMLStatementBuilder)iter.next()).parseStatementNode();
/* 179 */           iter.remove();
/*     */         }
/*     */         catch (IncompleteElementException e) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void cacheRefElement(XNode context)
/*     */   {
/* 188 */     if (context != null) {
/* 189 */       this.configuration.addCacheRef(this.builderAssistant.getCurrentNamespace(), context.getStringAttribute("namespace"));
/* 190 */       CacheRefResolver cacheRefResolver = new CacheRefResolver(this.builderAssistant, context.getStringAttribute("namespace"));
/*     */       try {
/* 192 */         cacheRefResolver.resolveCacheRef();
/*     */       } catch (IncompleteElementException e) {
/* 194 */         this.configuration.addIncompleteCacheRef(cacheRefResolver);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void cacheElement(XNode context) throws Exception {
/* 200 */     if (context != null) {
/* 201 */       String type = context.getStringAttribute("type", "PERPETUAL");
/* 202 */       Class<? extends Cache> typeClass = this.typeAliasRegistry.resolveAlias(type);
/* 203 */       String eviction = context.getStringAttribute("eviction", "LRU");
/* 204 */       Class<? extends Cache> evictionClass = this.typeAliasRegistry.resolveAlias(eviction);
/* 205 */       Long flushInterval = context.getLongAttribute("flushInterval");
/* 206 */       Integer size = context.getIntAttribute("size");
/* 207 */       boolean readWrite = !context.getBooleanAttribute("readOnly", Boolean.valueOf(false)).booleanValue();
/* 208 */       Properties props = context.getChildrenAsProperties();
/* 209 */       this.builderAssistant.useNewCache(typeClass, evictionClass, flushInterval, size, readWrite, props);
/*     */     }
/*     */   }
/*     */   
/*     */   private void parameterMapElement(List<XNode> list) throws Exception {
/* 214 */     for (XNode parameterMapNode : list) {
/* 215 */       String id = parameterMapNode.getStringAttribute("id");
/* 216 */       String type = parameterMapNode.getStringAttribute("type");
/* 217 */       Class<?> parameterClass = resolveClass(type);
/* 218 */       List<XNode> parameterNodes = parameterMapNode.evalNodes("parameter");
/* 219 */       List<ParameterMapping> parameterMappings = new ArrayList();
/* 220 */       for (XNode parameterNode : parameterNodes) {
/* 221 */         String property = parameterNode.getStringAttribute("property");
/* 222 */         String javaType = parameterNode.getStringAttribute("javaType");
/* 223 */         String jdbcType = parameterNode.getStringAttribute("jdbcType");
/* 224 */         String resultMap = parameterNode.getStringAttribute("resultMap");
/* 225 */         String mode = parameterNode.getStringAttribute("mode");
/* 226 */         String typeHandler = parameterNode.getStringAttribute("typeHandler");
/* 227 */         Integer numericScale = parameterNode.getIntAttribute("numericScale");
/* 228 */         ParameterMode modeEnum = resolveParameterMode(mode);
/* 229 */         Class<?> javaTypeClass = resolveClass(javaType);
/* 230 */         JdbcType jdbcTypeEnum = resolveJdbcType(jdbcType);
/*     */         
/* 232 */         Class<? extends TypeHandler<?>> typeHandlerClass = resolveClass(typeHandler);
/* 233 */         ParameterMapping parameterMapping = this.builderAssistant.buildParameterMapping(parameterClass, property, javaTypeClass, jdbcTypeEnum, resultMap, modeEnum, typeHandlerClass, numericScale);
/* 234 */         parameterMappings.add(parameterMapping);
/*     */       }
/* 236 */       this.builderAssistant.addParameterMap(id, parameterClass, parameterMappings);
/*     */     }
/*     */   }
/*     */   
/*     */   private void resultMapElements(List<XNode> list) throws Exception {
/* 241 */     for (XNode resultMapNode : list) {
/*     */       try {
/* 243 */         resultMapElement(resultMapNode);
/*     */       }
/*     */       catch (IncompleteElementException e) {}
/*     */     }
/*     */   }
/*     */   
/*     */   private ResultMap resultMapElement(XNode resultMapNode) throws Exception
/*     */   {
/* 251 */     return resultMapElement(resultMapNode, Collections.emptyList());
/*     */   }
/*     */   
/*     */   private ResultMap resultMapElement(XNode resultMapNode, List<ResultMapping> additionalResultMappings) throws Exception {
/* 255 */     ErrorContext.instance().activity("processing " + resultMapNode.getValueBasedIdentifier());
/* 256 */     String id = resultMapNode.getStringAttribute("id", resultMapNode.getValueBasedIdentifier());
/*     */     
/* 258 */     String type = resultMapNode.getStringAttribute("type", resultMapNode.getStringAttribute("ofType", resultMapNode.getStringAttribute("resultType", resultMapNode.getStringAttribute("javaType"))));
/*     */     
/*     */ 
/*     */ 
/* 262 */     String extend = resultMapNode.getStringAttribute("extends");
/* 263 */     Boolean autoMapping = resultMapNode.getBooleanAttribute("autoMapping");
/* 264 */     Class<?> typeClass = resolveClass(type);
/* 265 */     Discriminator discriminator = null;
/* 266 */     List<ResultMapping> resultMappings = new ArrayList();
/* 267 */     resultMappings.addAll(additionalResultMappings);
/* 268 */     List<XNode> resultChildren = resultMapNode.getChildren();
/* 269 */     for (XNode resultChild : resultChildren) {
/* 270 */       if ("constructor".equals(resultChild.getName())) {
/* 271 */         processConstructorElement(resultChild, typeClass, resultMappings);
/* 272 */       } else if ("discriminator".equals(resultChild.getName())) {
/* 273 */         discriminator = processDiscriminatorElement(resultChild, typeClass, resultMappings);
/*     */       } else {
/* 275 */         ArrayList<ResultFlag> flags = new ArrayList();
/* 276 */         if ("id".equals(resultChild.getName())) {
/* 277 */           flags.add(ResultFlag.ID);
/*     */         }
/* 279 */         resultMappings.add(buildResultMappingFromContext(resultChild, typeClass, flags));
/*     */       }
/*     */     }
/* 282 */     ResultMapResolver resultMapResolver = new ResultMapResolver(this.builderAssistant, id, typeClass, extend, discriminator, resultMappings, autoMapping);
/*     */     try {
/* 284 */       return resultMapResolver.resolve();
/*     */     } catch (IncompleteElementException e) {
/* 286 */       this.configuration.addIncompleteResultMap(resultMapResolver);
/* 287 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */   private void processConstructorElement(XNode resultChild, Class<?> resultType, List<ResultMapping> resultMappings) throws Exception {
/* 292 */     List<XNode> argChildren = resultChild.getChildren();
/* 293 */     for (XNode argChild : argChildren) {
/* 294 */       ArrayList<ResultFlag> flags = new ArrayList();
/* 295 */       flags.add(ResultFlag.CONSTRUCTOR);
/* 296 */       if ("idArg".equals(argChild.getName())) {
/* 297 */         flags.add(ResultFlag.ID);
/*     */       }
/* 299 */       resultMappings.add(buildResultMappingFromContext(argChild, resultType, flags));
/*     */     }
/*     */   }
/*     */   
/*     */   private Discriminator processDiscriminatorElement(XNode context, Class<?> resultType, List<ResultMapping> resultMappings) throws Exception {
/* 304 */     String column = context.getStringAttribute("column");
/* 305 */     String javaType = context.getStringAttribute("javaType");
/* 306 */     String jdbcType = context.getStringAttribute("jdbcType");
/* 307 */     String typeHandler = context.getStringAttribute("typeHandler");
/* 308 */     Class<?> javaTypeClass = resolveClass(javaType);
/*     */     
/* 310 */     Class<? extends TypeHandler<?>> typeHandlerClass = resolveClass(typeHandler);
/* 311 */     JdbcType jdbcTypeEnum = resolveJdbcType(jdbcType);
/* 312 */     Map<String, String> discriminatorMap = new HashMap();
/* 313 */     for (XNode caseChild : context.getChildren()) {
/* 314 */       String value = caseChild.getStringAttribute("value");
/* 315 */       String resultMap = caseChild.getStringAttribute("resultMap", processNestedResultMappings(caseChild, resultMappings));
/* 316 */       discriminatorMap.put(value, resultMap);
/*     */     }
/* 318 */     return this.builderAssistant.buildDiscriminator(resultType, column, javaTypeClass, jdbcTypeEnum, typeHandlerClass, discriminatorMap);
/*     */   }
/*     */   
/*     */   private void sqlElement(List<XNode> list) throws Exception {
/* 322 */     if (this.configuration.getDatabaseId() != null) {
/* 323 */       sqlElement(list, this.configuration.getDatabaseId());
/*     */     }
/* 325 */     sqlElement(list, null);
/*     */   }
/*     */   
/*     */   private void sqlElement(List<XNode> list, String requiredDatabaseId) throws Exception {
/* 329 */     for (XNode context : list) {
/* 330 */       String databaseId = context.getStringAttribute("databaseId");
/* 331 */       String id = context.getStringAttribute("id");
/* 332 */       id = this.builderAssistant.applyCurrentNamespace(id, false);
/* 333 */       if (databaseIdMatchesCurrent(id, databaseId, requiredDatabaseId)) this.sqlFragments.put(id, context);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean databaseIdMatchesCurrent(String id, String databaseId, String requiredDatabaseId) {
/* 338 */     if (requiredDatabaseId != null) {
/* 339 */       if (!requiredDatabaseId.equals(databaseId)) {
/* 340 */         return false;
/*     */       }
/*     */     } else {
/* 343 */       if (databaseId != null) {
/* 344 */         return false;
/*     */       }
/*     */       
/* 347 */       if (this.sqlFragments.containsKey(id)) {
/* 348 */         XNode context = (XNode)this.sqlFragments.get(id);
/* 349 */         if (context.getStringAttribute("databaseId") != null) {
/* 350 */           return false;
/*     */         }
/*     */       }
/*     */     }
/* 354 */     return true;
/*     */   }
/*     */   
/*     */   private ResultMapping buildResultMappingFromContext(XNode context, Class<?> resultType, ArrayList<ResultFlag> flags) throws Exception {
/* 358 */     String property = context.getStringAttribute("property");
/* 359 */     String column = context.getStringAttribute("column");
/* 360 */     String javaType = context.getStringAttribute("javaType");
/* 361 */     String jdbcType = context.getStringAttribute("jdbcType");
/* 362 */     String nestedSelect = context.getStringAttribute("select");
/* 363 */     String nestedResultMap = context.getStringAttribute("resultMap", processNestedResultMappings(context, Collections.emptyList()));
/*     */     
/* 365 */     String notNullColumn = context.getStringAttribute("notNullColumn");
/* 366 */     String columnPrefix = context.getStringAttribute("columnPrefix");
/* 367 */     String typeHandler = context.getStringAttribute("typeHandler");
/* 368 */     String resulSet = context.getStringAttribute("resultSet");
/* 369 */     String foreignColumn = context.getStringAttribute("foreignColumn");
/* 370 */     boolean lazy = "lazy".equals(context.getStringAttribute("fetchType", this.configuration.isLazyLoadingEnabled() ? "lazy" : "eager"));
/* 371 */     Class<?> javaTypeClass = resolveClass(javaType);
/*     */     
/* 373 */     Class<? extends TypeHandler<?>> typeHandlerClass = resolveClass(typeHandler);
/* 374 */     JdbcType jdbcTypeEnum = resolveJdbcType(jdbcType);
/* 375 */     return this.builderAssistant.buildResultMapping(resultType, property, column, javaTypeClass, jdbcTypeEnum, nestedSelect, nestedResultMap, notNullColumn, columnPrefix, typeHandlerClass, flags, resulSet, foreignColumn, lazy);
/*     */   }
/*     */   
/*     */   private String processNestedResultMappings(XNode context, List<ResultMapping> resultMappings) throws Exception {
/* 379 */     if (("association".equals(context.getName())) || ("collection".equals(context.getName())) || ("case".equals(context.getName())))
/*     */     {
/*     */ 
/* 382 */       if (context.getStringAttribute("select") == null) {
/* 383 */         ResultMap resultMap = resultMapElement(context, resultMappings);
/* 384 */         return resultMap.getId();
/*     */       }
/*     */     }
/* 387 */     return null;
/*     */   }
/*     */   
/*     */   private void bindMapperForNamespace() {
/* 391 */     String namespace = this.builderAssistant.getCurrentNamespace();
/* 392 */     if (namespace != null) {
/* 393 */       Class<?> boundType = null;
/*     */       try {
/* 395 */         boundType = Resources.classForName(namespace);
/*     */       }
/*     */       catch (ClassNotFoundException e) {}
/*     */       
/* 399 */       if ((boundType != null) && 
/* 400 */         (!this.configuration.hasMapper(boundType)))
/*     */       {
/*     */ 
/*     */ 
/* 404 */         this.configuration.addLoadedResource("namespace:" + namespace);
/* 405 */         this.configuration.addMapper(boundType);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\builder\xml\XMLMapperBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */