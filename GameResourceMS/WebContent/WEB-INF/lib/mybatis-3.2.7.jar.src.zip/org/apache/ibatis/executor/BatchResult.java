/*    */ package org.apache.ibatis.executor;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.ibatis.mapping.MappedStatement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BatchResult
/*    */ {
/*    */   private final MappedStatement mappedStatement;
/*    */   private final String sql;
/*    */   private final List<Object> parameterObjects;
/*    */   private int[] updateCounts;
/*    */   
/*    */   public BatchResult(MappedStatement mappedStatement, String sql)
/*    */   {
/* 36 */     this.mappedStatement = mappedStatement;
/* 37 */     this.sql = sql;
/* 38 */     this.parameterObjects = new ArrayList();
/*    */   }
/*    */   
/*    */   public BatchResult(MappedStatement mappedStatement, String sql, Object parameterObject) {
/* 42 */     this(mappedStatement, sql);
/* 43 */     addParameterObject(parameterObject);
/*    */   }
/*    */   
/*    */   public MappedStatement getMappedStatement() {
/* 47 */     return this.mappedStatement;
/*    */   }
/*    */   
/*    */   public String getSql() {
/* 51 */     return this.sql;
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public Object getParameterObject() {
/* 56 */     return this.parameterObjects.get(0);
/*    */   }
/*    */   
/*    */   public List<Object> getParameterObjects() {
/* 60 */     return this.parameterObjects;
/*    */   }
/*    */   
/*    */   public int[] getUpdateCounts() {
/* 64 */     return this.updateCounts;
/*    */   }
/*    */   
/*    */   public void setUpdateCounts(int[] updateCounts) {
/* 68 */     this.updateCounts = updateCounts;
/*    */   }
/*    */   
/*    */   public void addParameterObject(Object parameterObject) {
/* 72 */     this.parameterObjects.add(parameterObject);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\BatchResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */