/*     */ package org.apache.ibatis.executor.statement;
/*     */ 
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.List;
/*     */ import org.apache.ibatis.executor.Executor;
/*     */ import org.apache.ibatis.executor.ExecutorException;
/*     */ import org.apache.ibatis.executor.keygen.KeyGenerator;
/*     */ import org.apache.ibatis.executor.parameter.ParameterHandler;
/*     */ import org.apache.ibatis.executor.resultset.ResultSetHandler;
/*     */ import org.apache.ibatis.mapping.BoundSql;
/*     */ import org.apache.ibatis.mapping.MappedStatement;
/*     */ import org.apache.ibatis.mapping.ParameterMapping;
/*     */ import org.apache.ibatis.mapping.ParameterMode;
/*     */ import org.apache.ibatis.mapping.ResultSetType;
/*     */ import org.apache.ibatis.session.ResultHandler;
/*     */ import org.apache.ibatis.session.RowBounds;
/*     */ import org.apache.ibatis.type.JdbcType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CallableStatementHandler
/*     */   extends BaseStatementHandler
/*     */ {
/*     */   public CallableStatementHandler(Executor executor, MappedStatement mappedStatement, Object parameter, RowBounds rowBounds, ResultHandler resultHandler, BoundSql boundSql)
/*     */   {
/*  42 */     super(executor, mappedStatement, parameter, rowBounds, resultHandler, boundSql);
/*     */   }
/*     */   
/*     */   public int update(Statement statement) throws SQLException
/*     */   {
/*  47 */     CallableStatement cs = (CallableStatement)statement;
/*  48 */     cs.execute();
/*  49 */     int rows = cs.getUpdateCount();
/*  50 */     Object parameterObject = this.boundSql.getParameterObject();
/*  51 */     KeyGenerator keyGenerator = this.mappedStatement.getKeyGenerator();
/*  52 */     keyGenerator.processAfter(this.executor, this.mappedStatement, cs, parameterObject);
/*  53 */     this.resultSetHandler.handleOutputParameters(cs);
/*  54 */     return rows;
/*     */   }
/*     */   
/*     */   public void batch(Statement statement) throws SQLException
/*     */   {
/*  59 */     CallableStatement cs = (CallableStatement)statement;
/*  60 */     cs.addBatch();
/*     */   }
/*     */   
/*     */   public <E> List<E> query(Statement statement, ResultHandler resultHandler) throws SQLException
/*     */   {
/*  65 */     CallableStatement cs = (CallableStatement)statement;
/*  66 */     cs.execute();
/*  67 */     List<E> resultList = this.resultSetHandler.handleResultSets(cs);
/*  68 */     this.resultSetHandler.handleOutputParameters(cs);
/*  69 */     return resultList;
/*     */   }
/*     */   
/*     */   protected Statement instantiateStatement(Connection connection) throws SQLException {
/*  73 */     String sql = this.boundSql.getSql();
/*  74 */     if (this.mappedStatement.getResultSetType() != null) {
/*  75 */       return connection.prepareCall(sql, this.mappedStatement.getResultSetType().getValue(), 1007);
/*     */     }
/*  77 */     return connection.prepareCall(sql);
/*     */   }
/*     */   
/*     */   public void parameterize(Statement statement) throws SQLException
/*     */   {
/*  82 */     registerOutputParameters((CallableStatement)statement);
/*  83 */     this.parameterHandler.setParameters((CallableStatement)statement);
/*     */   }
/*     */   
/*     */   private void registerOutputParameters(CallableStatement cs) throws SQLException {
/*  87 */     List<ParameterMapping> parameterMappings = this.boundSql.getParameterMappings();
/*  88 */     int i = 0; for (int n = parameterMappings.size(); i < n; i++) {
/*  89 */       ParameterMapping parameterMapping = (ParameterMapping)parameterMappings.get(i);
/*  90 */       if ((parameterMapping.getMode() == ParameterMode.OUT) || (parameterMapping.getMode() == ParameterMode.INOUT)) {
/*  91 */         if (null == parameterMapping.getJdbcType()) {
/*  92 */           throw new ExecutorException("The JDBC Type must be specified for output parameter.  Parameter: " + parameterMapping.getProperty());
/*     */         }
/*  94 */         if ((parameterMapping.getNumericScale() != null) && ((parameterMapping.getJdbcType() == JdbcType.NUMERIC) || (parameterMapping.getJdbcType() == JdbcType.DECIMAL))) {
/*  95 */           cs.registerOutParameter(i + 1, parameterMapping.getJdbcType().TYPE_CODE, parameterMapping.getNumericScale().intValue());
/*     */         }
/*  97 */         else if (parameterMapping.getJdbcTypeName() == null) {
/*  98 */           cs.registerOutParameter(i + 1, parameterMapping.getJdbcType().TYPE_CODE);
/*     */         } else {
/* 100 */           cs.registerOutParameter(i + 1, parameterMapping.getJdbcType().TYPE_CODE, parameterMapping.getJdbcTypeName());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\statement\CallableStatementHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */