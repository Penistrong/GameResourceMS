/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTOr
/*    */   extends ExpressionNode
/*    */ {
/*    */   public ASTOr(int id)
/*    */   {
/* 40 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTOr(OgnlParser p, int id) {
/* 44 */     super(p, id);
/*    */   }
/*    */   
/*    */   public void jjtClose() {
/* 48 */     flattenTree();
/*    */   }
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException
/*    */   {
/* 53 */     Object result = null;
/* 54 */     int last = this.children.length - 1;
/* 55 */     for (int i = 0; i <= last; i++) {
/* 56 */       result = this.children[i].getValue(context, source);
/* 57 */       if ((i != last) && (OgnlOps.booleanValue(result)))
/*    */         break;
/*    */     }
/* 60 */     return result;
/*    */   }
/*    */   
/*    */   protected void setValueBody(OgnlContext context, Object target, Object value) throws OgnlException
/*    */   {
/* 65 */     int last = this.children.length - 1;
/* 66 */     for (int i = 0; i < last; i++) {
/* 67 */       Object v = this.children[i].getValue(context, target);
/* 68 */       if (OgnlOps.booleanValue(v))
/* 69 */         return;
/*    */     }
/* 71 */     this.children[last].setValue(context, target, value);
/*    */   }
/*    */   
/*    */   public String getExpressionOperator(int index)
/*    */   {
/* 76 */     return "||";
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTOr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */