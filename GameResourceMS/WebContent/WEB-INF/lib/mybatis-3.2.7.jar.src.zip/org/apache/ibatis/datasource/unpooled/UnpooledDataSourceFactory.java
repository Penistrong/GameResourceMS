/*    */ package org.apache.ibatis.datasource.unpooled;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.ibatis.datasource.DataSourceException;
/*    */ import org.apache.ibatis.datasource.DataSourceFactory;
/*    */ import org.apache.ibatis.reflection.MetaObject;
/*    */ import org.apache.ibatis.reflection.SystemMetaObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnpooledDataSourceFactory
/*    */   implements DataSourceFactory
/*    */ {
/*    */   private static final String DRIVER_PROPERTY_PREFIX = "driver.";
/* 33 */   private static final int DRIVER_PROPERTY_PREFIX_LENGTH = "driver.".length();
/*    */   protected DataSource dataSource;
/*    */   
/*    */   public UnpooledDataSourceFactory()
/*    */   {
/* 38 */     this.dataSource = new UnpooledDataSource();
/*    */   }
/*    */   
/*    */   public void setProperties(Properties properties) {
/* 42 */     Properties driverProperties = new Properties();
/* 43 */     MetaObject metaDataSource = SystemMetaObject.forObject(this.dataSource);
/* 44 */     for (Object key : properties.keySet()) {
/* 45 */       String propertyName = (String)key;
/* 46 */       if (propertyName.startsWith("driver.")) {
/* 47 */         String value = properties.getProperty(propertyName);
/* 48 */         driverProperties.setProperty(propertyName.substring(DRIVER_PROPERTY_PREFIX_LENGTH), value);
/* 49 */       } else if (metaDataSource.hasSetter(propertyName)) {
/* 50 */         String value = (String)properties.get(propertyName);
/* 51 */         Object convertedValue = convertValue(metaDataSource, propertyName, value);
/* 52 */         metaDataSource.setValue(propertyName, convertedValue);
/*    */       } else {
/* 54 */         throw new DataSourceException("Unknown DataSource property: " + propertyName);
/*    */       }
/*    */     }
/* 57 */     if (driverProperties.size() > 0) {
/* 58 */       metaDataSource.setValue("driverProperties", driverProperties);
/*    */     }
/*    */   }
/*    */   
/*    */   public DataSource getDataSource() {
/* 63 */     return this.dataSource;
/*    */   }
/*    */   
/*    */   private Object convertValue(MetaObject metaDataSource, String propertyName, String value) {
/* 67 */     Object convertedValue = value;
/* 68 */     Class<?> targetType = metaDataSource.getSetterType(propertyName);
/* 69 */     if ((targetType == Integer.class) || (targetType == Integer.TYPE)) {
/* 70 */       convertedValue = Integer.valueOf(value);
/* 71 */     } else if ((targetType == Long.class) || (targetType == Long.TYPE)) {
/* 72 */       convertedValue = Long.valueOf(value);
/* 73 */     } else if ((targetType == Boolean.class) || (targetType == Boolean.TYPE)) {
/* 74 */       convertedValue = Boolean.valueOf(value);
/*    */     }
/* 76 */     return convertedValue;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\datasource\unpooled\UnpooledDataSourceFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */