/*     */ package org.apache.ibatis.type;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.sql.ResultSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.ibatis.io.ResolverUtil;
/*     */ import org.apache.ibatis.io.ResolverUtil.IsA;
/*     */ import org.apache.ibatis.io.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeAliasRegistry
/*     */ {
/*  40 */   private final Map<String, Class<?>> TYPE_ALIASES = new HashMap();
/*     */   
/*     */   public TypeAliasRegistry() {
/*  43 */     registerAlias("string", String.class);
/*     */     
/*  45 */     registerAlias("byte", Byte.class);
/*  46 */     registerAlias("long", Long.class);
/*  47 */     registerAlias("short", Short.class);
/*  48 */     registerAlias("int", Integer.class);
/*  49 */     registerAlias("integer", Integer.class);
/*  50 */     registerAlias("double", Double.class);
/*  51 */     registerAlias("float", Float.class);
/*  52 */     registerAlias("boolean", Boolean.class);
/*     */     
/*  54 */     registerAlias("byte[]", Byte[].class);
/*  55 */     registerAlias("long[]", Long[].class);
/*  56 */     registerAlias("short[]", Short[].class);
/*  57 */     registerAlias("int[]", Integer[].class);
/*  58 */     registerAlias("integer[]", Integer[].class);
/*  59 */     registerAlias("double[]", Double[].class);
/*  60 */     registerAlias("float[]", Float[].class);
/*  61 */     registerAlias("boolean[]", Boolean[].class);
/*     */     
/*  63 */     registerAlias("_byte", Byte.TYPE);
/*  64 */     registerAlias("_long", Long.TYPE);
/*  65 */     registerAlias("_short", Short.TYPE);
/*  66 */     registerAlias("_int", Integer.TYPE);
/*  67 */     registerAlias("_integer", Integer.TYPE);
/*  68 */     registerAlias("_double", Double.TYPE);
/*  69 */     registerAlias("_float", Float.TYPE);
/*  70 */     registerAlias("_boolean", Boolean.TYPE);
/*     */     
/*  72 */     registerAlias("_byte[]", byte[].class);
/*  73 */     registerAlias("_long[]", long[].class);
/*  74 */     registerAlias("_short[]", short[].class);
/*  75 */     registerAlias("_int[]", int[].class);
/*  76 */     registerAlias("_integer[]", int[].class);
/*  77 */     registerAlias("_double[]", double[].class);
/*  78 */     registerAlias("_float[]", float[].class);
/*  79 */     registerAlias("_boolean[]", boolean[].class);
/*     */     
/*  81 */     registerAlias("date", Date.class);
/*  82 */     registerAlias("decimal", BigDecimal.class);
/*  83 */     registerAlias("bigdecimal", BigDecimal.class);
/*  84 */     registerAlias("biginteger", BigInteger.class);
/*  85 */     registerAlias("object", Object.class);
/*     */     
/*  87 */     registerAlias("date[]", Date[].class);
/*  88 */     registerAlias("decimal[]", BigDecimal[].class);
/*  89 */     registerAlias("bigdecimal[]", BigDecimal[].class);
/*  90 */     registerAlias("biginteger[]", BigInteger[].class);
/*  91 */     registerAlias("object[]", Object[].class);
/*     */     
/*  93 */     registerAlias("map", Map.class);
/*  94 */     registerAlias("hashmap", HashMap.class);
/*  95 */     registerAlias("list", List.class);
/*  96 */     registerAlias("arraylist", ArrayList.class);
/*  97 */     registerAlias("collection", Collection.class);
/*  98 */     registerAlias("iterator", Iterator.class);
/*     */     
/* 100 */     registerAlias("ResultSet", ResultSet.class);
/*     */   }
/*     */   
/*     */   public <T> Class<T> resolveAlias(String string)
/*     */   {
/*     */     try
/*     */     {
/* 107 */       if (string == null) return null;
/* 108 */       String key = string.toLowerCase(Locale.ENGLISH);
/*     */       Class<T> value;
/* 110 */       if (this.TYPE_ALIASES.containsKey(key)) {
/* 111 */         value = (Class)this.TYPE_ALIASES.get(key);
/*     */       }
/* 113 */       return Resources.classForName(string);
/*     */     }
/*     */     catch (ClassNotFoundException e)
/*     */     {
/* 117 */       throw new TypeException("Could not resolve type alias '" + string + "'.  Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void registerAliases(String packageName) {
/* 122 */     registerAliases(packageName, Object.class);
/*     */   }
/*     */   
/*     */   public void registerAliases(String packageName, Class<?> superType) {
/* 126 */     ResolverUtil<Class<?>> resolverUtil = new ResolverUtil();
/* 127 */     resolverUtil.find(new ResolverUtil.IsA(superType), packageName);
/* 128 */     Set<Class<? extends Class<?>>> typeSet = resolverUtil.getClasses();
/* 129 */     for (Class<?> type : typeSet)
/*     */     {
/*     */ 
/* 132 */       if ((!type.isAnonymousClass()) && (!type.isInterface()) && (!type.isMemberClass())) {
/* 133 */         registerAlias(type);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void registerAlias(Class<?> type) {
/* 139 */     String alias = type.getSimpleName();
/* 140 */     Alias aliasAnnotation = (Alias)type.getAnnotation(Alias.class);
/* 141 */     if (aliasAnnotation != null) {
/* 142 */       alias = aliasAnnotation.value();
/*     */     }
/* 144 */     registerAlias(alias, type);
/*     */   }
/*     */   
/*     */   public void registerAlias(String alias, Class<?> value) {
/* 148 */     if (alias == null) throw new TypeException("The parameter alias cannot be null");
/* 149 */     String key = alias.toLowerCase(Locale.ENGLISH);
/* 150 */     if ((this.TYPE_ALIASES.containsKey(key)) && (this.TYPE_ALIASES.get(key) != null) && (!((Class)this.TYPE_ALIASES.get(key)).equals(value))) {
/* 151 */       throw new TypeException("The alias '" + alias + "' is already mapped to the value '" + ((Class)this.TYPE_ALIASES.get(key)).getName() + "'.");
/*     */     }
/* 153 */     this.TYPE_ALIASES.put(key, value);
/*     */   }
/*     */   
/*     */   public void registerAlias(String alias, String value) {
/*     */     try {
/* 158 */       registerAlias(alias, Resources.classForName(value));
/*     */     } catch (ClassNotFoundException e) {
/* 160 */       throw new TypeException("Error registering type alias " + alias + " for " + value + ". Cause: " + e, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Map<String, Class<?>> getTypeAliases()
/*     */   {
/* 168 */     return Collections.unmodifiableMap(this.TYPE_ALIASES);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\TypeAliasRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */