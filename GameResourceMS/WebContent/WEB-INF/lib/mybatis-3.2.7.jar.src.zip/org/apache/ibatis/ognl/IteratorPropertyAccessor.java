/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IteratorPropertyAccessor
/*    */   extends ObjectPropertyAccessor
/*    */   implements PropertyAccessor
/*    */ {
/*    */   public Object getProperty(Map context, Object target, Object name)
/*    */     throws OgnlException
/*    */   {
/* 47 */     Iterator iterator = (Iterator)target;
/*    */     Object result;
/* 49 */     Object result; if ((name instanceof String)) { Object result;
/* 50 */       if (name.equals("next")) {
/* 51 */         result = iterator.next();
/*    */       } else { Object result;
/* 53 */         if (name.equals("hasNext")) {
/* 54 */           result = iterator.hasNext() ? Boolean.TRUE : Boolean.FALSE;
/*    */         } else {
/* 56 */           result = super.getProperty(context, target, name);
/*    */         }
/*    */       }
/*    */     } else {
/* 60 */       result = super.getProperty(context, target, name);
/*    */     }
/* 62 */     return result;
/*    */   }
/*    */   
/*    */   public void setProperty(Map context, Object target, Object name, Object value) throws OgnlException
/*    */   {
/* 67 */     throw new IllegalArgumentException("can't set property " + name + " on Iterator");
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\IteratorPropertyAccessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */