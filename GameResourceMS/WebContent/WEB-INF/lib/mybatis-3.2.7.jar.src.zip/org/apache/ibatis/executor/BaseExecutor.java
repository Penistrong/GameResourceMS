/*     */ package org.apache.ibatis.executor;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import org.apache.ibatis.cache.CacheKey;
/*     */ import org.apache.ibatis.cache.impl.PerpetualCache;
/*     */ import org.apache.ibatis.logging.Log;
/*     */ import org.apache.ibatis.logging.LogFactory;
/*     */ import org.apache.ibatis.logging.jdbc.ConnectionLogger;
/*     */ import org.apache.ibatis.mapping.BoundSql;
/*     */ import org.apache.ibatis.mapping.MappedStatement;
/*     */ import org.apache.ibatis.mapping.ParameterMapping;
/*     */ import org.apache.ibatis.mapping.ParameterMode;
/*     */ import org.apache.ibatis.mapping.StatementType;
/*     */ import org.apache.ibatis.reflection.MetaObject;
/*     */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.session.LocalCacheScope;
/*     */ import org.apache.ibatis.session.ResultHandler;
/*     */ import org.apache.ibatis.session.RowBounds;
/*     */ import org.apache.ibatis.transaction.Transaction;
/*     */ import org.apache.ibatis.type.TypeHandlerRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseExecutor
/*     */   implements Executor
/*     */ {
/*  50 */   private static final Log log = LogFactory.getLog(BaseExecutor.class);
/*     */   
/*     */   protected Transaction transaction;
/*     */   
/*     */   protected Executor wrapper;
/*     */   
/*     */   protected ConcurrentLinkedQueue<DeferredLoad> deferredLoads;
/*     */   protected PerpetualCache localCache;
/*     */   protected PerpetualCache localOutputParameterCache;
/*     */   protected Configuration configuration;
/*  60 */   protected int queryStack = 0;
/*     */   private boolean closed;
/*     */   
/*     */   protected BaseExecutor(Configuration configuration, Transaction transaction) {
/*  64 */     this.transaction = transaction;
/*  65 */     this.deferredLoads = new ConcurrentLinkedQueue();
/*  66 */     this.localCache = new PerpetualCache("LocalCache");
/*  67 */     this.localOutputParameterCache = new PerpetualCache("LocalOutputParameterCache");
/*  68 */     this.closed = false;
/*  69 */     this.configuration = configuration;
/*  70 */     this.wrapper = this;
/*     */   }
/*     */   
/*     */   public Transaction getTransaction() {
/*  74 */     if (this.closed) throw new ExecutorException("Executor was closed.");
/*  75 */     return this.transaction;
/*     */   }
/*     */   
/*     */   public void close(boolean forceRollback) {
/*     */     try {
/*     */       try {
/*  81 */         rollback(forceRollback);
/*     */       } finally {
/*  83 */         if (this.transaction != null) this.transaction.close();
/*     */       }
/*     */     }
/*     */     catch (SQLException e) {
/*  87 */       log.warn("Unexpected exception on closing transaction.  Cause: " + e);
/*     */     } finally {
/*  89 */       this.transaction = null;
/*  90 */       this.deferredLoads = null;
/*  91 */       this.localCache = null;
/*  92 */       this.localOutputParameterCache = null;
/*  93 */       this.closed = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isClosed() {
/*  98 */     return this.closed;
/*     */   }
/*     */   
/*     */   public int update(MappedStatement ms, Object parameter) throws SQLException {
/* 102 */     ErrorContext.instance().resource(ms.getResource()).activity("executing an update").object(ms.getId());
/* 103 */     if (this.closed) throw new ExecutorException("Executor was closed.");
/* 104 */     clearLocalCache();
/* 105 */     return doUpdate(ms, parameter);
/*     */   }
/*     */   
/*     */   public List<BatchResult> flushStatements() throws SQLException {
/* 109 */     return flushStatements(false);
/*     */   }
/*     */   
/*     */   public List<BatchResult> flushStatements(boolean isRollBack) throws SQLException {
/* 113 */     if (this.closed) throw new ExecutorException("Executor was closed.");
/* 114 */     return doFlushStatements(isRollBack);
/*     */   }
/*     */   
/*     */   public <E> List<E> query(MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler) throws SQLException {
/* 118 */     BoundSql boundSql = ms.getBoundSql(parameter);
/* 119 */     CacheKey key = createCacheKey(ms, parameter, rowBounds, boundSql);
/* 120 */     return query(ms, parameter, rowBounds, resultHandler, key, boundSql);
/*     */   }
/*     */   
/*     */   public <E> List<E> query(MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler, CacheKey key, BoundSql boundSql) throws SQLException
/*     */   {
/* 125 */     ErrorContext.instance().resource(ms.getResource()).activity("executing a query").object(ms.getId());
/* 126 */     if (this.closed) throw new ExecutorException("Executor was closed.");
/* 127 */     if ((this.queryStack == 0) && (ms.isFlushCacheRequired())) {
/* 128 */       clearLocalCache();
/*     */     }
/*     */     List<E> list;
/*     */     try {
/* 132 */       this.queryStack += 1;
/* 133 */       list = resultHandler == null ? (List)this.localCache.getObject(key) : null;
/* 134 */       if (list != null) {
/* 135 */         handleLocallyCachedOutputParameters(ms, key, parameter, boundSql);
/*     */       } else {
/* 137 */         list = queryFromDatabase(ms, parameter, rowBounds, resultHandler, key, boundSql);
/*     */       }
/*     */     } finally {
/* 140 */       this.queryStack -= 1;
/*     */     }
/* 142 */     if (this.queryStack == 0) {
/* 143 */       for (DeferredLoad deferredLoad : this.deferredLoads) {
/* 144 */         deferredLoad.load();
/*     */       }
/* 146 */       this.deferredLoads.clear();
/* 147 */       if (this.configuration.getLocalCacheScope() == LocalCacheScope.STATEMENT) {
/* 148 */         clearLocalCache();
/*     */       }
/*     */     }
/* 151 */     return list;
/*     */   }
/*     */   
/*     */   public void deferLoad(MappedStatement ms, MetaObject resultObject, String property, CacheKey key, Class<?> targetType) {
/* 155 */     if (this.closed) throw new ExecutorException("Executor was closed.");
/* 156 */     DeferredLoad deferredLoad = new DeferredLoad(resultObject, property, key, this.localCache, this.configuration, targetType);
/* 157 */     if (deferredLoad.canLoad()) {
/* 158 */       deferredLoad.load();
/*     */     } else {
/* 160 */       this.deferredLoads.add(new DeferredLoad(resultObject, property, key, this.localCache, this.configuration, targetType));
/*     */     }
/*     */   }
/*     */   
/*     */   public CacheKey createCacheKey(MappedStatement ms, Object parameterObject, RowBounds rowBounds, BoundSql boundSql) {
/* 165 */     if (this.closed) throw new ExecutorException("Executor was closed.");
/* 166 */     CacheKey cacheKey = new CacheKey();
/* 167 */     cacheKey.update(ms.getId());
/* 168 */     cacheKey.update(Integer.valueOf(rowBounds.getOffset()));
/* 169 */     cacheKey.update(Integer.valueOf(rowBounds.getLimit()));
/* 170 */     cacheKey.update(boundSql.getSql());
/* 171 */     List<ParameterMapping> parameterMappings = boundSql.getParameterMappings();
/* 172 */     TypeHandlerRegistry typeHandlerRegistry = ms.getConfiguration().getTypeHandlerRegistry();
/* 173 */     for (int i = 0; i < parameterMappings.size(); i++) {
/* 174 */       ParameterMapping parameterMapping = (ParameterMapping)parameterMappings.get(i);
/* 175 */       if (parameterMapping.getMode() != ParameterMode.OUT)
/*     */       {
/* 177 */         String propertyName = parameterMapping.getProperty();
/* 178 */         Object value; Object value; if (boundSql.hasAdditionalParameter(propertyName)) {
/* 179 */           value = boundSql.getAdditionalParameter(propertyName); } else { Object value;
/* 180 */           if (parameterObject == null) {
/* 181 */             value = null; } else { Object value;
/* 182 */             if (typeHandlerRegistry.hasTypeHandler(parameterObject.getClass())) {
/* 183 */               value = parameterObject;
/*     */             } else {
/* 185 */               MetaObject metaObject = this.configuration.newMetaObject(parameterObject);
/* 186 */               value = metaObject.getValue(propertyName);
/*     */             } } }
/* 188 */         cacheKey.update(value);
/*     */       }
/*     */     }
/* 191 */     return cacheKey;
/*     */   }
/*     */   
/*     */   public boolean isCached(MappedStatement ms, CacheKey key) {
/* 195 */     return this.localCache.getObject(key) != null;
/*     */   }
/*     */   
/*     */   public void commit(boolean required) throws SQLException {
/* 199 */     if (this.closed) throw new ExecutorException("Cannot commit, transaction is already closed");
/* 200 */     clearLocalCache();
/* 201 */     flushStatements();
/* 202 */     if (required) {
/* 203 */       this.transaction.commit();
/*     */     }
/*     */   }
/*     */   
/*     */   public void rollback(boolean required) throws SQLException {
/* 208 */     if (!this.closed) {
/*     */       try {
/* 210 */         clearLocalCache();
/* 211 */         flushStatements(true);
/*     */       } finally {
/* 213 */         if (required) {
/* 214 */           this.transaction.rollback();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void clearLocalCache() {
/* 221 */     if (!this.closed) {
/* 222 */       this.localCache.clear();
/* 223 */       this.localOutputParameterCache.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract int doUpdate(MappedStatement paramMappedStatement, Object paramObject)
/*     */     throws SQLException;
/*     */   
/*     */   protected abstract List<BatchResult> doFlushStatements(boolean paramBoolean)
/*     */     throws SQLException;
/*     */   
/*     */   protected abstract <E> List<E> doQuery(MappedStatement paramMappedStatement, Object paramObject, RowBounds paramRowBounds, ResultHandler paramResultHandler, BoundSql paramBoundSql) throws SQLException;
/*     */   
/*     */   protected void closeStatement(Statement statement)
/*     */   {
/* 237 */     if (statement != null) {
/*     */       try {
/* 239 */         statement.close();
/*     */       } catch (SQLException e) {}
/*     */     }
/*     */   }
/*     */   
/*     */   private void handleLocallyCachedOutputParameters(MappedStatement ms, CacheKey key, Object parameter, BoundSql boundSql) {
/*     */     MetaObject metaCachedParameter;
/*     */     MetaObject metaParameter;
/* 247 */     if (ms.getStatementType() == StatementType.CALLABLE) {
/* 248 */       Object cachedParameter = this.localOutputParameterCache.getObject(key);
/* 249 */       if ((cachedParameter != null) && (parameter != null)) {
/* 250 */         metaCachedParameter = this.configuration.newMetaObject(cachedParameter);
/* 251 */         metaParameter = this.configuration.newMetaObject(parameter);
/* 252 */         for (ParameterMapping parameterMapping : boundSql.getParameterMappings()) {
/* 253 */           if (parameterMapping.getMode() != ParameterMode.IN) {
/* 254 */             String parameterName = parameterMapping.getProperty();
/* 255 */             Object cachedValue = metaCachedParameter.getValue(parameterName);
/* 256 */             metaParameter.setValue(parameterName, cachedValue);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private <E> List<E> queryFromDatabase(MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler, CacheKey key, BoundSql boundSql) throws SQLException
/*     */   {
/* 265 */     this.localCache.putObject(key, ExecutionPlaceholder.EXECUTION_PLACEHOLDER);
/*     */     List<E> list;
/* 267 */     try { list = doQuery(ms, parameter, rowBounds, resultHandler, boundSql);
/*     */     } finally {
/* 269 */       this.localCache.removeObject(key);
/*     */     }
/* 271 */     this.localCache.putObject(key, list);
/* 272 */     if (ms.getStatementType() == StatementType.CALLABLE) {
/* 273 */       this.localOutputParameterCache.putObject(key, parameter);
/*     */     }
/* 275 */     return list;
/*     */   }
/*     */   
/*     */   protected Connection getConnection(Log statementLog) throws SQLException {
/* 279 */     Connection connection = this.transaction.getConnection();
/* 280 */     if (statementLog.isDebugEnabled()) {
/* 281 */       return ConnectionLogger.newInstance(connection, statementLog, this.queryStack);
/*     */     }
/* 283 */     return connection;
/*     */   }
/*     */   
/*     */   public void setExecutorWrapper(Executor wrapper)
/*     */   {
/* 288 */     this.wrapper = wrapper;
/*     */   }
/*     */   
/*     */ 
/*     */   private static class DeferredLoad
/*     */   {
/*     */     private final MetaObject resultObject;
/*     */     
/*     */     private final String property;
/*     */     
/*     */     private final Class<?> targetType;
/*     */     
/*     */     private final CacheKey key;
/*     */     private final PerpetualCache localCache;
/*     */     private final ObjectFactory objectFactory;
/*     */     private final ResultExtractor resultExtractor;
/*     */     
/*     */     public DeferredLoad(MetaObject resultObject, String property, CacheKey key, PerpetualCache localCache, Configuration configuration, Class<?> targetType)
/*     */     {
/* 307 */       this.resultObject = resultObject;
/* 308 */       this.property = property;
/* 309 */       this.key = key;
/* 310 */       this.localCache = localCache;
/* 311 */       this.objectFactory = configuration.getObjectFactory();
/* 312 */       this.resultExtractor = new ResultExtractor(configuration, this.objectFactory);
/* 313 */       this.targetType = targetType;
/*     */     }
/*     */     
/*     */     public boolean canLoad() {
/* 317 */       return (this.localCache.getObject(this.key) != null) && (this.localCache.getObject(this.key) != ExecutionPlaceholder.EXECUTION_PLACEHOLDER);
/*     */     }
/*     */     
/*     */     public void load()
/*     */     {
/* 322 */       List<Object> list = (List)this.localCache.getObject(this.key);
/* 323 */       Object value = this.resultExtractor.extractObjectFromList(list, this.targetType);
/* 324 */       this.resultObject.setValue(this.property, value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\BaseExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */