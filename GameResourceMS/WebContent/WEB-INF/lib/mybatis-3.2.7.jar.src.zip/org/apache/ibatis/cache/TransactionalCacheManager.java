/*    */ package org.apache.ibatis.cache;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.ibatis.cache.decorators.TransactionalCache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransactionalCacheManager
/*    */ {
/* 28 */   private Map<Cache, TransactionalCache> transactionalCaches = new HashMap();
/*    */   
/*    */   public void clear(Cache cache) {
/* 31 */     getTransactionalCache(cache).clear();
/*    */   }
/*    */   
/*    */   public Object getObject(Cache cache, CacheKey key) {
/* 35 */     return getTransactionalCache(cache).getObject(key);
/*    */   }
/*    */   
/*    */   public void putObject(Cache cache, CacheKey key, Object value) {
/* 39 */     getTransactionalCache(cache).putObject(key, value);
/*    */   }
/*    */   
/*    */   public void commit() {
/* 43 */     for (TransactionalCache txCache : this.transactionalCaches.values()) {
/* 44 */       txCache.commit();
/*    */     }
/*    */   }
/*    */   
/*    */   public void rollback() {
/* 49 */     for (TransactionalCache txCache : this.transactionalCaches.values()) {
/* 50 */       txCache.rollback();
/*    */     }
/*    */   }
/*    */   
/*    */   private TransactionalCache getTransactionalCache(Cache cache) {
/* 55 */     TransactionalCache txCache = (TransactionalCache)this.transactionalCaches.get(cache);
/* 56 */     if (txCache == null) {
/* 57 */       txCache = new TransactionalCache(cache);
/* 58 */       this.transactionalCaches.put(cache, txCache);
/*    */     }
/* 60 */     return txCache;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\cache\TransactionalCacheManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */