/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ 
/*     */ public abstract interface OgnlParserConstants
/*     */ {
/*     */   public static final int EOF = 0;
/*     */   
/*     */   public static final int IDENT = 64;
/*     */   
/*     */   public static final int LETTER = 65;
/*     */   public static final int DIGIT = 66;
/*     */   public static final int DYNAMIC_SUBSCRIPT = 67;
/*     */   public static final int ESC = 71;
/*     */   public static final int CHAR_LITERAL = 73;
/*     */   public static final int BACK_CHAR_ESC = 74;
/*     */   public static final int BACK_CHAR_LITERAL = 76;
/*     */   public static final int STRING_ESC = 77;
/*     */   public static final int STRING_LITERAL = 79;
/*     */   public static final int INT_LITERAL = 80;
/*     */   public static final int FLT_LITERAL = 81;
/*     */   public static final int DEC_FLT = 82;
/*     */   public static final int DEC_DIGITS = 83;
/*     */   public static final int EXPONENT = 84;
/*     */   public static final int FLT_SUFF = 85;
/*     */   public static final int DEFAULT = 0;
/*     */   public static final int WithinCharLiteral = 1;
/*     */   public static final int WithinBackCharLiteral = 2;
/*     */   public static final int WithinStringLiteral = 3;
/*  29 */   public static final String[] tokenImage = {
/*  30 */     "<EOF>", 
/*  31 */     "\",\"", 
/*  32 */     "\"=\"", 
/*  33 */     "\"?\"", 
/*  34 */     "\":\"", 
/*  35 */     "\"||\"", 
/*  36 */     "\"or\"", 
/*  37 */     "\"&&\"", 
/*  38 */     "\"and\"", 
/*  39 */     "\"|\"", 
/*  40 */     "\"bor\"", 
/*  41 */     "\"^\"", 
/*  42 */     "\"xor\"", 
/*  43 */     "\"&\"", 
/*  44 */     "\"band\"", 
/*  45 */     "\"==\"", 
/*  46 */     "\"eq\"", 
/*  47 */     "\"!=\"", 
/*  48 */     "\"neq\"", 
/*  49 */     "\"<\"", 
/*  50 */     "\"lt\"", 
/*  51 */     "\">\"", 
/*  52 */     "\"gt\"", 
/*  53 */     "\"<=\"", 
/*  54 */     "\"lte\"", 
/*  55 */     "\">=\"", 
/*  56 */     "\"gte\"", 
/*  57 */     "\"in\"", 
/*  58 */     "\"not\"", 
/*  59 */     "\"<<\"", 
/*  60 */     "\"shl\"", 
/*  61 */     "\">>\"", 
/*  62 */     "\"shr\"", 
/*  63 */     "\">>>\"", 
/*  64 */     "\"ushr\"", 
/*  65 */     "\"+\"", 
/*  66 */     "\"-\"", 
/*  67 */     "\"*\"", 
/*  68 */     "\"/\"", 
/*  69 */     "\"%\"", 
/*  70 */     "\"~\"", 
/*  71 */     "\"!\"", 
/*  72 */     "\"instanceof\"", 
/*  73 */     "\".\"", 
/*  74 */     "\"(\"", 
/*  75 */     "\")\"", 
/*  76 */     "\"true\"", 
/*  77 */     "\"false\"", 
/*  78 */     "\"null\"", 
/*  79 */     "\"#this\"", 
/*  80 */     "\"#root\"", 
/*  81 */     "\"#\"", 
/*  82 */     "\"[\"", 
/*  83 */     "\"]\"", 
/*  84 */     "\"{\"", 
/*  85 */     "\"}\"", 
/*  86 */     "\"@\"", 
/*  87 */     "\"new\"", 
/*  88 */     "\"$\"", 
/*  89 */     "\" \"", 
/*  90 */     "\"\\t\"", 
/*  91 */     "\"\\f\"", 
/*  92 */     "\"\\r\"", 
/*  93 */     "\"\\n\"", 
/*  94 */     "<IDENT>", 
/*  95 */     "<LETTER>", 
/*  96 */     "<DIGIT>", 
/*  97 */     "<DYNAMIC_SUBSCRIPT>", 
/*  98 */     "\"`\"", 
/*  99 */     "\"\\'\"", 
/* 100 */     "\"\\\"\"", 
/* 101 */     "<ESC>", 
/* 102 */     "<token of kind 72>", 
/* 103 */     "\"\\'\"", 
/* 104 */     "<BACK_CHAR_ESC>", 
/* 105 */     "<token of kind 75>", 
/* 106 */     "\"`\"", 
/* 107 */     "<STRING_ESC>", 
/* 108 */     "<token of kind 78>", 
/* 109 */     "\"\\\"\"", 
/* 110 */     "<INT_LITERAL>", 
/* 111 */     "<FLT_LITERAL>", 
/* 112 */     "<DEC_FLT>", 
/* 113 */     "<DEC_DIGITS>", 
/* 114 */     "<EXPONENT>", 
/* 115 */     "<FLT_SUFF>" };
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\OgnlParserConstants.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */