/*    */ package org.apache.ibatis.plugin;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InterceptorChain
/*    */ {
/* 27 */   private final List<Interceptor> interceptors = new ArrayList();
/*    */   
/*    */   public Object pluginAll(Object target) {
/* 30 */     for (Interceptor interceptor : this.interceptors) {
/* 31 */       target = interceptor.plugin(target);
/*    */     }
/* 33 */     return target;
/*    */   }
/*    */   
/*    */   public void addInterceptor(Interceptor interceptor) {
/* 37 */     this.interceptors.add(interceptor);
/*    */   }
/*    */   
/*    */   public List<Interceptor> getInterceptors() {
/* 41 */     return Collections.unmodifiableList(this.interceptors);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\plugin\InterceptorChain.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */