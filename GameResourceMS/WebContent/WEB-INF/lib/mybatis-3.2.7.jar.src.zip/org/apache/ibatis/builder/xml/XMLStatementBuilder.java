/*     */ package org.apache.ibatis.builder.xml;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import org.apache.ibatis.builder.BaseBuilder;
/*     */ import org.apache.ibatis.builder.MapperBuilderAssistant;
/*     */ import org.apache.ibatis.executor.keygen.Jdbc3KeyGenerator;
/*     */ import org.apache.ibatis.executor.keygen.KeyGenerator;
/*     */ import org.apache.ibatis.executor.keygen.NoKeyGenerator;
/*     */ import org.apache.ibatis.executor.keygen.SelectKeyGenerator;
/*     */ import org.apache.ibatis.mapping.MappedStatement;
/*     */ import org.apache.ibatis.mapping.ResultSetType;
/*     */ import org.apache.ibatis.mapping.SqlCommandType;
/*     */ import org.apache.ibatis.mapping.SqlSource;
/*     */ import org.apache.ibatis.mapping.StatementType;
/*     */ import org.apache.ibatis.parsing.XNode;
/*     */ import org.apache.ibatis.scripting.LanguageDriver;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLStatementBuilder
/*     */   extends BaseBuilder
/*     */ {
/*     */   private MapperBuilderAssistant builderAssistant;
/*     */   private XNode context;
/*     */   private String requiredDatabaseId;
/*     */   
/*     */   public XMLStatementBuilder(Configuration configuration, MapperBuilderAssistant builderAssistant, XNode context)
/*     */   {
/*  46 */     this(configuration, builderAssistant, context, null);
/*     */   }
/*     */   
/*     */   public XMLStatementBuilder(Configuration configuration, MapperBuilderAssistant builderAssistant, XNode context, String databaseId) {
/*  50 */     super(configuration);
/*  51 */     this.builderAssistant = builderAssistant;
/*  52 */     this.context = context;
/*  53 */     this.requiredDatabaseId = databaseId;
/*     */   }
/*     */   
/*     */   public void parseStatementNode() {
/*  57 */     String id = this.context.getStringAttribute("id");
/*  58 */     String databaseId = this.context.getStringAttribute("databaseId");
/*     */     
/*  60 */     if (!databaseIdMatchesCurrent(id, databaseId, this.requiredDatabaseId)) { return;
/*     */     }
/*  62 */     Integer fetchSize = this.context.getIntAttribute("fetchSize");
/*  63 */     Integer timeout = this.context.getIntAttribute("timeout");
/*  64 */     String parameterMap = this.context.getStringAttribute("parameterMap");
/*  65 */     String parameterType = this.context.getStringAttribute("parameterType");
/*  66 */     Class<?> parameterTypeClass = resolveClass(parameterType);
/*  67 */     String resultMap = this.context.getStringAttribute("resultMap");
/*  68 */     String resultType = this.context.getStringAttribute("resultType");
/*  69 */     String lang = this.context.getStringAttribute("lang");
/*  70 */     LanguageDriver langDriver = getLanguageDriver(lang);
/*     */     
/*  72 */     Class<?> resultTypeClass = resolveClass(resultType);
/*  73 */     String resultSetType = this.context.getStringAttribute("resultSetType");
/*  74 */     StatementType statementType = StatementType.valueOf(this.context.getStringAttribute("statementType", StatementType.PREPARED.toString()));
/*  75 */     ResultSetType resultSetTypeEnum = resolveResultSetType(resultSetType);
/*     */     
/*  77 */     String nodeName = this.context.getNode().getNodeName();
/*  78 */     SqlCommandType sqlCommandType = SqlCommandType.valueOf(nodeName.toUpperCase(Locale.ENGLISH));
/*  79 */     boolean isSelect = sqlCommandType == SqlCommandType.SELECT;
/*  80 */     boolean flushCache = this.context.getBooleanAttribute("flushCache", Boolean.valueOf(!isSelect)).booleanValue();
/*  81 */     boolean useCache = this.context.getBooleanAttribute("useCache", Boolean.valueOf(isSelect)).booleanValue();
/*  82 */     boolean resultOrdered = this.context.getBooleanAttribute("resultOrdered", Boolean.valueOf(false)).booleanValue();
/*     */     
/*     */ 
/*  85 */     XMLIncludeTransformer includeParser = new XMLIncludeTransformer(this.configuration, this.builderAssistant);
/*  86 */     includeParser.applyIncludes(this.context.getNode());
/*     */     
/*     */ 
/*  89 */     processSelectKeyNodes(id, parameterTypeClass, langDriver);
/*     */     
/*     */ 
/*  92 */     SqlSource sqlSource = langDriver.createSqlSource(this.configuration, this.context, parameterTypeClass);
/*  93 */     String resultSets = this.context.getStringAttribute("resultSets");
/*  94 */     String keyProperty = this.context.getStringAttribute("keyProperty");
/*  95 */     String keyColumn = this.context.getStringAttribute("keyColumn");
/*     */     
/*  97 */     String keyStatementId = id + "!selectKey";
/*  98 */     keyStatementId = this.builderAssistant.applyCurrentNamespace(keyStatementId, true);
/*  99 */     KeyGenerator keyGenerator; KeyGenerator keyGenerator; if (this.configuration.hasKeyGenerator(keyStatementId)) {
/* 100 */       keyGenerator = this.configuration.getKeyGenerator(keyStatementId);
/*     */     } else {
/* 102 */       keyGenerator = this.context.getBooleanAttribute("useGeneratedKeys", Boolean.valueOf((this.configuration.isUseGeneratedKeys()) && (SqlCommandType.INSERT.equals(sqlCommandType)))).booleanValue() ? new Jdbc3KeyGenerator() : new NoKeyGenerator();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 107 */     this.builderAssistant.addMappedStatement(id, sqlSource, statementType, sqlCommandType, fetchSize, timeout, parameterMap, parameterTypeClass, resultMap, resultTypeClass, resultSetTypeEnum, flushCache, useCache, resultOrdered, keyGenerator, keyProperty, keyColumn, databaseId, langDriver, resultSets);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void processSelectKeyNodes(String id, Class<?> parameterTypeClass, LanguageDriver langDriver)
/*     */   {
/* 114 */     List<XNode> selectKeyNodes = this.context.evalNodes("selectKey");
/* 115 */     if (this.configuration.getDatabaseId() != null) {
/* 116 */       parseSelectKeyNodes(id, selectKeyNodes, parameterTypeClass, langDriver, this.configuration.getDatabaseId());
/*     */     }
/* 118 */     parseSelectKeyNodes(id, selectKeyNodes, parameterTypeClass, langDriver, null);
/* 119 */     removeSelectKeyNodes(selectKeyNodes);
/*     */   }
/*     */   
/*     */   private void parseSelectKeyNodes(String parentId, List<XNode> list, Class<?> parameterTypeClass, LanguageDriver langDriver, String skRequiredDatabaseId) {
/* 123 */     for (XNode nodeToHandle : list) {
/* 124 */       String id = parentId + "!selectKey";
/* 125 */       String databaseId = nodeToHandle.getStringAttribute("databaseId");
/* 126 */       if (databaseIdMatchesCurrent(id, databaseId, skRequiredDatabaseId)) {
/* 127 */         parseSelectKeyNode(id, nodeToHandle, parameterTypeClass, langDriver, databaseId);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void parseSelectKeyNode(String id, XNode nodeToHandle, Class<?> parameterTypeClass, LanguageDriver langDriver, String databaseId) {
/* 133 */     String resultType = nodeToHandle.getStringAttribute("resultType");
/* 134 */     Class<?> resultTypeClass = resolveClass(resultType);
/* 135 */     StatementType statementType = StatementType.valueOf(nodeToHandle.getStringAttribute("statementType", StatementType.PREPARED.toString()));
/* 136 */     String keyProperty = nodeToHandle.getStringAttribute("keyProperty");
/* 137 */     String keyColumn = nodeToHandle.getStringAttribute("keyColumn");
/* 138 */     boolean executeBefore = "BEFORE".equals(nodeToHandle.getStringAttribute("order", "AFTER"));
/*     */     
/*     */ 
/* 141 */     boolean useCache = false;
/* 142 */     boolean resultOrdered = false;
/* 143 */     KeyGenerator keyGenerator = new NoKeyGenerator();
/* 144 */     Integer fetchSize = null;
/* 145 */     Integer timeout = null;
/* 146 */     boolean flushCache = false;
/* 147 */     String parameterMap = null;
/* 148 */     String resultMap = null;
/* 149 */     ResultSetType resultSetTypeEnum = null;
/*     */     
/* 151 */     SqlSource sqlSource = langDriver.createSqlSource(this.configuration, nodeToHandle, parameterTypeClass);
/* 152 */     SqlCommandType sqlCommandType = SqlCommandType.SELECT;
/*     */     
/* 154 */     this.builderAssistant.addMappedStatement(id, sqlSource, statementType, sqlCommandType, fetchSize, timeout, parameterMap, parameterTypeClass, resultMap, resultTypeClass, resultSetTypeEnum, flushCache, useCache, resultOrdered, keyGenerator, keyProperty, keyColumn, databaseId, langDriver, null);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 159 */     id = this.builderAssistant.applyCurrentNamespace(id, false);
/*     */     
/* 161 */     MappedStatement keyStatement = this.configuration.getMappedStatement(id, false);
/* 162 */     this.configuration.addKeyGenerator(id, new SelectKeyGenerator(keyStatement, executeBefore));
/*     */   }
/*     */   
/*     */   private void removeSelectKeyNodes(List<XNode> selectKeyNodes) {
/* 166 */     for (XNode nodeToHandle : selectKeyNodes) {
/* 167 */       nodeToHandle.getParent().getNode().removeChild(nodeToHandle.getNode());
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean databaseIdMatchesCurrent(String id, String databaseId, String requiredDatabaseId) {
/* 172 */     if (requiredDatabaseId != null) {
/* 173 */       if (!requiredDatabaseId.equals(databaseId)) {
/* 174 */         return false;
/*     */       }
/*     */     } else {
/* 177 */       if (databaseId != null) {
/* 178 */         return false;
/*     */       }
/*     */       
/* 181 */       id = this.builderAssistant.applyCurrentNamespace(id, false);
/* 182 */       if (this.configuration.hasStatement(id, false)) {
/* 183 */         MappedStatement previous = this.configuration.getMappedStatement(id, false);
/* 184 */         if (previous.getDatabaseId() != null) {
/* 185 */           return false;
/*     */         }
/*     */       }
/*     */     }
/* 189 */     return true;
/*     */   }
/*     */   
/*     */   private LanguageDriver getLanguageDriver(String lang) {
/* 193 */     Class<?> langClass = null;
/* 194 */     if (lang != null) {
/* 195 */       langClass = resolveClass(lang);
/*     */     }
/* 197 */     return this.builderAssistant.getLanguageDriver(langClass);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\builder\xml\XMLStatementBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */