/*    */ package org.apache.ibatis.binding;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Map;
/*    */ import org.apache.ibatis.reflection.ExceptionUtil;
/*    */ import org.apache.ibatis.session.SqlSession;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MapperProxy<T>
/*    */   implements InvocationHandler, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -6424540398559729838L;
/*    */   private final SqlSession sqlSession;
/*    */   private final Class<T> mapperInterface;
/*    */   private final Map<Method, MapperMethod> methodCache;
/*    */   
/*    */   public MapperProxy(SqlSession sqlSession, Class<T> mapperInterface, Map<Method, MapperMethod> methodCache)
/*    */   {
/* 38 */     this.sqlSession = sqlSession;
/* 39 */     this.mapperInterface = mapperInterface;
/* 40 */     this.methodCache = methodCache;
/*    */   }
/*    */   
/*    */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 44 */     if (Object.class.equals(method.getDeclaringClass())) {
/*    */       try {
/* 46 */         return method.invoke(this, args);
/*    */       } catch (Throwable t) {
/* 48 */         throw ExceptionUtil.unwrapThrowable(t);
/*    */       }
/*    */     }
/* 51 */     MapperMethod mapperMethod = cachedMapperMethod(method);
/* 52 */     return mapperMethod.execute(this.sqlSession, args);
/*    */   }
/*    */   
/*    */   private MapperMethod cachedMapperMethod(Method method) {
/* 56 */     MapperMethod mapperMethod = (MapperMethod)this.methodCache.get(method);
/* 57 */     if (mapperMethod == null) {
/* 58 */       mapperMethod = new MapperMethod(this.mapperInterface, method, this.sqlSession.getConfiguration());
/* 59 */       this.methodCache.put(method, mapperMethod);
/*    */     }
/* 61 */     return mapperMethod;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\binding\MapperProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */