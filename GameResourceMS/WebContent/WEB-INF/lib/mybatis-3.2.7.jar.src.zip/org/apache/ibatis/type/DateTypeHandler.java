/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Timestamp;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateTypeHandler
/*    */   extends BaseTypeHandler<Date>
/*    */ {
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, Date parameter, JdbcType jdbcType)
/*    */     throws SQLException
/*    */   {
/* 33 */     ps.setTimestamp(i, new Timestamp(parameter.getTime()));
/*    */   }
/*    */   
/*    */   public Date getNullableResult(ResultSet rs, String columnName)
/*    */     throws SQLException
/*    */   {
/* 39 */     Timestamp sqlTimestamp = rs.getTimestamp(columnName);
/* 40 */     if (sqlTimestamp != null) {
/* 41 */       return new Date(sqlTimestamp.getTime());
/*    */     }
/* 43 */     return null;
/*    */   }
/*    */   
/*    */   public Date getNullableResult(ResultSet rs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 49 */     Timestamp sqlTimestamp = rs.getTimestamp(columnIndex);
/* 50 */     if (sqlTimestamp != null) {
/* 51 */       return new Date(sqlTimestamp.getTime());
/*    */     }
/* 53 */     return null;
/*    */   }
/*    */   
/*    */   public Date getNullableResult(CallableStatement cs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 59 */     Timestamp sqlTimestamp = cs.getTimestamp(columnIndex);
/* 60 */     if (sqlTimestamp != null) {
/* 61 */       return new Date(sqlTimestamp.getTime());
/*    */     }
/* 63 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\DateTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */