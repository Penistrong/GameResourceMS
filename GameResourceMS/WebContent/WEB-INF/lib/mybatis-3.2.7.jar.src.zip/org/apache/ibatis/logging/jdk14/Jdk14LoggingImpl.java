/*    */ package org.apache.ibatis.logging.jdk14;
/*    */ 
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ import org.apache.ibatis.logging.Log;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Jdk14LoggingImpl
/*    */   implements Log
/*    */ {
/*    */   private Logger log;
/*    */   
/*    */   public Jdk14LoggingImpl(String clazz)
/*    */   {
/* 31 */     this.log = Logger.getLogger(clazz);
/*    */   }
/*    */   
/*    */   public boolean isDebugEnabled() {
/* 35 */     return this.log.isLoggable(Level.FINE);
/*    */   }
/*    */   
/*    */   public boolean isTraceEnabled() {
/* 39 */     return this.log.isLoggable(Level.FINER);
/*    */   }
/*    */   
/*    */   public void error(String s, Throwable e) {
/* 43 */     this.log.log(Level.SEVERE, s, e);
/*    */   }
/*    */   
/*    */   public void error(String s) {
/* 47 */     this.log.log(Level.SEVERE, s);
/*    */   }
/*    */   
/*    */   public void debug(String s) {
/* 51 */     this.log.log(Level.FINE, s);
/*    */   }
/*    */   
/*    */   public void trace(String s) {
/* 55 */     this.log.log(Level.FINER, s);
/*    */   }
/*    */   
/*    */   public void warn(String s) {
/* 59 */     this.log.log(Level.WARNING, s);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\logging\jdk14\Jdk14LoggingImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */