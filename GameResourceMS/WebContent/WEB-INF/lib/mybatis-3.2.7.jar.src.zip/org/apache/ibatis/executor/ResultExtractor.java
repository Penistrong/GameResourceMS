/*    */ package org.apache.ibatis.executor;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import java.util.List;
/*    */ import org.apache.ibatis.reflection.MetaObject;
/*    */ import org.apache.ibatis.reflection.factory.ObjectFactory;
/*    */ import org.apache.ibatis.session.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResultExtractor
/*    */ {
/*    */   private final Configuration configuration;
/*    */   private final ObjectFactory objectFactory;
/*    */   
/*    */   public ResultExtractor(Configuration configuration, ObjectFactory objectFactory)
/*    */   {
/* 33 */     this.configuration = configuration;
/* 34 */     this.objectFactory = objectFactory;
/*    */   }
/*    */   
/*    */   public Object extractObjectFromList(List<Object> list, Class<?> targetType) {
/* 38 */     Object value = null;
/* 39 */     if ((targetType != null) && (targetType.isAssignableFrom(list.getClass()))) {
/* 40 */       value = list;
/* 41 */     } else if ((targetType != null) && (this.objectFactory.isCollection(targetType))) {
/* 42 */       value = this.objectFactory.create(targetType);
/* 43 */       MetaObject metaObject = this.configuration.newMetaObject(value);
/* 44 */       metaObject.addAll(list);
/* 45 */     } else if ((targetType != null) && (targetType.isArray())) {
/* 46 */       Object[] array = (Object[])Array.newInstance(targetType.getComponentType(), list.size());
/* 47 */       value = list.toArray(array);
/*    */     } else {
/* 49 */       if ((list != null) && (list.size() > 1))
/* 50 */         throw new ExecutorException("Statement returned more than one row, where no more than one was expected.");
/* 51 */       if ((list != null) && (list.size() == 1)) {
/* 52 */         value = list.get(0);
/*    */       }
/*    */     }
/* 55 */     return value;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\ResultExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */