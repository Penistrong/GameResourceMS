/*    */ package org.apache.ibatis.logging.log4j2;
/*    */ 
/*    */ import org.apache.ibatis.logging.Log;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.logging.log4j.spi.AbstractLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Log4j2Impl
/*    */   implements Log
/*    */ {
/*    */   private Log log;
/*    */   
/*    */   public Log4j2Impl(String clazz)
/*    */   {
/* 31 */     Logger logger = LogManager.getLogger(clazz);
/*    */     
/* 33 */     if ((logger instanceof AbstractLogger)) {
/* 34 */       this.log = new Log4j2AbstractLoggerImpl((AbstractLogger)logger);
/*    */     } else {
/* 36 */       this.log = new Log4j2LoggerImpl(logger);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isDebugEnabled() {
/* 41 */     return this.log.isDebugEnabled();
/*    */   }
/*    */   
/*    */   public boolean isTraceEnabled() {
/* 45 */     return this.log.isTraceEnabled();
/*    */   }
/*    */   
/*    */   public void error(String s, Throwable e) {
/* 49 */     this.log.error(s, e);
/*    */   }
/*    */   
/*    */   public void error(String s) {
/* 53 */     this.log.error(s);
/*    */   }
/*    */   
/*    */   public void debug(String s) {
/* 57 */     this.log.debug(s);
/*    */   }
/*    */   
/*    */   public void trace(String s) {
/* 61 */     this.log.trace(s);
/*    */   }
/*    */   
/*    */   public void warn(String s) {
/* 65 */     this.log.warn(s);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\logging\log4j2\Log4j2Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */