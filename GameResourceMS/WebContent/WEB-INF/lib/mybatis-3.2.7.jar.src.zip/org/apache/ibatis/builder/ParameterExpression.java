/*     */ package org.apache.ibatis.builder;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterExpression
/*     */   extends HashMap<String, String>
/*     */ {
/*     */   private static final long serialVersionUID = -2417552199605158680L;
/*     */   
/*     */   public ParameterExpression(String expression)
/*     */   {
/*  40 */     parse(expression);
/*     */   }
/*     */   
/*     */   private void parse(String expression) {
/*  44 */     int p = skipWS(expression, 0);
/*  45 */     if (expression.charAt(p) == '(') {
/*  46 */       expression(expression, p + 1);
/*     */     } else {
/*  48 */       property(expression, p);
/*     */     }
/*     */   }
/*     */   
/*     */   private void expression(String expression, int left) {
/*  53 */     int match = 1;
/*  54 */     int right = left + 1;
/*  55 */     while (match > 0) {
/*  56 */       if (expression.charAt(right) == ')') {
/*  57 */         match--;
/*  58 */       } else if (expression.charAt(right) == '(') {
/*  59 */         match++;
/*     */       }
/*  61 */       right++;
/*     */     }
/*  63 */     put("expression", expression.substring(left, right - 1));
/*  64 */     jdbcTypeOpt(expression, right);
/*     */   }
/*     */   
/*     */   private void property(String expression, int left) {
/*  68 */     if (left < expression.length()) {
/*  69 */       int right = skipUntil(expression, left, ",:");
/*  70 */       put("property", trimmedStr(expression, left, right));
/*  71 */       jdbcTypeOpt(expression, right);
/*     */     }
/*     */   }
/*     */   
/*     */   private int skipWS(String expression, int p) {
/*  76 */     for (int i = p; i < expression.length(); i++) {
/*  77 */       if (expression.charAt(i) > ' ') {
/*  78 */         return i;
/*     */       }
/*     */     }
/*  81 */     return expression.length();
/*     */   }
/*     */   
/*     */   private int skipUntil(String expression, int p, String endChars) {
/*  85 */     for (int i = p; i < expression.length(); i++) {
/*  86 */       char c = expression.charAt(i);
/*  87 */       if (endChars.indexOf(c) > -1) {
/*  88 */         return i;
/*     */       }
/*     */     }
/*  91 */     return expression.length();
/*     */   }
/*     */   
/*     */   private void jdbcTypeOpt(String expression, int p) {
/*  95 */     p = skipWS(expression, p);
/*  96 */     if (p < expression.length()) {
/*  97 */       if (expression.charAt(p) == ':') {
/*  98 */         jdbcType(expression, p + 1);
/*  99 */       } else if (expression.charAt(p) == ',') {
/* 100 */         option(expression, p + 1);
/*     */       } else {
/* 102 */         throw new BuilderException("Parsing error in {" + new String(expression) + "} in position " + p);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void jdbcType(String expression, int p) {
/* 108 */     int left = skipWS(expression, p);
/* 109 */     int right = skipUntil(expression, left, ",");
/* 110 */     if (right > left) {
/* 111 */       put("jdbcType", trimmedStr(expression, left, right));
/*     */     } else {
/* 113 */       throw new BuilderException("Parsing error in {" + new String(expression) + "} in position " + p);
/*     */     }
/* 115 */     option(expression, right + 1);
/*     */   }
/*     */   
/*     */   private void option(String expression, int p) {
/* 119 */     int left = skipWS(expression, p);
/* 120 */     if (left < expression.length()) {
/* 121 */       int right = skipUntil(expression, left, "=");
/* 122 */       String name = trimmedStr(expression, left, right);
/* 123 */       left = right + 1;
/* 124 */       right = skipUntil(expression, left, ",");
/* 125 */       String value = trimmedStr(expression, left, right);
/* 126 */       put(name, value);
/* 127 */       option(expression, right + 1);
/*     */     }
/*     */   }
/*     */   
/*     */   private String trimmedStr(String str, int start, int end) {
/* 132 */     while (str.charAt(start) <= ' ') {
/* 133 */       start++;
/*     */     }
/* 135 */     while (str.charAt(end - 1) <= ' ') {
/* 136 */       end--;
/*     */     }
/* 138 */     return start >= end ? "" : str.substring(start, end);
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\builder\ParameterExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */