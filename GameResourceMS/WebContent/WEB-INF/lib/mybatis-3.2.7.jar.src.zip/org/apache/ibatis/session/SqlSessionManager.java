/*     */ package org.apache.ibatis.session;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.sql.Connection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.ibatis.executor.BatchResult;
/*     */ import org.apache.ibatis.reflection.ExceptionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlSessionManager
/*     */   implements SqlSessionFactory, SqlSession
/*     */ {
/*     */   private final SqlSessionFactory sqlSessionFactory;
/*     */   private final SqlSession sqlSessionProxy;
/*  39 */   private ThreadLocal<SqlSession> localSqlSession = new ThreadLocal();
/*     */   
/*     */   public static SqlSessionManager newInstance(Reader reader) {
/*  42 */     return new SqlSessionManager(new SqlSessionFactoryBuilder().build(reader, null, null));
/*     */   }
/*     */   
/*     */   public static SqlSessionManager newInstance(Reader reader, String environment) {
/*  46 */     return new SqlSessionManager(new SqlSessionFactoryBuilder().build(reader, environment, null));
/*     */   }
/*     */   
/*     */   public static SqlSessionManager newInstance(Reader reader, Properties properties) {
/*  50 */     return new SqlSessionManager(new SqlSessionFactoryBuilder().build(reader, null, properties));
/*     */   }
/*     */   
/*     */   public static SqlSessionManager newInstance(InputStream inputStream) {
/*  54 */     return new SqlSessionManager(new SqlSessionFactoryBuilder().build(inputStream, null, null));
/*     */   }
/*     */   
/*     */   public static SqlSessionManager newInstance(InputStream inputStream, String environment) {
/*  58 */     return new SqlSessionManager(new SqlSessionFactoryBuilder().build(inputStream, environment, null));
/*     */   }
/*     */   
/*     */   public static SqlSessionManager newInstance(InputStream inputStream, Properties properties) {
/*  62 */     return new SqlSessionManager(new SqlSessionFactoryBuilder().build(inputStream, null, properties));
/*     */   }
/*     */   
/*     */   public static SqlSessionManager newInstance(SqlSessionFactory sqlSessionFactory) {
/*  66 */     return new SqlSessionManager(sqlSessionFactory);
/*     */   }
/*     */   
/*     */   private SqlSessionManager(SqlSessionFactory sqlSessionFactory) {
/*  70 */     this.sqlSessionFactory = sqlSessionFactory;
/*  71 */     this.sqlSessionProxy = ((SqlSession)Proxy.newProxyInstance(SqlSessionFactory.class.getClassLoader(), new Class[] { SqlSession.class }, new SqlSessionInterceptor(null)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void startManagedSession()
/*     */   {
/*  78 */     this.localSqlSession.set(openSession());
/*     */   }
/*     */   
/*     */   public void startManagedSession(boolean autoCommit) {
/*  82 */     this.localSqlSession.set(openSession(autoCommit));
/*     */   }
/*     */   
/*     */   public void startManagedSession(Connection connection) {
/*  86 */     this.localSqlSession.set(openSession(connection));
/*     */   }
/*     */   
/*     */   public void startManagedSession(TransactionIsolationLevel level) {
/*  90 */     this.localSqlSession.set(openSession(level));
/*     */   }
/*     */   
/*     */   public void startManagedSession(ExecutorType execType) {
/*  94 */     this.localSqlSession.set(openSession(execType));
/*     */   }
/*     */   
/*     */   public void startManagedSession(ExecutorType execType, boolean autoCommit) {
/*  98 */     this.localSqlSession.set(openSession(execType, autoCommit));
/*     */   }
/*     */   
/*     */   public void startManagedSession(ExecutorType execType, TransactionIsolationLevel level) {
/* 102 */     this.localSqlSession.set(openSession(execType, level));
/*     */   }
/*     */   
/*     */   public void startManagedSession(ExecutorType execType, Connection connection) {
/* 106 */     this.localSqlSession.set(openSession(execType, connection));
/*     */   }
/*     */   
/*     */   public boolean isManagedSessionStarted() {
/* 110 */     return this.localSqlSession.get() != null;
/*     */   }
/*     */   
/*     */   public SqlSession openSession() {
/* 114 */     return this.sqlSessionFactory.openSession();
/*     */   }
/*     */   
/*     */   public SqlSession openSession(boolean autoCommit) {
/* 118 */     return this.sqlSessionFactory.openSession(autoCommit);
/*     */   }
/*     */   
/*     */   public SqlSession openSession(Connection connection) {
/* 122 */     return this.sqlSessionFactory.openSession(connection);
/*     */   }
/*     */   
/*     */   public SqlSession openSession(TransactionIsolationLevel level) {
/* 126 */     return this.sqlSessionFactory.openSession(level);
/*     */   }
/*     */   
/*     */   public SqlSession openSession(ExecutorType execType) {
/* 130 */     return this.sqlSessionFactory.openSession(execType);
/*     */   }
/*     */   
/*     */   public SqlSession openSession(ExecutorType execType, boolean autoCommit) {
/* 134 */     return this.sqlSessionFactory.openSession(execType, autoCommit);
/*     */   }
/*     */   
/*     */   public SqlSession openSession(ExecutorType execType, TransactionIsolationLevel level) {
/* 138 */     return this.sqlSessionFactory.openSession(execType, level);
/*     */   }
/*     */   
/*     */   public SqlSession openSession(ExecutorType execType, Connection connection) {
/* 142 */     return this.sqlSessionFactory.openSession(execType, connection);
/*     */   }
/*     */   
/*     */   public Configuration getConfiguration() {
/* 146 */     return this.sqlSessionFactory.getConfiguration();
/*     */   }
/*     */   
/*     */   public <T> T selectOne(String statement) {
/* 150 */     return (T)this.sqlSessionProxy.selectOne(statement);
/*     */   }
/*     */   
/*     */   public <T> T selectOne(String statement, Object parameter) {
/* 154 */     return (T)this.sqlSessionProxy.selectOne(statement, parameter);
/*     */   }
/*     */   
/*     */   public <K, V> Map<K, V> selectMap(String statement, String mapKey) {
/* 158 */     return this.sqlSessionProxy.selectMap(statement, mapKey);
/*     */   }
/*     */   
/*     */   public <K, V> Map<K, V> selectMap(String statement, Object parameter, String mapKey) {
/* 162 */     return this.sqlSessionProxy.selectMap(statement, parameter, mapKey);
/*     */   }
/*     */   
/*     */   public <K, V> Map<K, V> selectMap(String statement, Object parameter, String mapKey, RowBounds rowBounds) {
/* 166 */     return this.sqlSessionProxy.selectMap(statement, parameter, mapKey, rowBounds);
/*     */   }
/*     */   
/*     */   public <E> List<E> selectList(String statement) {
/* 170 */     return this.sqlSessionProxy.selectList(statement);
/*     */   }
/*     */   
/*     */   public <E> List<E> selectList(String statement, Object parameter) {
/* 174 */     return this.sqlSessionProxy.selectList(statement, parameter);
/*     */   }
/*     */   
/*     */   public <E> List<E> selectList(String statement, Object parameter, RowBounds rowBounds) {
/* 178 */     return this.sqlSessionProxy.selectList(statement, parameter, rowBounds);
/*     */   }
/*     */   
/*     */   public void select(String statement, ResultHandler handler) {
/* 182 */     this.sqlSessionProxy.select(statement, handler);
/*     */   }
/*     */   
/*     */   public void select(String statement, Object parameter, ResultHandler handler) {
/* 186 */     this.sqlSessionProxy.select(statement, parameter, handler);
/*     */   }
/*     */   
/*     */   public void select(String statement, Object parameter, RowBounds rowBounds, ResultHandler handler) {
/* 190 */     this.sqlSessionProxy.select(statement, parameter, rowBounds, handler);
/*     */   }
/*     */   
/*     */   public int insert(String statement) {
/* 194 */     return this.sqlSessionProxy.insert(statement);
/*     */   }
/*     */   
/*     */   public int insert(String statement, Object parameter) {
/* 198 */     return this.sqlSessionProxy.insert(statement, parameter);
/*     */   }
/*     */   
/*     */   public int update(String statement) {
/* 202 */     return this.sqlSessionProxy.update(statement);
/*     */   }
/*     */   
/*     */   public int update(String statement, Object parameter) {
/* 206 */     return this.sqlSessionProxy.update(statement, parameter);
/*     */   }
/*     */   
/*     */   public int delete(String statement) {
/* 210 */     return this.sqlSessionProxy.delete(statement);
/*     */   }
/*     */   
/*     */   public int delete(String statement, Object parameter) {
/* 214 */     return this.sqlSessionProxy.delete(statement, parameter);
/*     */   }
/*     */   
/*     */   public <T> T getMapper(Class<T> type) {
/* 218 */     return (T)getConfiguration().getMapper(type, this);
/*     */   }
/*     */   
/*     */   public Connection getConnection() {
/* 222 */     SqlSession sqlSession = (SqlSession)this.localSqlSession.get();
/* 223 */     if (sqlSession == null) throw new SqlSessionException("Error:  Cannot get connection.  No managed session is started.");
/* 224 */     return sqlSession.getConnection();
/*     */   }
/*     */   
/*     */   public void clearCache() {
/* 228 */     SqlSession sqlSession = (SqlSession)this.localSqlSession.get();
/* 229 */     if (sqlSession == null) throw new SqlSessionException("Error:  Cannot clear the cache.  No managed session is started.");
/* 230 */     sqlSession.clearCache();
/*     */   }
/*     */   
/*     */   public void commit() {
/* 234 */     SqlSession sqlSession = (SqlSession)this.localSqlSession.get();
/* 235 */     if (sqlSession == null) throw new SqlSessionException("Error:  Cannot commit.  No managed session is started.");
/* 236 */     sqlSession.commit();
/*     */   }
/*     */   
/*     */   public void commit(boolean force) {
/* 240 */     SqlSession sqlSession = (SqlSession)this.localSqlSession.get();
/* 241 */     if (sqlSession == null) throw new SqlSessionException("Error:  Cannot commit.  No managed session is started.");
/* 242 */     sqlSession.commit(force);
/*     */   }
/*     */   
/*     */   public void rollback() {
/* 246 */     SqlSession sqlSession = (SqlSession)this.localSqlSession.get();
/* 247 */     if (sqlSession == null) throw new SqlSessionException("Error:  Cannot rollback.  No managed session is started.");
/* 248 */     sqlSession.rollback();
/*     */   }
/*     */   
/*     */   public void rollback(boolean force) {
/* 252 */     SqlSession sqlSession = (SqlSession)this.localSqlSession.get();
/* 253 */     if (sqlSession == null) throw new SqlSessionException("Error:  Cannot rollback.  No managed session is started.");
/* 254 */     sqlSession.rollback(force);
/*     */   }
/*     */   
/*     */   public List<BatchResult> flushStatements() {
/* 258 */     SqlSession sqlSession = (SqlSession)this.localSqlSession.get();
/* 259 */     if (sqlSession == null) throw new SqlSessionException("Error:  Cannot rollback.  No managed session is started.");
/* 260 */     return sqlSession.flushStatements();
/*     */   }
/*     */   
/*     */   public void close() {
/* 264 */     SqlSession sqlSession = (SqlSession)this.localSqlSession.get();
/* 265 */     if (sqlSession == null) throw new SqlSessionException("Error:  Cannot close.  No managed session is started.");
/*     */     try {
/* 267 */       sqlSession.close();
/*     */     } finally {
/* 269 */       this.localSqlSession.set(null);
/*     */     }
/*     */   }
/*     */   
/*     */   private class SqlSessionInterceptor implements InvocationHandler { private SqlSessionInterceptor() {}
/*     */     
/* 275 */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable { SqlSession sqlSession = (SqlSession)SqlSessionManager.this.localSqlSession.get();
/* 276 */       if (sqlSession != null) {
/*     */         try {
/* 278 */           return method.invoke(sqlSession, args);
/*     */         } catch (Throwable t) {
/* 280 */           throw ExceptionUtil.unwrapThrowable(t);
/*     */         }
/*     */       }
/* 283 */       SqlSession autoSqlSession = SqlSessionManager.this.openSession();
/*     */       try {
/* 285 */         Object result = method.invoke(autoSqlSession, args);
/* 286 */         autoSqlSession.commit();
/* 287 */         return result;
/*     */       }
/*     */       catch (Throwable t) {
/* 290 */         throw ExceptionUtil.unwrapThrowable(t);
/*     */       } finally {
/* 292 */         autoSqlSession.close();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\session\SqlSessionManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */