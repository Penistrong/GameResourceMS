/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTMethod
/*    */   extends SimpleNode
/*    */ {
/*    */   private String methodName;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ASTMethod(int id)
/*    */   {
/* 42 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTMethod(OgnlParser p, int id) {
/* 46 */     super(p, id);
/*    */   }
/*    */   
/*    */   void setMethodName(String methodName)
/*    */   {
/* 51 */     this.methodName = methodName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getMethodName()
/*    */   {
/* 59 */     return this.methodName;
/*    */   }
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException
/*    */   {
/* 64 */     Object[] args = OgnlRuntime.getObjectArrayPool().create(jjtGetNumChildren());
/*    */     
/*    */     try
/*    */     {
/* 68 */       Object root = context.getRoot();
/*    */       
/* 70 */       int i = 0; for (int icount = args.length; i < icount; i++) {
/* 71 */         args[i] = this.children[i].getValue(context, root);
/*    */       }
/* 73 */       Object result = OgnlRuntime.callMethod(context, source, this.methodName, null, args);
/* 74 */       if (result == null) {
/* 75 */         NullHandler nh = OgnlRuntime.getNullHandler(OgnlRuntime.getTargetClass(source));
/*    */         
/* 77 */         result = nh.nullMethodResult(context, source, this.methodName, args);
/*    */       }
/* 79 */       return result;
/*    */     } finally {
/* 81 */       OgnlRuntime.getObjectArrayPool().recycle(args);
/*    */     }
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 87 */     String result = this.methodName;
/*    */     
/* 89 */     result = result + "(";
/* 90 */     if ((this.children != null) && (this.children.length > 0)) {
/* 91 */       for (int i = 0; i < this.children.length; i++) {
/* 92 */         if (i > 0) {
/* 93 */           result = result + ", ";
/*    */         }
/* 95 */         result = result + this.children[i];
/*    */       }
/*    */     }
/* 98 */     result = result + ")";
/* 99 */     return result;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTMethod.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */