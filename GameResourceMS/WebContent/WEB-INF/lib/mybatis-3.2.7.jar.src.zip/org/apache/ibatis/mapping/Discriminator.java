/*    */ package org.apache.ibatis.mapping;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import org.apache.ibatis.session.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Discriminator
/*    */ {
/*    */   private ResultMapping resultMapping;
/*    */   private Map<String, String> discriminatorMap;
/*    */   
/*    */   public static class Builder
/*    */   {
/* 35 */     private Discriminator discriminator = new Discriminator(null);
/*    */     
/*    */     public Builder(Configuration configuration, ResultMapping resultMapping, Map<String, String> discriminatorMap) {
/* 38 */       this.discriminator.resultMapping = resultMapping;
/* 39 */       this.discriminator.discriminatorMap = discriminatorMap;
/*    */     }
/*    */     
/*    */     public Discriminator build() {
/* 43 */       assert (this.discriminator.resultMapping != null);
/* 44 */       assert (this.discriminator.discriminatorMap != null);
/* 45 */       assert (this.discriminator.discriminatorMap.size() > 0);
/*    */       
/* 47 */       this.discriminator.discriminatorMap = Collections.unmodifiableMap(this.discriminator.discriminatorMap);
/* 48 */       return this.discriminator;
/*    */     }
/*    */   }
/*    */   
/*    */   public ResultMapping getResultMapping() {
/* 53 */     return this.resultMapping;
/*    */   }
/*    */   
/*    */   public Map<String, String> getDiscriminatorMap() {
/* 57 */     return this.discriminatorMap;
/*    */   }
/*    */   
/*    */   public String getMapIdFor(String s) {
/* 61 */     return (String)this.discriminatorMap.get(s);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\mapping\Discriminator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */