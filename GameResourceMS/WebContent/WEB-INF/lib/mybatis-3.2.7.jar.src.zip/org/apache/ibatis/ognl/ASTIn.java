/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTIn
/*    */   extends SimpleNode
/*    */ {
/*    */   public ASTIn(int id)
/*    */   {
/* 40 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTIn(OgnlParser p, int id) {
/* 44 */     super(p, id);
/*    */   }
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException
/*    */   {
/* 49 */     Object v1 = this.children[0].getValue(context, source);
/* 50 */     Object v2 = this.children[1].getValue(context, source);
/* 51 */     return OgnlOps.in(v1, v2) ? Boolean.TRUE : Boolean.FALSE;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 56 */     return this.children[0] + " in " + this.children[1];
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTIn.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */