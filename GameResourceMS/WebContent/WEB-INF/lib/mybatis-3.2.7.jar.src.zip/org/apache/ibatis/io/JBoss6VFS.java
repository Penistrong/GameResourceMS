/*     */ package org.apache.ibatis.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.ibatis.logging.Log;
/*     */ import org.apache.ibatis.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JBoss6VFS
/*     */   extends VFS
/*     */ {
/*  34 */   private static final Log log = LogFactory.getLog(ResolverUtil.class);
/*     */   private static Boolean valid;
/*     */   
/*     */   static class VirtualFile {
/*     */     static Class<?> VirtualFile;
/*     */     static Method getPathNameRelativeTo;
/*     */     static Method getChildrenRecursively;
/*     */     Object virtualFile;
/*     */     
/*     */     VirtualFile(Object virtualFile) {
/*  44 */       this.virtualFile = virtualFile;
/*     */     }
/*     */     
/*     */     String getPathNameRelativeTo(VirtualFile parent) {
/*     */       try {
/*  49 */         return (String)VFS.invoke(getPathNameRelativeTo, this.virtualFile, new Object[] { parent.virtualFile });
/*     */       }
/*     */       catch (IOException e) {
/*  52 */         JBoss6VFS.log.error("This should not be possible. VirtualFile.getPathNameRelativeTo() threw IOException."); }
/*  53 */       return null;
/*     */     }
/*     */     
/*     */     List<VirtualFile> getChildren() throws IOException
/*     */     {
/*  58 */       List<?> objects = (List)VFS.invoke(getChildrenRecursively, this.virtualFile, new Object[0]);
/*  59 */       List<VirtualFile> children = new ArrayList(objects.size());
/*  60 */       for (Object object : objects) {
/*  61 */         children.add(new VirtualFile(object));
/*     */       }
/*  63 */       return children;
/*     */     }
/*     */   }
/*     */   
/*     */   static class VFS
/*     */   {
/*     */     static Class<?> VFS;
/*     */     static Method getChild;
/*     */     
/*     */     static JBoss6VFS.VirtualFile getChild(URL url) throws IOException {
/*  73 */       Object o = VFS.invoke(getChild, VFS, new Object[] { url });
/*  74 */       return o == null ? null : new JBoss6VFS.VirtualFile(o);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static synchronized void initialize()
/*     */   {
/*  83 */     if (valid == null)
/*     */     {
/*  85 */       valid = Boolean.valueOf(true);
/*     */       
/*     */ 
/*  88 */       VFS.VFS = (Class)checkNotNull(getClass("org.jboss.vfs.VFS"));
/*  89 */       VirtualFile.VirtualFile = (Class)checkNotNull(getClass("org.jboss.vfs.VirtualFile"));
/*     */       
/*     */ 
/*  92 */       VFS.getChild = (Method)checkNotNull(getMethod(VFS.VFS, "getChild", new Class[] { URL.class }));
/*  93 */       VirtualFile.getChildrenRecursively = (Method)checkNotNull(getMethod(VirtualFile.VirtualFile, "getChildrenRecursively", new Class[0]));
/*     */       
/*  95 */       VirtualFile.getPathNameRelativeTo = (Method)checkNotNull(getMethod(VirtualFile.VirtualFile, "getPathNameRelativeTo", new Class[] { VirtualFile.VirtualFile }));
/*     */       
/*     */ 
/*     */ 
/*  99 */       checkReturnType(VFS.getChild, VirtualFile.VirtualFile);
/* 100 */       checkReturnType(VirtualFile.getChildrenRecursively, List.class);
/* 101 */       checkReturnType(VirtualFile.getPathNameRelativeTo, String.class);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static <T> T checkNotNull(T object)
/*     */   {
/* 112 */     if (object == null)
/* 113 */       setInvalid();
/* 114 */     return object;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void checkReturnType(Method method, Class<?> expected)
/*     */   {
/* 126 */     if ((method != null) && (!expected.isAssignableFrom(method.getReturnType()))) {
/* 127 */       log.error("Method " + method.getClass().getName() + "." + method.getName() + "(..) should return " + expected.getName() + " but returns " + method.getReturnType().getName() + " instead.");
/*     */       
/*     */ 
/* 130 */       setInvalid();
/*     */     }
/*     */   }
/*     */   
/*     */   protected static void setInvalid()
/*     */   {
/* 136 */     if ((valid != null) && (valid.booleanValue())) {
/* 137 */       log.debug("JBoss 6 VFS API is not available in this environment.");
/* 138 */       valid = Boolean.valueOf(false);
/*     */     }
/*     */   }
/*     */   
/*     */   static {
/* 143 */     initialize();
/*     */   }
/*     */   
/*     */   public boolean isValid()
/*     */   {
/* 148 */     return valid.booleanValue();
/*     */   }
/*     */   
/*     */   public List<String> list(URL url, String path)
/*     */     throws IOException
/*     */   {
/* 154 */     VirtualFile directory = VFS.getChild(url);
/* 155 */     if (directory == null) {
/* 156 */       return Collections.emptyList();
/*     */     }
/* 158 */     if (!path.endsWith("/")) {
/* 159 */       path = path + "/";
/*     */     }
/* 161 */     List<VirtualFile> children = directory.getChildren();
/* 162 */     List<String> names = new ArrayList(children.size());
/* 163 */     for (VirtualFile vf : children) {
/* 164 */       String relative = vf.getPathNameRelativeTo(directory);
/* 165 */       names.add(path + relative);
/*     */     }
/*     */     
/* 168 */     return names;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\io\JBoss6VFS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */