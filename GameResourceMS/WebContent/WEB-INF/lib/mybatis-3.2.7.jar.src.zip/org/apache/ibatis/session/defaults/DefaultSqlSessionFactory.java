/*     */ package org.apache.ibatis.session.defaults;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import org.apache.ibatis.exceptions.ExceptionFactory;
/*     */ import org.apache.ibatis.executor.ErrorContext;
/*     */ import org.apache.ibatis.executor.Executor;
/*     */ import org.apache.ibatis.mapping.Environment;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.session.ExecutorType;
/*     */ import org.apache.ibatis.session.SqlSession;
/*     */ import org.apache.ibatis.session.SqlSessionFactory;
/*     */ import org.apache.ibatis.session.TransactionIsolationLevel;
/*     */ import org.apache.ibatis.transaction.Transaction;
/*     */ import org.apache.ibatis.transaction.TransactionFactory;
/*     */ import org.apache.ibatis.transaction.managed.ManagedTransactionFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultSqlSessionFactory
/*     */   implements SqlSessionFactory
/*     */ {
/*     */   private final Configuration configuration;
/*     */   
/*     */   public DefaultSqlSessionFactory(Configuration configuration)
/*     */   {
/*  42 */     this.configuration = configuration;
/*     */   }
/*     */   
/*     */   public SqlSession openSession() {
/*  46 */     return openSessionFromDataSource(this.configuration.getDefaultExecutorType(), null, false);
/*     */   }
/*     */   
/*     */   public SqlSession openSession(boolean autoCommit) {
/*  50 */     return openSessionFromDataSource(this.configuration.getDefaultExecutorType(), null, autoCommit);
/*     */   }
/*     */   
/*     */   public SqlSession openSession(ExecutorType execType) {
/*  54 */     return openSessionFromDataSource(execType, null, false);
/*     */   }
/*     */   
/*     */   public SqlSession openSession(TransactionIsolationLevel level) {
/*  58 */     return openSessionFromDataSource(this.configuration.getDefaultExecutorType(), level, false);
/*     */   }
/*     */   
/*     */   public SqlSession openSession(ExecutorType execType, TransactionIsolationLevel level) {
/*  62 */     return openSessionFromDataSource(execType, level, false);
/*     */   }
/*     */   
/*     */   public SqlSession openSession(ExecutorType execType, boolean autoCommit) {
/*  66 */     return openSessionFromDataSource(execType, null, autoCommit);
/*     */   }
/*     */   
/*     */   public SqlSession openSession(Connection connection) {
/*  70 */     return openSessionFromConnection(this.configuration.getDefaultExecutorType(), connection);
/*     */   }
/*     */   
/*     */   public SqlSession openSession(ExecutorType execType, Connection connection) {
/*  74 */     return openSessionFromConnection(execType, connection);
/*     */   }
/*     */   
/*     */   public Configuration getConfiguration() {
/*  78 */     return this.configuration;
/*     */   }
/*     */   
/*     */   private SqlSession openSessionFromDataSource(ExecutorType execType, TransactionIsolationLevel level, boolean autoCommit) {
/*  82 */     Transaction tx = null;
/*     */     try {
/*  84 */       Environment environment = this.configuration.getEnvironment();
/*  85 */       TransactionFactory transactionFactory = getTransactionFactoryFromEnvironment(environment);
/*  86 */       tx = transactionFactory.newTransaction(environment.getDataSource(), level, autoCommit);
/*  87 */       Executor executor = this.configuration.newExecutor(tx, execType);
/*  88 */       return new DefaultSqlSession(this.configuration, executor, autoCommit);
/*     */     } catch (Exception e) {
/*  90 */       closeTransaction(tx);
/*  91 */       throw ExceptionFactory.wrapException("Error opening session.  Cause: " + e, e);
/*     */     } finally {
/*  93 */       ErrorContext.instance().reset();
/*     */     }
/*     */   }
/*     */   
/*     */   private SqlSession openSessionFromConnection(ExecutorType execType, Connection connection) {
/*     */     try {
/*     */       boolean autoCommit;
/*     */       try {
/* 101 */         autoCommit = connection.getAutoCommit();
/*     */       }
/*     */       catch (SQLException e)
/*     */       {
/* 105 */         autoCommit = true;
/*     */       }
/* 107 */       Environment environment = this.configuration.getEnvironment();
/* 108 */       TransactionFactory transactionFactory = getTransactionFactoryFromEnvironment(environment);
/* 109 */       Transaction tx = transactionFactory.newTransaction(connection);
/* 110 */       Executor executor = this.configuration.newExecutor(tx, execType);
/* 111 */       return new DefaultSqlSession(this.configuration, executor, autoCommit);
/*     */     } catch (Exception e) {
/* 113 */       throw ExceptionFactory.wrapException("Error opening session.  Cause: " + e, e);
/*     */     } finally {
/* 115 */       ErrorContext.instance().reset();
/*     */     }
/*     */   }
/*     */   
/*     */   private TransactionFactory getTransactionFactoryFromEnvironment(Environment environment) {
/* 120 */     if ((environment == null) || (environment.getTransactionFactory() == null)) {
/* 121 */       return new ManagedTransactionFactory();
/*     */     }
/* 123 */     return environment.getTransactionFactory();
/*     */   }
/*     */   
/*     */   private void closeTransaction(Transaction tx) {
/* 127 */     if (tx != null) {
/*     */       try {
/* 129 */         tx.close();
/*     */       }
/*     */       catch (SQLException ignore) {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\session\defaults\DefaultSqlSessionFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */