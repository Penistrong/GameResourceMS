/*     */ package org.apache.ibatis.mapping;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.type.JdbcType;
/*     */ import org.apache.ibatis.type.TypeHandler;
/*     */ import org.apache.ibatis.type.TypeHandlerRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterMapping
/*     */ {
/*     */   private Configuration configuration;
/*     */   private String property;
/*     */   private ParameterMode mode;
/*  34 */   private Class<?> javaType = Object.class;
/*     */   
/*     */   private JdbcType jdbcType;
/*     */   
/*     */   private Integer numericScale;
/*     */   private TypeHandler<?> typeHandler;
/*     */   private String resultMapId;
/*     */   private String jdbcTypeName;
/*     */   private String expression;
/*     */   
/*     */   public static class Builder
/*     */   {
/*  46 */     private ParameterMapping parameterMapping = new ParameterMapping(null);
/*     */     
/*     */     public Builder(Configuration configuration, String property, TypeHandler<?> typeHandler) {
/*  49 */       this.parameterMapping.configuration = configuration;
/*  50 */       this.parameterMapping.property = property;
/*  51 */       this.parameterMapping.typeHandler = typeHandler;
/*  52 */       this.parameterMapping.mode = ParameterMode.IN;
/*     */     }
/*     */     
/*     */     public Builder(Configuration configuration, String property, Class<?> javaType) {
/*  56 */       this.parameterMapping.configuration = configuration;
/*  57 */       this.parameterMapping.property = property;
/*  58 */       this.parameterMapping.javaType = javaType;
/*  59 */       this.parameterMapping.mode = ParameterMode.IN;
/*     */     }
/*     */     
/*     */     public Builder mode(ParameterMode mode) {
/*  63 */       this.parameterMapping.mode = mode;
/*  64 */       return this;
/*     */     }
/*     */     
/*     */     public Builder javaType(Class<?> javaType) {
/*  68 */       this.parameterMapping.javaType = javaType;
/*  69 */       return this;
/*     */     }
/*     */     
/*     */     public Builder jdbcType(JdbcType jdbcType) {
/*  73 */       this.parameterMapping.jdbcType = jdbcType;
/*  74 */       return this;
/*     */     }
/*     */     
/*     */     public Builder numericScale(Integer numericScale) {
/*  78 */       this.parameterMapping.numericScale = numericScale;
/*  79 */       return this;
/*     */     }
/*     */     
/*     */     public Builder resultMapId(String resultMapId) {
/*  83 */       this.parameterMapping.resultMapId = resultMapId;
/*  84 */       return this;
/*     */     }
/*     */     
/*     */     public Builder typeHandler(TypeHandler<?> typeHandler) {
/*  88 */       this.parameterMapping.typeHandler = typeHandler;
/*  89 */       return this;
/*     */     }
/*     */     
/*     */     public Builder jdbcTypeName(String jdbcTypeName) {
/*  93 */       this.parameterMapping.jdbcTypeName = jdbcTypeName;
/*  94 */       return this;
/*     */     }
/*     */     
/*     */     public Builder expression(String expression) {
/*  98 */       this.parameterMapping.expression = expression;
/*  99 */       return this;
/*     */     }
/*     */     
/*     */     public ParameterMapping build() {
/* 103 */       resolveTypeHandler();
/* 104 */       validate();
/* 105 */       return this.parameterMapping;
/*     */     }
/*     */     
/*     */     private void validate() {
/* 109 */       if (ResultSet.class.equals(this.parameterMapping.javaType)) {
/* 110 */         if (this.parameterMapping.resultMapId == null) {
/* 111 */           throw new IllegalStateException("Missing resultmap in property '" + this.parameterMapping.property + "'.  " + "Parameters of type java.sql.ResultSet require a resultmap.");
/*     */         }
/*     */         
/*     */ 
/*     */       }
/* 116 */       else if (this.parameterMapping.typeHandler == null) {
/* 117 */         throw new IllegalStateException("Type handler was null on parameter mapping for property '" + this.parameterMapping.property + "'.  " + "It was either not specified and/or could not be found for the javaType / jdbcType combination specified.");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private void resolveTypeHandler()
/*     */     {
/* 125 */       if ((this.parameterMapping.typeHandler == null) && (this.parameterMapping.javaType != null)) {
/* 126 */         Configuration configuration = this.parameterMapping.configuration;
/* 127 */         TypeHandlerRegistry typeHandlerRegistry = configuration.getTypeHandlerRegistry();
/* 128 */         this.parameterMapping.typeHandler = typeHandlerRegistry.getTypeHandler(this.parameterMapping.javaType, this.parameterMapping.jdbcType);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String getProperty()
/*     */   {
/* 135 */     return this.property;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParameterMode getMode()
/*     */   {
/* 143 */     return this.mode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getJavaType()
/*     */   {
/* 151 */     return this.javaType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JdbcType getJdbcType()
/*     */   {
/* 159 */     return this.jdbcType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getNumericScale()
/*     */   {
/* 167 */     return this.numericScale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypeHandler<?> getTypeHandler()
/*     */   {
/* 175 */     return this.typeHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getResultMapId()
/*     */   {
/* 183 */     return this.resultMapId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getJdbcTypeName()
/*     */   {
/* 191 */     return this.jdbcTypeName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExpression()
/*     */   {
/* 199 */     return this.expression;
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\mapping\ParameterMapping.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */