/*    */ package org.apache.ibatis.reflection.property;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyTokenizer
/*    */   implements Iterable<PropertyTokenizer>, Iterator<PropertyTokenizer>
/*    */ {
/*    */   private String name;
/*    */   private String indexedName;
/*    */   private String index;
/*    */   private String children;
/*    */   
/*    */   public PropertyTokenizer(String fullname)
/*    */   {
/* 30 */     int delim = fullname.indexOf('.');
/* 31 */     if (delim > -1) {
/* 32 */       this.name = fullname.substring(0, delim);
/* 33 */       this.children = fullname.substring(delim + 1);
/*    */     } else {
/* 35 */       this.name = fullname;
/* 36 */       this.children = null;
/*    */     }
/* 38 */     this.indexedName = this.name;
/* 39 */     delim = this.name.indexOf('[');
/* 40 */     if (delim > -1) {
/* 41 */       this.index = this.name.substring(delim + 1, this.name.length() - 1);
/* 42 */       this.name = this.name.substring(0, delim);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getName() {
/* 47 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getIndex() {
/* 51 */     return this.index;
/*    */   }
/*    */   
/*    */   public String getIndexedName() {
/* 55 */     return this.indexedName;
/*    */   }
/*    */   
/*    */   public String getChildren() {
/* 59 */     return this.children;
/*    */   }
/*    */   
/*    */   public boolean hasNext() {
/* 63 */     return this.children != null;
/*    */   }
/*    */   
/*    */   public PropertyTokenizer next() {
/* 67 */     return new PropertyTokenizer(this.children);
/*    */   }
/*    */   
/*    */   public void remove() {
/* 71 */     throw new UnsupportedOperationException("Remove is not supported, as it has no meaning in the context of properties.");
/*    */   }
/*    */   
/*    */   public Iterator<PropertyTokenizer> iterator() {
/* 75 */     return this;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\property\PropertyTokenizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */