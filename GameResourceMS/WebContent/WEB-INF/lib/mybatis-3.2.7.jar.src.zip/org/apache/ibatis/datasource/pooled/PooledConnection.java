/*     */ package org.apache.ibatis.datasource.pooled;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import org.apache.ibatis.reflection.ExceptionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PooledConnection
/*     */   implements InvocationHandler
/*     */ {
/*     */   private static final String CLOSE = "close";
/*  32 */   private static final Class<?>[] IFACES = { Connection.class };
/*     */   
/*  34 */   private int hashCode = 0;
/*     */   
/*     */   private PooledDataSource dataSource;
/*     */   
/*     */   private Connection realConnection;
/*     */   
/*     */   private Connection proxyConnection;
/*     */   
/*     */   private long checkoutTimestamp;
/*     */   
/*     */   private long createdTimestamp;
/*     */   private long lastUsedTimestamp;
/*     */   private int connectionTypeCode;
/*     */   private boolean valid;
/*     */   
/*     */   public PooledConnection(Connection connection, PooledDataSource dataSource)
/*     */   {
/*  51 */     this.hashCode = connection.hashCode();
/*  52 */     this.realConnection = connection;
/*  53 */     this.dataSource = dataSource;
/*  54 */     this.createdTimestamp = System.currentTimeMillis();
/*  55 */     this.lastUsedTimestamp = System.currentTimeMillis();
/*  56 */     this.valid = true;
/*  57 */     this.proxyConnection = ((Connection)Proxy.newProxyInstance(Connection.class.getClassLoader(), IFACES, this));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void invalidate()
/*     */   {
/*  64 */     this.valid = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isValid()
/*     */   {
/*  73 */     return (this.valid) && (this.realConnection != null) && (this.dataSource.pingConnection(this));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Connection getRealConnection()
/*     */   {
/*  82 */     return this.realConnection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Connection getProxyConnection()
/*     */   {
/*  91 */     return this.proxyConnection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRealHashCode()
/*     */   {
/* 100 */     if (this.realConnection == null) {
/* 101 */       return 0;
/*     */     }
/* 103 */     return this.realConnection.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getConnectionTypeCode()
/*     */   {
/* 113 */     return this.connectionTypeCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectionTypeCode(int connectionTypeCode)
/*     */   {
/* 122 */     this.connectionTypeCode = connectionTypeCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getCreatedTimestamp()
/*     */   {
/* 131 */     return this.createdTimestamp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCreatedTimestamp(long createdTimestamp)
/*     */   {
/* 140 */     this.createdTimestamp = createdTimestamp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getLastUsedTimestamp()
/*     */   {
/* 149 */     return this.lastUsedTimestamp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLastUsedTimestamp(long lastUsedTimestamp)
/*     */   {
/* 158 */     this.lastUsedTimestamp = lastUsedTimestamp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getTimeElapsedSinceLastUse()
/*     */   {
/* 167 */     return System.currentTimeMillis() - this.lastUsedTimestamp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getAge()
/*     */   {
/* 176 */     return System.currentTimeMillis() - this.createdTimestamp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getCheckoutTimestamp()
/*     */   {
/* 185 */     return this.checkoutTimestamp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCheckoutTimestamp(long timestamp)
/*     */   {
/* 194 */     this.checkoutTimestamp = timestamp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getCheckoutTime()
/*     */   {
/* 203 */     return System.currentTimeMillis() - this.checkoutTimestamp;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 207 */     return this.hashCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 217 */     if ((obj instanceof PooledConnection))
/* 218 */       return this.realConnection.hashCode() == ((PooledConnection)obj).realConnection.hashCode();
/* 219 */     if ((obj instanceof Connection)) {
/* 220 */       return this.hashCode == obj.hashCode();
/*     */     }
/* 222 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object proxy, Method method, Object[] args)
/*     */     throws Throwable
/*     */   {
/* 235 */     String methodName = method.getName();
/* 236 */     if (("close".hashCode() == methodName.hashCode()) && ("close".equals(methodName))) {
/* 237 */       this.dataSource.pushConnection(this);
/* 238 */       return null;
/*     */     }
/*     */     try {
/* 241 */       if (!Object.class.equals(method.getDeclaringClass()))
/*     */       {
/*     */ 
/* 244 */         checkConnection();
/*     */       }
/* 246 */       return method.invoke(this.realConnection, args);
/*     */     } catch (Throwable t) {
/* 248 */       throw ExceptionUtil.unwrapThrowable(t);
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkConnection() throws SQLException
/*     */   {
/* 254 */     if (!this.valid) {
/* 255 */       throw new SQLException("Error accessing PooledConnection. Connection is invalid.");
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\datasource\pooled\PooledConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */