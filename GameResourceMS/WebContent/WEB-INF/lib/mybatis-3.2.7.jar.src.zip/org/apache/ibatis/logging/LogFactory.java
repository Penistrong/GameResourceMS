/*     */ package org.apache.ibatis.logging;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import org.apache.ibatis.logging.commons.JakartaCommonsLoggingImpl;
/*     */ import org.apache.ibatis.logging.jdk14.Jdk14LoggingImpl;
/*     */ import org.apache.ibatis.logging.log4j.Log4jImpl;
/*     */ import org.apache.ibatis.logging.log4j2.Log4j2Impl;
/*     */ import org.apache.ibatis.logging.nologging.NoLoggingImpl;
/*     */ import org.apache.ibatis.logging.slf4j.Slf4jImpl;
/*     */ import org.apache.ibatis.logging.stdout.StdOutImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LogFactory
/*     */ {
/*     */   public static final String MARKER = "MYBATIS";
/*     */   private static Constructor<? extends Log> logConstructor;
/*     */   
/*     */   static
/*     */   {
/*  34 */     tryImplementation(new Runnable()
/*     */     {
/*     */       public void run() {}
/*     */ 
/*  38 */     });
/*  39 */     tryImplementation(new Runnable()
/*     */     {
/*     */       public void run() {}
/*     */ 
/*  43 */     });
/*  44 */     tryImplementation(new Runnable()
/*     */     {
/*     */       public void run() {}
/*     */ 
/*  48 */     });
/*  49 */     tryImplementation(new Runnable()
/*     */     {
/*     */       public void run() {}
/*     */ 
/*  53 */     });
/*  54 */     tryImplementation(new Runnable()
/*     */     {
/*     */       public void run() {}
/*     */ 
/*  58 */     });
/*  59 */     tryImplementation(new Runnable()
/*     */     {
/*     */       public void run() {}
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Log getLog(Class<?> aClass)
/*     */   {
/*  71 */     return getLog(aClass.getName());
/*     */   }
/*     */   
/*     */   public static Log getLog(String logger) {
/*     */     try {
/*  76 */       return (Log)logConstructor.newInstance(new Object[] { logger });
/*     */     } catch (Throwable t) {
/*  78 */       throw new LogException("Error creating logger for logger " + logger + ".  Cause: " + t, t);
/*     */     }
/*     */   }
/*     */   
/*     */   public static synchronized void useCustomLogging(Class<? extends Log> clazz) {
/*  83 */     setImplementation(clazz);
/*     */   }
/*     */   
/*     */   public static synchronized void useSlf4jLogging() {
/*  87 */     setImplementation(Slf4jImpl.class);
/*     */   }
/*     */   
/*     */   public static synchronized void useCommonsLogging() {
/*  91 */     setImplementation(JakartaCommonsLoggingImpl.class);
/*     */   }
/*     */   
/*     */   public static synchronized void useLog4JLogging() {
/*  95 */     setImplementation(Log4jImpl.class);
/*     */   }
/*     */   
/*     */   public static synchronized void useLog4J2Logging() {
/*  99 */     setImplementation(Log4j2Impl.class);
/*     */   }
/*     */   
/*     */   public static synchronized void useJdkLogging() {
/* 103 */     setImplementation(Jdk14LoggingImpl.class);
/*     */   }
/*     */   
/*     */   public static synchronized void useStdOutLogging() {
/* 107 */     setImplementation(StdOutImpl.class);
/*     */   }
/*     */   
/*     */   public static synchronized void useNoLogging() {
/* 111 */     setImplementation(NoLoggingImpl.class);
/*     */   }
/*     */   
/*     */   private static void tryImplementation(Runnable runnable) {
/* 115 */     if (logConstructor == null) {
/*     */       try {
/* 117 */         runnable.run();
/*     */       }
/*     */       catch (Throwable t) {}
/*     */     }
/*     */   }
/*     */   
/*     */   private static void setImplementation(Class<? extends Log> implClass)
/*     */   {
/*     */     try {
/* 126 */       Constructor<? extends Log> candidate = implClass.getConstructor(new Class[] { String.class });
/* 127 */       Log log = (Log)candidate.newInstance(new Object[] { LogFactory.class.getName() });
/* 128 */       log.debug("Logging initialized using '" + implClass + "' adapter.");
/* 129 */       logConstructor = candidate;
/*     */     } catch (Throwable t) {
/* 131 */       throw new LogException("Error setting Log implementation.  Cause: " + t, t);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\logging\LogFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */