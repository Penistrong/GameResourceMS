/*    */ package org.apache.ibatis.session;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.Reader;
/*    */ import java.util.Properties;
/*    */ import org.apache.ibatis.builder.xml.XMLConfigBuilder;
/*    */ import org.apache.ibatis.exceptions.ExceptionFactory;
/*    */ import org.apache.ibatis.executor.ErrorContext;
/*    */ import org.apache.ibatis.session.defaults.DefaultSqlSessionFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SqlSessionFactoryBuilder
/*    */ {
/*    */   public SqlSessionFactory build(Reader reader)
/*    */   {
/* 38 */     return build(reader, null, null);
/*    */   }
/*    */   
/*    */   public SqlSessionFactory build(Reader reader, String environment) {
/* 42 */     return build(reader, environment, null);
/*    */   }
/*    */   
/*    */   public SqlSessionFactory build(Reader reader, Properties properties) {
/* 46 */     return build(reader, null, properties);
/*    */   }
/*    */   
/*    */   public SqlSessionFactory build(Reader reader, String environment, Properties properties) {
/*    */     try {
/* 51 */       XMLConfigBuilder parser = new XMLConfigBuilder(reader, environment, properties);
/* 52 */       return build(parser.parse());
/*    */     } catch (Exception e) {
/* 54 */       throw ExceptionFactory.wrapException("Error building SqlSession.", e);
/*    */     } finally {
/* 56 */       ErrorContext.instance().reset();
/*    */       try {
/* 58 */         reader.close();
/*    */       }
/*    */       catch (IOException e) {}
/*    */     }
/*    */   }
/*    */   
/*    */   public SqlSessionFactory build(InputStream inputStream)
/*    */   {
/* 66 */     return build(inputStream, null, null);
/*    */   }
/*    */   
/*    */   public SqlSessionFactory build(InputStream inputStream, String environment) {
/* 70 */     return build(inputStream, environment, null);
/*    */   }
/*    */   
/*    */   public SqlSessionFactory build(InputStream inputStream, Properties properties) {
/* 74 */     return build(inputStream, null, properties);
/*    */   }
/*    */   
/*    */   public SqlSessionFactory build(InputStream inputStream, String environment, Properties properties) {
/*    */     try {
/* 79 */       XMLConfigBuilder parser = new XMLConfigBuilder(inputStream, environment, properties);
/* 80 */       return build(parser.parse());
/*    */     } catch (Exception e) {
/* 82 */       throw ExceptionFactory.wrapException("Error building SqlSession.", e);
/*    */     } finally {
/* 84 */       ErrorContext.instance().reset();
/*    */       try {
/* 86 */         inputStream.close();
/*    */       }
/*    */       catch (IOException e) {}
/*    */     }
/*    */   }
/*    */   
/*    */   public SqlSessionFactory build(Configuration config)
/*    */   {
/* 94 */     return new DefaultSqlSessionFactory(config);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\session\SqlSessionFactoryBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */