package org.apache.ibatis.annotations;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.apache.ibatis.mapping.FetchType;

@Retention(RetentionPolicy.RUNTIME)
@Target({java.lang.annotation.ElementType.METHOD})
public @interface Many
{
  String select() default "";
  
  FetchType fetchType() default FetchType.DEFAULT;
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\annotations\Many.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */