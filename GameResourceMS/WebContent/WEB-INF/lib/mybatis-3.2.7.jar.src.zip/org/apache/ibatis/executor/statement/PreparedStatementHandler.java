/*    */ package org.apache.ibatis.executor.statement;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import java.util.List;
/*    */ import org.apache.ibatis.executor.Executor;
/*    */ import org.apache.ibatis.executor.keygen.Jdbc3KeyGenerator;
/*    */ import org.apache.ibatis.executor.keygen.KeyGenerator;
/*    */ import org.apache.ibatis.executor.parameter.ParameterHandler;
/*    */ import org.apache.ibatis.executor.resultset.ResultSetHandler;
/*    */ import org.apache.ibatis.mapping.BoundSql;
/*    */ import org.apache.ibatis.mapping.MappedStatement;
/*    */ import org.apache.ibatis.mapping.ResultSetType;
/*    */ import org.apache.ibatis.session.ResultHandler;
/*    */ import org.apache.ibatis.session.RowBounds;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PreparedStatementHandler
/*    */   extends BaseStatementHandler
/*    */ {
/*    */   public PreparedStatementHandler(Executor executor, MappedStatement mappedStatement, Object parameter, RowBounds rowBounds, ResultHandler resultHandler, BoundSql boundSql)
/*    */   {
/* 39 */     super(executor, mappedStatement, parameter, rowBounds, resultHandler, boundSql);
/*    */   }
/*    */   
/*    */   public int update(Statement statement) throws SQLException {
/* 43 */     PreparedStatement ps = (PreparedStatement)statement;
/* 44 */     ps.execute();
/* 45 */     int rows = ps.getUpdateCount();
/* 46 */     Object parameterObject = this.boundSql.getParameterObject();
/* 47 */     KeyGenerator keyGenerator = this.mappedStatement.getKeyGenerator();
/* 48 */     keyGenerator.processAfter(this.executor, this.mappedStatement, ps, parameterObject);
/* 49 */     return rows;
/*    */   }
/*    */   
/*    */   public void batch(Statement statement) throws SQLException {
/* 53 */     PreparedStatement ps = (PreparedStatement)statement;
/* 54 */     ps.addBatch();
/*    */   }
/*    */   
/*    */   public <E> List<E> query(Statement statement, ResultHandler resultHandler) throws SQLException {
/* 58 */     PreparedStatement ps = (PreparedStatement)statement;
/* 59 */     ps.execute();
/* 60 */     return this.resultSetHandler.handleResultSets(ps);
/*    */   }
/*    */   
/*    */   protected Statement instantiateStatement(Connection connection) throws SQLException {
/* 64 */     String sql = this.boundSql.getSql();
/* 65 */     if ((this.mappedStatement.getKeyGenerator() instanceof Jdbc3KeyGenerator)) {
/* 66 */       String[] keyColumnNames = this.mappedStatement.getKeyColumns();
/* 67 */       if (keyColumnNames == null) {
/* 68 */         return connection.prepareStatement(sql, 1);
/*    */       }
/* 70 */       return connection.prepareStatement(sql, keyColumnNames);
/*    */     }
/* 72 */     if (this.mappedStatement.getResultSetType() != null) {
/* 73 */       return connection.prepareStatement(sql, this.mappedStatement.getResultSetType().getValue(), 1007);
/*    */     }
/* 75 */     return connection.prepareStatement(sql);
/*    */   }
/*    */   
/*    */   public void parameterize(Statement statement) throws SQLException
/*    */   {
/* 80 */     this.parameterHandler.setParameters((PreparedStatement)statement);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\statement\PreparedStatementHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */