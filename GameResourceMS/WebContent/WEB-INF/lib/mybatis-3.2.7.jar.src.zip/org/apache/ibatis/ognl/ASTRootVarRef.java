/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTRootVarRef
/*    */   extends ASTVarRef
/*    */ {
/*    */   private String name;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ASTRootVarRef(int id)
/*    */   {
/* 42 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTRootVarRef(OgnlParser p, int id) {
/* 46 */     super(p, id);
/*    */   }
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/* 50 */     return context.getRoot();
/*    */   }
/*    */   
/*    */   protected void setValueBody(OgnlContext context, Object target, Object value) throws OgnlException {
/* 54 */     context.setRoot(value);
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 59 */     return "#root";
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTRootVarRef.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */