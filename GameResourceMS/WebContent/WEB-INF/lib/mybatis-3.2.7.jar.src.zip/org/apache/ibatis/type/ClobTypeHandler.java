/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.io.StringReader;
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.Clob;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClobTypeHandler
/*    */   extends BaseTypeHandler<String>
/*    */ {
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, String parameter, JdbcType jdbcType)
/*    */     throws SQLException
/*    */   {
/* 33 */     StringReader reader = new StringReader(parameter);
/* 34 */     ps.setCharacterStream(i, reader, parameter.length());
/*    */   }
/*    */   
/*    */   public String getNullableResult(ResultSet rs, String columnName)
/*    */     throws SQLException
/*    */   {
/* 40 */     String value = "";
/* 41 */     Clob clob = rs.getClob(columnName);
/* 42 */     if (clob != null) {
/* 43 */       int size = (int)clob.length();
/* 44 */       value = clob.getSubString(1L, size);
/*    */     }
/* 46 */     return value;
/*    */   }
/*    */   
/*    */   public String getNullableResult(ResultSet rs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 52 */     String value = "";
/* 53 */     Clob clob = rs.getClob(columnIndex);
/* 54 */     if (clob != null) {
/* 55 */       int size = (int)clob.length();
/* 56 */       value = clob.getSubString(1L, size);
/*    */     }
/* 58 */     return value;
/*    */   }
/*    */   
/*    */   public String getNullableResult(CallableStatement cs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 64 */     String value = "";
/* 65 */     Clob clob = cs.getClob(columnIndex);
/* 66 */     if (clob != null) {
/* 67 */       int size = (int)clob.length();
/* 68 */       value = clob.getSubString(1L, size);
/*    */     }
/* 70 */     return value;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\ClobTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */