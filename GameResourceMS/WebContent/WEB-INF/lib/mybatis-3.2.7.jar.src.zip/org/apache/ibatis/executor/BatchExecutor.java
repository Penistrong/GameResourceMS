/*     */ package org.apache.ibatis.executor;
/*     */ 
/*     */ import java.sql.BatchUpdateException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.ibatis.executor.keygen.Jdbc3KeyGenerator;
/*     */ import org.apache.ibatis.executor.keygen.KeyGenerator;
/*     */ import org.apache.ibatis.executor.keygen.NoKeyGenerator;
/*     */ import org.apache.ibatis.executor.statement.StatementHandler;
/*     */ import org.apache.ibatis.mapping.BoundSql;
/*     */ import org.apache.ibatis.mapping.MappedStatement;
/*     */ import org.apache.ibatis.session.Configuration;
/*     */ import org.apache.ibatis.session.ResultHandler;
/*     */ import org.apache.ibatis.session.RowBounds;
/*     */ import org.apache.ibatis.transaction.Transaction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BatchExecutor
/*     */   extends BaseExecutor
/*     */ {
/*     */   public static final int BATCH_UPDATE_RETURN_VALUE = -2147482646;
/*  44 */   private final List<Statement> statementList = new ArrayList();
/*  45 */   private final List<BatchResult> batchResultList = new ArrayList();
/*     */   private String currentSql;
/*     */   private MappedStatement currentStatement;
/*     */   
/*     */   public BatchExecutor(Configuration configuration, Transaction transaction) {
/*  50 */     super(configuration, transaction);
/*     */   }
/*     */   
/*     */   public int doUpdate(MappedStatement ms, Object parameterObject) throws SQLException {
/*  54 */     Configuration configuration = ms.getConfiguration();
/*  55 */     StatementHandler handler = configuration.newStatementHandler(this, ms, parameterObject, RowBounds.DEFAULT, null, null);
/*  56 */     BoundSql boundSql = handler.getBoundSql();
/*  57 */     String sql = boundSql.getSql();
/*     */     Statement stmt;
/*  59 */     if ((sql.equals(this.currentSql)) && (ms.equals(this.currentStatement))) {
/*  60 */       int last = this.statementList.size() - 1;
/*  61 */       Statement stmt = (Statement)this.statementList.get(last);
/*  62 */       BatchResult batchResult = (BatchResult)this.batchResultList.get(last);
/*  63 */       batchResult.addParameterObject(parameterObject);
/*     */     } else {
/*  65 */       Connection connection = getConnection(ms.getStatementLog());
/*  66 */       stmt = handler.prepare(connection);
/*  67 */       this.currentSql = sql;
/*  68 */       this.currentStatement = ms;
/*  69 */       this.statementList.add(stmt);
/*  70 */       this.batchResultList.add(new BatchResult(ms, sql, parameterObject));
/*     */     }
/*  72 */     handler.parameterize(stmt);
/*  73 */     handler.batch(stmt);
/*  74 */     return -2147482646;
/*     */   }
/*     */   
/*     */   public <E> List<E> doQuery(MappedStatement ms, Object parameterObject, RowBounds rowBounds, ResultHandler resultHandler, BoundSql boundSql) throws SQLException
/*     */   {
/*  79 */     Statement stmt = null;
/*     */     try {
/*  81 */       flushStatements();
/*  82 */       Configuration configuration = ms.getConfiguration();
/*  83 */       StatementHandler handler = configuration.newStatementHandler(this.wrapper, ms, parameterObject, rowBounds, resultHandler, boundSql);
/*  84 */       Connection connection = getConnection(ms.getStatementLog());
/*  85 */       stmt = handler.prepare(connection);
/*  86 */       handler.parameterize(stmt);
/*  87 */       return handler.query(stmt, resultHandler);
/*     */     } finally {
/*  89 */       closeStatement(stmt);
/*     */     }
/*     */   }
/*     */   
/*     */   public List<BatchResult> doFlushStatements(boolean isRollback) throws SQLException {
/*     */     try {
/*  95 */       List<BatchResult> results = new ArrayList();
/*  96 */       if (isRollback) { Iterator i$;
/*  97 */         Statement stmt; return Collections.emptyList();
/*     */       }
/*  99 */       int i = 0; for (int n = this.statementList.size(); i < n; i++) {
/* 100 */         Statement stmt = (Statement)this.statementList.get(i);
/* 101 */         BatchResult batchResult = (BatchResult)this.batchResultList.get(i);
/*     */         try {
/* 103 */           batchResult.setUpdateCounts(stmt.executeBatch());
/* 104 */           ms = batchResult.getMappedStatement();
/* 105 */           List<Object> parameterObjects = batchResult.getParameterObjects();
/* 106 */           keyGenerator = ms.getKeyGenerator();
/* 107 */           if (Jdbc3KeyGenerator.class.equals(keyGenerator.getClass())) {
/* 108 */             Jdbc3KeyGenerator jdbc3KeyGenerator = (Jdbc3KeyGenerator)keyGenerator;
/* 109 */             jdbc3KeyGenerator.processBatch(ms, stmt, parameterObjects);
/* 110 */           } else if (!NoKeyGenerator.class.equals(keyGenerator.getClass())) {
/* 111 */             for (Object parameter : parameterObjects)
/* 112 */               keyGenerator.processAfter(this, ms, stmt, parameter);
/*     */           }
/*     */         } catch (BatchUpdateException e) { MappedStatement ms;
/*     */           KeyGenerator keyGenerator;
/* 116 */           StringBuffer message = new StringBuffer();
/* 117 */           message.append(batchResult.getMappedStatement().getId()).append(" (batch index #").append(i + 1).append(")").append(" failed.");
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 122 */           if (i > 0) {
/* 123 */             message.append(" ").append(i).append(" prior sub executor(s) completed successfully, but will be rolled back.");
/*     */           }
/*     */           
/*     */ 
/* 127 */           throw new BatchExecutorException(message.toString(), e, results, batchResult);
/*     */         }
/* 129 */         results.add(batchResult); }
/*     */       Iterator i$;
/* 131 */       Statement stmt; return results;
/*     */     }
/*     */     finally {
/* 134 */       for (Statement stmt : this.statementList) {
/* 135 */         closeStatement(stmt);
/*     */       }
/* 137 */       this.currentSql = null;
/* 138 */       this.statementList.clear();
/* 139 */       this.batchResultList.clear();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\executor\BatchExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */