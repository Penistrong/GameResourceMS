package org.apache.ibatis.ognl;

import java.util.Map;

public abstract interface ClassResolver
{
  public abstract Class classForName(String paramString, Map paramMap)
    throws ClassNotFoundException;
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ClassResolver.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */