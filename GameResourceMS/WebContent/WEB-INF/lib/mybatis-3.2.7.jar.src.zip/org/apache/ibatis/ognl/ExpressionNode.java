/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ExpressionNode
/*    */   extends SimpleNode
/*    */ {
/*    */   public ExpressionNode(int i)
/*    */   {
/* 40 */     super(i);
/*    */   }
/*    */   
/*    */   public ExpressionNode(OgnlParser p, int i) {
/* 44 */     super(p, i);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isNodeConstant(OgnlContext context)
/*    */     throws OgnlException
/*    */   {
/* 51 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isConstant(OgnlContext context) throws OgnlException
/*    */   {
/* 56 */     boolean result = isNodeConstant(context);
/*    */     
/* 58 */     if ((this.children != null) && (this.children.length > 0)) {
/* 59 */       result = true;
/* 60 */       for (int i = 0; (result) && (i < this.children.length); i++) {
/* 61 */         if ((this.children[i] instanceof SimpleNode)) {
/* 62 */           result = ((SimpleNode)this.children[i]).isConstant(context);
/*    */         } else {
/* 64 */           result = false;
/*    */         }
/*    */       }
/*    */     }
/* 68 */     return result;
/*    */   }
/*    */   
/*    */   public String getExpressionOperator(int index)
/*    */   {
/* 73 */     throw new RuntimeException("unknown operator for " + OgnlParserTreeConstants.jjtNodeName[this.id]);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 80 */     String result = this.parent == null ? "" : "(";
/* 81 */     if ((this.children != null) && (this.children.length > 0)) {
/* 82 */       for (int i = 0; i < this.children.length; i++) {
/* 83 */         if (i > 0) {
/* 84 */           result = result + " " + getExpressionOperator(i) + " ";
/*    */         }
/* 86 */         result = result + this.children[i].toString();
/*    */       }
/*    */     }
/* 89 */     if (this.parent != null) {
/* 90 */       result = result + ")";
/*    */     }
/* 92 */     return result;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ExpressionNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */