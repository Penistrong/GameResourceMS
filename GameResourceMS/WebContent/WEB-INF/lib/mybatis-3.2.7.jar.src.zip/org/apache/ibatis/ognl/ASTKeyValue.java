/*    */ package org.apache.ibatis.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTKeyValue
/*    */   extends SimpleNode
/*    */ {
/*    */   public ASTKeyValue(int id)
/*    */   {
/* 40 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTKeyValue(OgnlParser p, int id) {
/* 44 */     super(p, id);
/*    */   }
/*    */   
/*    */   protected Node getKey()
/*    */   {
/* 49 */     return this.children[0];
/*    */   }
/*    */   
/*    */   protected Node getValue()
/*    */   {
/* 54 */     return jjtGetNumChildren() > 1 ? this.children[1] : null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected Object getValueBody(OgnlContext context, Object source)
/*    */     throws OgnlException
/*    */   {
/* 62 */     return null;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 67 */     return getKey() + " -> " + getValue();
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ASTKeyValue.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */