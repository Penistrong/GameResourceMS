/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnumTypeHandler<E extends Enum<E>>
/*    */   extends BaseTypeHandler<E>
/*    */ {
/*    */   private Class<E> type;
/*    */   
/*    */   public EnumTypeHandler(Class<E> type)
/*    */   {
/* 31 */     if (type == null) throw new IllegalArgumentException("Type argument cannot be null");
/* 32 */     this.type = type;
/*    */   }
/*    */   
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, E parameter, JdbcType jdbcType) throws SQLException
/*    */   {
/* 37 */     if (jdbcType == null) {
/* 38 */       ps.setString(i, parameter.name());
/*    */     } else {
/* 40 */       ps.setObject(i, parameter.name(), jdbcType.TYPE_CODE);
/*    */     }
/*    */   }
/*    */   
/*    */   public E getNullableResult(ResultSet rs, String columnName) throws SQLException
/*    */   {
/* 46 */     String s = rs.getString(columnName);
/* 47 */     return s == null ? null : Enum.valueOf(this.type, s);
/*    */   }
/*    */   
/*    */   public E getNullableResult(ResultSet rs, int columnIndex) throws SQLException
/*    */   {
/* 52 */     String s = rs.getString(columnIndex);
/* 53 */     return s == null ? null : Enum.valueOf(this.type, s);
/*    */   }
/*    */   
/*    */   public E getNullableResult(CallableStatement cs, int columnIndex) throws SQLException
/*    */   {
/* 58 */     String s = cs.getString(columnIndex);
/* 59 */     return s == null ? null : Enum.valueOf(this.type, s);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\EnumTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */