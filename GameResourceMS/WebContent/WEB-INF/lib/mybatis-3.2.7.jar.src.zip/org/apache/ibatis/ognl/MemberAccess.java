package org.apache.ibatis.ognl;

import java.lang.reflect.Member;
import java.util.Map;

public abstract interface MemberAccess
{
  public abstract Object setup(Map paramMap, Object paramObject, Member paramMember, String paramString);
  
  public abstract void restore(Map paramMap, Object paramObject1, Member paramMember, String paramString, Object paramObject2);
  
  public abstract boolean isAccessible(Map paramMap, Object paramObject, Member paramMember, String paramString);
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\MemberAccess.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */