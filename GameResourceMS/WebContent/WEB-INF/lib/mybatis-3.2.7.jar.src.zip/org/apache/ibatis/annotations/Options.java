package org.apache.ibatis.annotations;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.apache.ibatis.mapping.ResultSetType;
import org.apache.ibatis.mapping.StatementType;

@Retention(RetentionPolicy.RUNTIME)
@Target({java.lang.annotation.ElementType.METHOD})
public @interface Options
{
  boolean useCache() default true;
  
  boolean flushCache() default false;
  
  ResultSetType resultSetType() default ResultSetType.FORWARD_ONLY;
  
  StatementType statementType() default StatementType.PREPARED;
  
  int fetchSize() default -1;
  
  int timeout() default -1;
  
  boolean useGeneratedKeys() default false;
  
  String keyProperty() default "id";
  
  String keyColumn() default "";
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\annotations\Options.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */