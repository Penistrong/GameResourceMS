/*    */ package org.apache.ibatis.scripting.xmltags;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StaticTextSqlNode
/*    */   implements SqlNode
/*    */ {
/*    */   private String text;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public StaticTextSqlNode(String text)
/*    */   {
/* 25 */     this.text = text;
/*    */   }
/*    */   
/*    */   public boolean apply(DynamicContext context) {
/* 29 */     context.appendSql(this.text);
/* 30 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\xmltags\StaticTextSqlNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */