package org.apache.ibatis.annotations;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.apache.ibatis.cache.Cache;
import org.apache.ibatis.cache.decorators.LruCache;
import org.apache.ibatis.cache.impl.PerpetualCache;

@Retention(RetentionPolicy.RUNTIME)
@Target({java.lang.annotation.ElementType.TYPE})
public @interface CacheNamespace
{
  Class<? extends Cache> implementation() default PerpetualCache.class;
  
  Class<? extends Cache> eviction() default LruCache.class;
  
  long flushInterval() default 3600000L;
  
  int size() default 1000;
  
  boolean readWrite() default true;
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\annotations\CacheNamespace.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */