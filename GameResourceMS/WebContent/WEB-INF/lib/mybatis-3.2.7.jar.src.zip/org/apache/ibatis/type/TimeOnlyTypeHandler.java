/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Time;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimeOnlyTypeHandler
/*    */   extends BaseTypeHandler<Date>
/*    */ {
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, Date parameter, JdbcType jdbcType)
/*    */     throws SQLException
/*    */   {
/* 33 */     ps.setTime(i, new Time(parameter.getTime()));
/*    */   }
/*    */   
/*    */   public Date getNullableResult(ResultSet rs, String columnName)
/*    */     throws SQLException
/*    */   {
/* 39 */     Time sqlTime = rs.getTime(columnName);
/* 40 */     if (sqlTime != null) {
/* 41 */       return new Date(sqlTime.getTime());
/*    */     }
/* 43 */     return null;
/*    */   }
/*    */   
/*    */   public Date getNullableResult(ResultSet rs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 49 */     Time sqlTime = rs.getTime(columnIndex);
/* 50 */     if (sqlTime != null) {
/* 51 */       return new Date(sqlTime.getTime());
/*    */     }
/* 53 */     return null;
/*    */   }
/*    */   
/*    */   public Date getNullableResult(CallableStatement cs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 59 */     Time sqlTime = cs.getTime(columnIndex);
/* 60 */     if (sqlTime != null) {
/* 61 */       return new Date(sqlTime.getTime());
/*    */     }
/* 63 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\TimeOnlyTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */