/*    */ package org.apache.ibatis.scripting.xmltags;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IfSqlNode
/*    */   implements SqlNode
/*    */ {
/*    */   private ExpressionEvaluator evaluator;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private String test;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private SqlNode contents;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public IfSqlNode(SqlNode contents, String test)
/*    */   {
/* 27 */     this.test = test;
/* 28 */     this.contents = contents;
/* 29 */     this.evaluator = new ExpressionEvaluator();
/*    */   }
/*    */   
/*    */   public boolean apply(DynamicContext context) {
/* 33 */     if (this.evaluator.evaluateBoolean(this.test, context.getBindings())) {
/* 34 */       this.contents.apply(context);
/* 35 */       return true;
/*    */     }
/* 37 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\scripting\xmltags\IfSqlNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */