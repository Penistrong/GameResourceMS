/*     */ package org.apache.ibatis.ognl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ObjectArrayPool
/*     */ {
/*  37 */   private IntHashMap pools = new IntHashMap(23);
/*     */   
/*     */   public static class SizePool
/*     */   {
/*  41 */     private List arrays = new ArrayList();
/*     */     private int arraySize;
/*     */     private int size;
/*  44 */     private int created = 0;
/*  45 */     private int recovered = 0;
/*  46 */     private int recycled = 0;
/*     */     
/*     */     public SizePool(int arraySize)
/*     */     {
/*  50 */       this(arraySize, 0);
/*     */     }
/*     */     
/*     */ 
/*     */     public SizePool(int arraySize, int initialSize)
/*     */     {
/*  56 */       this.arraySize = arraySize;
/*  57 */       for (int i = 0; i < initialSize; i++) {
/*  58 */         this.arrays.add(new Object[arraySize]);
/*     */       }
/*  60 */       this.created = (this.size = initialSize);
/*     */     }
/*     */     
/*     */     public int getArraySize()
/*     */     {
/*  65 */       return this.arraySize;
/*     */     }
/*     */     
/*     */ 
/*     */     public Object[] create()
/*     */     {
/*     */       Object[] result;
/*  72 */       if (this.size > 0) {
/*  73 */         Object[] result = (Object[])this.arrays.remove(this.size - 1);
/*  74 */         this.size -= 1;
/*  75 */         this.recovered += 1;
/*     */       } else {
/*  77 */         result = new Object[this.arraySize];
/*  78 */         this.created += 1;
/*     */       }
/*  80 */       return result;
/*     */     }
/*     */     
/*     */     public synchronized void recycle(Object[] value)
/*     */     {
/*  85 */       if (value != null) {
/*  86 */         if (value.length != this.arraySize) {
/*  87 */           throw new IllegalArgumentException("recycled array size " + value.length + " inappropriate for pool array size " + this.arraySize);
/*     */         }
/*  89 */         Arrays.fill(value, null);
/*  90 */         this.arrays.add(value);
/*  91 */         this.size += 1;
/*  92 */         this.recycled += 1;
/*     */       } else {
/*  94 */         throw new IllegalArgumentException("cannot recycle null object");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getSize()
/*     */     {
/* 103 */       return this.size;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getCreatedCount()
/*     */     {
/* 112 */       return this.created;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getRecoveredCount()
/*     */     {
/* 121 */       return this.recovered;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getRecycledCount()
/*     */     {
/* 130 */       return this.recycled;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IntHashMap getSizePools()
/*     */   {
/* 141 */     return this.pools;
/*     */   }
/*     */   
/*     */   public synchronized SizePool getSizePool(int arraySize)
/*     */   {
/* 146 */     SizePool result = (SizePool)this.pools.get(arraySize);
/*     */     
/* 148 */     if (result == null) {
/* 149 */       this.pools.put(arraySize, result = new SizePool(arraySize));
/*     */     }
/* 151 */     return result;
/*     */   }
/*     */   
/*     */   public synchronized Object[] create(int arraySize)
/*     */   {
/* 156 */     return getSizePool(arraySize).create();
/*     */   }
/*     */   
/*     */   public synchronized Object[] create(Object singleton)
/*     */   {
/* 161 */     Object[] result = create(1);
/*     */     
/* 163 */     result[0] = singleton;
/* 164 */     return result;
/*     */   }
/*     */   
/*     */   public synchronized Object[] create(Object object1, Object object2)
/*     */   {
/* 169 */     Object[] result = create(2);
/*     */     
/* 171 */     result[0] = object1;
/* 172 */     result[1] = object2;
/* 173 */     return result;
/*     */   }
/*     */   
/*     */   public synchronized Object[] create(Object object1, Object object2, Object object3)
/*     */   {
/* 178 */     Object[] result = create(3);
/*     */     
/* 180 */     result[0] = object1;
/* 181 */     result[1] = object2;
/* 182 */     result[2] = object3;
/* 183 */     return result;
/*     */   }
/*     */   
/*     */   public synchronized Object[] create(Object object1, Object object2, Object object3, Object object4)
/*     */   {
/* 188 */     Object[] result = create(4);
/*     */     
/* 190 */     result[0] = object1;
/* 191 */     result[1] = object2;
/* 192 */     result[2] = object3;
/* 193 */     result[3] = object4;
/* 194 */     return result;
/*     */   }
/*     */   
/*     */   public synchronized Object[] create(Object object1, Object object2, Object object3, Object object4, Object object5)
/*     */   {
/* 199 */     Object[] result = create(5);
/*     */     
/* 201 */     result[0] = object1;
/* 202 */     result[1] = object2;
/* 203 */     result[2] = object3;
/* 204 */     result[3] = object4;
/* 205 */     result[4] = object5;
/* 206 */     return result;
/*     */   }
/*     */   
/*     */   public synchronized void recycle(Object[] value)
/*     */   {
/* 211 */     if (value != null) {
/* 212 */       getSizePool(value.length).recycle(value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\ognl\ObjectArrayPool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */