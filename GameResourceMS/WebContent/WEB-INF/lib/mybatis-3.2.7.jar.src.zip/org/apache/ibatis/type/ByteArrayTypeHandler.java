/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteArrayTypeHandler
/*    */   extends BaseTypeHandler<byte[]>
/*    */ {
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, byte[] parameter, JdbcType jdbcType)
/*    */     throws SQLException
/*    */   {
/* 31 */     ps.setBytes(i, parameter);
/*    */   }
/*    */   
/*    */   public byte[] getNullableResult(ResultSet rs, String columnName)
/*    */     throws SQLException
/*    */   {
/* 37 */     return rs.getBytes(columnName);
/*    */   }
/*    */   
/*    */   public byte[] getNullableResult(ResultSet rs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 43 */     return rs.getBytes(columnIndex);
/*    */   }
/*    */   
/*    */   public byte[] getNullableResult(CallableStatement cs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 49 */     return cs.getBytes(columnIndex);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\ByteArrayTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */