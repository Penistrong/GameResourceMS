/*    */ package org.apache.ibatis.transaction.managed;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.ibatis.logging.Log;
/*    */ import org.apache.ibatis.logging.LogFactory;
/*    */ import org.apache.ibatis.session.TransactionIsolationLevel;
/*    */ import org.apache.ibatis.transaction.Transaction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ManagedTransaction
/*    */   implements Transaction
/*    */ {
/* 41 */   private static final Log log = LogFactory.getLog(ManagedTransaction.class);
/*    */   private DataSource dataSource;
/*    */   private TransactionIsolationLevel level;
/*    */   private Connection connection;
/*    */   private boolean closeConnection;
/*    */   
/*    */   public ManagedTransaction(Connection connection, boolean closeConnection)
/*    */   {
/* 49 */     this.connection = connection;
/* 50 */     this.closeConnection = closeConnection;
/*    */   }
/*    */   
/*    */   public ManagedTransaction(DataSource ds, TransactionIsolationLevel level, boolean closeConnection) {
/* 54 */     this.dataSource = ds;
/* 55 */     this.level = level;
/* 56 */     this.closeConnection = closeConnection;
/*    */   }
/*    */   
/*    */   public Connection getConnection() throws SQLException {
/* 60 */     if (this.connection == null) {
/* 61 */       openConnection();
/*    */     }
/* 63 */     return this.connection;
/*    */   }
/*    */   
/*    */   public void commit()
/*    */     throws SQLException
/*    */   {}
/*    */   
/*    */   public void rollback() throws SQLException
/*    */   {}
/*    */   
/*    */   public void close() throws SQLException
/*    */   {
/* 75 */     if ((this.closeConnection) && (this.connection != null)) {
/* 76 */       if (log.isDebugEnabled()) {
/* 77 */         log.debug("Closing JDBC Connection [" + this.connection + "]");
/*    */       }
/* 79 */       this.connection.close();
/*    */     }
/*    */   }
/*    */   
/*    */   protected void openConnection() throws SQLException {
/* 84 */     if (log.isDebugEnabled()) {
/* 85 */       log.debug("Opening JDBC Connection");
/*    */     }
/* 87 */     this.connection = this.dataSource.getConnection();
/* 88 */     if (this.level != null) {
/* 89 */       this.connection.setTransactionIsolation(this.level.getLevel());
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\transaction\managed\ManagedTransaction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */