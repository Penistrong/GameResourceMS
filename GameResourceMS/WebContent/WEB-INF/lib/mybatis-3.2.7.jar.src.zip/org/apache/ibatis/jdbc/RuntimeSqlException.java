/*    */ package org.apache.ibatis.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RuntimeSqlException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 5224696788505678598L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RuntimeSqlException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RuntimeSqlException(String message)
/*    */   {
/* 30 */     super(message);
/*    */   }
/*    */   
/*    */   public RuntimeSqlException(String message, Throwable cause) {
/* 34 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public RuntimeSqlException(Throwable cause) {
/* 38 */     super(cause);
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\jdbc\RuntimeSqlException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */