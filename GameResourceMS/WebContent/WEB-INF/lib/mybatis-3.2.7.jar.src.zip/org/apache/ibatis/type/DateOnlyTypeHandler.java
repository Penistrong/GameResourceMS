/*    */ package org.apache.ibatis.type;
/*    */ 
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateOnlyTypeHandler
/*    */   extends BaseTypeHandler<java.util.Date>
/*    */ {
/*    */   public void setNonNullParameter(PreparedStatement ps, int i, java.util.Date parameter, JdbcType jdbcType)
/*    */     throws SQLException
/*    */   {
/* 32 */     ps.setDate(i, new java.sql.Date(parameter.getTime()));
/*    */   }
/*    */   
/*    */   public java.util.Date getNullableResult(ResultSet rs, String columnName)
/*    */     throws SQLException
/*    */   {
/* 38 */     java.sql.Date sqlDate = rs.getDate(columnName);
/* 39 */     if (sqlDate != null) {
/* 40 */       return new java.util.Date(sqlDate.getTime());
/*    */     }
/* 42 */     return null;
/*    */   }
/*    */   
/*    */   public java.util.Date getNullableResult(ResultSet rs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 48 */     java.sql.Date sqlDate = rs.getDate(columnIndex);
/* 49 */     if (sqlDate != null) {
/* 50 */       return new java.util.Date(sqlDate.getTime());
/*    */     }
/* 52 */     return null;
/*    */   }
/*    */   
/*    */   public java.util.Date getNullableResult(CallableStatement cs, int columnIndex)
/*    */     throws SQLException
/*    */   {
/* 58 */     java.sql.Date sqlDate = cs.getDate(columnIndex);
/* 59 */     if (sqlDate != null) {
/* 60 */       return new java.util.Date(sqlDate.getTime());
/*    */     }
/* 62 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\type\DateOnlyTypeHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */