package org.apache.ibatis.reflection.wrapper;

import org.apache.ibatis.reflection.MetaObject;

public abstract interface ObjectWrapperFactory
{
  public abstract boolean hasWrapperFor(Object paramObject);
  
  public abstract ObjectWrapper getWrapperFor(MetaObject paramMetaObject, Object paramObject);
}


/* Location:              E:\eclipseJavaEEworkspace\GameResourceMS\WebContent\WEB-INF\lib\mybatis-3.2.7.jar!\org\apache\ibatis\reflection\wrapper\ObjectWrapperFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */